package net.abaqus.mygeotracking.deviceagent.heartbeat;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import android.util.Xml;

import net.abaqus.mygeotracking.deviceagent.MGTScheduleStatus;
import net.abaqus.mygeotracking.deviceagent.data.HeartBeatContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HeartBeatTable;
import net.abaqus.mygeotracking.deviceagent.utils.AppUtils;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.DeviceUtils;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkUtils;
import net.abaqus.mygeotracking.deviceagent.utils.PhoneUtils;
import net.abaqus.mygeotracking.deviceagent.utils.ServiceUtils;

import org.xmlpull.v1.XmlSerializer;

import java.io.IOException;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Locale;

/**
 * Created by bm on 6/1/16.
 */
public class ConstructHeartBeat {

    private static final String TAG = ConstructHeartBeat.class.getSimpleName();

    private Context mContext = null;
    private SharedPreferences prefs = null;
    private HeartBeatMetaData hbMetaData = null;


    public ConstructHeartBeat(Context con) {
        this.mContext = con;
        this.prefs = con.getSharedPreferences(MDACons.PREFS, 0);
        hbMetaData = new HeartBeatMetaData(con.getApplicationContext());


    }

    public void processHBEntries(String triggeredSource) {

        String deviceId = prefs.getString(MDACons.DEVICE_NUMBER, "");
        if (deviceId.length() < 1)
            return;


        XmlSerializer serializer = Xml.newSerializer();
        StringWriter writer = new StringWriter();
        try {
            serializer.setOutput(writer);
            serializer.startDocument("UTF-8", true);
            serializer.startTag(null, "MGTRequest");
            generateXMLReqBlock(serializer, triggeredSource);
            serializer.endTag(null, "MGTRequest");
            serializer.endDocument();
            saveHBEntriesToDB(writer.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void generateXMLReqBlock(XmlSerializer serializer, String triggeredSource)
            throws IOException {
        serializer.startTag(null, "Device");
        String deviceId = prefs.getString(MDACons.DEVICE_NUMBER, "");
        String agent_device_id = prefs.getString(MDACons.AGENT_DEVICE_ID,"");
        serializer.startTag(null, "DeviceID");
        serializer.text(deviceId);
        serializer.endTag(null, "DeviceID");
        String time = "";
        SimpleDateFormat sdf = null;

        try {
            sdf = new SimpleDateFormat("yyyy/MMM/dd,HH:mm:ss",
                    Locale.getDefault());
            time = CurrentDateAndTime.getDateTime(new SimpleDateFormat(
                    "yyyy/MM/dd'T'HH:mm:ssZ", Locale.getDefault()));
        } catch (Exception e) {
        }
        try {
            serializer.startTag(null, "Time");
            serializer.text(time);
            serializer.endTag(null, "Time");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "UUID");
            serializer.text(prefs.getString(MDACons.DEVICE_GUID, ""));
            serializer.endTag(null, "UUID");
        } catch (Exception e) {
        }

        String versionName = "";
        try {
            versionName = mContext.getPackageManager().getPackageInfo(mContext.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }


        try {
            serializer.startTag(null, "DeviceDetails");
            serializer.startTag(null, "Manufacturer");
            serializer.text(DeviceUtils.getManufacturer());
            serializer.endTag(null, "Manufacturer");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "Model");
            serializer.text(DeviceUtils.getModel());
            serializer.endTag(null, "Model");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "Platform");
            serializer.text("Android");
            serializer.endTag(null, "Platform");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "isDeviceRooted");
            serializer.text(String.valueOf(DeviceUtils.isDeviceRooted()));
            serializer.endTag(null, "isDeviceRooted");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "AndroidID");
            serializer.text(DeviceUtils.getAndroidID(mContext));
            serializer.endTag(null, "AndroidID");
        } catch (Exception e) {
        }

        serializer.startTag(null, "agentDeviceID");
        serializer.text(agent_device_id);
        serializer.endTag(null,"agentDeviceID");


        serializer.startTag(null, "Provider");
        serializer.text("Sixgill");
        serializer.endTag(null,"Provider");

/*
        serializer.startTag(null, "MacAddress");
        serializer.text(DeviceUtils.getMacAddress(mContext));
        serializer.endTag(null, "MacAddress");
*/
        try {
            serializer.startTag(null, "BatteryLevel");
            serializer.text(Math.round(hbMetaData.getBatteryLevel()) + "%");
            serializer.endTag(null, "BatteryLevel");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "Charging");
            serializer.text(hbMetaData.getBatteryChargingState() + "");
            serializer.endTag(null, "Charging");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "DozeMode");
            serializer.text((DeviceUtils.getPowerSavingMode(mContext) ? "ON" : "OFF"));
            serializer.endTag(null, "DozeMode");
        } catch (Exception e) {
            e.printStackTrace();
        }


        try {
            serializer.startTag(null, "BatteryOptimizeWhitelist");
            serializer.text(DeviceUtils.getBatteryOptimizationStatus(mContext) + ""); /// check the Battery optimization Mode
            serializer.endTag(null, "BatteryOptimizeWhitelist");
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            serializer.startTag(null, "isPhone");
            serializer.text(String.valueOf(PhoneUtils.isPhone(mContext)));
            serializer.endTag(null, "isPhone");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "isSimCardReady");
            serializer.text(String.valueOf(PhoneUtils.isSimCardReady(mContext)));
            serializer.endTag(null, "isSimCardReady");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "SimOperatorName");
            serializer.text(PhoneUtils.getSimOperatorName(mContext));
            serializer.endTag(null, "SimOperatorName");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "LocationSpoofingEnabled");
            serializer.text(HeartBeatMetaData.isMockSettingsON(mContext) + "");
            serializer.endTag(null, "LocationSpoofingEnabled");

            serializer.startTag(null, "LocationSpoofingAppsCount");
            serializer.text(HeartBeatMetaData.noOfMockPermissionApps(mContext) + "");
            serializer.endTag(null, "LocationSpoofingAppsCount");
        } catch (NullPointerException e) {
        }
        serializer.endTag(null, "DeviceDetails");


        serializer.startTag(null, "AppDetails");
        try {
            serializer.startTag(null, "AgentVersion");
            serializer.text(versionName);
            serializer.endTag(null, "AgentVersion");
        } catch (Exception e) {
        }


        try {
            serializer.startTag(null, "AppForeground");
            serializer.text(String.valueOf(AppUtils.isAppForeground(mContext)));
            serializer.endTag(null, "AppForeground");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "ScheduleStatus");
            serializer.text(String.valueOf(MGTScheduleStatus.getInstance(mContext).isScheduleRunning()));
            serializer.endTag(null, "ScheduleStatus");
        } catch (Exception e) {
        }




        try {
            serializer.startTag(null, "SoftwareVersion");
            serializer.text(Build.VERSION.RELEASE);
            serializer.endTag(null, "SoftwareVersion");
        } catch (Exception e) {
        }



        try {
            serializer.startTag(null, "customersCount");
            serializer.text(hbMetaData.getCustomersCount());
            serializer.endTag(null, "customersCount");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "tasksCount");
            serializer.text(hbMetaData.getTaskssCount());
            serializer.endTag(null, "tasksCount");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "relationsData");
            serializer.text(hbMetaData.getRelationsCount());
            serializer.endTag(null, "relationsData");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "HOSLabelsCount");
            serializer.text(hbMetaData.getHOSLabelsCount());
            serializer.endTag(null, "HOSLabelsCount");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "HOSEntryCount");
            serializer.text(hbMetaData.getHOSEntryCount());
            serializer.endTag(null, "HOSEntryCount");
        } catch (Exception e) {
        }

        try {
            serializer.startTag(null, "CurrentHOSStage");
            serializer.text(prefs.getString(MDACons.HOS_SELECTION_NAME, "") + "|" + prefs.getInt(MDACons.HOS_SELECTION, -1) + "|" + prefs.getString(MDACons.HOS_TIME, "NA"));
            serializer.endTag(null, "CurrentHOSStage");
        } catch (Exception e) {
            DebugLog.debug(TAG, e.getLocalizedMessage());
        }

        try {
            serializer.startTag(null, "NotesEntryCount");
            serializer.text(hbMetaData.getHOSEntryCount());
            serializer.endTag(null, "NotesEntryCount");
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "NotesEntryCount");
        }
        serializer.endTag(null, "AppDetails");

        serializer.startTag(null, "NetworkDetails");
        try {
            serializer.startTag(null, "isConnected");
            serializer.text(String.valueOf(NetworkUtils.isConnected(mContext)));
            serializer.endTag(null, "isConnected");
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "isConnected");
        }

        try {
            serializer.startTag(null, "isAvailableByPing");
            serializer.text(String.valueOf(NetworkUtils.isAvailableByPing()));
            serializer.endTag(null, "isAvailableByPing");
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "isAvailableByPing");
        }

        try {
            serializer.startTag(null, "is4G");
            serializer.text(String.valueOf(NetworkUtils.is4G(mContext)));
            serializer.endTag(null, "is4G");
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "is4G");
        }

        try {
            serializer.startTag(null, "isWifiConnected");
            serializer.text(String.valueOf(NetworkUtils.isWifiConnected(mContext)));
            serializer.endTag(null, "isWifiConnected");
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "isWifiConnected");
        }

        try {
            serializer.startTag(null, "isWifiAvailable");
            serializer.text(String.valueOf(NetworkUtils.isWifiAvailable(mContext)));
            serializer.endTag(null, "isWifiAvailable");
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "isWifiAvailable");
        }

        try {
            serializer.startTag(null, "NetworkOperatorName");
            serializer.text(NetworkUtils.getNetworkOperatorName(mContext));
            serializer.endTag(null, "NetworkOperatorName");
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "NetworkOperatorName");
        }

        try {
            serializer.startTag(null, "NetworkType");
            serializer.text(NetworkUtils.getNetworkType(mContext).name());
            serializer.endTag(null, "NetworkType");
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "NetworkType");
        }

        try {
            serializer.startTag(null, "IPAddress");
            serializer.text(NetworkUtils.getIPAddress(true));
            serializer.endTag(null, "IPAddress");
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "IPAddress");
        }


        try {
            if (hbMetaData.getGPSAvailability()) {
                serializer.startTag(null, "GPSStatus");
                serializer.text(hbMetaData.getGpsStatus() + "");
                serializer.endTag(null, "GPSStatus");
            }
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "GPSStatus");
        }

        try {
            serializer.startTag(null, "CellNetworkAvailablity");
            serializer.text(hbMetaData.checkMobileNetworkAvailable() + "");
            serializer.endTag(null, "CellNetworkAvailablity");
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "CellNetworkAvailablity");
        }

        serializer.endTag(null, "NetworkDetails");


        serializer.startTag(null, "PermissionDetails");
        try {
            serializer.startTag(null, "locationPermission");
            serializer.text(hbMetaData.getLocationPermission() + "");
            serializer.endTag(null, "locationPermission");
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "locationPermission");
        }

        try {
            serializer.startTag(null, "cameraPermission");
            serializer.text(hbMetaData.getCameraPermission() + "");
            serializer.endTag(null, "cameraPermission");
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "cameraPermission");
        }

        try {
            serializer.startTag(null, "storagePermission");
            serializer.text(hbMetaData.getStoragePermission() + "");
            serializer.endTag(null, "storagePermission");
        } catch (Exception e) {
            serializer.text("");
            serializer.endTag(null, "storagePermission");
        }

        try {
            serializer.startTag(null, "lastRegistrationTime");
            serializer.text(prefs.getString(MDACons.LAST_REGISTER_TIME, ""));
            serializer.endTag(null, "lastRegistrationTime");
        }
        catch (Exception e)
        {
            serializer.text("");
            serializer.endTag(null, "lastRegistrationTime");
        }

        try
        {
            serializer.startTag(null, "lastSDKLocationEventTime");
            serializer.text(prefs.getString(MDACons.SIXGILL_LAST_LOCATION_EVENT_TIME, ""));
            serializer.endTag(null, "lastSDKLocationEventTime");
        }
        catch (Exception e)
        {
            serializer.text("");
            serializer.endTag(null, "lastSDKLocationEventTime");
        }

        try {
            serializer.startTag(null, "nativeLocationEventTime");
            serializer.text(prefs.getString(MDACons.NATIVE_LAST_LOCATION_EVENT_TIME, ""));
            serializer.endTag(null, "nativeLocationEventTime");
        }
        catch (Exception e)
        {
            serializer.text("");
            serializer.endTag(null, "nativeLocationEventTime");
        }

        serializer.endTag(null, "PermissionDetails");

        serializer.endTag(null, "Device");

        serializer.startTag(null, "TriggerSource");
        serializer.text(triggeredSource);
        serializer.endTag(null, "TriggerSource");

    }


    private void saveHBEntriesToDB(String HBEntry) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(HeartBeatTable.HEARTBEAT_ENTRY_XML, HBEntry);
        initialValues.put(HeartBeatTable.HEARTBEAT_ENTRY_NO_OF_TRIES, 0);
        mContext.getContentResolver().insert(HeartBeatContentProvider.CONTENT_URI,
                initialValues);
    }

}

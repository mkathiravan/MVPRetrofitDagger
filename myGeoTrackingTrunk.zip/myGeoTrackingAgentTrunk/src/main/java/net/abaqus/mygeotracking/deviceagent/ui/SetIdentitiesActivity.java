package net.abaqus.mygeotracking.deviceagent.ui;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.Notification;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.sixgill.sync.sdk.Reach;
import com.sixgill.sync.sdk.ReachCallback;
import com.sixgill.sync.sdk.ReachConfig;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiClient;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiInterface;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsCons;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsEvent;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsKey;
import net.abaqus.mygeotracking.deviceagent.bgthread.RegistrationTaskMGT;
import net.abaqus.mygeotracking.deviceagent.data.HOSEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HeartBeat;
import net.abaqus.mygeotracking.deviceagent.heartbeat.TriggerSource;
import net.abaqus.mygeotracking.deviceagent.home.LocationUpdatesService;
import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.hos.HOSHistoryActivity;
import net.abaqus.mygeotracking.deviceagent.listeners.TaskCompleteListener;
import net.abaqus.mygeotracking.deviceagent.notification.NotificationCommands;
import net.abaqus.mygeotracking.deviceagent.notification.NotificationPreferences;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.sixgill.RegistrationToken;
import net.abaqus.mygeotracking.deviceagent.sixgill.TokenModel;
import net.abaqus.mygeotracking.deviceagent.utils.FetchDeviceNumber;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.SnackbarUtils;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SetIdentitiesActivity extends ReceiverActivity implements TaskCompleteListener {

    private static final int MY_PERMISSIONS_REQUEST_PHONE_STATE = 201;
    public static ProgressDialog pDialog;
    @BindView(R.id.root_register_layout)
    RelativeLayout rootLayout;
    @BindView(R.id.device_number_edit_text)
    EditText device_num_et;
    @BindView(R.id.etCallingCodeWelcome)
    EditText callingCodeEt;
    @BindView(R.id.layoutEnterPhoneNumber)
    TextInputLayout layoutEnterPhoneNumber;
    @BindView(R.id.register_button)
    Button register_btn;
    @BindString(R.string.txtmsg_warning_invalid_number)
    String INVALID_NUMBER_WARNING;
    @BindString(R.string.text_processing)
    String CONS_PROCESSING;
    @BindString(R.string.txtmsg_registration_success)
    String CONS_INSTALLED_SUCCESSFULLY;
    @BindString(R.string.txtmsg_registration_failed)
    String CONS_REGISTER_FAILED;
    @BindString(R.string.txtmsg_registering_phone_number)
    String CONS_SETTING_PHONE_NUMBER;
    //public SharedPrefsForAgentApp prefs;
    @BindString(R.string.txtmsg_register_later)
    String CONS_LATER_MESSAGE;
    private SharedPreferences sh_prefs;
    boolean status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_device_layout);
        ButterKnife.bind(this);
        pDialog = null;
        checkForPhoneStatePermission();


        device_num_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                layoutEnterPhoneNumber.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        initialConfigurations();
        setupActionbar();
        /*if (!NetworkConnectionInfo.isNetworkMetered(SetIdentitiesActivity.this)) {
            SnackbarUtils.showShort(register_btn, "Slow Network", Color.WHITE, Color.BLUE);
        } else {
            SnackbarUtils.showShort(register_btn, "Good Network", Color.WHITE, Color.BLUE);
        }*/
    }




    private void setupActionbar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
    }

    @OnClick(R.id.register_button)
    void registerButtonOnClick() {

        if (NetworkConnectionInfo.isOnline(SetIdentitiesActivity.this)) {
            emptyGCMRelatedPrefs();
            String callingCode = callingCodeEt.getText().toString().replaceFirst("^0+(?!$)", "");
            if (callingCode.length() <= 0 || callingCode.equals("0")) {
                callingCode = "1";
            }

            if (device_num_et.getText().length() > 3) {
                String deviceNumber = "+" + callingCode + device_num_et.getText()
                        .toString();
                String deviceNo = device_num_et.getText().toString();
                hideKeyboard();
                fillDeviceNumberPrefs(callingCode, deviceNumber);
                clearHOSTable();

                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O)
                {
                    doInitialize(deviceNo);
                }
                else
                {
                    setDeviceValue();

                }





                // Remove the shared preferences value of schedule status flag
                SharedPreferences sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
                SharedPreferences.Editor editor = sh_prefs.edit();
                editor.putBoolean(MDACons.SCHUDELE_TRACK_STATUS,false);
                editor.commit();


//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
//                {
//                    Intent intent = new Intent(SetIdentitiesActivity.this, LocationUpdatesService.class);
//                    stopService(intent);
//                }





                FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(SetIdentitiesActivity.this);
                Bundle bundle = new Bundle();
                bundle.putString(AnalyticsKey.EVENT_STATE, AnalyticsCons.ITEM_SUBMITTED);
                mFirebaseAnalytics.logEvent(AnalyticsEvent.RE_REGISTRATION_EVENT, bundle);


            } else {
                layoutEnterPhoneNumber.setErrorEnabled(true);
                layoutEnterPhoneNumber.setError(INVALID_NUMBER_WARNING);
            }
        }
        else {

            hideKeyboard();
//            View view = SetIdentitiesActivity.this.getCurrentFocus();
//            if (view != null) {
//                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
//                imm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
//            }
            //  getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            //Snackbar.make(register_btn, getString(R.string.msg_internet_disabled_please_try_later), Snackbar.LENGTH_SHORT).show();
            SnackbarUtils.showShort(rootLayout, getString(R.string.msg_internet_disabled_please_try_later), Color.WHITE, ContextCompat.getColor(SetIdentitiesActivity.this, R.color.alert));

        }
    }

    private void hideKeyboard()
    {
        View view = SetIdentitiesActivity.this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    public void setDeviceValue() {
        setHBIntervalTodefault();
        pDialog = new ProgressDialog(SetIdentitiesActivity.this);
        pDialog.setTitle(CONS_PROCESSING);
        pDialog.setMessage(CONS_SETTING_PHONE_NUMBER);
        pDialog.setCancelable(false);
        pDialog.show();
        new RegistrationTaskMGT(SetIdentitiesActivity.this, SetIdentitiesActivity.this).execute();
        /*
        new ZDAEventListenerSetIdentities(this, pDialog, number, SetIdentitiesActivity.this)
                .setIdentitiesHandler(thisHandler);
        */
    }

    @Override
    public void onTaskCompleted(boolean success) {
        if (pDialog.isShowing())
            pDialog.dismiss();
        if (this != null && success) {
            showDialog();

            HeartBeat heartBeat = HeartBeat.getInstance();
            heartBeat.justOneBeat(SetIdentitiesActivity.this, TriggerSource.APP_LAUNCHED);
            heartBeat.startBeating(SetIdentitiesActivity.this);


            FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(SetIdentitiesActivity.this);
            Bundle bundle = new Bundle();
            bundle.putString(AnalyticsKey.EVENT_STATE, AnalyticsCons.ITEM_SUCCUESS);
            mFirebaseAnalytics.logEvent(AnalyticsEvent.RE_REGISTRATION_EVENT, bundle);

            SharedPreferences mda_prefs = getSharedPreferences(
                    MDACons.PREFS, 0);
            SharedPreferences.Editor prefs_edit = mda_prefs.edit();
           // prefs_edit.putBoolean(MDACons.ZOS_FAILURE_STATUS, false);
            prefs_edit.putBoolean(MDACons.MGT_CONFIGURATION_STATUS, false);
           // prefs_edit.putBoolean(MDACons.ZOS_REGISTRATION_STATUS, false);
            prefs_edit.apply();

        } else {
            showDialog(101);
        }

    }

    @Override
    protected Dialog onCreateDialog(int id) {
        AlertDialog dialog;
        switch (id) {
            case 100:

                Builder builder = new AlertDialog.Builder(this);
                builder.setMessage(CONS_INSTALLED_SUCCESSFULLY);
                builder.setCancelable(false);
                builder.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                final Intent mda_main_view = new Intent(
                                        SetIdentitiesActivity.this,
                                        MDAMainActivity.class);
                                runOnUiThread(new Runnable() {
                                    public void run() {
                                        SetIdentitiesActivity.this
                                                .startActivity(mda_main_view);
                                    }
                                });
                                ((Activity) (SetIdentitiesActivity.this)).finish();
                            }
                        });
                dialog = builder.create();
                dialog.show();
                break;

            case 101:

                Builder builder1 = new AlertDialog.Builder(this);
                builder1.setMessage(CONS_REGISTER_FAILED);
                builder1.setCancelable(false);
                builder1.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                device_num_et.setText("");
                                register_btn.setVisibility(View.VISIBLE);

                            }
                        });

                builder1.setNegativeButton("Later",
                        new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();

                                showDialog(102);
                                register_btn.setVisibility(View.VISIBLE);
                            }
                        });

                dialog = builder1.create();
                dialog.show();
                break;

            case 102:
                Builder builder2 = new AlertDialog.Builder(this);
                builder2.setMessage(CONS_LATER_MESSAGE);
                builder2.setCancelable(false);
                builder2.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent mda_main_view = new Intent(
                                        SetIdentitiesActivity.this,
                                        MDAMainActivity.class);
                                mda_main_view
                                        .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                                SetIdentitiesActivity.this
                                        .startActivity(mda_main_view);
                                //prefs.clearData();
                                ((Activity) (SetIdentitiesActivity.this)).finish();
                            }
                        });

                dialog = builder2.create();
                dialog.show();
                break;
            default:
                break;
        }

        return super.onCreateDialog(id);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    void showDialog() {
        AlertDailogFragment newFragment = AlertDailogFragment.newInstance(
                CONS_INSTALLED_SUCCESSFULLY);
        newFragment.show(getFragmentManager(), "dialog");
    }

    public void doPositiveClick() {
        // Do stuff here.
        Intent mda_main_view = new Intent(
                SetIdentitiesActivity.this,
                MDAMainActivity.class);
        mda_main_view
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        startActivity(mda_main_view);
        //prefs.clearData();
        finish();
        Log.i("FragmentAlertDialog", "Positive click!");
    }

    public void doNegativeClick() {
        // Do stuff here.
        Log.i("FragmentAlertDialog", "Negative click!");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_PHONE_STATE: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    FetchDeviceNumber fetchDeviceNumber = new FetchDeviceNumber(
                            getApplicationContext());
                    String auto_detect_number = fetchDeviceNumber.getPhoneNumber();
                    String countryCallingCode = fetchDeviceNumber.getCountryCallingCode();
                    device_num_et.setText(auto_detect_number);
                    callingCodeEt.setText(countryCallingCode);
                    Log.d(TAG,"DECVICEDECR "+auto_detect_number);




                } else {
                    //Snackbar.make(main_view,"Storage permission denied.",Snackbar.LENGTH_LONG).show();
                }
                return;
            }

        }
    }

    private void checkForPhoneStatePermission() {
        if (ContextCompat.checkSelfPermission(SetIdentitiesActivity.this,
                Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(SetIdentitiesActivity.this,
                    Manifest.permission.READ_PHONE_STATE)) {
                android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(SetIdentitiesActivity.this, R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Read Phone number permission required");
                builder.setMessage("Without Read phone number permission the application will not be able to detect the phone number. Are you sure you want to deny this permission?");
                builder.setPositiveButton("I'M SURE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.setNegativeButton("RE-TRY", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityCompat.requestPermissions(SetIdentitiesActivity.this,
                                new String[]{Manifest.permission.READ_PHONE_STATE},
                                MY_PERMISSIONS_REQUEST_PHONE_STATE);
                    }
                });
                builder.show();
            } else {
                ActivityCompat.requestPermissions(SetIdentitiesActivity.this,
                        new String[]{Manifest.permission.READ_PHONE_STATE},
                        MY_PERMISSIONS_REQUEST_PHONE_STATE);
            }
        } else {
            FetchDeviceNumber fetchDeviceNumber = new FetchDeviceNumber(
                    getApplicationContext());
            String auto_detect_number = fetchDeviceNumber.getPhoneNumber();
            String countryCallingCode = fetchDeviceNumber.getCountryCallingCode();
            device_num_et.setText(auto_detect_number);
            callingCodeEt.setText(countryCallingCode);
            Log.d(TAG,"FETCHJDRED "+auto_detect_number);




        }
    }

    public static class AlertDailogFragment extends DialogFragment {

        String dialogMessage;

        static AlertDailogFragment newInstance(String message) {
            AlertDailogFragment f = new AlertDailogFragment();

            // Supply num input as an argument.
            Bundle args = new Bundle();
            args.putString("dialogMessage", message);
            f.setArguments(args);
            return f;
        }


        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            dialogMessage = getArguments().getString("dialogMessage");

            return new AlertDialog.Builder(getActivity())
                    //.setIcon(R.drawable.alert_dialog_icon)
                    .setTitle("myGeoTracking Agent Alert")
                    .setMessage(dialogMessage)
                    .setPositiveButton("Ok",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                    ((SetIdentitiesActivity) getActivity()).doPositiveClick();
                                }
                            }
                    )
                    /*.setNegativeButton("Cancel",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog, int whichButton) {
									((SetIdentitiesActivity)getActivity()).doNegativeClick();
								}
							}
					)*/
                    .create();
        }
    }


    /*
     *Preferences related settings. Mostly setting the most values to default.
     */

    private void setHBIntervalTodefault() {
        SharedPreferences mda_prefs = getSharedPreferences(
                MDACons.PREFS, 0);
        SharedPreferences.Editor prefs_edit = mda_prefs.edit();
        prefs_edit.putString(MDACons.HB_INTERVAL_OLD, "");
        prefs_edit.putBoolean(MDACons.LOCATION_ENABLE_DISABLE, true);
        prefs_edit.apply();
    }

    private void initialConfigurations() {
        SharedPreferences mda_prefs = getSharedPreferences(
                MDACons.PREFS, 0);
        SharedPreferences.Editor prefs_edit = mda_prefs.edit();
        prefs_edit.putBoolean(MDACons.LOCATION_ENABLE_DISABLE, true);
        prefs_edit.putBoolean(MDACons.AUTO_RELAUNCH_ENABLED_STATUS, true);
        prefs_edit.apply();
    }

    private void fillDeviceNumberPrefs(String callingCode, String deviceNumber) {
        SharedPreferences mda_prefs = getSharedPreferences(
                MDACons.PREFS, 0);
        deviceNumber = deviceNumber.replace("+", "");

        if (callingCode.equals("1") && deviceNumber.length() > 10)
            deviceNumber = deviceNumber.substring(deviceNumber.length() - 10, deviceNumber.length());

        SharedPreferences.Editor prefs_edit = mda_prefs.edit();
        prefs_edit.putString(MDACons.DEVICE_NUMBER, deviceNumber);
        prefs_edit.putString(MDACons.DEVICE_NUMBER_COUNTRY_CALLING_CODE, callingCode);
        prefs_edit.apply();
    }

    private void clearHOSTable() {
        getContentResolver().delete(HOSEntryContentProvider.CONTENT_URI, null, null);
    }

    private void emptyGCMRelatedPrefs() {
        //Emptying the values for re registerign with gcm server
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(SetIdentitiesActivity.this);
        SharedPreferences.Editor shaEditor = sharedPreferences.edit();
        shaEditor.putBoolean(NotificationPreferences.SENT_TOKEN_TO_MGT_SERVER, false);
        shaEditor.apply();
        SharedPreferences sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
        shaEditor.putString(RegisterDeviceActivity.PROPERTY_REG_ID_MGT, "");
        shaEditor.apply();

        //Emptying END
    }


    // Do the Initialization of the Reach SDK
    public void doInitialize(String device_number) {

        pDialog = new ProgressDialog(SetIdentitiesActivity.this);
        pDialog.setTitle(CONS_PROCESSING);
        pDialog.setMessage(CONS_SETTING_PHONE_NUMBER);
        pDialog.setCancelable(false);
        pDialog.show();

        Log.d(TAG,"DEviceNumbe "+device_number);

        ReachConfig config = new ReachConfig();

        //custom notification builder for sticky notification

        config.setStickyNotificationTitle("MyGeoTracking");
        config.setStickyNotificationBody("myGeoTracking is using GPS information");
        config.setStickyNotificationIcon(R.drawable.notification);
        config.setNotificationIcon(R.drawable.notification);



        Map<String, String> aliases = new HashMap<>();
        aliases.put("phone", device_number);
        config.setAliases(aliases);



        config.setIngressURL("https://sense-ingress-api.sixgill.com");
        config.setSendEvents(false);


        //custom notification builder for sticky notification
//        config.setStickyNotificationTitle("MyGeoTracking");
//        config.setStickyNotificationBody("myGeoTracking is using GPS information");
//        config.setStickyNotificationIcon(R.drawable.notification_icon);
//
//        // custom notification builder for any notification
//        config.setNotificationIcon(R.drawable.notification_icon);
        // pass this config object to initWithAPIKey call




        Reach.initWithAPIKey(SetIdentitiesActivity.this, "66c0d9f139d55c134825d38881", config, new ReachCallback() {
            @Override
            public void onReachSuccess() {
                Log.wtf(TAG,"Success Reach Initialization");
                Reach.enable(SetIdentitiesActivity.this);
//                Toast.makeText(SetIdentitiesActivity.this,"ONSUCCESS",Toast.LENGTH_SHORT).show();
//                Toast.makeText(SetIdentitiesActivity.this,"REACHID"+Reach.deviceId(getApplicationContext()),Toast.LENGTH_SHORT).show();
                getSixgillToken();
                setDeviceValue();

            }

            @Override
            public void onReachFailure(String s) {
                Log.wtf(TAG,"FAILIED Reach Initialization ");

                Toast.makeText(SetIdentitiesActivity.this, "Failed to register the SDK", Toast.LENGTH_LONG).show();

            }
        });


    }

    public void getSixgillToken() {

        RegistrationToken registrationToken = new RegistrationToken();
        registrationToken.setEmail("badari@abaq.us");
        registrationToken.setPassword("Bman1547$#");


        final ApiInterface requestInterface = ApiClient.getCallSixgill();
        //TODO: Need to remove hardcoded date and device number
        Call<TokenModel> call = requestInterface.getLoginInfo(registrationToken);
        Log.d(TAG, "REQIESERCALL " + call.request());
        call.enqueue(new Callback<TokenModel>() {
            @Override
            public void onResponse(Call<TokenModel> call, Response<TokenModel> response) {
                Log.d(TAG, "GETTOKENRES " + response);
                // If the response code is 200 we are showing the data
                if (response.code() == 200) {

                    myGeoTrackingDevieAgentApplication.SIXGILL_AUTH_TOKEN = response.body().getToken();
                    Log.d(TAG, "GETTOKEN " + myGeoTrackingDevieAgentApplication.SIXGILL_AUTH_TOKEN);

                    //get_cadence_apiCall(response.body().getToken());

                }
            }

            @Override
            public void onFailure(Call<TokenModel> call, Throwable t) {
                //  progress.hide();
                Log.d(TAG, "ERRRESITD " + t.getMessage());
            }
        });



    }

}

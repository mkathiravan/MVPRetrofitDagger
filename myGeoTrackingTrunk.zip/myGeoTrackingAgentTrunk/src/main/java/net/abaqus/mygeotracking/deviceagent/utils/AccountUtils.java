package net.abaqus.mygeotracking.deviceagent.utils;

import android.content.SharedPreferences;

/**
 * Created by Karthikraj Duraisamy on 31/7/17.
 *
 * To make use of account related configurations and settings
 * such as HOS Availability, myteam Availability, Forms availability,
 * Notes mandatory, Customer attchments mandatory, Task attachments mandatory and etc...
 */

public class AccountUtils {


    /**
        @param sh_prefs requires to access the SharedPreferences datastore
        @return boolean SOS Availability by checking the SharedPreferences data
     */
    public static boolean isSOSAvailable(SharedPreferences sh_prefs) {
        if (sh_prefs.getBoolean(MDACons.SOS_STAGE_PRESENT, false)) {
            return true;
        } else {
            return false;
        }
    }
}

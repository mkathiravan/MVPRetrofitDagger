package net.abaqus.mygeotracking.deviceagent.utils;

import java.util.Locale;

import net.abaqus.mygeotracking.deviceagent.R;

import android.os.Build;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.text.TextUtilsCompat;
import android.view.View;

public class FragmentTransactionBaseClass {
	public static final int TRANSITION_VERTICAL = 0;
	public static int TRANSITION_HORIZONTAL = 1;
	
	
	
	public static void animateTransition(FragmentTransaction transaction, int direction) {
	boolean rtl = false;
	if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
		rtl = TextUtilsCompat.getLayoutDirectionFromLocale(Locale.getDefault()) == View.LAYOUT_DIRECTION_RTL;
	}
	/*if (direction == TRANSITION_HORIZONTAL) {
		if (rtl) {
			transaction.setCustomAnimations(R.animator.slide_left, R.animator.slide_right,
					R.animator.slide_back_right, R.animator.slide_back_left);
		} else {
			transaction.setCustomAnimations(R.animator.slide_back_right, R.animator.slide_back_left,
					R.animator.slide_left, R.animator.slide_right);
		}
	}
	if (direction == TRANSITION_VERTICAL && Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
		transaction.setCustomAnimations(
                R.animator.anim_in, R.animator.anim_out, R.animator.anim_in_pop, R.animator.anim_out_pop);
	}*/
}
}

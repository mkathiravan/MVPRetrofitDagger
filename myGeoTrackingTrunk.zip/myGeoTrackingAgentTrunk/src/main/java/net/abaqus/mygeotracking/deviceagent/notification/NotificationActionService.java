package net.abaqus.mygeotracking.deviceagent.notification;

import android.app.IntentService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.analytics.FirebaseAnalytics;

import net.abaqus.mygeotracking.deviceagent.bgthread.HOSBackgroundService;
import net.abaqus.mygeotracking.deviceagent.ui.RegisterDeviceActivity;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

/**
 * Created by root on 21/6/16.
 */
public class NotificationActionService extends IntentService {
    private static final String TAG = NotificationActionService.class.getSimpleName();

    public static final String ACTION_TIMECLOCKING = "timeClocking";
    public static final String ACTION_UPDATE_APP = "appUpdate";
    public static final String ACTION_RELAUNCH_APP = "relaunchTheApp";

    public NotificationActionService() {
        super("NotificationActionService");
    }

    @Override
    public void onHandleIntent(Intent intent) {
        final String action = intent.getAction();
        if (ACTION_TIMECLOCKING.equals(action)) {
            // do stuff...
            try {
                SharedPreferences sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
                FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
                String hos_Selection_stage_name = sh_prefs.getString(MDACons.HOS_SELECTION_NAME, "");

                Bundle bundle = new Bundle();
                bundle.putString("TC_REMINDED_STAGE", intent.getStringExtra("stage_desc"));
                bundle.putString("TC_PREVIOUS_STAGE", hos_Selection_stage_name);
                bundle.putString("TC_CONFIRMATION", "Submitted");
                bundle.putString("TC_EVENT_SOURCE", "Push Notification Reminder");
                mFirebaseAnalytics.logEvent("TC_EVENT", bundle);

                new HOSBackgroundService().processHOS(this, intent.getStringExtra("stage_desc"), intent.getStringExtra("stage_id"));
            } catch (Exception e) {e.printStackTrace();}
            AgentNotificationBuilder.DismissNotifications(this);
        } else {
            throw new IllegalArgumentException("Unsupported action: " + action);
        }
    }
}

package net.abaqus.mygeotracking.deviceagent.home;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;


import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.SnackbarUtils;

import butterknife.BindView;
import butterknife.ButterKnife;

public class FAQActivity extends AppCompatActivity {

    @BindView(R.id.weblayout)
    RelativeLayout rootLayout;
    @BindView(R.id.faq_webview)
    WebView webView;
    @BindView(R.id.progressBar1)
    ProgressBar pbar;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_center);
        ButterKnife.bind(this);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.clearCache(true);
        webView.clearHistory();
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView.setVerticalScrollBarEnabled(false);

        if (NetworkConnectionInfo.isOnline(this))
        {
            webView.loadUrl("http://help.mygeotracking.com/faqs-mygeotracking-agent-app-on-android-phones");
        }
        else
        {
            SnackbarUtils.showShort(rootLayout, getString(R.string.msg_internet_disabled_please_try_later), Color.WHITE, ContextCompat.getColor(FAQActivity.this, R.color.alert));

        }

        }


    public class WebViewClient extends android.webkit.WebViewClient
    {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {

            // TODO Auto-generated method stub
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {

            // TODO Auto-generated method stub
            view.loadUrl(url);
            return true;
        }
        @Override
        public void onPageFinished(WebView view, String url) {

            // TODO Auto-generated method stub

            super.onPageFinished(view, url);
            pbar.setVisibility(View.GONE);

        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.web_home, menu);
        MenuItem menuHistoryItem = menu.findItem(R.id.web_home);
        menuHistoryItem.setVisible(true);
        return true;
    }


    @Override
    public void onBackPressed() {
        if (webView.canGoBack())
            webView.goBack();
        else
            super.onBackPressed();

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            case R.id.web_home:
                Intent intent = new Intent(FAQActivity.this,MDAMainActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


}

package net.abaqus.mygeotracking.deviceagent.forms;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * Created by user on 28-06-2018.
 */

public class Form_Model implements Parcelable {

    String Device;

    protected Form_Model(Parcel in) {
        Device = in.readString();
        StatusCode = in.readString();
        forms = in.createTypedArrayList(FormsList.CREATOR);
    }

    public static final Creator<Form_Model> CREATOR = new Creator<Form_Model>() {
        @Override
        public Form_Model createFromParcel(Parcel in) {
            return new Form_Model(in);
        }

        @Override
        public Form_Model[] newArray(int size) {
            return new Form_Model[size];
        }
    };

    public String getDevice() {
        return Device;
    }

    public void setDevice(String device) {
        Device = device;
    }

    public String getStatusCode() {
        return StatusCode;
    }

    public void setStatusCode(String statusCode) {
        StatusCode = statusCode;
    }

    public List<FormsList> getForms() {
        return forms;
    }

    public void setForms(List<FormsList> forms) {
        this.forms = forms;
    }

    String StatusCode;
    List<FormsList> forms;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(Device);
        dest.writeString(StatusCode);
        dest.writeTypedList(forms);
    }


}

package net.abaqus.mygeotracking.deviceagent.home;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentManager.OnBackStackChangedListener;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatDelegate;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.work.WorkManager;

import com.activeandroid.query.Select;
import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.androidadvance.topsnackbar.TSnackbar;
import com.crashlytics.android.Crashlytics;
import com.facebook.network.connectionclass.ConnectionClassManager;
import com.facebook.network.connectionclass.ConnectionQuality;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.sixgill.protobuf.Ingress;
import com.sixgill.sync.sdk.Reach;
import com.sixgill.sync.sdk.ReachCallback;
import com.sixgill.sync.sdk.ReachConfig;
import com.sixgill.sync.sdk.ReachLocationCallback;

import net.abaqus.mygeotracking.deviceagent.BuildConfig;
import net.abaqus.mygeotracking.deviceagent.MGTScheduleStatus;
import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.ViewUtils.RelativeTimeTextView;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsCons;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsEvent;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsKey;
import net.abaqus.mygeotracking.deviceagent.bgthread.HOSBackgroundService;
import net.abaqus.mygeotracking.deviceagent.bgthread.RegistrationTaskMGT;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryTable;
import net.abaqus.mygeotracking.deviceagent.enums.InternetState;
import net.abaqus.mygeotracking.deviceagent.enums.PhoneServiceState;
import net.abaqus.mygeotracking.deviceagent.forms.FormsTable;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HeartBeat;
import net.abaqus.mygeotracking.deviceagent.heartbeat.TriggerSource;
import net.abaqus.mygeotracking.deviceagent.hos.HOSActivity;
import net.abaqus.mygeotracking.deviceagent.hos.HOSHistoryActivity;
import net.abaqus.mygeotracking.deviceagent.listeners.InternetChangeListener;
import net.abaqus.mygeotracking.deviceagent.listeners.PhoneStateChangeListener;
import net.abaqus.mygeotracking.deviceagent.listeners.TaskCompleteListener;
import net.abaqus.mygeotracking.deviceagent.myteam.MyTeamActivity;
import net.abaqus.mygeotracking.deviceagent.notes.NotesComposeFragment;
import net.abaqus.mygeotracking.deviceagent.notes.UploadNotesTask;
import net.abaqus.mygeotracking.deviceagent.receivers.InternetConnectivityReciever;
import net.abaqus.mygeotracking.deviceagent.receivers.PhoneStateChangeReceiver;
import net.abaqus.mygeotracking.deviceagent.sixgill.FusedProvider;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.soshardware.ProcessSMS;
import net.abaqus.mygeotracking.deviceagent.ui.FormsActivity;
import net.abaqus.mygeotracking.deviceagent.ui.RegisterDeviceActivity;
import net.abaqus.mygeotracking.deviceagent.ui.SettingsAcitivty;
import net.abaqus.mygeotracking.deviceagent.updatechecker.UpdateChecker;
import net.abaqus.mygeotracking.deviceagent.utils.AccountUtils;
import net.abaqus.mygeotracking.deviceagent.utils.ConnectionSampler;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;
import net.abaqus.mygeotracking.deviceagent.utils.DeviceUtils;
import net.abaqus.mygeotracking.deviceagent.utils.DownloadFiles;
import net.abaqus.mygeotracking.deviceagent.utils.FragmentTransactionBaseClass;
import net.abaqus.mygeotracking.deviceagent.utils.HOSPullCalls;
import net.abaqus.mygeotracking.deviceagent.utils.LocationPUSHTask;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkDeviceStatus;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkUtils;
import net.abaqus.mygeotracking.deviceagent.utils.SnackbarUtils;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;
import net.abaqus.mygeotracking.deviceagent.workorder.WorkOrderActivity;

import java.io.File;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.nlopez.smartlocation.OnLocationUpdatedListener;
import io.nlopez.smartlocation.SmartLocation;
import io.nlopez.smartlocation.location.config.LocationParams;

public class MDAMainActivity extends ReceiverActivity implements TaskCompleteListener, ConnectionClassManager.ConnectionClassStateChangeListener, InternetChangeListener, PhoneStateChangeListener, SharedPreferences.OnSharedPreferenceChangeListener {

    public final String BUNDLE_INTERNET_STATUS = "Internet_status";
    public final String BUNDLE_CONNECTIVITY_STATUS = "Connectivity_status";

    public final String FRAGMENT_NOTES_TAG = "fragment_notes";
    private final String TAG = MDAMainActivity.class.getSimpleName();
    private MainActivityHelper mainActivityHelper;
    @BindView(R.id.timer_text)
    TextView timerTextView;
    @BindView(R.id.checkinStatusTextView)
    TextView checkinStatusText;
    @BindView(R.id.checkinStatusTime)
    TextView checkinStatusTimeText;
    @BindView(R.id.instantMenuButtonLayout)
    LinearLayout bottomMenuButtonsLayout;
    @BindView(R.id.checkinstatustextViewLayout)
    LinearLayout checkinstatustextViewLayout;
    @BindView(R.id.button_messages_menu)
    ImageView btn_menu_messages;
    @BindView(R.id.button_sos_menu)
    ImageView btn_menu_sos;
    @BindView(R.id.button_timeclock_menu)
    ImageView btn_menu_timecloking;

    @BindView(R.id.floatingActionButtonText)
    TextView floatingSOSButton;
    @BindView(R.id.fragment_container)
    FrameLayout frag;
    @BindView(R.id.checkinStatusTimeAgo)
    RelativeTimeTextView checkinStatusTimeAgoText;

    private List<FormsTable> formsTableArrayList;
    private Context mContext;
    private SharedPreferences sh_prefs;
    private SharedPreferences.Editor sh_prefs_edit;
    private myGeoTrackingDevieAgentApplication app_con;
    private Animation mAnimation;
    private CountDownTimer count_down_timer;
    private TSnackbar connWarningSnackBar;
    private PhoneServiceState CONNECTIVITY_STATUS;
    private InternetState INTERNET_STATUS;
    private TelephonyManager telephonyManager;
    private NotesComposeFragment mDetailFragment = null;
    private FragmentManager mFragmentManager;
    public static boolean isUrlPath = false;
    private static FusedProvider fusedProvider;
    String agent_device_id = "";
    private InternetConnectivityReciever internetConnectivityReciever;
    private static final int REQUEST_PERMISSIONS_REQUEST_CODE = 34;
    Location mLocation;
    String device_number = "";
    NativeLocationTable nativeLocationTable;


    // A reference to the service used to get location updates.
    private LocationUpdatesService mService = null;

    // Tracks the bound state of the service.
    private boolean mBound = false;


    private List<NativeLocationTable> nativeLocationTableList;


    long trip_start_seconds,trip_end_seconds,system_seconds;


    private WorkManager mWorkManager;




    @SuppressWarnings("deprecation")
    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //DebugLog.debug(TAG, "OnCreate Called");
        Log.d(TAG,"MDAMAINONCREATECALLED");

        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        setContentView(R.layout.mda_main_layout);
        ButterKnife.bind(this);
        sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
        sh_prefs_edit = sh_prefs.edit();
        mContext = this;
        app_con = (myGeoTrackingDevieAgentApplication) getApplicationContext();
        mainActivityHelper = new MainActivityHelper(mContext, this);


       // mWorkManager = WorkManager.getInstance();

        agent_device_id = sh_prefs.getString(MDACons.AGENT_DEVICE_ID, "");

        device_number = sh_prefs.getString(MDACons.DEVICE_NUMBER, "");

        MGTScheduleStatus.getInstance(this).comparTripTimes();
        HeartBeat heartBeat = HeartBeat.getInstance();
        heartBeat.justOneBeat(this, TriggerSource.APP_LAUNCHED);
        heartBeat.startBeating(this);


        Log.d(TAG,"STATVAL "+sh_prefs.getBoolean(MDACons.MGT_REGISTRATION_HAPPENED,false));
        if(!device_number.isEmpty())
        {
            if(agent_device_id.isEmpty())
            {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O)
                {
                    doInitialize(device_number);

                }

            }
            else if(!sh_prefs.getBoolean(MDACons.MGT_REGISTRATION_HAPPENED, false))
            {
                new RegistrationTaskMGT(MDAMainActivity.this, MDAMainActivity.this).execute();
            }

        }
        else
        {
            Log.d(TAG,"ELSPART ");
            Intent intent = new Intent(this, RegisterDeviceActivity.class);
            startActivity(intent);
            finish();
        }


        fusedProvider = new FusedProvider(this,MDAMainActivity.this);


        formsTableArrayList = new ArrayList<>();
        initializeComposeMsgDependencies();

        if (NetworkConnectionInfo.isOnline(MDAMainActivity.this)) {
            //new HeartBeatMetaData(MDAMainActivity.this.getApplicationContext());
        }



        FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        mFirebaseAnalytics.setUserId(DeviceUtils.getAndroidID(MDAMainActivity.this));
        mFirebaseAnalytics.setUserProperty("mgt_track_id", DeviceUtils.getAndroidID(MDAMainActivity.this));
        mFirebaseAnalytics.setCurrentScreen(this, MDAMainActivity.class.getSimpleName(), null /* class override */);

        mainActivityHelper.sendGCMTOServer(sh_prefs);
        initUIElements();

        // Filling up the data for keys and token
        //fillData();

        if (NetworkConnectionInfo.isOnline(MDAMainActivity.this)) {
            new UpdateChecker(this);
            UpdateChecker.start();
        }

        Cursor notesCursor = getNotesEntries();
        if (notesCursor != null)
            if (notesCursor.getCount() > 0)
                new UploadNotesTask(this).execute();
        notesCursor.close();






        try {
            Intent appLinkIntent = getIntent();
            String appLinkAction = appLinkIntent.getAction();
            Uri appLinkData = appLinkIntent.getData();
            String urlName = appLinkData.getPath();
            Log.d(TAG,"SEREDRE "+urlName);
            Log.d(TAG,"APLNKACTION "+appLinkAction + "APLNKDAT "+appLinkData);

            isUrlPath = true;
            if(urlName.equals("/agent/notes") && isUrlPath)
            {
                Log.d(TAG,"INSEIDETHENOTESDATA ");
                openNotesComposer();
            }
            if(urlName.equals("/agent/notes/scan") && isUrlPath)
            {
                Log.d(TAG,"SCANOPEN");
                openNotesComposer();
            }

            if(urlName.equals("/agent/notes/sign") && isUrlPath)
            {
                openNotesComposer();
            }



        } catch (Exception e) {
            e.printStackTrace();
        }


        Crashlytics.logException(new SDKRegistrationFailureException("Failed Initializing With SDK Partner"));



        // Check the condition whether tracking is already started or not
        final boolean tracking_status = sh_prefs.getBoolean(MDACons.SCHUDELE_TRACK_STATUS,false);

        Log.d(TAG,"TRACKINGSTATUS "+tracking_status);

        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {

                tracking_start_call(tracking_status);
            }
        }, 30000);


    }



    private void tracking_start_call(boolean tracking_status)
    {
        trip_start_seconds = sh_prefs.getLong(MDACons.TRIP_STARTS_SECONDS,-1);
        trip_end_seconds = sh_prefs.getLong(MDACons.TRIP_END_SECONDS,-1);
        system_seconds = System.currentTimeMillis();

        Log.d(TAG," TIME_SCHEDULE "+ trip_start_seconds + " NOW " + system_seconds + " END_TRIP_SECONDS "+ trip_end_seconds);


        if((tracking_status) || (system_seconds > trip_start_seconds && system_seconds < trip_end_seconds))
        {
            Log.d(TAG,"TRACKING_CALLED ");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            {
                Intent intent = new Intent(MDAMainActivity.this, LocationUpdatesService.class);
                startForegroundService(intent);

            }

            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            {

                LocationNativeJob locationNativeJob = LocationNativeJob.getInstance();
                locationNativeJob.startTracking(MDAMainActivity.this);

            }


            // The following snippet to run when the device is idle mode
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                Constraints constraints = new Constraints.Builder().
//                        setRequiredNetworkType(NetworkType.CONNECTED).
//                        setRequiresCharging(true).
//                        setRequiresDeviceIdle(true).
//                        build();
//                PeriodicWorkRequest locationWork = new PeriodicWorkRequest.Builder(MyWorker
//                        .class, 15, TimeUnit.MINUTES).addTag(MyWorker.TAG)
//                        .setConstraints(constraints).build();
//                mWorkManager.getInstance().enqueue(locationWork);
//
//            }

        }


    }



    public void doInitialize(String device_number) {


        Log.d(TAG, "DEviceNumbe " + device_number);

        ReachConfig config = new ReachConfig();

        //custom notification builder for sticky notification
        config.setStickyNotificationTitle("MyGeoTracking");
        config.setStickyNotificationBody("myGeoTracking is using GPS information");
        config.setStickyNotificationIcon(R.drawable.notification);
        config.setNotificationIcon(R.drawable.notification);



        Map<String, String> aliases = new HashMap<>();
        aliases.put("phone", device_number);
        config.setAliases(aliases);




        config.setIngressURL("https://sense-ingress-api.sixgill.com");
        config.setSendEvents(false);

        //custom notification builder for sticky notification
//        config.setStickyNotificationTitle("MyGeoTracking");
//        config.setStickyNotificationBody("myGeoTracking is using GPS information");
//        config.setStickyNotificationIcon(R.drawable.notification_icon);
//
//        // custom notification builder for any notification
//        config.setNotificationIcon(R.drawable.notification_icon);
//        // pass this config object to initWithAPIKey call


        Reach.initWithAPIKey(MDAMainActivity.this, "66c0d9f139d55c134825d38881", config, new ReachCallback() {
            @Override
            public void onReachSuccess() {
                Crashlytics.log("Success Reach Initialization");

                Log.wtf(TAG, "Success Reach Initialization");
                Reach.enable(MDAMainActivity.this);
//                Toast.makeText(SetIdentitiesActivity.this,"ONSUCCESS",Toast.LENGTH_SHORT).show();
//                Toast.makeText(SetIdentitiesActivity.this,"REACHID"+Reach.deviceId(getApplicationContext()),Toast.LENGTH_SHORT).show();
                setDeviceValue();
                HeartBeat heartBeat = HeartBeat.getInstance();
                heartBeat.justOneBeat(MDAMainActivity.this, TriggerSource.APP_LAUNCHED);
                heartBeat.startBeating(MDAMainActivity.this);


            }

            @Override
            public void onReachFailure(String s) {
                Log.wtf(TAG, "FAILIED Reach Initialization ");
                Crashlytics.log("Failed Reach Initialization with reason: " + s);
                Crashlytics.logException(new SDKRegistrationFailureException("Failed Initializing With SDK Partner"));
            }
        });


    }

    public void setDeviceValue() {
        new RegistrationTaskMGT(MDAMainActivity.this, MDAMainActivity.this).execute();

    }





    private void requestPermissions() {
        boolean shouldProvideRationale =
                ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.ACCESS_FINE_LOCATION);

        // Provide an additional rationale to the user. This would happen if the user denied the
        // request previously, but didn't check the "Don't ask again" checkbox.
        if (shouldProvideRationale) {
            Log.i(TAG, "Displaying permission rationale to provide additional context.");
            Snackbar.make(
                    findViewById(R.id.activity_main),
                    R.string.permission_rationale,
                    Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.ok, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            // Request permission
                            ActivityCompat.requestPermissions(MDAMainActivity.this,
                                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                    REQUEST_PERMISSIONS_REQUEST_CODE);
                        }
                    })
                    .show();
        } else {
            Log.i(TAG, "Requesting permission");
            // Request permission. It's possible this can be auto answered if device policy
            // sets the permission in a given state or the user denied the permission
            // previously and checked "Never ask again".
            ActivityCompat.requestPermissions(MDAMainActivity.this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_PERMISSIONS_REQUEST_CODE);
        }
    }





    public void statusCheck() {
        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps();

        }
    }

    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(MDAMainActivity.this);
        builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }


    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        //DebugLog.debug(TAG, "OnPostCreate Called");

    }

    protected void onPause() {
        //DebugLog.debug(TAG, "OnPause Called");

        myGeoTrackingDevieAgentApplication.mainActivityPaused();
        //  LocalBroadcastManager.getInstance(this).unregisterReceiver(myReceiver);
        super.onPause();
    }

    @SuppressLint("NewApi")
    @Override
    protected void onResume() {
        //DebugLog.debug(TAG, "OnResume Called");

        Log.d(TAG,"MDAMAINONRESUMECALLED");

        super.onResume();
        myGeoTrackingDevieAgentApplication.mainActivityResumed();
        telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        telephonyManager.listen(new PhoneStateChangeReceiver(mContext, this), PhoneStateListener.LISTEN_SERVICE_STATE | PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);


//        LocalBroadcastManager.getInstance(this).registerReceiver(myReceiver,		//        LocalBroadcastManager.getInstance(this).registerReceiver(myReceiver,
//                new IntentFilter(LocationUpdatesService.ACTION_BROADCAST));

/*
        if(savedInstanceState != null) {
            boolean internetStatus = savedInstanceState.getBoolean(BUNDLE_INTERNET_STATUS);
            boolean connectivityStatus = savedInstanceState.getBoolean(BUNDLE_CONNECTIVITY_STATUS);
            if(internetStatus)
                INTERNET_STATUS = InternetState.STATE_CONNECTED;
            else
                INTERNET_STATUS = InternetState.STATE_DISCONNECTED;

            if(connectivityStatus)
                CONNECTIVITY_STATUS = PhoneServiceState.STATE_CONNECTED;
            else
                CONNECTIVITY_STATUS = PhoneServiceState.STATE_DISCONNECTED;

        }
*/


        int SIM_STATE = telephonyManager.getSimState();
        if( SIM_STATE == TelephonyManager.SIM_STATE_UNKNOWN ||
                SIM_STATE == TelephonyManager.SIM_STATE_ABSENT ||
                SIM_STATE == TelephonyManager.SIM_STATE_NETWORK_LOCKED ||
                SIM_STATE == TelephonyManager.SIM_STATE_PIN_REQUIRED ||
                SIM_STATE == TelephonyManager.SIM_STATE_PUK_REQUIRED|| isAirplaneModeOn(mContext)) {
            CONNECTIVITY_STATUS = PhoneServiceState.STATE_DISCONNECTED;
        } else {
            CONNECTIVITY_STATUS = PhoneServiceState.STATE_UNKNOWN;
        }

        if(NetworkConnectionInfo.isOnline(this)) {
            INTERNET_STATUS = InternetState.STATE_CONNECTED;
        } else {
            INTERNET_STATUS = InternetState.STATE_DISCONNECTED;
        }




        //Do MGT configuration if it is not already done & if it is done
        //Check offline forms availability and initiate the download
        if (!sh_prefs.getBoolean(MDACons.MGT_CONFIGURATION_STATUS, false)) {
            //DebugLog.debug(TAG, "MGT Configuration status is false. Initiating downloads");
            HOSPullCalls.makeHOSInitializeCalls(MDAMainActivity.this, null);
            //DebugLog.debug(TAG, "After Inititating downloads");

        } else {
            //setupOfflineFileDownloading();
        }

        boolean alarmUp = (PendingIntent.getBroadcast(this, 0,
                new Intent("net.abaqus.mygeotracking.deviceagent.HB_SERVICE_ACTION"),
                PendingIntent.FLAG_NO_CREATE) != null);
        if (alarmUp) {
            //DebugLog.debug(TAG, "Alarm is already active");
        } else {
            //DebugLog.debug(TAG, "Alarm is not active");
            sh_prefs_edit.putString(MDACons.HB_INTERVAL_OLD, "");
            sh_prefs_edit.commit();
        }


        if (timerTextView.getVisibility() == View.VISIBLE)
            timerTextView.setVisibility(View.INVISIBLE);

        invalidateOptionsMenu();


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        reachReceiver.unregisterReachReceiver();

        //Unregister the broadcast receiver
//        LocalBroadcastManager.getInstance(this).unregisterReceiver(myReceiver);

    }

    @Override
    protected void onStop() {
        //DebugLog.debug(TAG, "onStop Called");

        if(internetConnectivityReciever != null)
            unregisterReceiver(internetConnectivityReciever);


        super.onStop();
    }

    private void initUIElements() {
        //DebugLog.debug(TAG, "InitUIElements Called");

        btn_menu_messages.setBackgroundResource(R.drawable.bluebtnbgnew);
        btn_menu_sos.setBackgroundResource(R.drawable.bluebtnbgnew);
        btn_menu_timecloking.setBackgroundResource(R.drawable.bluebtnbgnew);
        btn_menu_timecloking.setVisibility(View.GONE);
        btn_menu_messages.setPadding(0, 0, 0, 0);
        btn_menu_sos.setVisibility(View.GONE);
        floatingSOSButton.setVisibility(View.GONE);
        //floatingActionButtonText.setVisibility(View.INVISIBLE);
        checkinstatustextViewLayout.setVisibility(View.GONE);
        btn_menu_messages.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                openNotesComposer();
                isUrlPath = false;




            }
        });

        btn_menu_timecloking.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                launchTimeClockingView();
            }
        });

        floatingSOSButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                btn_menu_sos.performClick();
            }
        });
        btn_menu_sos.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                new MaterialDialog.Builder(MDAMainActivity.this)
                        .title("Send SOS")
                        .content("Please Confirm.")
                        .positiveText("Yes")
                        .negativeText("Cancel")
                        .autoDismiss(true)
                        .onPositive(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {

                                if (!NetworkConnectionInfo.isOnline(MDAMainActivity.this)) {
                                    String toPhoneNumber = sh_prefs.getString(MDACons.TWILIO_SHORT_CODE, "+18032327769");
                                    String sosCommand = sh_prefs.getString(MDACons.SOS_EMER_COMMAND, "SOS");
                                    SharedPreferences.Editor edit_prefs = sh_prefs.edit();
                                    edit_prefs.putInt(MDACons.HOS_SELECTION,
                                            Integer.parseInt("7"));

                                    edit_prefs.putString(MDACons.HOS_SELECTION_NAME,
                                            "Safety Alert Triggered");
                                    edit_prefs.commit();

                                    new ProcessSMS().sendNow(MDAMainActivity.this, toPhoneNumber, sosCommand, "7", "");
                                } else {
                                    if (ConnectionClassManager.getInstance().getCurrentBandwidthQuality() == ConnectionQuality.POOR) {
                                        String toPhoneNumber = sh_prefs.getString(MDACons.TWILIO_SHORT_CODE, "+18032327769");
                                        String sosCommand = sh_prefs.getString(MDACons.SOS_EMER_COMMAND, "SOS");
                                        SharedPreferences.Editor edit_prefs = sh_prefs.edit();
                                        edit_prefs.putInt(MDACons.HOS_SELECTION,
                                                Integer.parseInt("7"));
                                        edit_prefs.putString(MDACons.HOS_SELECTION_NAME,
                                                "Safety Alert Triggered");
                                        edit_prefs.commit();

                                        new ProcessSMS().sendNow(MDAMainActivity.this, toPhoneNumber, sosCommand, "7", "");
                                    } else {
                                        new HOSBackgroundService().processHOS(MDAMainActivity.this, "Safety Alert Triggered", "7");
                                    }
                                }
                                prepareCheckinStatusText();
                            }
                        })
                        .show();
            }
        });
        mAnimation = AnimationUtils.loadAnimation(this,
                R.anim.dropfromdownanimation);
        // Location timerTextView text hide on click
        timerTextView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                timerTextView.setVisibility(View.GONE);
            }
        });
    }


    private Cursor getNotesEntries() {
        //DebugLog.debug(TAG, "getNotesEntries Called");

        String[] projection = {
                NotesEntryTable.NOTES_ENTRY_XML, NotesEntryTable.COLUMN_ID};
        Cursor cursor = getContentResolver().query(Uri.parse(NotesEntryContentProvider.CONTENT_URI.toString()), projection, null, null,
                null);
        return cursor;
    }

    private void initializeComposeMsgDependencies() {
        //DebugLog.debug(TAG, "initializeComposeMsgDependencies Called");

        /*Code block for in app notes implementation*/
        mFragmentManager = getSupportFragmentManager();
        mFragmentManager.addOnBackStackChangedListener(new OnBackStackChangedListener() {
            @SuppressLint("NewApi")
            @Override
            public void onBackStackChanged() {
                if (getFragmentManager().getBackStackEntryCount() == 0)
                    if (frag.getVisibility() == View.VISIBLE)
                        frag.setVisibility(View.GONE);
            }
        });
        frag.setVisibility(View.GONE);
        /*Code block for in app notes implementation*/
    }


    public void onRefreshClick() {
        //DebugLog.debug(TAG, "onRefreshClick Called");

        if (INTERNET_STATUS == InternetState.STATE_CONNECTED) {
            Toast.makeText(MDAMainActivity.this,
                    "Refreshing...", Toast.LENGTH_SHORT)
                    .show();
            RegistrationTaskMGT registrationTaskMGT = new RegistrationTaskMGT(this, this);
            registrationTaskMGT.execute("");
            HOSPullCalls.makeHOSInitializeCalls(MDAMainActivity.this,
                    null);
        } else {
            if(AccountUtils.isSOSAvailable(sh_prefs)) {
                displayNoConnectivityAlert();
            } else {
                SnackbarUtils.showShort(bottomMenuButtonsLayout, getString(R.string.msg_internet_disabled_please_try_later), Color.WHITE, ContextCompat.getColor(MDAMainActivity.this, R.color.alert));
            }
        }
    }

    @Override
    public void onTaskCompleted(boolean success) {
        //DebugLog.debug(TAG, "onTaskCompleted Called. refreshTimeClockingUI");

        refreshTimeClockingUI();
    }

    private void refreshTimeClockingUI() {
        //DebugLog.debug(TAG, "refreshTimeClockingUI Called. ");

        if (sh_prefs.getBoolean(MDACons.HOS_MENU_AVAILABLE, false)) {
            if (sh_prefs.getBoolean(MDACons.HOS_SHOW_MENU, true) && sh_prefs.getString(MDACons.DEVICE_NUMBER, "").length() > 0) {
                btn_menu_timecloking.setVisibility(View.VISIBLE);
                btn_menu_messages.setPadding(0, 0, 70, 0);
                btn_menu_timecloking.setPadding(70, 0, 0, 0);
                SharedPreferences sharedPreferences = getSharedPreferences(MDACons.PREFS, 0);
                if (AccountUtils.isSOSAvailable(sharedPreferences)) {
                    makeSOSButtonVisible();
                } else {
                    makeSOSButtonGone();
                }
                //checkinstatustextViewLayout.setVisibility(View.VISIBLE);
            } else {
                btn_menu_timecloking.setVisibility(View.GONE);
                btn_menu_sos.setVisibility(View.GONE);
                floatingSOSButton.setVisibility(View.GONE);
                // floatingActionButtonText.setVisibility(View.INVISIBLE);
                checkinstatustextViewLayout.setVisibility(View.GONE);
            }
        } else {
            btn_menu_timecloking.setVisibility(View.GONE);
            btn_menu_sos.setVisibility(View.GONE);
            floatingSOSButton.setVisibility(View.GONE);
            // floatingActionButtonText.setVisibility(View.INVISIBLE);
            checkinstatustextViewLayout.setVisibility(View.GONE);
        }
    }

    private void makeSOSButtonGone() {
        //DebugLog.debug(TAG, "makeSOSButtonGone Called. ");

        btn_menu_sos.setVisibility(View.GONE);
        floatingSOSButton.setVisibility(View.GONE);
        // floatingActionButtonText.setVisibility(View.INVISIBLE);
    }

    private void makeSOSButtonVisible() {
        //DebugLog.debug(TAG, "makeSOSButtonVisible Called. ");

        btn_menu_sos.setVisibility(View.GONE);
        //floatingActionButtonText.setVisibility(View.VISIBLE);
        floatingSOSButton.setVisibility(View.VISIBLE);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        //DebugLog.debug(TAG, "onPrepareOptionsMenu Called. ");

        if (sh_prefs.getBoolean(MDACons.MY_TEAM_SHOW_MENU, false)) {
            menu.findItem(R.id.action_myteam).setVisible(true);
        } else {
            menu.findItem(R.id.action_myteam).setVisible(false);
        }

        if(sh_prefs.getBoolean(MDACons.WORK_ORDER_SHOW_MENU,false)){
            String workOrderCommand = sh_prefs.getString(MDACons.WORK_ORDER_TEXT, "SOS");
            MenuItem workOrderMenuItem = menu.findItem(R.id.action_workorder);
            workOrderMenuItem.setTitle(workOrderCommand.trim());
            workOrderMenuItem.setVisible(true);
        }else {
            menu.findItem(R.id.action_workorder).setVisible(false);
        }

        if (sh_prefs.getBoolean(MDACons.HOS_MENU_AVAILABLE, false)) {
            if (sh_prefs.getBoolean(MDACons.HOS_SHOW_MENU, true) && sh_prefs.getString(MDACons.DEVICE_NUMBER, "").length() > 0) {
                btn_menu_timecloking.setVisibility(View.VISIBLE);
                btn_menu_messages.setPadding(0, 0, 70, 0);
                btn_menu_timecloking.setPadding(70, 0, 0, 0);
                if (AccountUtils.isSOSAvailable(sh_prefs)) {
                    makeSOSButtonVisible();
                } else {
                    makeSOSButtonGone();
                }
                checkinstatustextViewLayout.setVisibility(View.VISIBLE);
                prepareCheckinStatusText();
                if ((sh_prefs.getString(MDACons.HOS_GROUP_ID, "").equals("Mobile"))) {
                    menu.findItem(R.id.action_timeclocking).setTitle("Time Clock");
                    menu.findItem(R.id.action_hoshistory).setTitle("Time Clock Report");
                } else {
                    menu.findItem(R.id.action_timeclocking).setTitle("Hrs-Of-Service");
                    menu.findItem(R.id.action_hoshistory).setTitle("Hrs-Of-Service Report");
                }
            } else {
                menu.findItem(R.id.action_timeclocking).setVisible(false);
                menu.findItem(R.id.action_hoshistory).setVisible(false);
            }

            menu.findItem(R.id.action_timeclocking).setVisible(true);
            menu.findItem(R.id.action_hoshistory).setVisible(true);

        } else {
            menu.findItem(R.id.action_timeclocking).setVisible(false);
            menu.findItem(R.id.action_hoshistory).setVisible(false);
        }

        menu.findItem(R.id.action_multiple_forms).setVisible(false);

        if (mDetailFragment != null) {
            menu.findItem(R.id.action_close).setVisible(true);
            menu.findItem(R.id.action_timeclocking).setVisible(false);
            menu.findItem(R.id.action_settings).setVisible(false);
            menu.findItem(R.id.action_update_location).setVisible(false);
            menu.findItem(R.id.action_workorder).setVisible(false);
            menu.findItem(R.id.action_myteam).setVisible(false);
            menu.findItem(R.id.action_messages).setVisible(false);
            menu.findItem(R.id.action_about).setVisible(false);
            menu.findItem(R.id.action_refresh).setVisible(false);
            menu.findItem(R.id.action_hoshistory).setVisible(false);
            menu.findItem(R.id.action_faq).setVisible(false);
            return true;
        } else {
            return super.onPrepareOptionsMenu(menu);
        }
    }


    private void prepareCheckinStatusText() {
        //DebugLog.debug(TAG, "prepareCheckinStatusText Called. ");

        String hos_selection = sh_prefs.getString(MDACons.HOS_SELECTION_NAME, "");
        String hos_time = sh_prefs.getString(MDACons.HOS_TIME, "");
        Log.d(TAG,"HOSTATUSER "+hos_selection);

        if (hos_selection.length() >= 1 && hos_time.length() > 1) {
            checkinStatusText.setText("TimeClock Status: " + hos_selection);

            SimpleDateFormat sdf = new java.text.SimpleDateFormat(
                    "yyyy/MM/dd, HH:mm:ss", Locale.getDefault());

            SimpleDateFormat formatter = new SimpleDateFormat(
                    "yyyy/MM/dd'T'HH:mm:ssZ",
                    Locale.getDefault());
            Date date =
                    null;
            try {
                date = (Date) formatter.parse(hos_time);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            hos_time = sdf.format(date).toString();
            checkinStatusTimeText.setText(hos_time);
            checkinStatusTimeAgoText.setReferenceTime(date.getTime());
        } else {
            checkinstatustextViewLayout.setVisibility(View.GONE);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //DebugLog.debug(TAG, "onCreateOptionsMenu Called. ");

        if (!btn_menu_timecloking.isEnabled() && !btn_menu_sos.isEnabled()) {
            return false;
        } else {
            getMenuInflater().inflate(R.menu.main, menu);
            return true;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //DebugLog.debug(TAG, "onOptionsItemSelected Called. ");

        switch (item.getItemId()) {
            case R.id.action_settings:
                Intent settings_intent_one = new Intent(getApplicationContext(),
                        SettingsAcitivty.class);
                startActivity(settings_intent_one);
                return true;
            case R.id.action_update_location:
                if (INTERNET_STATUS == InternetState.STATE_CONNECTED) {
                    if (sh_prefs.getString(MDACons.DEVICE_NUMBER, "").length() > 0)
                        doLocationShotCall();
                    else
                        Toast.makeText(MDAMainActivity.this,
                                "Please register your device number in settings.", Toast.LENGTH_SHORT)
                                .show();
                } else {
                    SnackbarUtils.showShort(bottomMenuButtonsLayout, getString(R.string.msg_internet_disabled_please_try_later), Color.WHITE, ContextCompat.getColor(MDAMainActivity.this, R.color.alert));
                }
                return true;

            case R.id.action_messages:
//                launchMessagesView();
                return true;


            case R.id.action_timeclocking:
                launchTimeClockingView();
                return true;

            case R.id.action_multiple_forms:
                launchMultipleForms();
                return true;

            case R.id.action_myteam:
                launchmyTeamView();
                return true;


            case R.id.action_refresh:
                onRefreshClick();
                return true;

            case R.id.action_hoshistory:
                launchHOSHistoryView();
                return true;

            case R.id.action_faq:
                launchWebView();
                return true;

            case R.id.action_workorder:
                lauchWorkOrderView();
                return true;

            case R.id.action_feedback:
                launchplaystoreView();
                return true;


            case R.id.action_startTracking:
                startTracking();
                return true;


            case R.id.action_stopTracking:
                stopTracking();
                return true;

            case R.id.action_close:
                closeComposeView();
                return true;

        }

        return super.onOptionsItemSelected(item);
    }


    private void startTracking()
    {
        if (Build.VERSION.SDK_INT >= 26)
        {
            Log.d(TAG,"CALLED THE updateSErvice");
            Intent intent = new Intent(MDAMainActivity.this, LocationUpdatesService.class);
            startForegroundService(intent);
            // startService(intent);
        }
    }

    private void stopTracking()
    {

        if (Build.VERSION.SDK_INT >= 26)
        {
            Log.d(TAG,"To Stop the service");
            Intent intent = new Intent(MDAMainActivity.this, LocationUpdatesService.class);
            stopService(intent);
            // startService(intent);
        }
    }




    private void launchplaystoreView() {

        // Uri uri = Uri.parse("market://details?id=" + getPackageName());
        Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=net.abaqus.mygeotracking.deviceagent");
        Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
        try {
            startActivity(myAppLinkToMarket);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, " unable to find market app", Toast.LENGTH_LONG).show();
        }
    }


    @SuppressLint("NewApi")
    @Override
    public void onBackPressed() {
        //DebugLog.debug(TAG, "onBackPressed Called. ");

        if (count_down_timer != null) {
            count_down_timer.cancel();
        }

        if (mDetailFragment != null) {
            if(mDetailFragment.isClosable()) {
                closeComposeView();
            } else {
                showWarningOnBackPress();
            }
        } else {
            super.onBackPressed();
        }
    }

    private void showWarningOnBackPress() {
        //DebugLog.debug(TAG, "showWarningOnBackPress Called. ");

        new MaterialDialog.Builder(MDAMainActivity.this)
                .title(R.string.title_warning_backbtn_press)
                .content(R.string.msg_warning_backbtn_press_notes_compose)
                .positiveText(R.string.action_discard)
                .negativeText(R.string.action_stay)
                .autoDismiss(true)
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        closeComposeView();
                    }
                })
                .show();
    }


    private void doLocationShotCall() {

        final Long long_value = Long.parseLong(String.valueOf(sh_prefs
                .getInt(MDACons.LOCATION_SHOT_TIMEOUT, 20)));

        if(Build.VERSION.SDK_INT >= 26)
        {
            native_call_location(long_value);
        }
        else
        {
            reach_call_location(long_value);
        }

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
//        {
//            reach_call_location(long_value);
//        }
//        else
//        {
//            native_call_location(long_value);
//        }


    }


    private void reach_call_location(final Long long_value)
    {
        Reach.getLocation(MDAMainActivity.this, new ReachLocationCallback() {
            @Override
            public void onLocationSuccess(final Ingress.Location location) {

                CurrentDateAndTime.setLatLonValues(
                        Double.valueOf(location.getLatitude()),
                        Double.valueOf(location.getLongitude()));

                //String methodParam = NetworkDeviceStatus.checkNetworkStatus(MDAMainActivity.this);

                String methodParam = NetworkDeviceStatus.checkNetworkStatus(MDAMainActivity.this);
                CurrentDateAndTime.setDeviceMethod(methodParam);
                CurrentDateAndTime.setAccuracyValue(location.getAccuracy()+"");



                timerTextView.startAnimation(mAnimation);
                if (timerTextView.getVisibility() == View.INVISIBLE
                        || timerTextView.getVisibility() == View.GONE) {
                    timerTextView.setText("");
                    timerTextView.setVisibility(View.VISIBLE);
                }

                if (count_down_timer != null)
                    count_down_timer.cancel();

                count_down_timer = new CountDownTimer(long_value * 1000, 1000) {

                    public void onTick(long millisUntilFinished) {

                        if (timerTextView.getVisibility() == View.INVISIBLE)
                            timerTextView.setVisibility(View.VISIBLE);

                        timerTextView.setText(MDACons.MSG_LOCATING_COUNT_DOWN_TIMER
                                + millisUntilFinished / 1000);
                    }

                    public void onFinish() {
                        timerTextView.setVisibility(View.VISIBLE);

                        timerTextView.setText("Updated Location: \nLat="
                                + new java.util.Formatter().format("%1.5f",
                                location.getLatitude())
                                + ","
                                + new java.util.Formatter().format(" Lon = %1.5f",
                                location.getLongitude()));
                    }
                }.start();




                new LocationPUSHTask(MDAMainActivity.this).execute();

            }

            @Override
            public void onLocationFailure(Ingress.Error error) {

            }
        });
    }

    private void native_call_location(final Long long_value)
    {


        SmartLocation.with(MDAMainActivity.this).location()
                .oneFix()
                .config(LocationParams.LAZY)
                .start(new OnLocationUpdatedListener() {
                    @Override
                    public void onLocationUpdated(final Location location) {
                        String accuracyParam = location.getAccuracy() + "";
                        Double latitudeParam = location.getLatitude();
                        Double longitudeParam = location.getLongitude();
                        long timestampParam = location.getTime();
                        Log.d(TAG,"LICATSCESDER");

                        CurrentDateAndTime.setLatLonValues(
                                location.getLatitude(),
                                location.getLongitude());

                        String methodParam = NetworkDeviceStatus.checkNetworkStatus(MDAMainActivity.this);
                        CurrentDateAndTime.setDeviceMethod(methodParam);
                        CurrentDateAndTime.setAccuracyValue(location.getAccuracy()+"");



                        timerTextView.startAnimation(mAnimation);
                        if (timerTextView.getVisibility() == View.INVISIBLE
                                || timerTextView.getVisibility() == View.GONE) {
                            timerTextView.setText("");
                            timerTextView.setVisibility(View.VISIBLE);
                        }

                        if (count_down_timer != null)
                            count_down_timer.cancel();

                        count_down_timer = new CountDownTimer(long_value * 1000, 1000) {

                            public void onTick(long millisUntilFinished) {

                                if (timerTextView.getVisibility() == View.INVISIBLE)
                                    timerTextView.setVisibility(View.VISIBLE);

                                timerTextView.setText(MDACons.MSG_LOCATING_COUNT_DOWN_TIMER
                                        + millisUntilFinished / 1000);
                            }

                            public void onFinish() {
                                timerTextView.setVisibility(View.VISIBLE);

                                timerTextView.setText("Updated Location: \nLat="
                                        + new java.util.Formatter().format("%1.5f",
                                        location.getLatitude())
                                        + ","
                                        + new java.util.Formatter().format(" Lon = %1.5f",
                                        location.getLongitude()));
                            }
                        }.start();




                        new LocationPUSHTask(MDAMainActivity.this).execute();
                    }
                });
    }




    @SuppressLint("NewApi")
    public void openNotesComposer() {
        //DebugLog.debug(TAG, "openNotesComposer Called. ");

        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        FragmentTransactionBaseClass.animateTransition(transaction, FragmentTransactionBaseClass.TRANSITION_VERTICAL);
        mDetailFragment = new NotesComposeFragment();
        Bundle b = new Bundle();
        mDetailFragment.setArguments(b);
        if (mFragmentManager.findFragmentByTag(FRAGMENT_NOTES_TAG) == null) {
            transaction.replace(R.id.fragment_container, mDetailFragment,
                    FRAGMENT_NOTES_TAG)
                    .commitAllowingStateLoss();
        } else {
            transaction.replace(R.id.fragment_container, mDetailFragment,
                    FRAGMENT_NOTES_TAG).commitAllowingStateLoss();
        }
        FrameLayout frag = (FrameLayout) findViewById(R.id.fragment_container);
        frag.setVisibility(View.VISIBLE);
        invalidateOptionsMenuItems();
    }

    private void closeComposeView() {
        //DebugLog.debug(TAG, "closeComposeView Called. ");

        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction trans = manager.beginTransaction();
        trans.remove(mDetailFragment);
        trans.commit();
        manager.popBackStack();
        FrameLayout frag = (FrameLayout) findViewById(R.id.fragment_container);
        frag.setVisibility(View.GONE);
        mDetailFragment = null;
        invalidateOptionsMenuItems();
    }

    @SuppressLint("NewApi")
    private void invalidateOptionsMenuItems() {
        invalidateOptionsMenu();
    }

    @Override
    public void onBandwidthStateChange(ConnectionQuality bandwidthState) {
        //DebugLog.debug(TAG, "onBandwidthStateChange Called. ");

        if (bandwidthState == ConnectionQuality.POOR) {
            if (AccountUtils.isSOSAvailable(sh_prefs)) {
                showSlowNetworkWarning();
                Log.i("CONNECTION_SAMPLING", "POOR");
            }
        } else if (bandwidthState == ConnectionQuality.MODERATE) {
            //return false;
            if (AccountUtils.isSOSAvailable(sh_prefs)) {
                SnackbarUtils.dismiss();
                Log.i("CONNECTION_SAMPLING", "MODERATE");
            }
        } else if (bandwidthState == ConnectionQuality.UNKNOWN) {
            //return false;
            if (AccountUtils.isSOSAvailable(sh_prefs)) {
                SnackbarUtils.dismiss();
                Log.i("CONNECTION_SAMPLING", "UNKNOWN");
            }
        } else if (bandwidthState == ConnectionQuality.EXCELLENT) {
            //return false;
            if (AccountUtils.isSOSAvailable(sh_prefs)) {
                SnackbarUtils.dismiss();
                Log.i("CONNECTION_SAMPLING", "EXCELLENT");
            }
        } else if (bandwidthState == ConnectionQuality.GOOD) {
            //return false;
            if (AccountUtils.isSOSAvailable(sh_prefs)) {
                SnackbarUtils.dismiss();
                Log.i("CONNECTION_SAMPLING", "GOOD");
            }
        } else {
            //return true;
            Log.i("CONNECTION_SAMPLING", "SOMETHING ELSE");
        }
    }

    //Methods for Launching views
    protected void launchTimeClockingView() {
        //DebugLog.debug(TAG, "launchTimeClockingView Called. ");

        Intent hos_activity_intent = new Intent(getApplicationContext(), HOSActivity.class);
        startActivity(hos_activity_intent);
    }

    protected void launchMultipleForms() {
        //DebugLog.debug(TAG, "launchMultipleForms Called. ");

        Intent formsIntent = new Intent(getApplicationContext(), FormsActivity.class);
        startActivity(formsIntent);
    }

    protected void launchHOSHistoryView() {

        Intent formsIntent = new Intent(getApplicationContext(), HOSHistoryActivity.class);
        startActivity(formsIntent);
    }

    private void launchWebView() {
        FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(MDAMainActivity.this);
        Bundle bundle = new Bundle();
        bundle.putString(AnalyticsKey.EVENT_STATE, AnalyticsCons.ITEM_CLICKED);
        mFirebaseAnalytics.logEvent(AnalyticsEvent.HELP_CENTER_CLICK_EVENT, bundle);
        Intent formsIntent = new Intent(getApplicationContext(), FAQActivity.class);
        startActivity(formsIntent);
    }

    private void lauchWorkOrderView() {
        FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(MDAMainActivity.this);
        Bundle bundle = new Bundle();
        bundle.putString(AnalyticsKey.EVENT_STATE, AnalyticsCons.ITEM_CLICKED);
        mFirebaseAnalytics.logEvent(AnalyticsEvent.WORK_ORDER_CLICK_EVENT, bundle);
        Intent formsIntent = new Intent(getApplicationContext(), WorkOrderActivity.class);
        startActivity(formsIntent);
    }





    //Connectivity based warning methods

    protected void launchmyTeamView() {
        //DebugLog.debug(TAG, "launchmyTeamView Called. ");

        Intent myteam_activity_intent = new Intent(getApplicationContext(),
                MyTeamActivity.class);
        startActivity(myteam_activity_intent);
    }

//    protected void launchMessagesView() {
//        //DebugLog.debug(TAG, "launchMessagesView Called. ");
//
//        if (sh_prefs.getString(MDACons.DEVICE_NUMBER, "").length() > 0) {
//            Intent settings_intent_three = new Intent(getApplicationContext(),//SharedPrefsForAgentApp prefs;
//                    MyGeoTrackingAgentInboxActivity.class);
//            startActivity(settings_intent_three);
//        } else
//            Toast.makeText(MDAMainActivity.this,
//                    R.string.please_register_device_error_msg, Toast.LENGTH_SHORT)
//                    .show();
//    }

    private void showSlowNetworkWarning() {
        //DebugLog.debug(TAG, "showSlowNetworkWarning Called. ");

        Log.i("HOSSOSDISABLELOG", "Slow network get called");
        if (AccountUtils.isSOSAvailable(sh_prefs) && !NetworkUtils.isConnectedFast(mContext)) {
            final TSnackbar snackbar = TSnackbar.make(findViewById(android.R.id.content), getString(R.string.slow_internet_alert_checkins), TSnackbar.LENGTH_INDEFINITE);
            snackbar.setActionTextColor(Color.parseColor("#00adee"));
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#ececec"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.parseColor("#535454"));
            textView.setTypeface(null, Typeface.BOLD);
            snackbar.setAction("GOT IT", new OnClickListener() {
                @Override
                public void onClick(View v) {
                    snackbar.dismiss();
                }
            });
            snackbar.show();
        }
    }

    private void showNoNetworkWarning() {
        //DebugLog.debug(TAG, "showNoNetworkWarning Called. ");

        Log.i("HOSSOSDISABLELOG", "Internet disabled warning called");
        if (CONNECTIVITY_STATUS == PhoneServiceState.STATE_DISCONNECTED) {
            displayNoConnectivityAlert();
            Log.i("HOSSOSDISABLELOG", "Internet disabled warning called - COnnectivity false so moved to no connectivity warning");
        } else if (INTERNET_STATUS == InternetState.STATE_DISCONNECTED) {
            Log.i("HOSSOSDISABLELOG", "Internet disabled warning called - Displaying");
            final TSnackbar snackbar = TSnackbar.make(findViewById(android.R.id.content), getString(R.string.slow_internet_alert_checkins), TSnackbar.LENGTH_INDEFINITE);
            snackbar.setActionTextColor(Color.parseColor("#00adee"));
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#ececec"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.parseColor("#535454"));
            textView.setTypeface(null, Typeface.BOLD);
            snackbar.setAction("GOT IT", new OnClickListener() {
                @Override
                public void onClick(View v) {
                    snackbar.dismiss();
                }
            });
            snackbar.show();
        }
    }

    private void displayNoConnectivityAlert() {
        //DebugLog.debug(TAG, "displayNoConnectivityAlert Called. ");

        Log.i("HOSSOSDISABLELOG", "No Connectivty alert called to display");
        if (connWarningSnackBar == null)
            connWarningSnackBar = TSnackbar.make(findViewById(android.R.id.content), getString(R.string.txtwarning_no_connectivty_reachable), TSnackbar.LENGTH_INDEFINITE);

        if (!connWarningSnackBar.isShownOrQueued() && mDetailFragment == null) {
            connWarningSnackBar.setActionTextColor(Color.parseColor("#00adee"));
            View snackbarView = connWarningSnackBar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#ececec"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.parseColor("#535454"));
            textView.setTypeface(null, Typeface.BOLD);
            connWarningSnackBar.setAction("GOT IT", new OnClickListener() {
                @Override
                public void onClick(View v) {
                    connWarningSnackBar.dismiss();
                }
            });
            connWarningSnackBar.show();
        }
    }

    private void showNoConnectivityWarning() {
        //DebugLog.debug(TAG, "showNoConnectivityWarning Called. ");

        Log.i("HOSSOSDISABLELOG", "No Connectivity warning get called");

        if (AccountUtils.isSOSAvailable(sh_prefs)) {

            if (isAirplaneModeOn(MDAMainActivity.this)) {
                displayNoConnectivityAlert();
                disableHOSSOSButtons();
                return;
            }


            if (INTERNET_STATUS == InternetState.STATE_DISCONNECTED && CONNECTIVITY_STATUS == PhoneServiceState.STATE_DISCONNECTED) {
                Log.i("HOSSOSDISABLELOG", "Internet connectivity " + NetworkConnectionInfo.isOnline(MDAMainActivity.this));
                Log.i("HOSSOSDISABLELOG", "Connectivity status network " + CONNECTIVITY_STATUS);
                Log.i("HOSSOSDISABLELOG", "Yes it is no connectivity and disabling everything");
                displayNoConnectivityAlert();
            } else if (CONNECTIVITY_STATUS == PhoneServiceState.STATE_CONNECTED) {
                Log.i("HOSSOSDISABLELOG", "Internet disabled warning called from NoConnectivity block");
                showNoNetworkWarning();
            }
        }
    }

    private void disableHOSSOSButtons() {
        //DebugLog.debug(TAG, "disableHOSSOSButtons Called. ");

        btn_menu_messages.setEnabled(false);
        btn_menu_timecloking.setEnabled(false);
        btn_menu_sos.setEnabled(false);
        floatingSOSButton.setEnabled(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            floatingSOSButton.setBackgroundTintList(ColorStateList.valueOf(Color.GRAY));
        } else {
            ViewCompat.setBackgroundTintList(floatingSOSButton, ColorStateList.valueOf(Color.GRAY));
        }

        invalidateOptionsMenuItems();
        btn_menu_timecloking.setVisibility(View.VISIBLE);
        btn_menu_messages.setVisibility(View.VISIBLE);
        makeSOSButtonVisible();
    }

    private void enableHOSSOSButtons() {
        //DebugLog.debug(TAG, "enableHOSSOSButtons Called. ");

        btn_menu_messages.setEnabled(true);
        btn_menu_timecloking.setEnabled(true);
        btn_menu_sos.setEnabled(true);
        floatingSOSButton.setEnabled(true);
        btn_menu_timecloking.setVisibility(View.VISIBLE);
        btn_menu_messages.setVisibility(View.VISIBLE);
        makeSOSButtonVisible();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            //floatingSOSButton.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.alert, null)));
            floatingSOSButton.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
        } else {
            //ViewCompat.setBackgroundTintList(floatingSOSButton, ColorStateList.valueOf(getResources().getColor(R.color.alert, null)));
            ViewCompat.setBackgroundTintList(floatingSOSButton, ColorStateList.valueOf(Color.RED));

        }



        invalidateOptionsMenuItems();
    }

    private void setupOfflineFileDownloading() {
        formsTableArrayList = getFormsData();
        //TODO Move path variable into Cons variable in MDACons and start accessing the Constant String from all required places
        String path = "/data/" + mContext.getPackageName() + "/forms/";
        File dir = new File(Environment.getDataDirectory() + path);
        File[] files = dir.listFiles();
        //TODO Print all the logs only by using //DebugLog utils class.
        //For ex: //DebugLog.debug(TAG, "Size of Saved File :")
        //Follow this //DebugLog log printing here after in any case if we want to print something.
        //Do not use any Android Log class directly here after.
        //Also in our project which ever class we ttouch we need to make sure that we are using either //DebugLog or ReleaseLog classes utility methods
        //Log.d(TAG, "Size Of Saved File :  " + files.length + " Size Of FormTable  :  " + formsTableArrayList.size());
        if (files != null && formsTableArrayList.size() > files.length) {
            for (FormsTable formsTable : formsTableArrayList) {
                if (!(DownloadFiles.isExistLocalFile(formsTable, mContext))) {
                    DownloadFiles.downloadZipFileRx(formsTable, mContext);
                }
            }
        }
    }

    private List<FormsTable> getFormsData() {
        //DebugLog.debug(TAG, "getFormsData Called. ");

        return new Select()
                .from(FormsTable.class)
                .execute();
    }


    @Override
    public void onInternetChanged() {
        //DebugLog.debug(TAG, "onInternetChanged Called. ");

        if(NetworkConnectionInfo.isOnline(MDAMainActivity.this)) {
            //determineButtonDisableCondition
            INTERNET_STATUS = InternetState.STATE_CONNECTED;
            if(AccountUtils.isSOSAvailable(sh_prefs)) {
                enableHOSSOSButtons();
            }
        } else {
            //determineButtonDisableCondition
            INTERNET_STATUS = InternetState.STATE_DISCONNECTED;


            if(!AccountUtils.isSOSAvailable(sh_prefs)) {
                final TSnackbar snackbar = TSnackbar.make(findViewById(android.R.id.content), getString(R.string.msg_internet_disabled_please_try_later), TSnackbar.LENGTH_INDEFINITE);
                snackbar.setActionTextColor(Color.parseColor("#00adee"));
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#ececec"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.parseColor("#535454"));
                textView.setTypeface(null, Typeface.BOLD);
                snackbar.setAction("GOT IT", new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        snackbar.dismiss();
                    }
                });
                snackbar.show();
            } else if(CONNECTIVITY_STATUS == PhoneServiceState.STATE_DISCONNECTED) {
                disableHOSSOSButtons();
            }
        }
    }

    @Override
    public void onNetworkConnected() {
        //DebugLog.debug(TAG, "onNetworkConnected Called. ");

        //determineButtonDisableCondition
        int SIM_STATE = telephonyManager.getSimState();
        if( SIM_STATE == TelephonyManager.SIM_STATE_UNKNOWN ||
                SIM_STATE == TelephonyManager.SIM_STATE_ABSENT ||
                SIM_STATE == TelephonyManager.SIM_STATE_NETWORK_LOCKED ||
                SIM_STATE == TelephonyManager.SIM_STATE_PIN_REQUIRED ||
                SIM_STATE == TelephonyManager.SIM_STATE_PUK_REQUIRED || isAirplaneModeOn(mContext)) {
            CONNECTIVITY_STATUS = PhoneServiceState.STATE_DISCONNECTED;
            if(AccountUtils.isSOSAvailable(sh_prefs) && INTERNET_STATUS == InternetState.STATE_DISCONNECTED) {
                enableHOSSOSButtons();
            }
        } else {
            CONNECTIVITY_STATUS = PhoneServiceState.STATE_CONNECTED;
            if(AccountUtils.isSOSAvailable(sh_prefs)) {
                enableHOSSOSButtons();
            }
        }
    }

    @Override
    public void onNetworkDisconnected() {
        //DebugLog.debug(TAG, "onNetworkDisconnected Called. ");

        //determineButtonDisableCondition
        CONNECTIVITY_STATUS = PhoneServiceState.STATE_DISCONNECTED;
        if(INTERNET_STATUS == InternetState.STATE_DISCONNECTED) {
            if(AccountUtils.isSOSAvailable(sh_prefs)) {
                disableHOSSOSButtons();
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        //DebugLog.debug(TAG, "onSaveInstanceState Called. ");

        boolean internetStatus;
        if(INTERNET_STATUS == InternetState.STATE_CONNECTED) {
            internetStatus = true;
        } else {
            internetStatus = false;
        }
        boolean connectivityStatus;
        if(CONNECTIVITY_STATUS == PhoneServiceState.STATE_CONNECTED) {
            connectivityStatus = true;
        } else {
            connectivityStatus = false;
        }
        outState.putBoolean(BUNDLE_INTERNET_STATUS, internetStatus);
        outState.putBoolean(BUNDLE_CONNECTIVITY_STATUS, connectivityStatus);
        super.onSaveInstanceState(outState);
    }

    private static boolean isAirplaneModeOn(Context context) {
        if (Build.VERSION.SDK_INT < 17) {
            return Settings.System.getInt(context.getContentResolver(),
                    Settings.Global.AIRPLANE_MODE_ON, 0) != 0;
        } else {
            return Settings.System.getInt(context.getContentResolver(),
                    Settings.System.AIRPLANE_MODE_ON, 0) != 0;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        Log.d(TAG,"MDAMainActivity onStartCalled");


        // Internet connectivity receiver to let user know the connectivity status instantly
        this.internetConnectivityReciever = new InternetConnectivityReciever(this);
        registerReceiver(
                this.internetConnectivityReciever,
                new IntentFilter(
                        ConnectivityManager.CONNECTIVITY_ACTION));


        //Start Connection sampling to show poor network error
        //only for SOS enabled accounts
        if (AccountUtils.isSOSAvailable(sh_prefs)) {
            Log.i("CONNECTION_SAMPLING_HOS", "Download kbps : " + ConnectionClassManager.getInstance().getDownloadKBitsPerSecond());
            if (INTERNET_STATUS == InternetState.STATE_CONNECTED)
                ConnectionSampler.doSmapling(this);

            mainActivityHelper.checkSMSPersmission();
            mainActivityHelper.checkTelephonyPersmission();

            Handler mHandler = new Handler();
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (INTERNET_STATUS == InternetState.STATE_CONNECTED) {
                        if (ConnectionClassManager.getInstance().getCurrentBandwidthQuality() == ConnectionQuality.POOR) {
                            showSlowNetworkWarning();
                        }
                    } else {
                        Log.i("HOSSOSDISABLELOG", " from Sampler result");
                        showNoConnectivityWarning();
                    }
                }
            }, 3000);
        } else {
            if (INTERNET_STATUS == InternetState.STATE_DISCONNECTED) {
                mainActivityHelper.showInternetDisabledWarning();
            }
        }


    }


    class SDKRegistrationFailureException extends Exception{
        SDKRegistrationFailureException(String s){
            super(s);
        }
    }

    public static FusedProvider getInstanceLocation()
    {
        return fusedProvider;
    }




    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {

    }




    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        Log.i(TAG, "onRequestPermissionResult");
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            if (grantResults.length <= 0) {
                // If user interaction was interrupted, the permission request is cancelled and you
                // receive empty arrays.
                Log.i(TAG, "User interaction was cancelled.");
            } else if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted.
                mService.requestLocationUpdates();
            } else {
                // Permission denied.
                Snackbar.make(
                        findViewById(R.id.activity_main),
                        R.string.permission_denied_explanation,
                        Snackbar.LENGTH_INDEFINITE)
                        .setAction(R.string.settings, new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                // Build intent that displays the App settings screen.
                                Intent intent = new Intent();
                                intent.setAction(
                                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                Uri uri = Uri.fromParts("package",
                                        BuildConfig.APPLICATION_ID, null);
                                intent.setData(uri);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        })
                        .show();
            }
        }


    }





}
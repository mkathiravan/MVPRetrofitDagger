package net.abaqus.mygeotracking.deviceagent.expandableview;

import android.util.Log;

import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;


import net.abaqus.mygeotracking.deviceagent.forms.FormPrefillListViewModel;

import java.util.List;

/**
 * Created by user on 28-06-2018.
 */

public class Genre extends ExpandableGroup<FormPrefillListViewModel>{

//    int HdrIndex;
//    List<String> HdrTitle;
//
//    public int getHdrIndex() {
//        return HdrIndex;
//    }
//
//
//    public Genre(String title, int Index, List<FormPrefillListViewModel> items) {
//        super(title, items);
//        HdrIndex=Index;
//    }



    String formId;

    public String getFormId()
    {
        return formId;
    }



    public Genre(String title, String formId, List<FormPrefillListViewModel> items) {
        super(title, items);

        Log.d("GETFOIRMDE", "GETFOIRMDE "+formId);
        this.formId=formId;
    }



}


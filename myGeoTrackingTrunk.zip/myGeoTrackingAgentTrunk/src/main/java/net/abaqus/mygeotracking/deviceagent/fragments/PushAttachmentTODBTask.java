package net.abaqus.mygeotracking.deviceagent.fragments;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import com.facebook.network.connectionclass.DeviceBandwidthSampler;

import net.abaqus.mygeotracking.deviceagent.bgthread.AttachmentPushTask;
import net.abaqus.mygeotracking.deviceagent.data.ImageAttachmentContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.ImageAttachmentTable;
import net.abaqus.mygeotracking.deviceagent.notes.ImageAttachment;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

/**
 * Created by bm on 6/11/15.
 */
public class PushAttachmentTODBTask extends AsyncTask<ImageAttachment, Integer, Integer>
{
        ImageAttachment imageAttachment;
        Context mContext;

        public PushAttachmentTODBTask(ImageAttachment imageAttachment1, Context context)
        {
        imageAttachment = imageAttachment1;
            mContext = context;
        }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        DeviceBandwidthSampler.getInstance().startSampling();

    }

    @Override
    protected void onPostExecute(Integer integer) {
        DeviceBandwidthSampler.getInstance().stopSampling();
        new AttachmentPushTask(mContext.getApplicationContext()).execute();
        super.onPostExecute(integer);
        }

@Override
protected Integer doInBackground(ImageAttachment... params) {
        try {
        ContentValues initialValues = new ContentValues();
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_TYPE,
        imageAttachment.getType());
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_SIZE,
        imageAttachment.getSize());
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_ID,
        imageAttachment.getUniqueID());
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_ORIGINAL_METADATA,
        imageAttachment.getOriginalMetadata());
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_ENTRY_NO_OF_TRIES,
        0);

        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_PATH, imageAttachment.getPath());
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_NAME, imageAttachment.getName());
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_MD5, imageAttachment.getMd5());

        mContext.getContentResolver().insert(ImageAttachmentContentProvider.CONTENT_URI,
                initialValues);
        }catch(Exception e){e.printStackTrace();}
        return 0;
        }
        }
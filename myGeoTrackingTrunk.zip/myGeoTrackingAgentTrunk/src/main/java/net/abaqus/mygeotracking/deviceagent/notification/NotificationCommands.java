package net.abaqus.mygeotracking.deviceagent.notification;

/**
 * Created by root on 8/6/16.
 */

/**
 * GCMConstants used on GCM default key/pair values, which determines about the action to be taken in client app side.
 */

public final class NotificationCommands {


    /**
     * Key for the type of message
     */

    public static final String KEY_GCM_MESSAGE_TYPE = "gcmKeyMessageType";

    /**
     * Key for the type of action
     */

    public static final String KEY_GCM_ACTION_TYPE = "gcmKeyActionType";

    /**
     * Key Constant for isolating all kind of background progress to be happened in client app by receiving the silent push notification.
     */

    public static final String KEY_GCM_SILENT_PUSH =

            "silentPush";


    /**
     * Key Constant for isolating all kind of data change progress to be happened in client app by receiving the push notification with some payload.
     */

    public static final String KEY_GCM_DATA_PUSH =

            "dataPush";


    /**
     * Key Constant for isolating all kind of data change progress to be happened in client app with Actionable notification by receiving the push notification with some payload.
     */

    public static final String KEY_GCM_ACTIONABLE_PUSH =

            "actionPush";


    /**
     * Key Constant for isolating push Message with purpose of inApp messaging communication
     */

    public static final String KEY_GCM_INAPP_MESSAGE =

            "inAppMessage";


    /**
     * Key Constant for holding the value of inapp message body
     */

    public static final String KEY_INAPP_MESSAGE_BODY =

            "inAppMessageBody";

    /**
     * Key Constant for holding the value of from address for the inapp message
     */

    public static final String KEY_INAPP_MESSAGE_FROM =

            "inAppMessageFrom";

    /**
     * Key Constant for holding the value of time for the inapp message
     */

    public static final String KEY_INAPP_MESSAGE_TIME =

            "inAppMessageTime";


    /**
     * Key Constant for HOS State Description
     */

    public static final String KEY_GCM_HOS_STATE_DESC =

            "gcmHOSStateDesc";


    /**
     * Key Constant for HOS State ID
     */

    public static final String KEY_GCM_HOS_STATE_ID =

            "gcmHOSStateID";


    /**
     * Key Constant for data message
     */

    public static final String KEY_GCM_DATA_MESSAGE = "gcmDataMessage";


    /**
     * Key Constant for data message title
     */

    public static final String KEY_GCM_DATA_TITLE = "gcmDataMessageTitle";


    /**
     * Value Constant for checking the app installed status through - GCM_SILENT_PUSH Key.
     */

    public static final String VAL_CHECK_INSTALLATION_STATUS =

            "checkInstallationStatus";


    /**
     * Value Constant for checking the app installed status - through GCM_SILENT_PUSH Key.
     */

    public static final String VAL_RESTART_CLIENT_APP =

            "restartClientApplication";


    /**
     * Value Constant for letting the client application know about the changes in customer site list - through GCM_SILENT_PUSH Key.
     */

    public static final String VAL_CUSTOMER_SITES_UPDATED =

            "customerSitesUpdated";


    /**
     * Value Constant for letting the client application know about the changes in job site list - through GCM_SILENT_PUSH Key.
     */

    public static final String VAL_JOB_SITES_UPDATED =

            "jobSitesUpdated";


    /**

     * Value Constant for letting the client application know about the changes in HOS Labels like added,removed or updated - through GCM_SILENT_PUSH Key.

     */

    public static final String VAL_HOS_LABELS_UPDATED =

            "hosLabelsUpdated";



    /**
     * Value Constant for asking the client application to send some debug info - through GCM_SILENT_PUSH Key.
     */

    public static final String VAL_REQUEST_DEBUG_INFO =

            "requestDebugInfo";


    /**
     * Value Constant for asking the client application to process HeartBeat API Request instantly - through GCM_SILENT_PUSH Key.
     */

    public static final String VAL_REQUEST_HEARTBEAT_DATA =

            "requestHeartBeatData";


    /**
     * Value Constant for asking the client application to send any pending transactions like HOS/Notes - through GCM_SILENT_PUSH Key.
     */

    public static final String KEY_PENDING_TRANSACTIONS_TYPE =

            "keyForPendingTransactionType";


    /**
     * Key Constant for notifying the client application about tracking schedule start and stop information- through GCM_SILENT_PUSH type.
     */

    public static final String KEY_TRACKING_STATE =

            "keyForTrackingScheduleState";



    public static final String KEY_TRACKING_FREQUENCY = "keyForTrackingScheduleFrequency";

    /**
     * Value Constant for asking the client application to send any pending transactions like HOS/Notes - through GCM_SILENT_PUSH Key.
     */

    public static final String VAL_REQUEST_PENDING_TRANSACTIONS =

            "requestAllPendingTransactions";


    /**
     * Value Constant for asking the client application to send HOS pending transactions- through GCM_SILENT_PUSH Key.
     */

    public static final String VAL_REQUEST_CURRENT_LOCATION = "requestCurrentLocation";


    /**
     * Value Constant for notifying the client application about tracking started - through KEY_TRACKING_STATE Key.
     */

    public static final String VAL_TRACKING_STARTED = "notifyTrackingScheduleStarted";

    /**
     * Value Constant for notifying the client application about tracking stopped - through KEY_TRACKING_STATE Key.
     */

    public static final String VAL_TRACKING_STOPPED = "notifyTrackingScheduleStopped";

    /**
     * Value Constant for notifying the client application about tracking schedule start and stop information- through GCM_SILENT_PUSH Key.
     */

    public static final String VAL_NOTIFY_TRACKING_SCHEDULE_CHANGES = "notifyTrackingScheduleChanges";


    /**
     * Value Constant for notifying the client application about the changes happened in configuration related to mobile app - through GCM_SILENT_PUSH Key.
     */

    public static final String VAL_NOTIFY_CONFIGURATION_CHANGES =

            "notifyConfigurationChanges";


    /**
     * Value Constant for notifying the client application about TimeClock status changes happened in the server - through GCM_DATA_PUSH Key.
     */

    public static final String VAL_NOTIFY_TIMECLOCK_CHANGES =

            "notifyTimeClockChanges";


    /**
     * Value Constant for notifying the client application about TimeClock status changes happened in the server - through GCM_DATA_PUSH Key.
     */

    public static final String VAL_REMIND_TO_RELAUNCH =

            "remindToReLaunch";


    /**
     * Value Constant for notifying the client application about TimeClock status changes happened in the server - through GCM_DATA_PUSH Key.
     */

    public static final String VAL_REMIND_TO_TIMECLOCK =

            "remindToTimeClock";


    /**
     * Value Constant for notifying the client application about TimeClock status changes happened in the server - through GCM_DATA_PUSH Key.
     */

    public static final String VAL_REMIND_ABOUT_UPDATED_VERSION =

            "remindAboutUpdatedVersion";


    /**
     * Value Constant for sending inApp Messages.
     */

    public static final String VAL_PLAIN_IN_APP_MESSAGE =

            "plainInAppMessage";


    /**
     * Value Constant for notifying General message contents
     */

    public static final String VAL_INFO_NOTIFIACTIONS = "generalInformationNotifications";


    /**
     * Constant for pending transactions type HOS
     */

    public static final String PENDING_TRANSACTIONS_TYPE_HOS = "pendingTransactionTypesHOS";


    /**
     * Constant for pending transactions type Notes
     */

    public static final String PENDING_TRANSACTIONS_TYPE_NOTES = "pendingTransactionTypesNotes";


    /**
     * Constant for pending transactions type All
     */

    public static final String PENDING_TRANSACTIONS_TYPE_ALL = "pendingTransactionTypesAll";


    /**
     * Constant for pending transactions type Attachments
     */

    public static final String PENDING_TRANSACTIONS_TYPE_ATTACHMENTS = "pendingTransactionTypesAttachments";



    /**

     * Value Constant for letting the client application know about the changes in Forms list changed like added,removed or updated - through GCM_SILENT_PUSH Key.

     */

    public static final String VAL_FORMS_LIST_UPDATED = "formsListUpdated";
}
package net.abaqus.mygeotracking.deviceagent.utils;

import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlSerializer;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;

import com.facebook.network.connectionclass.DeviceBandwidthSampler;

public class LocationPUSHTask extends AsyncTask<String, Void, Boolean> {
	//**FIELDS**//
	private static final String TAG = LocationPUSHTask.class.getSimpleName();


	private Context mContext;
	
	//String hos_value_to_push;
	//ProgressDialog m_ProgressDialog;
	private SharedPreferences prefs;
	private String requestedTimestamp = "";
	private SharedPreferences.Editor edit_prefs;
	//private AlertDialog.Builder builder;
	//private final int ERROR_OCCURED = 0;
	//private final int OPTIN_SUCCESS = 1;
	//private final int PIN_EMPTY = 2;
	
	
	//private boolean pin_empty;
	
	SAXParserFactory spf = null; 
    SAXParser sp = null;
    /* Get the XMLReader of the SAXParser we created. */ 
    XMLReader xr = null;
    /* Create a new ContentHandler and apply it to the XML-Reader*/ 
    LocationPushXmlHandler locationPUSHHandler = null;
	
	//CONS
	/*private static final String PROG_TITLE = "Please Wait";
	private static final String PROG_MSG = "Processing...";*/
	
    
	
	public LocationPUSHTask(Context con) {
		this.mContext = con;
		this.prefs = con.getSharedPreferences(MDACons.PREFS, 0);
		
		
	        
	        locationPUSHHandler=new LocationPushXmlHandler();
	      
	}
	
	public LocationPUSHTask(Context con, String withTimestamps) {
		this.mContext = con;
		this.prefs = con.getSharedPreferences(MDACons.PREFS, 0);
		locationPUSHHandler = new LocationPushXmlHandler();
		requestedTimestamp = withTimestamps;
	}

	protected void onPreExecute() {
		DeviceBandwidthSampler.getInstance().startSampling();

		//m_ProgressDialog = ProgressDialog.show(mContext, PROG_TITLE, PROG_MSG , true);
		
		//save data into database
		//hos_value_to_push = ""+prefs.getInt(MDACons.HOS_SELECTION, -1);
	}

		
	protected void onPostExecute(Boolean success) {
		DeviceBandwidthSampler.getInstance().stopSampling();

		/*if(m_ProgressDialog.isShowing())
		m_ProgressDialog.dismiss();*/
		
		//check for response and delete or keep the value in database
		
		/*if (!hosPUSHXMLHandler.error_occured)
			doCreateDialog(OPTIN_SUCCESS);
		else if (!success)
			doCreateDialog(PIN_EMPTY);
		else
			doCreateDialog(ERROR_OCCURED);*/
		
	}
	
	protected Boolean doInBackground(String... urls) {
		
		DebugLog.debug(TAG, "REQUEST" + MDACons.SERVER_URL+"updateEventData");
		
		
		
			
		
		
		ConnectionManager cm = new ConnectionManager();
		cm.setupHttpPost(MDACons.SERVER_URL+"updateEventData");
		cm.setHttpHeader("Content-Type", "application/xml");
		
		
		XmlSerializer serializer = Xml.newSerializer();
		StringWriter writer = new StringWriter();
		try{   
		serializer.setOutput(writer);
        
		serializer.startDocument("UTF-8", true);
        serializer.startTag(null, "MGTRequest");
        /*serializer.startTag(null, "Account");
        serializer.text("Demo");
        serializer.endTag(null,"Account");*/
        serializer.startTag(null, "DeviceLocation");


			Date date = new Date(CurrentDateAndTime.getTime());
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US);
			GregorianCalendar gc = new GregorianCalendar();
			String native_location_time = formatter.format(date.getTime());

			edit_prefs = prefs.edit();
			edit_prefs.putString(MDACons.NATIVE_LAST_LOCATION_EVENT_TIME,native_location_time);
			edit_prefs.commit();

        
        serializer.startTag(null, "Device");
        serializer.text(prefs.getString(MDACons.DEVICE_NUMBER, ""));
        serializer.endTag(null,"Device");
        
        serializer.startTag(null, "Time");
        serializer.text(CurrentDateAndTime.getDateTime(new SimpleDateFormat("yyyy:MM:dd,HH:mm:ss")));
        serializer.endTag(null,"Time");
         
        serializer.startTag(null, "RequestedTime");
        serializer.text(requestedTimestamp);
        serializer.endTag(null,"RequestedTime");

        serializer.startTag(null, "StatusCode");
        serializer.text("0xF020");
        serializer.endTag(null,"StatusCode");
        
        serializer.startTag(null, "Field");
        serializer.attribute("","name", "latitude");
        serializer.text(CurrentDateAndTime.getLatValue()+"");
        serializer.endTag(null,"Field");
        
        serializer.startTag(null, "Field");
        serializer.attribute("","name", "longitude");
        serializer.text(CurrentDateAndTime.getLonValue()+"");
        serializer.endTag(null,"Field");
        
        serializer.startTag(null, "Field");
        serializer.attribute("","name", "deviceMethod");
        serializer.text(CurrentDateAndTime.getDeviceMethod());
        serializer.endTag(null,"Field");
        
        serializer.startTag(null, "Field");
        serializer.attribute("","name", "horzAccuracy");
        serializer.text(CurrentDateAndTime.getAccuracy());
        serializer.endTag(null,"Field");


			List<Address> addressArray = null;
			try{
				Geocoder geocoding = new Geocoder(mContext);
				addressArray = geocoding.getFromLocation(
						CurrentDateAndTime.getLatValue(),
						CurrentDateAndTime.getLonValue(), 2);


			}catch(Exception e){
				e.printStackTrace();
			}

			if(addressArray != null && addressArray.size() > 0)
				try {
					if (addressArray.get(0).getAddressLine(0) != null) {
						serializer.startTag(null, "AddressModel");
						String addressLine = "";
						for(int i = 0; i < addressArray.get(0).getMaxAddressLineIndex()+1; i++) {
							if(addressLine.length() > 0)
								addressLine = addressLine +", "+ addressArray.get(0).getAddressLine(i);
							else
								addressLine = addressLine + addressArray.get(0).getAddressLine(i);
						}
						serializer.text(addressLine);
						serializer.endTag(null,"AddressModel");
					}
//					if (addressArray.get(0).getLocality() != null) {
//						serializer.startTag(null, "City");
//						serializer.text(addressArray.get(0).getLocality());
//						serializer.endTag(null,"City");
//					}
//					if (addressArray.get(0).getFeatureName() != null) {
//						serializer.startTag(null, "Street");
//						serializer.text(addressArray.get(0).getFeatureName());
//						serializer.endTag(null,"Street");
//					}
//					if (addressArray.get(0).getAdminArea() != null) {
//						serializer.startTag(null, "State");
//						serializer.text(addressArray.get(0).getAdminArea());
//						serializer.endTag(null,"State");
//					}
//					if (addressArray.get(0).getCountryName() != null) {
//						serializer.startTag(null, "Country");
//						serializer.text(addressArray.get(0).getCountryName());
//						serializer.endTag(null,"Country");
//					}
//					if (addressArray.get(0).getPostalCode() != null){
//						serializer.startTag(null, "Zip");
//						serializer.text(addressArray.get(0).getPostalCode());
//						serializer.endTag(null,"Zip");
//					}
				} catch (Exception e) {
					e.printStackTrace();
				}




//        serializer.startTag(null, "AddressModel");
//        serializer.text(CurrentDateAndTime.getAddress());
//        serializer.endTag(null,"AddressModel");

        /*serializer.startTag(null, "Field");
        serializer.attribute("", "address","null");
        serializer.endTag(null,"Field");*/
        
        serializer.startTag(null, "UUID");
	    serializer.text(prefs.getString(MDACons.DEVICE_GUID, ""));
	    serializer.endTag(null,"UUID");
	     
	    String versionName = "";
        String bundleid = "";
		try {
			bundleid = mContext.getPackageManager()
					.getPackageInfo(mContext.getPackageName(), 0).packageName;
			versionName =mContext.getPackageManager()
					.getPackageInfo(mContext.getPackageName(), 0).versionName;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
	    
	    serializer.startTag(null, "AgentVersion");
	    serializer.text(versionName);
	    serializer.endTag(null,"AgentVersion");
	    
	    serializer.startTag(null, "BundleID");
	    serializer.text(bundleid);
	    serializer.endTag(null,"BundleID");
	    
	    serializer.startTag(null, "Platform");
	    serializer.text("Android");
	    serializer.endTag(null,"Platform");
        
        
        serializer.endTag(null, "DeviceLocation");
        serializer.endTag(null,"MGTRequest");
        serializer.endDocument();
		}catch (Exception e) {
			
		}
        HttpEntity en = null;
		try {
			en = new StringEntity(writer.toString());
		} catch (UnsupportedEncodingException e2) {
			e2.printStackTrace();
		}
    	try {
			Log.i("REQUEST",EntityUtils.toString(en));
		} catch (Exception e1) {
			e1.printStackTrace();
		} 
		cm.setHttpPostEntity(en);
		
		
		try {
			InputSource m_is = cm.makeRequestGetResponse();
			 spf = SAXParserFactory.newInstance(); 
		        sp = spf.newSAXParser(); 
		
		        /* Get the XMLReader of the SAXParser we created. */ 
		        xr = sp.getXMLReader(); 
			 xr.setContentHandler(locationPUSHHandler);
			xr.parse(m_is);
			
			
		}catch (Exception e)
		{
			e.printStackTrace();
		}
		return true;
	}


	public static String error_message = "", last_logged_value="", auth_token = "";
	
	public class LocationPushXmlHandler extends DefaultHandler{

		private boolean in_GTSResponseTag = false;
		private boolean in_Comment = false;
		
		

		
		public boolean error_occured = false;
		// =========================================================== 
	    // Methods 
	    // =========================================================== 
		public String getValue() {
			return last_logged_value;
		}
		public String getToken() {
			return auth_token;
		}
		public String getErrorMSG(){
			return error_message;
		}
		
		@Override 
	    public void startDocument() throws SAXException { 
	         
	    } 

	    @Override 
	    public void endDocument() throws SAXException { 
	         // Nothing to do 
	    }
	    
	    public void startElement(String namespaceURI, String localName, 
	              String qName, Attributes atts) throws SAXException { 
	    	
	    	if (localName.equals("MGTResponse")) { 
	            this.in_GTSResponseTag = true;
	            if(atts.getValue("result").equalsIgnoreCase("error"))
	            {
	            	error_occured = true;
	            }
	       }else if (localName.equals("Comment")) { 
	           this.in_Comment = true; 
	      }
	    	
	       
	    } /* startELement */
	    
	    @Override 
	    public void endElement(String namespaceURI, String localName, String qName) 
	              throws SAXException { 
	    	if (localName.equals("MGTResponse")) { 
	            this.in_GTSResponseTag = false;
	       }else if (localName.equals("Comment")) { 
	            this.in_Comment = false; 
	       }
	       
	    } 

	    @Override 
	   public void characters(char ch[], int start, int length) { 
	    	if (in_GTSResponseTag && in_Comment )
	    	{
	    		if (error_occured){
	    		error_message = new String(ch,start,length);
	    		//MDAMainActivity.pinOptinErrorCloseButtonPressedFromAsyncTask(error_message);
	    		}
	    		else
	    		error_message = "Optin PIN Sent to server Successfully.";
	    	}
	    	
	    }/* characters*/
	}

	
}
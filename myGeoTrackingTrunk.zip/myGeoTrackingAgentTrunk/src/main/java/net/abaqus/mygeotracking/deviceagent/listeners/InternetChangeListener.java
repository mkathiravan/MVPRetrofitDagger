package net.abaqus.mygeotracking.deviceagent.listeners;

/**
 * Created by root on 14/11/17.
 */

public interface InternetChangeListener {
    void onInternetChanged();
}

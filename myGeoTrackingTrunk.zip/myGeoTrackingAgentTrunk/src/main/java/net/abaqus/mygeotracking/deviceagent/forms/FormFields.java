package net.abaqus.mygeotracking.deviceagent.forms;

/**
 * Created by user on 04-07-2018.
 */

public class FormFields {

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    String name;
    String value;
}

package net.abaqus.mygeotracking.deviceagent.listeners;

/**
 * Created by bm on 4/6/15.
 */
public interface TaskCompleteListener {
        void onTaskCompleted(boolean success);
}

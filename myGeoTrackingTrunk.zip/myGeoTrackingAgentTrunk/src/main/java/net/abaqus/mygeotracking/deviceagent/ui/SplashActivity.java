package net.abaqus.mygeotracking.deviceagent.ui;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.crashlytics.android.Crashlytics;
import com.google.firebase.analytics.FirebaseAnalytics;

import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.utils.DeviceUtils;

/**
 * Created by root on 15/5/17.
 */

public class SplashActivity extends ReceiverActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        mFirebaseAnalytics.setUserId(DeviceUtils.getAndroidID(SplashActivity.this));
        mFirebaseAnalytics.setUserProperty("mgt_track_id", DeviceUtils.getAndroidID(SplashActivity.this));
        mFirebaseAnalytics.setCurrentScreen(this, SplashActivity.class.getSimpleName(), null /* class override */);

        Crashlytics.log("Splash Activity opened and moving to register activity");
        Intent intent = new Intent(this, RegisterDeviceActivity.class);
        startActivity(intent);
        finish();
        // ATTENTION: This was auto-generated to handle app links.
        Intent appLinkIntent = getIntent();
        String appLinkAction = appLinkIntent.getAction();
        Uri appLinkData = appLinkIntent.getData();
    }
}

package net.abaqus.mygeotracking.deviceagent.data;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.myteam.MyTeamData;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

import java.util.ArrayList;

/**
 * Created by bm on 20/10/15.
 */
public class MyTeamSearchProvider {

    private static final String TAG = MyTeamSearchProvider.class.getSimpleName();

    AgentDataBaseDBHelper database;

    public MyTeamSearchProvider(Context c)
    {
        database = new AgentDataBaseDBHelper(c);
    }


    public void close()
    {
        if(database != null)
            database.close();
    }
    public ArrayList<MyTeamData> readMyTeamData(String searchTerm) {

        ArrayList<MyTeamData> recordsList = new ArrayList<MyTeamData>();

        DebugLog.debug(TAG, searchTerm.contains("'") + "");
        DebugLog.debug(TAG, searchTerm.contains("\'")+"");


        // select query
        if (searchTerm.contains("'"));{

            searchTerm = searchTerm.replace("'","\\'");
        }

        DebugLog.debug(TAG, searchTerm);

        String sql = "";
        Cursor cursor;
        SQLiteDatabase db = database.getWritableDatabase();
        if (searchTerm.length() == 0){
            sql += "SELECT * FROM " + MyTeamTable.MYTEAM_TABLE;
            //sql += " WHERE " + MyTeamTable.MT_DEVICE_DESC +" LIKE ? ";
            // sql += "AND "+HOSCustomerANDJobTable.HOS_CJ_NAME + " LIKE ? ";
            sql += " ORDER BY " + MyTeamTable.COLUMN_ID + " DESC";
            //sql += " LIMIT 0,5";
            cursor = db.rawQuery(sql, new String[]{});

        }else{
            sql += "SELECT * FROM " + MyTeamTable.MYTEAM_TABLE;
            sql += " WHERE " + MyTeamTable.MT_DEVICE_DESC +" LIKE ? ";
            //sql += "AND "+HOSCustomerANDJobTable.HOS_CJ_NAME + " LIKE ? ";
            sql += " ORDER BY " + MyTeamTable.COLUMN_ID + " DESC";
            //sql += " LIMIT 0,5";
            cursor = db.rawQuery(sql, new String[] {"%" + searchTerm + "%"});

        }

        // execute the query
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {

                MyTeamData myTeamData = new MyTeamData();
                myTeamData.setDeviceDescription(cursor.getString(cursor.getColumnIndex(MyTeamTable.MT_DEVICE_DESC)));
                myTeamData.setDeviceNumber(cursor.getString(cursor.getColumnIndex(MyTeamTable.MT_DEVICE_ID)));
                myTeamData.setGroupName(cursor.getString(cursor.getColumnIndex(MyTeamTable.MT_GROUP_NAME)));
                myTeamData.setAddressString(cursor.getString(cursor.getColumnIndex(MyTeamTable.MT_ADDRESS)));
                myTeamData.setLatitude(cursor.getString(cursor.getColumnIndex(MyTeamTable.MT_LATITUDE)));
                myTeamData.setLongitude(cursor.getString(cursor.getColumnIndex(MyTeamTable.MT_LONGITUDE)));
                myTeamData.setUpdatedTime(cursor.getString(cursor.getColumnIndex(MyTeamTable.MT_UPDATED_TIME)));
                myTeamData.setLastHosStage(cursor.getString(cursor.getColumnIndex(MyTeamTable.MT_LAST_HOS_STAGE)));
                myTeamData.setLastMessage(cursor.getString(cursor.getColumnIndex(MyTeamTable.MT_MESSAGE)));
                myTeamData.setChecked(false);
                // add to list
                recordsList.add(myTeamData);

            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        // return the list of records
        return recordsList;
    }
}

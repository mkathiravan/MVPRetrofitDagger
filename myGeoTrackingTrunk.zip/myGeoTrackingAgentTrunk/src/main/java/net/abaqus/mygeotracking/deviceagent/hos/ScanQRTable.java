package net.abaqus.mygeotracking.deviceagent.hos;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;


@Table(name = "ScanQRTable", id = "_id")
public class ScanQRTable extends Model {


    @Column(name = "QR")
    public String QR;

    @Column(name = "history_info_id")
    public String history_info_id;


    public String getQR() {
        return QR;
    }

    public void setQR(String QR) {
        this.QR = QR;
    }

    public String getHistory_info_id() {
        return history_info_id;
    }

    public void setHistory_info_id(String history_info_id) {
        this.history_info_id = history_info_id;
    }
}

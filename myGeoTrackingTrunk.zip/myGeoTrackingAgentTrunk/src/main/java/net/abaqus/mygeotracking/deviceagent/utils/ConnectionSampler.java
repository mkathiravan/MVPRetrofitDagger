package net.abaqus.mygeotracking.deviceagent.utils;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.facebook.network.connectionclass.ConnectionClassManager;
import com.facebook.network.connectionclass.ConnectionQuality;
import com.facebook.network.connectionclass.DeviceBandwidthSampler;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by root on 31/7/17.
 */

public class ConnectionSampler {

    private static final String TAG = "ConnectionSampler";

    private static ConnectionClassManager mConnectionClassManager;
    private static DeviceBandwidthSampler mDeviceBandwidthSampler;

    private static String mURL = "http://placehold.it/150/771796";
    private static int mTries = 0;
    private static ConnectionQuality mConnectionClass = ConnectionQuality.UNKNOWN;

    private static ConnectionChangedListener mListener;
    public static void doSmapling(Context mContext) {

        mConnectionClassManager = ConnectionClassManager.getInstance();
        mDeviceBandwidthSampler = DeviceBandwidthSampler.getInstance();
        mListener = new ConnectionChangedListener();
        mConnectionClassManager.register(mListener);
        new DownloadImage().execute(mURL);
    }


    /**
     * AsyncTask for handling downloading and making calls to the timer.
     */
    private static class DownloadImage extends AsyncTask<String, Void, Void> {

        @Override
        protected void onPreExecute() {
            mDeviceBandwidthSampler.startSampling();
            Log.i(TAG, "Started Sampling mTries = " + mTries);
        }

        @Override
        protected Void doInBackground(String... url) {
            String imageURL = url[0];
            try {
                // Open a stream to download the image from our URL.
                URLConnection connection = new URL(imageURL).openConnection();
                connection.setUseCaches(false);
                connection.connect();
                InputStream input = connection.getInputStream();
                try {
                    byte[] buffer = new byte[1024];

                    // Do some busy waiting while the stream is open.
                    while (input.read(buffer) != -1) {
                    }
                } finally {
                    input.close();
                }
            } catch (IOException e) {
                Log.e(TAG, "Error while downloading image.");
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void v) {
            mDeviceBandwidthSampler.stopSampling();
            Log.i(TAG, "Stopped Sampling mTries = " + mTries);
            if(mConnectionClass == ConnectionQuality.POOR) {
                Log.i(TAG, "POOR");
            } else if(mConnectionClass == ConnectionQuality.MODERATE) {
                Log.i(TAG, "MODERATE");
            } else if(mConnectionClass == ConnectionQuality.UNKNOWN) {
                Log.i(TAG, "UNKNOWN");
            } else if(mConnectionClass == ConnectionQuality.EXCELLENT){
                Log.i(TAG, "EXCELLENT");
            } else if(mConnectionClass == ConnectionQuality.GOOD){
                Log.i(TAG, "GOOD");
            }
            // Retry for up to 10 times until we find a ConnectionClass.
            if (mConnectionClass == ConnectionQuality.UNKNOWN && mTries < 10) {
                mTries++;
                new DownloadImage().execute(mURL);
            } else {
                mConnectionClassManager.remove(mListener);
            }
        }
    }


    /**
     * Listener to update the UI upon connectionclass change.
     */
    private static class ConnectionChangedListener
            implements ConnectionClassManager.ConnectionClassStateChangeListener {

        @Override
        public void onBandwidthStateChange(ConnectionQuality bandwidthState) {
            mConnectionClass = bandwidthState;
        }
    }



}

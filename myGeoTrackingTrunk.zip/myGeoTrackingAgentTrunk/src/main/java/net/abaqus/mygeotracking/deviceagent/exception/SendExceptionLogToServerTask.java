package net.abaqus.mygeotracking.deviceagent.exception;

import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

import net.abaqus.mygeotracking.deviceagent.utils.ConnectionManager;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.xml.sax.InputSource;
import org.xmlpull.v1.XmlSerializer;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;
import android.widget.Toast;

public class SendExceptionLogToServerTask extends AsyncTask<String, Integer, Boolean>{

	private static final String TAG = SendExceptionLogToServerTask.class.getSimpleName();

	Context mContext;
    public SendExceptionLogToServerTask(Context con) {
	mContext = con;
    }
    
	@Override
	protected Boolean doInBackground(String... params) {

		DebugLog.debug(TAG, params[0].toString());
		ConnectionManager cm = new ConnectionManager();
		cm.setupHttpPost(MDACons.SERVER_URL+"deviceExceptionLog");
		cm.setHttpHeader("Content-Type", "application/xml");
		XmlSerializer serializer = Xml.newSerializer();
		StringWriter writer = new StringWriter();
		try{   
		serializer.setOutput(writer);
		serializer.startDocument("UTF-8", true);
		serializer.startTag(null, "MGTRequest");
		/*serializer.startTag(null, "Account");
   		serializer.text("Demo");
   		serializer.endTag(null,"Account");*/
		serializer.startTag(null, "LogText");
		serializer.text(params[0]);
		serializer.endTag(null,"LogText");
               serializer.endTag(null,"MGTRequest");
               serializer.endDocument();
           	}catch (Exception e) {
           	}
               HttpEntity en = null;
           	try {
			en = new StringEntity(writer.toString());
		} catch (UnsupportedEncodingException e2) {
			e2.printStackTrace();
		}
           	try {
			Log.i("REQUEST",EntityUtils.toString(en));
		} catch (Exception e1) {
			e1.printStackTrace();
		} 
		cm.setHttpPostEntity(en);
		
		
		try {
			InputSource m_is =  cm.makeRequestGetResponse();
		}catch (Exception e)
		{
			e.printStackTrace();
		}
		
		 
	    return null;
	}
	
	@Override
	protected void onPostExecute(Boolean result) {

	    
	  super.onPostExecute(result);
	}
	@Override
	protected void onPreExecute() {
	super.onPreExecute();
	Toast.makeText(mContext, "Restarting Agent", Toast.LENGTH_SHORT).show();
	
	}
   }
   
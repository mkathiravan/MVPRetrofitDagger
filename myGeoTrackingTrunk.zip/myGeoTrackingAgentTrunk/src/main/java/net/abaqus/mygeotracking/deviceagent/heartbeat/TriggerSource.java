package net.abaqus.mygeotracking.deviceagent.heartbeat;

public class TriggerSource {

    /*Whenever the app is launched*/
    public static final String APP_LAUNCHED = "AppLaunched";
    /*Whenever the device is rebooted*/
    public static final String DEVICE_REBOOT_COMPLETED = "DeviceRebootCompleted";
    /*Whenever user changes the location setting in Device Settings*/
    public static final String LOCATION_SETTINGS_CHANGED = "LocationSettingsChanged";
    /*Whenever the app receives Push notification request from server to send a heartbeat to server*/
    public static final String PUSH_NOTIFICATION_REQUEST = "PushNotifRequest";
    /*Whenever user presses Send Debug Info in app Settings screen.*/
    public static final String DEBUG_INFO_SENT = "DebugInfoSent";
    /*Heartbeat Schedule based Triggers*/
    public static final String SCHEDULE = "Schedule";

}

package net.abaqus.mygeotracking.deviceagent.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.widget.Button;

public class MDAEula {

	//private String EULA_PREFIX = "eula_";
	private Activity mActivity;

	public MDAEula(Activity activity) {
		mActivity = activity;
		loadedStringBuffer = loadEulaText();
	}

	private PackageInfo getPackageInfo() {
		PackageInfo pi = null;
			try {
				pi = mActivity.getPackageManager().getPackageInfo(mActivity.getPackageName(), PackageManager.GET_ACTIVITIES);
			} catch (PackageManager.NameNotFoundException e) {
				e.printStackTrace();
			}
		return pi;
	}

	/*public void show() {
		PackageInfo versionInfo = getPackageInfo();
		*//** The eulaKey changes every time you increment the version number in
		    the AndroidManifest.xml. Later we changed as ask only once while installing the app.*//*
		final String eulaKey = EULA_PREFIX;// + versionInfo.versionCode;
		final SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(mActivity);
		boolean hasBeenShown = prefs.getBoolean(eulaKey, false);
		// hasBeenShown = true;
			if (hasBeenShown == false) {
				// get Eula Text from Assets directory
				String title = mActivity.getString(R.string.app_name) + " v"+ versionInfo.versionName;
				
	
				AlertDialog.Builder builder = new AlertDialog.Builder(mActivity)
				.setTitle(title)
				.setMessage(loadedStringBuffer);
				
				builder.setPositiveButton(android.R.string.ok,
						new Dialog.OnClickListener() {
	
					@Override
					public void onClick(
							DialogInterface dialogInterface, int i) {
						// Mark this version as read.
						SharedPreferences.Editor editor = prefs.edit();
						editor.putBoolean(eulaKey, true);
						editor.commit();
						dialogInterface.dismiss();
						SharedPreferences sh_prefs = mActivity.getSharedPreferences(MDACons.PREFS, 0);
							if (sh_prefs.getString(MDACons.DEVICE_NUMBER, "").length() > 2) {
								Intent mda_main_view = new Intent(mActivity.getApplicationContext(),MDAMainActivity.class);
								// mda_main_view.putExtra("id_type",
								// MDACons.IDENTITY_TYPE_TEL);
								mActivity.startActivity(mda_main_view);
								((Activity) (mActivity)).finish();
							} else {
		
								Intent mda_main_view = new Intent(mActivity.getApplicationContext(),SetIdentitiesActivity.class);
								mda_main_view.putExtra("id_type",MDACons.IDENTITY_TYPE_TEL);
								mActivity.startActivity(mda_main_view);
								((Activity) (mActivity)).finish();
							}
					}
				});
				builder.setNegativeButton(android.R.string.cancel,new Dialog.OnClickListener() {
	
					@Override
					public void onClick(DialogInterface dialog,
							int which) {
						// Close the activity as user have declined the EULA
						mActivity.finish();
					}
				});
				
				AlertDialog dialog = builder.create();
				dialog.show();
				try {
					Button negButton = dialog.getButton(DialogInterface.BUTTON_NEGATIVE);
					Button posButton = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
					if(negButton != null && posButton != null){
						
					        negButton.setBackgroundResource(R.drawable.bluebtnbgnewdullish);
					        posButton.setBackgroundResource(R.drawable.bluebtnbgnew);
					        negButton.setTextColor(Color.WHITE);
					        posButton.setTextColor(Color.WHITE);
					        
					}
				}
				catch (Exception e) {
					
				}
			} else {
				Intent mda_main_view = new Intent(mActivity.getApplicationContext(), MDAMainActivity.class);
				mActivity.startActivity(mda_main_view);
				((Activity) (mActivity)).finish();
			}
	}*/
	
	
	
	
	
	
	
	StringBuffer loadedStringBuffer = new StringBuffer();
	
	public void show(boolean onlyShow) {
	PackageInfo versionInfo = getPackageInfo();
	
			// get Eula Text from Assets directory
			String title = mActivity.getString(R.string.app_name) + " v"+ versionInfo.versionName;
			AlertDialog.Builder builder = new AlertDialog.Builder(mActivity)
			.setTitle(title)
			.setMessage(loadedStringBuffer);
			
				builder.setNegativeButton("Ok",new Dialog.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog,
						int which) {
					// Close the activity as user have declined the EULA
					dialog.dismiss();
				}
			});
			
			AlertDialog dialog = builder.create();
			dialog.show();
			try {
				Button negButton = dialog.getButton(DialogInterface.BUTTON_NEGATIVE);
				Button posButton = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
				if(negButton != null && posButton != null){
					
				        negButton.setBackgroundResource(R.drawable.bluebtnbgnewdullish);
				        posButton.setBackgroundResource(R.drawable.bluebtnbgnew);
				        negButton.setTextColor(Color.WHITE);
				        posButton.setTextColor(Color.WHITE);
				        
				}
			}
			catch (Exception e) {
				
			}
		
}

	private StringBuffer loadEulaText() {
	BufferedReader br = null;
	StringBuffer messageToShowEula = new StringBuffer();
		try {
			br = new BufferedReader(new InputStreamReader(mActivity.getAssets().open("eula.txt")));
			String temp;
			while ((temp = br.readLine()) != null)
				messageToShowEula.append(temp + "\n");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				br.close(); // stop reading
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return messageToShowEula;
	}
}
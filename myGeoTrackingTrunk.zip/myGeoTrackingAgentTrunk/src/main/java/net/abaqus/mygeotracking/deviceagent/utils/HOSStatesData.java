package net.abaqus.mygeotracking.deviceagent.utils;

import net.abaqus.mygeotracking.deviceagent.data.HOSEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSEntryTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSLabelsTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSLabelseContentProvider;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

public class HOSStatesData {
	public Context	mContext;
	
	public HOSStatesData(Context con) {
	this.mContext = con;
	}
	
	public Cursor getHOSEntries() throws Exception {
	
	String[] projection =
		{ HOSEntryTable.HOS_ENTRY_XML, HOSEntryTable.COLUMN_ID, HOSEntryTable.HOS_ENTRY_NO_OF_TRIES
/*				HOSEntryTable.HOS_ENTRY_CUSTOMER_ID,
				HOSEntryTable.HOS_ENTRY_JOB_ID,
				HOSEntryTable.HOS_ENTRY_LAT,
				HOSEntryTable.HOS_ENTRY_LON,
				HOSEntryTable.HOS_ENTRY_STATE,
				HOSEntryTable.HOS_ENTRY_TIME,
				HOSEntryTable.HOS_ENTRY_NEW_CUSTOMER,
				HOSEntryTable.HOS_ENTRY_NEW_JOB*/ };
	
	Cursor cursor = this.mContext.getContentResolver().query(
			Uri.parse(HOSEntryContentProvider.CONTENT_URI.toString()),
			projection, null, null, null);
	return cursor;
	}
	
	
public Cursor getHOSLabels() throws Exception {
	
	String[] projection =
		{ HOSLabelsTable.COLUMN_ID,
				HOSLabelsTable.HOS_LABEL,
				 };
	
	Cursor cursor = this.mContext.getContentResolver().query(
			Uri.parse(HOSLabelseContentProvider.CONTENT_URI.toString()),
			projection, null, null, null);
	return cursor;
	}
	
}
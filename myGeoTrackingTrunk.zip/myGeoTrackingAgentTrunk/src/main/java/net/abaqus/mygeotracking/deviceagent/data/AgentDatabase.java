package net.abaqus.mygeotracking.deviceagent.data;

import java.util.HashMap;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.provider.BaseColumns;
import android.util.Log;



public class AgentDatabase {
    public static final String DATABASE_NAME = "mgtagent.db";
    //Version increased after i added the hosentry table corrections with store version 2.3
    public static final int DATABASE_VERSION =29;
}

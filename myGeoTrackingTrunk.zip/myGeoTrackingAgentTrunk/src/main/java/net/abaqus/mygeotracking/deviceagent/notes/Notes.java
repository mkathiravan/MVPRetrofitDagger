package net.abaqus.mygeotracking.deviceagent.notes;

public class Notes {
	
	private String message_body = "";
	private String to_device = "";
	private String to_group = "";
	private String task_description = "";
	private String jobsite_description = "";
	private String task_id = "";
	private String qr_result = "";
	private String form_result = "";
	private String form_fdUID = "";

	
			
	public void setMessageBody(String value){
		message_body = value;
	}
	
	public String getMessageBody(){
		return message_body;
	}


	public void setjobsite_description(String value){
		jobsite_description = value;
	}

	public String getjobsite_description(){
		return jobsite_description;
	}

	public void setTask_description(String value){
		task_description = value;
	}

	public String getTask_description(){
		return task_description;
	}


	public void setTask_id(String value){
		task_id = value;
	}

	public String getTask_id(){
		return task_id;
	}

	public void setQr_result(String value){
		qr_result = value;
	}

	public String getQr_result(){
		return qr_result;
	}
	public void setForm_result(String value){
		form_result = value;
	}

	public String getForm_result(){
		return form_result;
	}

	
	public void setDeviceLsit(String value) {
		to_device = value;
	}
	
	public String getToDevice() {
		return to_device;
	}	
	
	public void setGroupList(String value) {
		to_group = value;
	}
	
	public String getToGroup() {
		return to_group;
	}

	public String getForm_fdUID() {
		return form_fdUID;
	}

	public void setForm_fdUID(String form_fdUID) {
		this.form_fdUID = form_fdUID;
	}

	public boolean toAvailable() {
		if(to_device.length()>1 || to_group.length()>1)
			return true;
		else
			return false;
	}
}

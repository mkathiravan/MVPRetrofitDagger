package net.abaqus.mygeotracking.deviceagent.utils;


public class MDACons {

	//public static String BASE_URL = "https://www.mygeotracking.com";
	//public static String BASE_URL = "http://10.1.6.106:8080";
	//public static String BASE_URL = "https://prerelease.mygeotracking.com";
	public static String BASE_URL = "https://staging.mygeotracking.com";
	//public static String BASE_URL = "https://stagingui.mygeotracking.com";
	public static String SERVER_URL = BASE_URL+"/track/agent/";
	public static String SERVER_URL_REST = BASE_URL+"/track/api/v1/";
	public static String SIXGILL_BASE_URL = "https://sense-api.sixgill.com/";



	/*Shared Preferences keys*/
	public static final String DEVICE_NUMBER = "mda_device_number";
	public static final String DEVICE_NUMBER_COUNTRY_CALLING_CODE = "mda_country_calling_code";
	public static final String DEVICE_GUID = "mda_device_guid";
	public static final String PREFS = "mda_prefs";
	public static final String AUTH_TOKEN = "token";
	public static final String HB_INTERVAL = "hb_interval";
	public static final String HB_INTERVAL_OLD = "hb_interval_old";
	public static final String PIN_NUMBER = "pin_number";
	public static final String HOS_SELECTION = "hos_selection";
	public static final String AGENT_DEVICE_ID = "agent_device_id";
	public static final String LAST_REGISTER_TIME = "last_register_time";
	public static final String SIXGILL_POSTING_EVENT_TIME = "sixgill_posting_event_time";
	public static final String SIXGILL_LAST_LOCATION_EVENT_TIME = "sixgill_last_event_time";
	public static final String NATIVE_LAST_LOCATION_EVENT_TIME = "native_last_event_time";
	public static final String CADENCE_SETTING_VALUE = "cadence_setting_value";

	public static final String MGT_CONFIGURATION_STATUS = "mgt_configuration_status";
	public static final String SCHUDELE_TRACK_STATUS = "schedule_track_status";

	public static final String HOS_TIME = "hos_time";
	public static final String HOS_CUSTOMER_SELECTED = "hos_customer_selected";
	public static final String HOS_JOB_SELECTED = "hos_job_selected";
	public static final String HOS_CUSTOMER_SELECTED_ID = "hos_customer_selected_id";
	public static final String HOS_JOB_SELECTED_ID = "hos_job_selected_id";
    public static final String HOS_WORK_SELECTED_ID = "hos_work_selected_id";
	public static final String HOS_SHOW_MENU = "hos_show_menu";
	public static final String HOS_MENU_AVAILABLE = "hos_menu_available";
	public static final String HOS_GROUP_ID = "hos_group_id";
	public static final String HOS_CUSTOMER_SELECTED_NEW = "hos_customer_selected_new";
	public static final String HOS_JOB_SELECTED_NEW = "hos_job_selected_new";
	public static final String HB_SENT_STATUS = "hb_sent_status";
	public static final String HOS_QUEUE_AVAILABLE	= "hos_queue_available";

	public static final String HOS_HISTORY_UPDATED_TIME = "hos_history_updated_time";


	public static final String TWILIO_SHORT_CODE	= "twilio_shortcode";
	public static final String SOS_EMER_COMMAND = "sos_emer_command";
	public static final String SOS_STAGE_PRESENT = "sos_stage_present";
	public static final String WORK_ORDER_TEXT = "work_order_text";
	public static final String WORK_ORDER_POS_ID = "work_order_pos_id";
	public static final String WORK_ORDER_NUMBER = "work_order_number";
	public static final String PROVIDER_NAME = "tlp";


	public static final String DEVICE_LOCATE_FREQUENCY = "device_locate_frequency";
	public static final String DEVICE_TRIP_START_TIME	= "device_trip_start_time";
	public static final String DEVICE_TRIP_END_TIME= "device_trip_end_time";
	public static final String TRIP_STARTS_SECONDS = "trip_starts_seconds";
	public static final String TRIP_END_SECONDS = "trip_end_seconds";

	public static final String LOG_TAG	= "MGT_AGENT_LOG"; 

	//REGISTRATION
	public static final String MGT_REGISTRATION_HAPPENED = "mgt_registration_happened";

	//MYTEAM
	public static final String MY_TEAM_SHOW_MENU = "myteam_show_menu";
	public static final String MY_TEAM_UPDATED_TIME = "myteam_updated_time";

	//WORKORDER
	public static final String WORK_ORDER_SHOW_MENU = "workorder_show_menu";

	public static final String REGISTER_STATUS = "register_status";
	public static final String SIXGILL_STATUS = "sixgill_status";

	//LOCATION CONSTANTS	
	public static final String LOCATION_INTERVAL = "mda_loca_interval";
	public static final String LOCATION_ENABLE_DISABLE = "mda_location_enable";

	//AUTO RELAUNCH OPTIONS
	public static final String AUTO_RELAUNCH_ENABLED_STATUS = "auto_relaunch__enabled";


	//LOCATION_SHOT_CONS
	public static final String LOCATION_SHOT_ACCURACY = "location_shot_accuracy";
	public static final String LOCATION_SHOT_TIMEOUT = "location_shot_timeout";
	
	//TO PULL UPDATE FOR CUS/JOB SITE LIST, WE SUPPOSED TO STORE LAST UPDATED DATE & TIME
	public static final String IS_JOB_SITE_MANDATORY = "is_job_site_mandatory";
	public static final String IS_CUSTOMER_MANDATORY = "is_customer_mandatory";
	public static final String IS_NOTES_MANDATORY = "is_notes_mandatory";

	//TO SUPPORT THE MANDATORY ITEMS WHILE CHECK IN CHECK OUT
	public static final String JOB_SITE_LAST_UPDATED_TIME = "job_site_last_updated_time";
	public static final String CUSTOMER_LAST_UPDATED_TIME = "customer_last_updated_time";
	public static final String FORMS_LAST_UPDATED_TIME = "forms_last_updated_time";

	public static final String	HOS_SELECTION_NAME	= "hos_selection_name";
	public static final String	HOS_SELECTION_SMS_COMMAND	= "hos_selection_sms_command";


	public static String MSG_SEND_YOUR_EMAIL_IN= "Send your email via:";
	public static String MSG_LOCATING_COUNT_DOWN_TIMER= "...Locating.  Time remaining =";


	public static String SCHEDULE_STATUS= "schedule_status";

	public static String ERROR_PROTOCOL_ERROR= "Something went wrong. Please relaunch the app and try again.";



	//Set the frequency for tracking

	public static String TRACKING_FREQUENCY = "tracking_frequency";
	public static String GET_ACCOUNT_LEVEL_PHONE_NO = "get_phone_number";
	public static String ACCOUNT_TYPE_NAME = "account_type_name";
	
}

package net.abaqus.mygeotracking.deviceagent.workorder;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.thoughtbot.expandablerecyclerview.ExpandableRecyclerViewAdapter;
import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class WorkOrderItemAdapter extends ExpandableRecyclerViewAdapter<WorkViewHolder,WorkOrderSubViewHolder>{


    private static final String TAG = WorkOrderItemAdapter.class.getSimpleName();
    private int lastSelectedPosition = -1;
    private SharedPreferences sh_prefs;
    private SharedPreferences.Editor sh_prefs_edit;

    Context mContext;
    public WorkOrderItemAdapter(Context context, List<? extends ExpandableGroup> groups) {
        super(groups);
        mContext = context;
        sh_prefs = context.getSharedPreferences(MDACons.PREFS, 0);
        sh_prefs_edit = sh_prefs.edit();
    }

    @Override
    public WorkViewHolder onCreateGroupViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.work_order_title_items,parent,false);
        return new WorkViewHolder(view);
    }

    @Override
    public WorkOrderSubViewHolder onCreateChildViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.work_order_sub_items,parent,false);
        return new WorkOrderSubViewHolder(view);
    }

    @Override
    public void onBindChildViewHolder(WorkOrderSubViewHolder holder, int flatPosition, ExpandableGroup group, int childIndex) {

        WorkOrderData workOrderData = ((Genre)group).getItems().get(childIndex);

        //Prepare and display stage actual time
        Date startDate = new Date(workOrderData.getStartTime());
        Date endDate = new Date(workOrderData.getEndTime());

        DateFormat df = new SimpleDateFormat("yyyy/MM/dd, hh:mm:ss");
        String dateAndTime = df.format(startDate);


        //Prepare and display sinceTime
        SimpleDateFormat inFormat = new SimpleDateFormat("hh:mm a");
        SimpleDateFormat onFormat = new SimpleDateFormat("MMM d, yyyy", Locale.ENGLISH);
        String sinceTime = inFormat.format(startDate);
        String onDate = onFormat.format(startDate);
        String startDayAndTime =sinceTime + " on " + onDate;

        String sinceTime1 = inFormat.format(endDate);
        String onDate1 = onFormat.format(endDate);
        String endDayAndTime = sinceTime1 + " on " + onDate1;


        holder.setFormName(workOrderData.getCustomerName(),workOrderData.getTaskName(),startDayAndTime,endDayAndTime,workOrderData.getAddress(),workOrderData.getStatus());

        int indexPosition=((Genre) group).getPosition();

        }

    @Override
    public void onBindGroupViewHolder(final WorkViewHolder holder, final int flatPosition, final ExpandableGroup group) {
        final ImageView imageView = holder.itemView.findViewById(R.id.list_item_form_arrow);
        final RadioButton radioButton = holder.itemView.findViewById(R.id.work_order_selected);
        if(((Genre)group).getItems().size()==0)
        {
            imageView.setVisibility(View.GONE);

            }else {
            imageView.setVisibility(View.VISIBLE);

        }



        radioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "FLATORISEERED "+ lastSelectedPosition + "DLFE "+flatPosition);
                lastSelectedPosition = flatPosition;
                notifyDataSetChanged();
                sh_prefs_edit.putString(MDACons.WORK_ORDER_POS_ID, ((Genre) group).getWorkOrderId());
                sh_prefs_edit.putString(MDACons.WORK_ORDER_NUMBER, ((Genre) group).getWorkOrderNumber());
                sh_prefs_edit.commit();
            }
        });

        radioButton.setChecked(lastSelectedPosition == flatPosition);

        SharedPreferences sharedPreferences = mContext.getSharedPreferences(MDACons.PREFS, 0);

        String work_order_pos_id = sharedPreferences.getString(MDACons.WORK_ORDER_POS_ID, "");

        if(work_order_pos_id.equalsIgnoreCase(((Genre) group).getWorkOrderId()))
        {
            radioButton.setChecked(work_order_pos_id == ((Genre) group).getWorkOrderId());
            radioButton.setChecked(true);
        }
        //Added this else part to avoid multiple selection in randomly.
        else
        {
            radioButton.setChecked(false);
        }

        holder.setGenreTitle(group,mContext,flatPosition);




    }





}

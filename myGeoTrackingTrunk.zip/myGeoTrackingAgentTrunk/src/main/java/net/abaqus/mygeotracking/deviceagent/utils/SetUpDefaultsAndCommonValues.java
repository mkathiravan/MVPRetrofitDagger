package net.abaqus.mygeotracking.deviceagent.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;

public class SetUpDefaultsAndCommonValues {
	
	private Context mContext = null;
	private SharedPreferences mda_prefs;
	private SharedPreferences.Editor prefs_edit;

	public SetUpDefaultsAndCommonValues(Context con){
		mContext = con;
		
		mda_prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
		prefs_edit = mda_prefs.edit();
		setLocationShotAccuracyDefault();
		setLocationShotTimeoutDefault();
		setLocationEnableDisableValue();
		setAutoRelaunchEnableDisableValue();
		if(!checkHOSDataAvailability() && mda_prefs.getString(MDACons.DEVICE_NUMBER, "").length()>2 || !mda_prefs.getBoolean(MDACons.MGT_REGISTRATION_HAPPENED, false))
			HOSPullCalls.makeHOSInitializeCallsInBg(mContext, true);

	}
	
	public SetUpDefaultsAndCommonValues(Context con, boolean checkHOS){
	mContext = con;
	
	mda_prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
	prefs_edit = mda_prefs.edit();
	if(!checkHOSDataAvailability()&& mda_prefs.getString(MDACons.DEVICE_NUMBER, "").length()>2 || !mda_prefs.getBoolean(MDACons.MGT_REGISTRATION_HAPPENED, false))
		HOSPullCalls.makeHOSInitializeCallsInBg(mContext, true);
}
	
	private void setLocationShotAccuracyDefault(){
		if (mda_prefs.getInt(MDACons.LOCATION_SHOT_ACCURACY, 0) == 0) {
				prefs_edit.putInt(MDACons.LOCATION_SHOT_ACCURACY, 500);
				prefs_edit.putLong(MDACons.JOB_SITE_LAST_UPDATED_TIME, -1);
				prefs_edit.putLong(MDACons.CUSTOMER_LAST_UPDATED_TIME, -1);
				prefs_edit.commit();
		}
	}
	
	private void setLocationShotTimeoutDefault(){
		if (mda_prefs.getInt(MDACons.LOCATION_SHOT_TIMEOUT, 0) == 0) {
			prefs_edit.putInt(MDACons.LOCATION_SHOT_TIMEOUT, 20);
			prefs_edit.commit();
		}
	}
	
	private void setLocationEnableDisableValue(){
		if (!mda_prefs.getBoolean(MDACons.LOCATION_ENABLE_DISABLE, false)) {
			prefs_edit.putBoolean(MDACons.LOCATION_ENABLE_DISABLE, true);
			prefs_edit.commit();
		}

	}
	
	private void setAutoRelaunchEnableDisableValue(){

			prefs_edit.putBoolean(MDACons.AUTO_RELAUNCH_ENABLED_STATUS, true);
			prefs_edit.commit();


	}
	
	
	private boolean checkHOSDataAvailability(){
	Cursor entryCursor =
			null;
		try {
			entryCursor = new HOSStatesData(mContext).getHOSLabels();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		if (entryCursor.getCount() > 0){
			    prefs_edit.putBoolean(MDACons.HOS_SHOW_MENU, true);
			    prefs_edit.commit();
				entryCursor.close();
				return true;
			    
		}else{
			prefs_edit.putBoolean(MDACons.HOS_SHOW_MENU, false);
			prefs_edit.commit();
			entryCursor.close();
			return false;
		}
		
		}
	

}

/*
 * Copyright 2010, YQ Soft Labs Pvt Ltd,abaqus.inc
 * Project Name: mygeodiary
 * Customer: 
 * Developed by: hiteshv@yqlabs.com
 */

package net.abaqus.mygeotracking.deviceagent.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.concurrent.TimeUnit;

import org.apache.http.HttpConnectionMetrics;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.ManagedClientConnection;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.SingleClientConnManager;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.xml.sax.InputSource;

import android.content.Context;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.bgthread.SimpleSSLSocketFactory;

public class ConnectionManager {

	private static final String TAG = ConnectionManager.class.getSimpleName();
	/** FIELDS */
    private DefaultHttpClient httpclient;
    private HttpPost httppost;
    private InputStream inputStreamResponse;
   	private String returnString; 
   	MeasuringConnManager conmanager;
   	
	/** FIELDS */
	
   	/*
	 * Default constructor
	 */
	public ConnectionManager()
	{
		
	}
	
	/*
	 * Setup HTTPPost HTTP
	 */
	
	public void setupHttpPost(String uri)
	{
		try {
			// Setup a custom SSL Factory object which simply ignore the certificates validation and accept all type of self signed certificates
			SSLSocketFactory sslFactory = new SimpleSSLSocketFactory(null);
			sslFactory.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

			// Enable HTTP parameters
			HttpParams params = new BasicHttpParams();
			HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
			HttpProtocolParams.setContentCharset(params, HTTP.UTF_8);

			// Register the HTTP and HTTPS Protocols. For HTTPS, register our custom SSL Factory object.
			SchemeRegistry registry = new SchemeRegistry();
			registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
			registry.register(new Scheme("https", sslFactory, 443));

			// Create a new connection manager using the newly created registry and then create a new HTTP client using this connection manager
			ClientConnectionManager ccm = new ThreadSafeClientConnManager(params, registry);
			this.httpclient = new DefaultHttpClient(ccm, params);
			this.httppost = new HttpPost(uri);
		} catch (Exception e) {
			Log.e("ErrorMGTHTTP", e.getMessage());
			this.httpclient.getConnectionManager().shutdown();
		}
	}
	
	
	
	
	
	
	/*
	 *  setHttpHeader
	 */
	public void setHttpHeader(String name, String value){
		//this.httppost.setHeader(name, value);
	}
	
	/* setHttpPostEntity
	 * 
	 */
	public void setHttpPostEntity(HttpEntity entity){
		this.httppost.setEntity(entity);
		try {
			  if( entity != null ) {	        	
		        	
		        	DebugLog.debug(TAG, "Request TO Server" + EntityUtils.toString(entity));
	            	}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	/*
	 * makeRequestGetResponse
	 * Just send the request, wait for response, convert to Input Source to return back
	 */
	public InputSource makeRequestGetResponse()
	{
		InputSource is = null;
		try {
	       
	        /** Perform the actual HTTP POST */
			
			
			
			
			
	        HttpResponse response = httpclient.execute(httppost);
	       
	        
	        HttpEntity entity = response.getEntity();
	       
	        inputStreamResponse = entity.getContent();
	        
	        this.returnString = convertStreamToString(inputStreamResponse);
	     	Log.i("RESPONSE",this.returnString);
	     	//appendLog(returnString);
	        /* Lets try to parse the HTTP Response here */
	        is = new InputSource();
	        is.setCharacterStream(new StringReader(this.returnString));

	    } catch (Exception uee) {
	        //Some Exception, Print the stack trace
	    		uee.printStackTrace();
	    } 
		
	    return is;
	}
	
	
	/*
	 * makeRequestGetResponse
	 * Just send the request, wait for response, convert to Input Source to return back
	 */
	public String makeRequestGetResponseAsString()
	{
		try {
	       
	        /** Perform the actual HTTP POST */
	        HttpResponse response = httpclient.execute(httppost);
	        HttpEntity entity = response.getEntity();
	   
	        inputStreamResponse = entity.getContent();
	        this.returnString = convertStreamToString(inputStreamResponse);
	     	Log.i("RESPONSE",this.returnString);
	        

	    } catch (Exception uee) {
	        //Some Exception, Print the stack trace
	    		uee.printStackTrace();
	    } 
	    return returnString;
	}
	
	/*
	 * convertStreamToString
	 * This is used to convert IS to string
	 */
	 public String convertStreamToString(InputStream is) {
         BufferedReader reader = new BufferedReader(new InputStreamReader(is));
         StringBuilder sb = new StringBuilder();

         String line = null;
         try {
              while ((line = reader.readLine()) != null) {
                   sb.append(line + "\n");
              }
         } catch (IOException e) {
              e.printStackTrace();
         } finally {
              try {
                   is.close();
              } catch (IOException e) {
                   e.printStackTrace();
              }
         }

         return sb.toString();
    }
	 
	 public class MeasuringConnManager extends SingleClientConnManager {
		    private long mReceivedBytes = -1;
		    private long mSentBytes = -1;
		    public MeasuringConnManager(HttpParams params, SchemeRegistry schreg) {
		        super(params, schreg);
		    }
		    @Override
		    public void releaseConnection(ManagedClientConnection conn,
		            long validDuration, TimeUnit timeUnit) {
		        HttpConnectionMetrics metrics = conn.getMetrics();
		        mReceivedBytes = metrics.getReceivedBytesCount();
		        mSentBytes = metrics.getSentBytesCount();
		        metrics.reset();
		        super.releaseConnection(conn, validDuration, timeUnit);
		    }

		    public long getReceivedBytes() {
		        return mReceivedBytes;
		    }
		    public long getSentBytes() {
		        return mSentBytes;
		    }
		}
	 
}

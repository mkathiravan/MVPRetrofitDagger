//package net.abaqus.mygeotracking.deviceagent.utils;
//
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.os.Handler;
//import android.os.Message;
//import android.util.Log;
//
//import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
//
//public class AppStatusListener extends BroadcastReceiver{
//Context thisContext;
//	@Override
//	public void onReceive(Context con, Intent intent) {
//	thisContext = con;
//	final String msg="intent:"+intent+" action:"+intent.getAction();
//	   Log.d("DEBUG",msg);
//	   // Toast.makeText(context,msg,Toast.LENGTH_SHORT).show();
//
//	   ZDAListener.getInstance().getIdentitiesList();
//
//	   ZDAListener.getInstance().setIdentitiesHandler(mHandler);
//	}
//
//	private Handler mHandler = new Handler() {
//	public void handleMessage(Message msg) {
//
//		switch (msg.what) {
//		/* ZDA onError error handling follows here */
//		case ZDAListener.UPDATE_IDENTITIES:
//			HOSPullCalls.makeHOSInitializeCalls(thisContext, this);
//			break;
//		}
//	}
//	};
//
//}

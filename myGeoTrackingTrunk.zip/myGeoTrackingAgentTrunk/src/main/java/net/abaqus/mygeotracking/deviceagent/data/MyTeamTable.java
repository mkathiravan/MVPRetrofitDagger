package net.abaqus.mygeotracking.deviceagent.data;

/**
 * Created by bm on 11/6/15.
 */

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

public class MyTeamTable {



    private static final String TAG = "MGT_Database";
	/*<Device>
 			<DeviceID>1212121212</DeviceID>
 			<DeviceDescription>Amith</DeviceDescription>
 			<groupName>abaqus</groupName>
 			<AddressModel>Unnamed Road, Thattaguppe, Karnataka 560082, India</AddressModel>
 			<latitude>12.77054</latitude>
 			<longitude>77.52584</longitude>
 			<updatedTime>2015/05/04 00:10:29 PDT</updatedTime>
 			<lastHosStage>Start Shift</lastHosStage>
 			<lastMessage>testing</lastMessage>
 		</Device>*/

    //The columns we'll include in the dictionary table
    public static final String COLUMN_ID = "_id";
    public static final String MT_DEVICE_ID = "myteam_device_id";
    public static final String MT_DEVICE_DESC = "myteam_device_desc";
    public static final String MT_GROUP_NAME = "myteam_group_name";
    public static final String MT_ADDRESS = "myteam_address";
    public static final String MT_LATITUDE = "myteam_latitude";
    public static final String MT_LONGITUDE = "myteam_longitude";
    public static final String MT_UPDATED_TIME = "myteam_updated_time";
    public static final String MT_LAST_HOS_STAGE = "myteam_last_hos_stage";
    public static final String MT_MESSAGE = "myteam_message";

    public static final String MYTEAM_TABLE = "mgtagentmyteamtable";


    // Database creation SQL statement

    private static final String MYTEAM_TABLE_CREATE = "create table "
            + MYTEAM_TABLE
            + "("
            + COLUMN_ID + " integer primary key autoincrement, "
            + MT_DEVICE_ID + " text null, "
            + MT_DEVICE_DESC + " text null,"

            + MT_GROUP_NAME+ " text null,"
            + MT_ADDRESS+ " text null,"
            + MT_LATITUDE+ " text null,"
            + MT_LONGITUDE+ " text not null,"
            + MT_UPDATED_TIME+ " text null,"
            + MT_LAST_HOS_STAGE+ " text null,"
            + MT_MESSAGE+ " text null"
            + ");";

    public static void onCreate(SQLiteDatabase database) {
        Log.d(TAG, "Creating MYTEAM Table");
        database.execSQL(MYTEAM_TABLE_CREATE);
    }

    public static void onUpgrade(SQLiteDatabase database, int oldVersion,
                                 int newVersion) {
        DebugLog.debug(TAG, "Upgrading database from version "
                + oldVersion + " to " + newVersion
                + ", which will destroy all old data");
        database.execSQL("DROP TABLE IF EXISTS " + MYTEAM_TABLE);
        onCreate(database);
    }

}

package net.abaqus.mygeotracking.deviceagent;

import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;

public class MyGeoTrackingAgentBroadcastReceiver extends BroadcastReceiver {
	/** Keeps track of the number of pending messages. */
	private static int totalNewMessageCount = 0;
	private static StringBuilder totalNewMessageGuids = new StringBuilder();

	// private static Object notificationLock = new Object();

	@SuppressWarnings("deprecation")
	@Override
	public void onReceive(Context context, Intent intent) {
		// NOTE : We only handle one type of message
		// ("com.zoscomm.zda.NEW_MESSAGES_AVAILABLE")
		// so no need to check it here.

		// Compare the client id to our API key - if it matches we can handle
		// this message.
		String clientID = intent.getStringExtra("client_id");
		
		 if (clientID != null &&
		 clientID.equals(myGeoTrackingDevieAgentApplication.API_KEY)) {
		
		int newMessageCount = intent.getIntExtra("newCount", 0);
		if (newMessageCount > 0) {
			// synchronized (notificationLock)
			// {
			// Accumulate the new message count.
			totalNewMessageCount += newMessageCount;

			// Acculate the new messages guids.
			String guids = intent.getStringExtra("guids");
			if (guids != null) {
				if (totalNewMessageGuids.length() > 0)
					totalNewMessageGuids.append(",");
				totalNewMessageGuids.append(guids);
			}

			// Set up an intent that will be sent if the user clicks the
			// notification.
			Intent displayIntent = new Intent(context,
					MDAMainActivity.class);
			displayIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			displayIntent.putExtra("message_count", totalNewMessageCount);
			if (totalNewMessageGuids.length() > 0)
				displayIntent
						.putExtra("guids", totalNewMessageGuids.toString());
			PendingIntent launchIntent = PendingIntent.getActivity(context, 0,
					displayIntent, PendingIntent.FLAG_UPDATE_CURRENT);

			// Set up notification resources.
			int icon = R.drawable.main_image_72;
			Resources res = context.getResources();
			StringBuilder tickerText = new StringBuilder();
			tickerText.append("You have ");
			tickerText.append(totalNewMessageCount);
			tickerText.append(" new message(s)");
			String expandedText = tickerText.toString();
			String expandedTitle = res.getString(R.string.app_name);
			long when = System.currentTimeMillis();

			// Get the notification manager.
			NotificationManager notificationManager = (NotificationManager) context
					.getSystemService(Context.NOTIFICATION_SERVICE);

			// Create the notification.
			Notification notification = new Notification(icon, tickerText, when);
			//notification.setLatestEventInfo(context, expandedTitle,
			//		expandedText, launchIntent);
			notification.defaults |= Notification.DEFAULT_ALL;
			notification.flags |= Notification.FLAG_SHOW_LIGHTS;

			notificationManager.notify(1, notification);
			// }
		}
		 }
	}

	/**
	 * Removes our new message notification (if exists).
	 */
	public static void removeNotification(Context context) {
		// synchronized (notificationLock)
		// {
		// Reset the accumulated new count and new guids variables.
		totalNewMessageCount = 0;
		totalNewMessageGuids = new StringBuilder();

		// Get the notification manager.
		NotificationManager notificationManager = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);

		notificationManager.cancel(1);
		// }
	}
}

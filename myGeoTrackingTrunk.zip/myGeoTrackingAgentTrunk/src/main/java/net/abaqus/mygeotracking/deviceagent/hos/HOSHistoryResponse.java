package net.abaqus.mygeotracking.deviceagent.hos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by user on 22-06-2018.
 */

public class HOSHistoryResponse {

    @SerializedName("Device")
    String Device;

    public String getDevice() {
        return Device;
    }

    public void setDevice(String device) {
        Device = device;
    }

    public List<HOSHistoryDetail> getHos() {
        return hos;
    }

    public void setHos(List<HOSHistoryDetail> hos) {
        this.hos = hos;
    }

    @SerializedName("hos")
    List<HOSHistoryDetail> hos;


    public String getStatusCode() {
        return StatusCode;
    }

    public void setStatusCode(String statusCode) {
        StatusCode = statusCode;
    }


    @SerializedName("StatusCode")
    String StatusCode;


    public Total getTotal() {
        return total;
    }

    public void setTotal(Total total) {
        this.total = total;
    }

    @SerializedName("total")
    @Expose
    private Total total;




}

package net.abaqus.mygeotracking.deviceagent.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiEndPointsInterface;
import net.abaqus.mygeotracking.deviceagent.forms.FormsTable;

import java.io.File;
import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okio.BufferedSink;
import okio.Okio;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import rx.Observable;
import rx.Observer;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

import static android.content.ContentValues.TAG;

/**
 * Created by user on 23-10-2017.
 */

public class DownloadFiles {
    public static Context mycontext;
    private static SharedPreferences sh_prefs;
    private static String device_number = "";

    public static void downloadZipFileRx(FormsTable formsTable, Context mContext) {
        mycontext=mContext;
        String BaseURL="";
        String urlLink="";
        sh_prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
        device_number = sh_prefs.getString(MDACons.DEVICE_NUMBER, "");
        if (formsTable.formType.equalsIgnoreCase("Upload")) {
                BaseURL = "https://abaqusforms.s3.amazonaws.com/";
                urlLink = formsTable.formLinkURL;
            }

        else
        {
//            BaseURL="https://www.mygeotracking.com/";
//            urlLink = formsTable.formURL+"?formId=" + formsTable.formId + "&Token=" + formsTable.formToken;

            BaseURL="https://www.mygeotracking.com/";
            urlLink = formsTable.formURL+"?formId=" + formsTable.formId + "&Token=" + formsTable.formToken + "&deviceId=" + device_number;
        }

        ApiEndPointsInterface downloadService = createService(ApiEndPointsInterface.class,BaseURL);
        downloadService.downloadFileByUrlRxForUpload(urlLink)
                .flatMap(processResponse(formsTable))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(handleResult());


    }

    public static Func1<Response<ResponseBody>, Observable<File>> processResponse(final FormsTable myFormTable) {
        return new Func1<Response<ResponseBody>, Observable<File>>() {
            @Override
            public Observable<File> call(Response<ResponseBody> responseBodyResponse) {
                return saveToDiskRx(responseBodyResponse,myFormTable);
            }
        };
    }


    public static Observer<File> handleResult() {
        return new Observer<File>() {

            @Override
            public void onCompleted() {
                Log.d(TAG, "onCompleted");
            }

            @Override
            public void onError(Throwable e) {
                e.printStackTrace();
                Log.d(TAG, "Error " + e.getMessage());
            }

            @Override
            public void onNext(File file) {
                Log.d(TAG, "File downloaded to " + file.getAbsolutePath());
            }
        };
    }

    public static <T> T createService(Class<T> serviceClass, String baseUrl) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(new OkHttpClient.Builder().build())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create()).build();
        return retrofit.create(serviceClass);
    }

    public static Observable<File> saveToDiskRx(final Response<ResponseBody> response, final FormsTable myFormTable) {
        return Observable.create(new Observable.OnSubscribe<File>() {
            @Override
            public void call(Subscriber<? super File> subscriber) {
                try {

                    String path = "/data/" + mycontext.getPackageName() + "/forms/";
                    File myFile = new File(Environment.getDataDirectory(), path);
                    myFile.mkdirs();
                    if (!isExistLocalFile(myFormTable, mycontext)) {

                        try {
                            Log.d(TAG, "MYFILE :  " + myFile.toString() + myFormTable.formId);
                            String ab = myFormTable.formId + ".html";
                            File file = new File(myFile.getAbsolutePath()//folder path
                                    + File.separator
                                    + ab); //file name
                            BufferedSink bufferedSink = Okio.buffer(Okio.sink(file));
                            bufferedSink.writeAll(response.body().source());
                            bufferedSink.close();
                            subscriber.onNext(file);
                            subscriber.onCompleted();

                        } catch (IOException e) {

                            e.printStackTrace();
                        }

                    }


                    /*if(!dir.exists())
                    {
                        if(!isExistLocalFile(myFormTable,mycontext))
                        {
                            File destinationFile = new File(dir + myFormTable.formId+".html");
                            Log.d(TAG, "MYFILE :  " +destinationFile.toString());
                            BufferedSink bufferedSink = Okio.buffer(Okio.sink(destinationFile));
                            bufferedSink.writeAll(response.body().source());
                            bufferedSink.close();
                            subscriber.onNext(destinationFile);
                            subscriber.onCompleted();

                        }

                    }*/




                } catch (Exception e) {
                    e.printStackTrace();
                    subscriber.onError(e);
                }
            }
        });
    }



    public static boolean isExistLocalFile(FormsTable myFormTable, Context mcontext) {
        String path="/data/" +mcontext.getPackageName() +"/forms/" + myFormTable.formId+".html";
        File file = new File ( path );
        if ( file.exists() )
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}

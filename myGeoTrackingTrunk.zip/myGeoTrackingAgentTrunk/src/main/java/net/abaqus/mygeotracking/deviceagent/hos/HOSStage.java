package net.abaqus.mygeotracking.deviceagent.hos;

/**
 * Created by root on 25/5/17.
 */

public class HOSStage {

    private String StageID;
    private String StageName;
    private String SMSCommand;

    public HOSStage() {
        StageID = "";
        StageName = "";
        this.SMSCommand = "";
    }

    public HOSStage(String stageID, String stageName, String SMSCommand) {
        StageID = stageID;
        StageName = stageName;
        this.SMSCommand = SMSCommand;
    }

    public String getStageID() {
        return StageID;
    }

    public void setStageID(String stageID) {
        StageID = stageID;
    }

    public String getStageName() {
        return StageName;
    }

    public void setStageName(String stageName) {
        StageName = stageName;
    }

    public String getSMSCommand() {
        return SMSCommand;
    }

    public void setSMSCommand(String SMSCommand) {
        this.SMSCommand = SMSCommand;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HOSStage hosStage = (HOSStage) o;

        return StageID != null ? StageID.equals(hosStage.StageID) : hosStage.StageID == null;

    }

    @Override
    public int hashCode() {
        return StageID != null ? StageID.hashCode() : 0;
    }
}

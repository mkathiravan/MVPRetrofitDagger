package net.abaqus.mygeotracking.deviceagent.utils;

import android.app.ActivityManager;
import android.content.Context;

import java.util.List;

/**
 * Created by root on 23/5/17.
 */

public class AppUtils {


    /**
     *
     * @param mContext context to access the context based API methods
     * @return true if the app is running in foreground, false if it is in background
     */
    public static boolean isAppForeground(Context mContext) {
        ActivityManager manager = (ActivityManager) mContext.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> info = manager.getRunningAppProcesses();
        if (info == null || info.size() == 0) return false;
        for (ActivityManager.RunningAppProcessInfo aInfo : info) {
            if (aInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                return aInfo.processName.equals(mContext.getPackageName());
            }
        }
        return false;
    }
}

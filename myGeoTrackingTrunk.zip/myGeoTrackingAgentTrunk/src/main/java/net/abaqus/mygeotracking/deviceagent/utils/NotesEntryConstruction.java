package net.abaqus.mygeotracking.deviceagent.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.util.Xml;

import net.abaqus.mygeotracking.deviceagent.notes.Attachments;
import net.abaqus.mygeotracking.deviceagent.notes.Notes;

import org.xmlpull.v1.XmlSerializer;

import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Created by bm on 14/9/15.
 */
public class NotesEntryConstruction {

    private static final String TAG = NotesEntryConstruction.class.getSimpleName();

    public static String constructNotesEntryBlock(Context mContext, Notes notes, ArrayList<Attachments> attachmentseList){


        XmlSerializer serializer;
        StringWriter writer;
        SharedPreferences prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
        serializer = Xml.newSerializer();
        writer = new StringWriter();
        try{
            serializer.setOutput(writer);
            serializer.startDocument("UTF-8", true);
            serializer.startTag(null, "MGTRequest");
            serializer.startTag(null, "Message");

            String deviceId = prefs.getString(MDACons.DEVICE_NUMBER, "");

            if (deviceId.length() < 1)
                deviceId = new FetchDeviceNumber(
                        mContext.getApplicationContext())
                        .getPhoneNumber();

            serializer.startTag(null, "From");
            serializer.text(deviceId);
            serializer.endTag(null, "From");

            if(toAvailable(notes)){
                serializer.startTag(null, "To");
                if(toDeviceAvailable(notes)){
                    serializer.startTag(null, "Devices");
                    serializer.startTag(null, "Device");
                    serializer.text(notes.getToDevice());
                    serializer.endTag(null, "Device");
                    serializer.endTag(null, "Devices");
                }
                if(toGroupAvailable(notes)){
                    serializer.startTag(null, "Groups");
                    serializer.startTag(null, "Group");
                    serializer.text(notes.getToGroup());
                    serializer.endTag(null, "Group");
                    serializer.endTag(null, "Groups");
                }
                serializer.endTag(null, "To");
            }

            serializer.startTag(null, "Type");
            serializer.text(getMessageType());
            serializer.endTag(null, "Type");

            if(dataTagApplicable()){
                serializer.startTag(null, "Data");
                insertTypeValues(serializer);
                serializer.endTag(null, "Data");
            }

            serializer.startTag(null, "Priority");
            serializer.text(getMessagePriority());
            serializer.endTag(null, "Priority");

            serializer.startTag(null, "DateTime");
            serializer.text(getDateAndTime());
            serializer.endTag(null, "DateTime");

            serializer.startTag(null, "Message");
            serializer.text(getMessageBody(notes));
            serializer.endTag(null, "Message");

            List<String> fdUIDList = Arrays.asList(notes.getForm_fdUID().split("\\|"));
            if(notes.getForm_fdUID() != null && notes.getForm_fdUID().length() > 0) {
                for (String tempfdUID : fdUIDList) {
                    serializer.startTag(null, "fdUID");
                    serializer.text(tempfdUID);
                    serializer.endTag(null, "fdUID");
                }
            }

            serializer.startTag(null, "Tags");
            String taskDesc = getTaskDescription(notes).trim();
            List<String> itemsTask = Arrays.asList(taskDesc.split("\\|"));
            if(taskDesc.length() > 0)
                for (String tempTask : itemsTask) {
                    serializer.startTag(null, "Task");
                    serializer.text(tempTask);
                    serializer.endTag(null, "Task");
                }

            String jobSiteDesc = getJobSiteDescription(notes).trim();
            List<String> itemjobSite = Arrays.asList(jobSiteDesc.split("\\|"));
            if(jobSiteDesc.length() > 0)
                for (String tempJobSite : itemjobSite) {
                    serializer.startTag(null, "Customer");
                    serializer.text(tempJobSite);
                    serializer.endTag(null, "Customer");


                    serializer.startTag(null,"CustomerID");
                    serializer.text(prefs.getString(MDACons.HOS_CUSTOMER_SELECTED_ID,""));
                    serializer.endTag(null,"CustomerID");
                }

            String qrResult = getQRScanResult(notes).trim();
            List<String> items = Arrays.asList(qrResult.split("\\|"));
            if(qrResult.length() > 0)
                for (String temp : items) {
                    serializer.startTag(null, "QR");
                    serializer.text(temp);
                    serializer.endTag(null, "QR");
                }

            serializer.endTag(null, "Tags");
            if(attachmentseList.size() > 0){
                serializer.startTag(null, "Attachments");
                for(int position = 0; position < attachmentseList.size() ; position++) {
                    Attachments attachments = attachmentseList.get(position);
                    if(attachments.getImageAttachment() != null) {
                        serializer.startTag(null, "Attachment");

                        serializer.startTag(null, "Id");
                        serializer.text(attachments.getImageAttachment().getUniqueID());
                        serializer.endTag(null, "Id");

                        serializer.startTag(null, "Name");
                        serializer.text(attachments.getImageAttachment().getName());
                        serializer.endTag(null, "Name");

                        serializer.startTag(null, "Size");
                        serializer.text(attachments.getImageAttachment().getSize());
                        serializer.endTag(null, "Size");

                        serializer.startTag(null, "Type");
                        serializer.text(attachments.getImageAttachment().getType());
                        serializer.endTag(null, "Type");

                        serializer.endTag(null, "Attachment");
                    }
                }
                serializer.endTag(null, "Attachments");
            }
            if(isLocaionAvailable()){
                serializer.startTag(null, "Location");

                serializer.startTag(null, "Latitude");
                serializer.text(CurrentDateAndTime.getLatValue()+"");
                serializer.endTag(null, "Latitude");

                serializer.startTag(null, "Longitude");
                serializer.text(CurrentDateAndTime.getLonValue()+"");
                serializer.endTag(null, "Longitude");

                serializer.startTag(null, "Accuracy");
                serializer.text(CurrentDateAndTime.getAccuracy());
                serializer.endTag(null, "Accuracy");

                serializer.endTag(null, "Location");

            }

            serializer.endTag(null, "Message");



            serializer.endTag(null,"MGTRequest");
            serializer.endDocument();
        }catch (Exception e) {
            DebugLog.debug(TAG, "REQUEST" + " Exception happened"+e.toString());
        }
        return writer.toString();
    }




    private static boolean toGroupAvailable(Notes notes) {
        if(notes.getToGroup().length()>1)
            return true;
        else
            return false;
    }

    private static boolean toDeviceAvailable(Notes notes) {
        if(notes.getToDevice().length()>1)
            return true;
        else
            return false;
    }

    private static String getAttachmentName(Notes notes) {
        return null;
    }

    private static String getAttachmentID(Notes notes) {
        return null;
    }

    private static boolean isLocaionAvailable() {
        if(CurrentDateAndTime.getLatValue() != null)
            return true;
        else
            return false;

    }

    private static boolean isAttachmentsAvailable(Notes notes) {
        return false;
    }

    private static String getMessageBody(Notes notes) {
        return notes.getMessageBody();
    }

    private static String getTaskDescription(Notes notes) {
        return notes.getTask_description();
    }

    private static String getJobSiteDescription(Notes notes) {
        return notes.getjobsite_description();
    }

    private static String getQRScanResult(Notes notes) {
        return notes.getQr_result();
    }

    private static String getDateAndTime() {
        SimpleDateFormat df = new SimpleDateFormat(
                "yyyy/MM/dd'T'HH:mm:ssZ", Locale.getDefault());

        return CurrentDateAndTime.getDateTime(df);
    }

    private static String getMessagePriority() {
        return "Normal";
    }

    private static void insertTypeValues(XmlSerializer serializer) {

    }

    private static boolean dataTagApplicable() {
        return false;
    }

    private static String getMessageType() {
        return "Message";
    }

    private static boolean toAvailable(Notes notes) {
        return notes.toAvailable();
    }
}

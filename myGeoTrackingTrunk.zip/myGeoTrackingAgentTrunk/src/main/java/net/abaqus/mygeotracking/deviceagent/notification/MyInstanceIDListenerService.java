//package net.abaqus.mygeotracking.deviceagent.notification;
//
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.preference.PreferenceManager;
//import android.util.Log;
//
//import com.google.firebase.iid.FirebaseInstanceId;
//import com.google.firebase.iid.FirebaseInstanceIdService;
//
//import java.io.IOException;
//
///**
// * Created by root on 8/6/16.
// */
//
//public class MyInstanceIDListenerService extends FirebaseInstanceIdService {
//
//    private static final String TAG = "MyInstanceIDLS";
//
//    /**
//     * Called if InstanceID token is updated. This may occur if the security of
//     * the previous token had been compromised. This call is initiated by the
//     * InstanceID provider.
//     */
//    // [START refresh_token]
//    @Override
//    public void onTokenRefresh() {
//        // Fetch updated Instance ID token and notify our app's server of any changes (if applicable).
///*
//        Intent intent = new Intent(this, RegistrationIntentService.class);
//        startService(intent);
//*/
//
//        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
//        try {
//            sharedPreferences.edit().putBoolean(NotificationPreferences.SENT_TOKEN_TO_MGT_SERVER, false).apply();
//            new Thread(new Runnable() {
//                @Override
//                public void run() {
//                    ShareRegistrationToken.sendRegistrationToServer(MyInstanceIDListenerService.this);
//                }
//            }).start();
//            // You should store a boolean that indicates whether the generated token has been
//            // sent to your server. If the boolean is false, send the token to your server,
//            // otherwise your server should have already received the token.
//            // [END register_for_gcm]
//        } catch (Exception e) {
//            Log.d(TAG, "Failed to complete token refresh", e);
//            // If an exception happens while fetching the new token or updating our registration data
//            // on a third-party server, this ensures that we'll attempt the update at a later time.
//        }
//    }
//    // [END refresh_token]
//}
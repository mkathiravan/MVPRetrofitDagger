package net.abaqus.mygeotracking.deviceagent.RetrofitBuilder;


import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Streaming;
import retrofit2.http.Url;
import rx.Observable;

/**
 * Created by user on 12-10-2017.
 */

public interface ApiEndPointsInterface {



    //Good Job you have created this APIInterface to use it with retrofit.
    //TODO We are using only one method in this interface. So we can remove the unused methods from here.
    //TODO Also Please rename downloadFileByUrlRxForUpload method into downloadForm.
    //TODO Follow the coding guidelines from the document. especially spacing in this file
    @Streaming
    @GET
    Call<ResponseBody> downloadFileByUrl(@Url String fileUrl);


    // Retrofit 2 GET request for rxjava
    @Streaming
    @GET
    Observable<Response<ResponseBody>> downloadFileByUrlRxForUpload(@Url String fileUrl);


    @Streaming
    @GET("htmlform?formId={id}&Token={token}")
    Observable<Response<ResponseBody>> downloadfileByURLManualy(@Path("id") String formid, @Path("token") String formToken);


}

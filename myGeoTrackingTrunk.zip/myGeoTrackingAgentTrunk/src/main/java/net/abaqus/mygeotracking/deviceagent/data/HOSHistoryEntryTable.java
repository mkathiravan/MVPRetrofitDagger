package net.abaqus.mygeotracking.deviceagent.data;

import android.database.sqlite.SQLiteDatabase;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

/**
 * Created by user on 25-06-2018.
 */

public class HOSHistoryEntryTable {

    private static final String TAG = HOSHistoryEntryTable.class.getSimpleName();

    public static final String COLUMN_ID = "_id";

    public static final String HOS_HISTORY_STAGETIME = "hos_history_stagetime";
    public static final String HOS_HISTORY_STAGEID = "hos_history_stageid";
    public static final String HOS_HISTORY_STAGEDESC = "hos_history_stagedesc";
    public static final String HOS_HISTORY__SERVICEHOUR = "hos_history_servicehour";
    public static final String HOS_TEXT_NOTES = "hostextnotes";
    public static final String HOS_ADDRESS = "hosaddress";
    public static final String HOS_HISTORY_TABLE = "hoshistoryentrytable";



    //Database creation SQL statement

    private static final String HOS_HISTORY_ENTRY_TABLE = "create table "
            + HOS_HISTORY_TABLE
            + "("
            + COLUMN_ID + " integer primary key autoincrement, "
            + HOS_HISTORY_STAGETIME + " text null,"
            + HOS_HISTORY_STAGEID + " int not null,"
            + HOS_HISTORY_STAGEDESC + " text null,"
            + HOS_HISTORY__SERVICEHOUR + " text null,"
            + HOS_TEXT_NOTES + " text null,"
            + HOS_ADDRESS + " text null,"
            + " text null"
            + ");";


    public static void onCreate(SQLiteDatabase database)
    {
        DebugLog.debug(TAG,"Creating Database ");
        database.execSQL(HOS_HISTORY_ENTRY_TABLE);
    }

    public static void onDelete(SQLiteDatabase database)
    {
        DebugLog.debug(TAG,"Delete Database");
        database.delete(HOS_HISTORY_ENTRY_TABLE,null,null);
    }


    public static void onUpgrade(SQLiteDatabase database,int oldVersion,int newVersion)
    {
        DebugLog.debug(TAG,"Upgrading database from version "
        + oldVersion + "to "+ newVersion
        + ", which will destroy all old data");

        database.execSQL("DROP TABLE IF EXISTS "+ HOS_HISTORY_TABLE);
        onCreate(database);
    }
}

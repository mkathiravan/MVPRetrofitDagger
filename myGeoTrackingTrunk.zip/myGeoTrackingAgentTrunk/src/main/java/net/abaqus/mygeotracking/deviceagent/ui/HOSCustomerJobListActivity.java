package net.abaqus.mygeotracking.deviceagent.ui;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.adapter.CustomerListCursorAdapter;
import net.abaqus.mygeotracking.deviceagent.adapter.JobListCursorAdapter;
import net.abaqus.mygeotracking.deviceagent.data.HOSCusJobSearchProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobRelationContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobRelationsTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobTable;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

import android.annotation.SuppressLint;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.widget.CursorAdapter;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FilterQueryProvider;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class HOSCustomerJobListActivity extends ListActivity implements TextWatcher, OnClickListener{

	private static final String TAG = HOSCustomerJobListActivity.class.getSimpleName();
	private ListView selfListView; 
	private Cursor mCursor;
	private EditText inputSearch,hos_cj_createnew_editext;
	private CursorAdapter adapter;
	private HOSCusJobSearchProvider hoscjdbHelper;
	private TextView hos_cj_createnew_cancel_btn, hos_cj_createnew_save_btn, hos_cj_createnew_title_view,back_button_text, create_new_button_text, title_text;
	String which;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//Remove title bar
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.hos_cj_listview_static_header);
	    updateListingUI();
	}

	
	
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		Intent i = getIntent();
		 i.putExtra("selected_which", adapter.getCursor().getString(adapter.getCursor().getColumnIndexOrThrow(HOSCustomerANDJobTable.HOS_CJ_NAME)));
		 Log.i("TAG", "l.adapter.getCursor().getColumnNames() " + adapter.getCursor().getString(adapter.getCursor().getColumnIndexOrThrow(HOSCustomerANDJobTable.HOS_CJ_NAME)));
		 setResult(RESULT_OK, i);
		 finish();
		super.onListItemClick(l, v, position, id);
	}



	@Override
	public void afterTextChanged(Editable s) {
		adapter.getFilter().filter(s.toString());
	}



	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
	}



	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
	}



	@Override
	public void onClick(View v) {
		Intent i = getIntent();
		switch (v.getId()) {
		case R.id.hos_cj_static_header_back_btn:
			 i.putExtra("selected_which", "null");
			 setResult(RESULT_OK, i);
			finish();
			break;
		case R.id.hos_cj_static_header_add_new_btn:

			 /*i.putExtra("selected_which", "");
			 setResult(RESULT_OK, i);
			finish();*/
			setContentView(R.layout.hos_cj_createcj_view);
			try {
				updateCreateNewUI();
			} catch (Exception e) {e.printStackTrace();}
			
			
			break;
		case R.id.hos_cj_createnew_cancel_btn:
			
			 /*i.putExtra("selected_which", "");
			 setResult(RESULT_OK, i);
			finish();*/
			setContentView(R.layout.hos_cj_listview_static_header);
			updateListingUI();
			break;
			
		case R.id.hos_cj_createnew_save_btn:
			
			 i.putExtra("selected_which", hos_cj_createnew_editext.getText().toString());
			 setResult(RESULT_OK, i);
			finish();
			
			break;
			
		default:
			break;
		}
	}
	
	
	
	public void updateCreateNewUI(){
		
		
		/*hos_cj_createnew_cancel_btn = (TextView) createNew_view.findViewById(R.id.hos_cj_createnew_cancel_btn);
		hos_cj_createnew_title_view = (TextView) createNew_view.findViewById(R.id.hos_cj_createnew_title_text);
		hos_cj_createnew_save_btn = (TextView) createNew_view.findViewById(R.id.hos_cj_createnew_save_btn);
		hos_cj_createnew_editext = (EditText) createNew_view.findViewById(R.id.hos_cj_createnew_edittext);*/
		
		
		hos_cj_createnew_cancel_btn = (TextView) findViewById(R.id.hos_cj_createnew_cancel_btn);
		hos_cj_createnew_title_view = (TextView) findViewById(R.id.hos_cj_createnew_title_text);
		hos_cj_createnew_save_btn = (TextView) findViewById(R.id.hos_cj_createnew_save_btn);
		hos_cj_createnew_editext = (EditText) findViewById(R.id.hos_cj_createnew_edittext);
		
		hos_cj_createnew_cancel_btn.setOnClickListener(this);
		hos_cj_createnew_save_btn.setOnClickListener(this);
		
		InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.showSoftInput(hos_cj_createnew_editext, InputMethodManager.SHOW_IMPLICIT);
		
		hos_cj_createnew_editext.requestFocus();
	
		
		if (which.equals("customer")){
			hos_cj_createnew_title_view.setText("Create Customer");
			hos_cj_createnew_editext.setHint("Customer name");
		}
			else if(which.equals("job")){
				hos_cj_createnew_title_view.setText("Create Job");
				hos_cj_createnew_editext.setHint("Job name");
			}
		
		((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
	}
	
	@SuppressLint("NewApi")
	public void updateListingUI(){
		
		
		selfListView = getListView();
		
		back_button_text = (TextView) findViewById(R.id.hos_cj_static_header_back_btn);
		title_text = (TextView) findViewById(R.id.hos_cj_static_header_title_text);
		create_new_button_text = (TextView) findViewById(R.id.hos_cj_static_header_add_new_btn);
		
		
		
		
		
		back_button_text.setOnClickListener(this);
		create_new_button_text.setOnClickListener(this);
		Intent this_intent = getIntent();
		which = this_intent.getStringExtra("which");
		
		if (which.equals("customer"))
		title_text.setText("Select Customer");
		else if(which.equals("job"))
			title_text.setText("Select Task");
		
		
		
		inputSearch = (EditText) findViewById(R.id.inputSearch);
		inputSearch.addTextChangedListener(this);
		
		String[] projection = { HOSCustomerANDJobTable.COLUMN_ID,
		        HOSCustomerANDJobTable.HOS_CJ_NAME,
		        HOSCustomerANDJobTable.HOS_CJ_WHICH};
		    
		
		String[] projection_cus = { HOSCustomerANDJobTable.COLUMN_ID,
		        HOSCustomerANDJobTable.HOS_CJ_NAME,
		        HOSCustomerANDJobTable.HOS_CJ_SITE_ID,
		        HOSCustomerANDJobTable.HOS_CJ_WHICH};
		 
		
		if (which.equals("customer"))
			mCursor = this.getContentResolver().query(Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI.toString()), projection_cus, HOSCustomerANDJobTable.HOS_CJ_WHICH+" LIKE ?", new String[]{"Customer"},
					HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");
			else if(which.equals("job"))
		{
			String[] relationsTableResult = getRelationsData(this_intent.getStringExtra("customer"));
			int argcount = relationsTableResult.length; // number of IN arguments
			if(argcount == 0 || relationsTableResult[0].equals("all"))
			mCursor = this.getContentResolver().query(Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI.toString()), projection, HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ?", new String[]{"Job"},
					HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");
			else {
				StringBuilder inList = new StringBuilder(argcount*2);
				for(int i=0;i<argcount;i++){ if(i > 0) inList.append(","); inList.append("?"); }

				mCursor = this.getContentResolver().query(Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI.toString()), projection, HOSCustomerANDJobTable.HOS_CJ_ID + " IN ("+ inList.toString()+")", relationsTableResult,
						HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");
			}
		}
        startManagingCursor(mCursor);
        
        /*DebugLog.debug(TAG, "Cusrosr COunt : "+mCursor.getCount()+", Cursor For : "+which);
        for (int i = 0; i < mCursor.getCount(); i++){
        	while(mCursor.moveToNext() == true){
        		
        		DebugLog.debug(TAG, "Cusname : "+ mCursor.getString(mCursor.getColumnIndex(HOSCustomerANDJobTable.HOS_CJ_NAME)));
        		if (which.equals("customer"))
        		DebugLog.debug(TAG, "Site ID : "+ mCursor.getString(mCursor.getColumnIndex(HOSCustomerANDJobTable.HOS_CJ_SITE_ID)));
        		mCursor.moveToNext();
        	}
        }*/
        DebugLog.debug(TAG, "Cusrosr COunt : "+mCursor.getCount()+", Cursor For : "+which);

        // Now create a new list adapter bound to the cursor.
        // SimpleListAdapter is designed for binding to a Cursor.
       
        LayoutInflater inflater = getLayoutInflater();
		View createNew_view = inflater.inflate(R.layout.hos_cj_listview_content, selfListView, false);
	
        if (which.equals("customer")){
        	
        	TextView tvtv = (TextView) createNew_view.findViewById(R.id.text2);
        	tvtv.setVisibility(View.VISIBLE);
        	
        	adapter = new CustomerListCursorAdapter(this, mCursor, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        		/*adapter = new SimpleCursorAdapter(
        	                this, R.layout.hos_cj_listview_content, mCursor,                                              // Pass in the cursor to bind to.
        	                new String[] {HOSCustomerANDJobTable.HOS_CJ_NAME, HOSCustomerANDJobTable.HOS_CJ_SITE_ID,
        	        		        },           // Array of cursor columns to bind to.
        	                new int[] {R.id.text1, R.id.text2});*/ 
        	
        }else{
      	  adapter = new JobListCursorAdapter(this, mCursor, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);  
      		 /* adapter = new SimpleCursorAdapter(
      	                     this, R.layout.hos_cj_listview_content_single_textview, mCursor,                                              // Pass in the cursor to bind to.
      	                     new String[] {HOSCustomerANDJobTable.HOS_CJ_NAME,
      	             		        },           // Array of cursor columns to bind to.
      	                     new int[] {R.id.text1});  */
      	 
        }
        hoscjdbHelper = new HOSCusJobSearchProvider(HOSCustomerJobListActivity.this);
        
        
        
        // Bind to our new adapter.
        setListAdapter(adapter);
        
        //setContentView(selfListView);
       
        
        adapter.setFilterQueryProvider(new FilterQueryProvider() {
            public Cursor runQuery(CharSequence constraint) {
                return hoscjdbHelper.fetchCountriesByName(constraint.toString(), which);
            }
        }); 
        
        
        
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if (hoscjdbHelper != null)
		hoscjdbHelper.close();
	}
	
	@Override
	public void onBackPressed() {
		Intent i = getIntent();
		
			 i.putExtra("selected_which", "null");
			 setResult(RESULT_OK, i);

		
		super.onBackPressed();
	}

	private String[] getRelationsData(String customerID) {

		if(customerID == null)
			customerID = "";
		int i = 0;
		String[] projection = {
				HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID, HOSCustomerANDJobRelationsTable.HOS_CJ_REL_CUS_ID};
		Cursor cursor = this.getContentResolver().query(Uri.parse(HOSCustomerANDJobRelationContentProvider.CONTENT_URI.toString()), projection, HOSCustomerANDJobRelationsTable.HOS_CJ_REL_CUS_ID + " LIKE ?", new String[]{customerID},
				null);
		String[] resultString = new String[cursor.getCount()];
		if (cursor != null) {
			while (cursor.moveToNext()) {
				try {
					DebugLog.debug(TAG, cursor.getString(cursor
							.getColumnIndexOrThrow(HOSCustomerANDJobRelationsTable.HOS_CJ_REL_CUS_ID)));

					DebugLog.debug(TAG, cursor.getString(cursor
							.getColumnIndexOrThrow(HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID)));
					resultString[i]  = cursor.getString(cursor
							.getColumnIndexOrThrow(HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID));
					i++;
				} catch (Exception e) {
				}
			}

		}
		cursor.close();
		return resultString;
	}
}

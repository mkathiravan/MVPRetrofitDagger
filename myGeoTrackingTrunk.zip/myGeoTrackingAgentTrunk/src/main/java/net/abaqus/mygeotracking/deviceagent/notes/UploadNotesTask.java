package net.abaqus.mygeotracking.deviceagent.notes;

import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import net.abaqus.mygeotracking.deviceagent.data.NotesEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryTable;
import net.abaqus.mygeotracking.deviceagent.utils.ConnectionManager;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.FetchDeviceNumber;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EncodingUtils;
import org.apache.http.util.EntityUtils;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xmlpull.v1.XmlSerializer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.Toast;

import com.facebook.network.connectionclass.DeviceBandwidthSampler;

public class UploadNotesTask extends AsyncTask<String, Integer, Boolean>{

	private static final String TAG = UploadNotesTask.class.getSimpleName();

	private static String SEND_NOTES_COMMAND = "saveMessage";
	private Context context;
	private SharedPreferences prefs;
	SAXParserFactory spf = null; 
	SAXParser sp = null;
	/* Get the XMLReader of the SAXParser we created. */ 
	XMLReader xr = null;
	/* Create a new ContentHandler and apply it to the XML-Reader*/ 
	NotesUploadXMLHandler notesUploadHandler = null;

	private static final String LOG_TAG = UploadNotesTask.class.getSimpleName();



	public UploadNotesTask(Context con) {
		this.context = con;
		this.prefs = con.getSharedPreferences(MDACons.PREFS, 0);
		notesUploadHandler = new NotesUploadXMLHandler();
		Log.d(LOG_TAG, "UploadNotesTask");

	}
	
	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		DeviceBandwidthSampler.getInstance().startSampling();

	}
	
	
	@Override
	protected Boolean doInBackground(String... params) {

		try{

		Cursor entriesCursor = getNotesEntries();
		ConnectionManager cm;
		HttpEntity en = null;

			if (entriesCursor.getCount() > 0) {
				entriesCursor.moveToLast();
				DebugLog.debug("REQUEST" + MDACons.SERVER_URL + SEND_NOTES_COMMAND);
				cm = new ConnectionManager();
				cm.setupHttpPost(MDACons.SERVER_URL + SEND_NOTES_COMMAND);
				cm.setHttpHeader("Content-Type", "application/xml");
				try {

					if(Integer.parseInt(entriesCursor.getString(entriesCursor
							.getColumnIndexOrThrow(NotesEntryTable.NOTES_ENTRY_NO_OF_TRIES))) >= 5)
					{
						notesUploadHandler.error_occured = false;
						return true;
					}

					en = new StringEntity(entriesCursor.getString(entriesCursor
							.getColumnIndexOrThrow(NotesEntryTable.NOTES_ENTRY_XML)));
				} catch (Exception e) {

				}
				try {
					Log.i("REQUEST", EntityUtils.toString(en));
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				cm.setHttpPostEntity(en);

				try {
					InputSource m_is = cm.makeRequestGetResponse();
					spf = SAXParserFactory.newInstance();
					sp = spf.newSAXParser();
			
			/* Get the XMLReader of the SAXParser we created. */
					xr = sp.getXMLReader();
					xr.setContentHandler(notesUploadHandler);
					xr.parse(m_is);

				} catch (Exception e) {
					notesUploadHandler.error_occured = true;
					e.printStackTrace();
				}
				entriesCursor.close();
				return true;
			}else{
				entriesCursor.close();
				return false;
			}

		}catch(Exception e){

			return false;
		}
	
	
	}

	private Cursor getNotesEntries() {
		String[] projection = {
				NotesEntryTable.NOTES_ENTRY_XML, NotesEntryTable.COLUMN_ID, NotesEntryTable.NOTES_ENTRY_NO_OF_TRIES, NotesEntryTable.NOTES_ENTRY_FORM_POST_DATA};
		Cursor cursor = context.getContentResolver().query(Uri.parse(NotesEntryContentProvider.CONTENT_URI.toString()), projection, null, null,
				null);

		return cursor;
	}

	@Override
	protected void onPostExecute(Boolean result) {
		DeviceBandwidthSampler.getInstance().stopSampling();

		if (notesUploadHandler.error_occured){
			//Toast.makeText(context.getApplicationContext(), notesUploadHandler.getErrorMSG(), Toast.LENGTH_LONG).show();

			ContentValues initialValues = new ContentValues();
			Cursor eCursor = getNotesEntries();
			if (eCursor.getCount() > 0) {
				eCursor.moveToLast();
				initialValues.put(NotesEntryTable.NOTES_ENTRY_NO_OF_TRIES, Integer.parseInt(eCursor.getString(eCursor
						.getColumnIndexOrThrow(NotesEntryTable.NOTES_ENTRY_NO_OF_TRIES)))+1);

				context.getContentResolver().update(NotesEntryContentProvider.CONTENT_URI, initialValues, NotesEntryTable.COLUMN_ID+" = '"+ eCursor.getString(eCursor
						.getColumnIndexOrThrow(NotesEntryTable.COLUMN_ID))+"'", null);
			}
			eCursor.close();

		}else{
			Cursor eCursor = getNotesEntries();
			if (eCursor.getCount() > 0){
				eCursor.moveToLast();

				String url = MDACons.BASE_URL + "/track/htmlform";
				String postData = eCursor.getString(eCursor.getColumnIndexOrThrow(NotesEntryTable.NOTES_ENTRY_FORM_POST_DATA));
				List<String> postDataList = Arrays.asList(postData.split("\\|"));
					for (String tempPostData : postDataList) {
						if(tempPostData != null && tempPostData.length() > 0) {
							WebView webview = new WebView(context);
							webview.postUrl(url, EncodingUtils.getBytes(tempPostData, "base64"));
							DebugLog.debug(TAG, "Submitting form" + tempPostData);
						}
					}
				context.getContentResolver().delete(NotesEntryContentProvider.CONTENT_URI, NotesEntryTable.COLUMN_ID + " = '" + eCursor.getString(eCursor
						.getColumnIndexOrThrow(NotesEntryTable.COLUMN_ID)) + "'", null);
			}
			eCursor.close();

			Cursor entryCursor = getNotesEntries();
			if (entryCursor.getCount() > 0){
				new UploadNotesTask(context).execute();
			}
			entryCursor.close();
		}
	super.onPostExecute(result);
	}
	
	

/*<MGTRequest>
    <Message>
        <From>9481769676</From>
        <MessageID>uuid</MessageID>

        <To>
            <Devices>
                <Device>Device 1</Device>
                <Device>Device 2</Device>
            </Devices>
            <Groups>
                <Group>Group 1</Group>
                <Group>Group 2</Group>
            </Groups>
        </To>
        <Type>HOS</Type>
        <Data>
              <HosStage></HosStage>
              <Customer></Customer>
              <Job></Job> 
        </Data>
        <Priority>Normal</Priority>
        <DateTime>2014/05/14T10:26:57GMT+05:30</DateTime>
        <Message>hello how are you</Message>
        <Attachments>
            <Attachment>
                <Id></Id>
                <Name></Name>
                <Size></Size>
                <Type></Type>
            </Attachment>
            <Attachment>
                <Id></Id>
                <Name></Name>
                <Size></Size>
                <Type></Type>
            </Attachment>
        </Attachments>
        <Location>
            <Latitude>12.9862018</Latitude>
            <Longitude>77.5414036</Longitude>
            <Accuracy>30.0</Accuracy>
        <Location>
    </Message>
</MGTRequest>*/
}

package net.abaqus.mygeotracking.deviceagent.soshardware;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.support.v4.content.ContextCompat;
import android.telephony.SmsManager;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.bgthread.HOSBackgroundService;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;

import static android.content.Intent.ACTION_SCREEN_OFF;
import static android.content.Intent.ACTION_SCREEN_ON;

/**
 * Created by root on 12/12/16.
 */

public class PowerButtonTriggerReceiver extends BroadcastReceiver {
    private static final String TAG = PowerButtonTriggerReceiver.class.getName();
    //    private MultiClickEvent multiClickEvent;
    protected MultiClickEvent multiClickEvent;

    public PowerButtonTriggerReceiver() {
        resetEvent();
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.e(">>>>>>>", "in onReceive of HWReceiver");
        String action = intent.getAction();
        if (!isCallActive(context) && (action.equals(ACTION_SCREEN_OFF) || action.equals(ACTION_SCREEN_ON))) {
            multiClickEvent.registerClick(System.currentTimeMillis());

            if(multiClickEvent.skipCurrentClick()){
                Log.e("*****", "skipped click");
                multiClickEvent.resetSkipCurrentClickFlag();
            }

            else if(multiClickEvent.canStartVibration()){
                Log.e("*****", "vibration started");
                //PanicAlert panicAlert = getPanicAlert(context);
                //panicAlert.vibrate();
                SharedPreferences sharedPreferences = context.getSharedPreferences(MDACons.PREFS, 0);
                if(sharedPreferences.getBoolean(MDACons.SOS_STAGE_PRESENT, true))
                {
                    vibrate(context);
                    Intent launchIntent = context.getPackageManager().getLaunchIntentForPackage("net.abaqus.mygeotracking.deviceagent");
                    context.startActivity(launchIntent);
                    if (!NetworkConnectionInfo.isOnline(context) || ContextCompat.checkSelfPermission(context,
                            Manifest.permission.SEND_SMS)
                            == PackageManager.PERMISSION_GRANTED) {
                        String toPhoneNumber = sharedPreferences.getString(MDACons.TWILIO_SHORT_CODE, "+18032327769");
                        String sosCommand = sharedPreferences.getString(MDACons.SOS_EMER_COMMAND, "SOS");

                        SharedPreferences.Editor edit_prefs = sharedPreferences.edit();
                        edit_prefs.putInt(MDACons.HOS_SELECTION,
                                Integer.parseInt("7"));
                        edit_prefs.putString(MDACons.HOS_SELECTION_NAME,
                                "Safety Alert Triggered");
                        edit_prefs.commit();


                        new ProcessSMS().sendNow(context, toPhoneNumber, sosCommand, "7", "");
                    } else {
                        new HOSBackgroundService().processHOS(context, "Safety Alert Triggered", "7");
                    }
                }
            }

            else if (multiClickEvent.isActivated()) {
                Log.e("*****", "alerts activated");
                //onActivation(context);
                resetEvent();
            }
        }
    }

    /*protected void onActivation(Context context) {
        Log.e(">>>>>>>", "in onActivation of HWReceiver");
        activateAlert(getPanicAlert(context));
    }

    void activateAlert(PanicAlert panicAlert) {
//        panicAlert.start();
        panicAlert.activate();
    }*/

    protected void resetEvent() {
        multiClickEvent = new MultiClickEvent();
    }

   /* protected PanicAlert getPanicAlert(Context context) {
        return new PanicAlert(context);
    }
*/
    private boolean isCallActive(Context context) {
        AudioManager manager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        return manager.getMode() == AudioManager.MODE_IN_CALL;
    }

    public void vibrate(Context mContext) {
        Vibrator vibrator = (Vibrator) mContext.getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(5000);
    }

}
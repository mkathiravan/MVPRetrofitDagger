package net.abaqus.mygeotracking.deviceagent.utils;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;

public class NetworkConnectionInfo {


	public static boolean isOnline(Context mContext){
		ConnectivityManager connMgr = (ConnectivityManager)
				mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
	    NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
	    if (networkInfo != null && networkInfo.isConnected()) {
	        return true;
	    } else {	
	    	return false;
	    }
	}


	@TargetApi(16)
	public static boolean isNetworkMetered(Context mContext){
		ConnectivityManager connMgr = (ConnectivityManager)
				mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
		return connMgr.isActiveNetworkMetered();
	}

}

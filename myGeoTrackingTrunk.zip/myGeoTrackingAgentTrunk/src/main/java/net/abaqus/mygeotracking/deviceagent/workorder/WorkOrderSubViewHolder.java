package net.abaqus.mygeotracking.deviceagent.workorder;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.view.View;
import android.widget.TextView;

import com.thoughtbot.expandablerecyclerview.viewholders.ChildViewHolder;

import net.abaqus.mygeotracking.deviceagent.R;

public class WorkOrderSubViewHolder extends ChildViewHolder {

    private static final String TAG = WorkOrderSubViewHolder.class.getSimpleName();
    private TextView taskNameValue,endDateValue,addressValue,statusValue;

    public WorkOrderSubViewHolder(View itemView) {
        super(itemView);
        taskNameValue = (TextView)itemView.findViewById(R.id.tasknameValueView);
        endDateValue = (TextView)itemView.findViewById(R.id.enddateValueView);
        statusValue  = (TextView)itemView.findViewById(R.id.statusnameValueView);
        addressValue = (TextView)itemView.findViewById(R.id.addressValueView);

    }


    public void setFormName(String customerName, String taskname, String startTime, String EndTime, final String address, String status)
    {

      taskNameValue.setText(taskname);
      endDateValue.setText(EndTime);
      statusValue.setText(status);
      addressValue.setText(address);
//      addressValue.setText(Html.fromHtml("<a href='\"+ mobileUrl +\"'>"+address +"</a>"));
//      addressValue.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                final String map = "http://maps.google.co.in/maps?q=" + address;
//                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(map));
//                itemView.getContext().startActivity(i);
//
//            }
//        });

      }



}

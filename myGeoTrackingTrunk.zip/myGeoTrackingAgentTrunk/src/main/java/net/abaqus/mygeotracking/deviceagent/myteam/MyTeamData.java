package net.abaqus.mygeotracking.deviceagent.myteam;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * Created by bm on 5/6/15.
 */
public class MyTeamData implements Serializable{

        private String deviceDescription;
        private String deviceNumber;
        private String groupName;
        private String addressString;
        private String latitude;
        private String longitude;
        private String updatedTime;
        private String lastHosStage;
        private String lastMessage;
        private boolean checked;
        private int position;

        public MyTeamData() {super();}

        public MyTeamData(String deviceDescription, String deviceNumber, boolean checked) {
                super();
                this.deviceDescription = deviceDescription;
                this.deviceNumber = deviceNumber;
                this.checked = checked;
        }

        public String getDeviceDescription() {return this.deviceDescription;}

        public void setDeviceDescription(String deviceDescription) {this.deviceDescription = deviceDescription.replace("\n","");}

        public String getDeviceNumber() {return this.deviceNumber;}

        public void setDeviceNumber(String deviceNumber) {
                this.deviceNumber = deviceNumber.replace("\n","");
        }

        public String getGroupName(){return this.groupName;}

        public void setGroupName(String groupName){this.groupName = groupName.replace("\n","");}

        public String getAddressString(){return this.addressString;}

        public void setAddressString(String addressString){this.addressString = addressString.replace("\n","");}

        public String getLatitude(){return this.latitude;}

        public void setLatitude(String latitude){this.latitude = latitude.replace("\n","");}

        public String getLongitude(){return this.longitude;}

        public void setLongitude(String longitude){this.longitude = longitude.replace("\n","");}

        public String getUpdatedTime(){return this.updatedTime;}

        public void setUpdatedTime(String updatedTime){this.updatedTime = updatedTime.replace("\n","");}

        public String getLastHosStage(){return this.lastHosStage;}

        public void setLastHosStage(String lastHosStage){this.lastHosStage = lastHosStage.replace("\n","");}

        public String getLastMessage(){return this.lastMessage;}

        public void setLastMessage(String lastMessage){this.lastMessage = lastMessage.replace("\n","");}

        public boolean isChecked() {
                return checked;
        }

        public void setChecked(boolean checked) {
                this.checked = checked;
        }


        public int getPosition() {
                return position;
        }

        public void setPosition(int position) {
                this.position = position;
        }
}

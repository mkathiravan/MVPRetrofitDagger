
package net.abaqus.mygeotracking.deviceagent.myteam;


/*
 *
 * Created by bm on 4/6/15.
 */



import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;

import com.facebook.network.connectionclass.DeviceBandwidthSampler;

import net.abaqus.mygeotracking.deviceagent.data.MyTeamContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.MyTeamTable;
import net.abaqus.mygeotracking.deviceagent.listeners.TaskCompleteListener;
import net.abaqus.mygeotracking.deviceagent.utils.ConnectionManager;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlSerializer;

import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;


/*
 *
 * Created by bm on 4/6/15.
 */



public class MyTeamDataPullTask extends AsyncTask<String, Void, Boolean> {

    private static final String TAG = MyTeamDataPullTask.class.getSimpleName();

    // **FIELDS*

    private Context mContext;
    private SharedPreferences prefs		= null;
    SAXParserFactory spf		= null;
    SAXParser sp		= null;

    /* Get the XMLReader of the SAXParser we created.*/


    XMLReader xr		= null;
// Create a new ContentHandler and apply it to the XML-Reader

    MyTeamXMLHandler			myTeamXMLHandler	= null;
    public static String	error_message	= "";
    private TaskCompleteListener listener;

    public MyTeamDataPullTask(TaskCompleteListener taskCompleteListener, Context con) {
        this.mContext = con;
        this.listener = taskCompleteListener;
        this.prefs = con.getSharedPreferences(MDACons.PREFS, 0);
        myTeamXMLHandler = new MyTeamXMLHandler();
    }

    protected void onPreExecute() {
        DeviceBandwidthSampler.getInstance().startSampling();

    }

    protected void onPostExecute(Boolean success) {

        DeviceBandwidthSampler.getInstance().stopSampling();

        if (myTeamXMLHandler.error_occured) {
            if(listener != null){
                listener.onTaskCompleted(false);
            }
            if (myTeamXMLHandler.getErrorMSG().contains(
                    "Can not find a account for the Device with")) {
                //Toast.makeText(mContext.getApplicationContext(),
                // myTeamXMLHandler.getErrorMSG(), Toast.LENGTH_LONG)
                // .show();
            }
            else if (myTeamXMLHandler.getErrorMSG().contains(
                    "Multiple account for the Device")) {
                //Toast.makeText(mContext.getApplicationContext(),
                //myTeamXMLHandler.getErrorMSG(), Toast.LENGTH_LONG)
                //.show();
            }
        }
        else {
            this.mContext.getContentResolver().delete(MyTeamContentProvider.CONTENT_URI, null, null);
            SharedPreferences.Editor prefs_edit = prefs.edit();
            prefs_edit.putString(MDACons.MY_TEAM_UPDATED_TIME,getCurrentDate("yyyy/MM/dd' 'HH:mm:ss"));
            prefs_edit.commit();
            ArrayList<MyTeamData> tempMyTeamArrayList = myTeamXMLHandler.getMyTeamDataArrayList();
            MyTeamData tempMyTeamData;
            for (int i = 0 ; i < tempMyTeamArrayList.size(); i++){
                tempMyTeamData = tempMyTeamArrayList.get(i);
                ContentValues initialValues = new ContentValues();
                initialValues.put(MyTeamTable.MT_DEVICE_ID, tempMyTeamData.getDeviceNumber());
                initialValues.put(MyTeamTable.MT_DEVICE_DESC, tempMyTeamData.getDeviceDescription());
                initialValues.put(MyTeamTable.MT_GROUP_NAME, tempMyTeamData.getGroupName());
                initialValues.put(MyTeamTable.MT_ADDRESS, tempMyTeamData.getAddressString());
                initialValues.put(MyTeamTable.MT_LATITUDE, tempMyTeamData.getLatitude());
                initialValues.put(MyTeamTable.MT_LONGITUDE, tempMyTeamData.getLongitude());
                initialValues.put(MyTeamTable.MT_UPDATED_TIME, tempMyTeamData.getUpdatedTime());
                initialValues.put(MyTeamTable.MT_LAST_HOS_STAGE, tempMyTeamData.getLastHosStage());
                initialValues.put(MyTeamTable.MT_MESSAGE, tempMyTeamData.getLastMessage());
                this.mContext.getContentResolver().insert(MyTeamContentProvider.CONTENT_URI, initialValues);
            }

            if(listener != null){
                listener.onTaskCompleted(true);
            }
        }
    }

    public String getCurrentDate(String dateFormat) {
        Date d = new Date();
        String currentDate = new SimpleDateFormat(dateFormat).format(d.getTime());
        return currentDate;
    }

    protected Boolean doInBackground(String... urls) {

        DebugLog.debug(TAG, "REQUEST" + MDACons.SERVER_URL + "myTeam");
        ConnectionManager cm = new ConnectionManager();
        cm.setupHttpPost(MDACons.SERVER_URL + "myTeam");
        cm.setHttpHeader("Content-Type", "application/xml");
        XmlSerializer serializer = Xml.newSerializer();
        StringWriter writer = new StringWriter();
        try {
            serializer.setOutput(writer);
            serializer.startDocument("UTF-8", true);
            serializer.startTag(null, "MGTRequest");
            generateXMLReqBlock(serializer);
            serializer.endTag(null, "MGTRequest");
            serializer.endDocument();
        }
        catch (Exception e) {}
        HttpEntity en = null;
        try {
            en = new StringEntity(writer.toString());
        }
        catch (UnsupportedEncodingException e2) {
            e2.printStackTrace();
        }
        try {
            Log.i("REQUEST", EntityUtils.toString(en));
        }
        catch (Exception e1) {
            e1.printStackTrace();
        }
        cm.setHttpPostEntity(en);
        try {
            InputSource m_is = cm.makeRequestGetResponse();
            spf = SAXParserFactory.newInstance();
            sp = spf.newSAXParser();
            xr = sp.getXMLReader();
            xr.setContentHandler(myTeamXMLHandler);
            xr.parse(m_is);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    private void generateXMLReqBlock(XmlSerializer serializer)
            throws IOException {
        serializer.startTag(null, "myTeam");
        String deviceId = prefs.getString(MDACons.DEVICE_NUMBER, "");
        serializer.startTag(null, "DeviceId");
        serializer.text(deviceId);
        serializer.endTag(null, "DeviceId");
        serializer.endTag(null, "myTeam");
    }



    public class MyTeamXMLHandler extends DefaultHandler {

        private boolean	MGT_RESPONSE_TAG				= false;
        private boolean	COMMENT_TAG					= false;
        private boolean	MY_TEAM_TAG	= false;
        private boolean	DEVICE_TAG	= false;
        private boolean	DEVICE_ID_TAG				= false;
        private boolean	DEVICE_DESC				= false;
        private boolean	GROUP_NAME				= false;
        private boolean	ADDRESS_TAG				= false;
        private boolean	LATITUDE_TAG				= false;
        public boolean	LONGITUDE_TAG				= false;

        private boolean	UPDATED_TIME_TAG				= false;
        private boolean	LAST_HOS_STAGE				= false;
        private boolean	LAST_MESSAGE				= false;
        public boolean	error_occured				= false;


        public ArrayList<MyTeamData> myTeamDataArrayList = new ArrayList<MyTeamData>();
        private MyTeamData myTeamData;
        StringBuilder builder;

        public String getErrorMSG() {
            return error_message;
        }

        public ArrayList<MyTeamData> getMyTeamDataArrayList() {
            return myTeamDataArrayList;
        }

        @Override
        public void startDocument() throws SAXException {
            myTeamDataArrayList.clear();
            myTeamData = new MyTeamData();
        }

        @Override
        public void endDocument() throws SAXException {}

        public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
            SharedPreferences sh_prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
            SharedPreferences.Editor sh_prefs_edit = sh_prefs.edit();

            builder=new StringBuilder();
            if (localName.equals("MGTResponse")) {
                this.MGT_RESPONSE_TAG = true;
                if (atts.getValue("result").equalsIgnoreCase("error")) {
                    error_occured = true;
                }
            }else if (localName.equals("Comment")) {
                this.COMMENT_TAG = true;
            }else if (localName.equals("Message")) {
                this.COMMENT_TAG = true;
                if (atts.getValue("code").equalsIgnoreCase("ACT0022")) {
                    sh_prefs_edit.putBoolean(MDACons.MY_TEAM_SHOW_MENU, false);
                    sh_prefs_edit.commit();
                }
            }else if (localName.equals("myTeam")) {
                this.MY_TEAM_TAG = true;
            }else if (localName.equals("Device")) {
                this.DEVICE_TAG = true;
            }else if (localName.equals("DeviceID")) {
                this.DEVICE_ID_TAG = true;
            }else if (localName.equals("DeviceDescription")) {
                this.DEVICE_DESC = true;
            }else if (localName.equals("groupName")) {
                this.GROUP_NAME = true;
            }else if (localName.equals("Address")) {
                this.ADDRESS_TAG = true;
            }else if (localName.equals("latitude")) {
                this.LATITUDE_TAG = true;
            }else if (localName.equals("longitude")) {
                this.LONGITUDE_TAG = true;
            }else if (localName.equals("updatedTime")) {
                this.UPDATED_TIME_TAG = true;
            }else if (localName.equals("lastHosStage")) {
                this.LAST_HOS_STAGE = true;
            }else if (localName.equals("lastMessage")) {
                this.LAST_MESSAGE = true;
            }

        }



        @Override
        public void endElement(String namespaceURI, String localName,
                               String qName) throws SAXException {
            if (localName.equals("MGTResponse")) {
                this.MGT_RESPONSE_TAG = false;
            }else if (localName.equals("Comment")) {
                this.COMMENT_TAG = false;
            }else if (localName.equals("myTeam")) {
                this.MY_TEAM_TAG = false;
            }else if (localName.equals("Device")) {
                this.DEVICE_TAG = false;
                myTeamDataArrayList.add(myTeamData);
                myTeamData = new MyTeamData();
            }else if (localName.equals("DeviceID")) {
                this.DEVICE_ID_TAG = false;
                myTeamData.setDeviceNumber(builder.toString().trim());
            }else if (localName.equals("DeviceDescription")) {
                this.DEVICE_DESC = false;
                myTeamData.setDeviceDescription(builder.toString().trim());
            }else if (localName.equals("groupName")) {
                this.GROUP_NAME = false;
                myTeamData.setGroupName(builder.toString().trim());
            }else if (localName.equals("Address")) {
                this.ADDRESS_TAG = false;
                myTeamData.setAddressString(builder.toString().trim());
            }else if (localName.equals("latitude")) {
                this.LATITUDE_TAG = false;
                myTeamData.setLatitude(builder.toString().trim());
            }else if (localName.equals("longitude")) {
                this.LONGITUDE_TAG = false;
                myTeamData.setLongitude(builder.toString().trim());
            }else if (localName.equals("updatedTime")) {
                this.UPDATED_TIME_TAG = false;
                myTeamData.setUpdatedTime(builder.toString().trim());
            }else if (localName.equals("lastHosStage")) {
                this.LAST_HOS_STAGE = false;
                myTeamData.setLastHosStage(builder.toString().trim());
            }else if (localName.equals("lastMessage")) {
                this.LAST_MESSAGE = false;
                myTeamData.setLastMessage(builder.toString().trim());
            }
        }

        @Override
        public void characters(char ch[], int start, int length) {
            if (MGT_RESPONSE_TAG && COMMENT_TAG) {
                if (error_occured) {
                    error_message = new String(ch, start, length);
                    //MDAMainActivity.pinOptinErrorCloseButtonPressedFromAsyncTask(error_message);
                }
                else
                    error_message = "";
            }
            else if (MGT_RESPONSE_TAG) {
                String tempString=new String(ch, start, length);

                builder.append(tempString);
            }


        }


    }
}


package net.abaqus.mygeotracking.deviceagent.search;

import android.text.Editable;
import android.text.TextWatcher;

public class CustomerAutoCompleteTextChangedListener implements TextWatcher{

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
	}

	@Override
	public void afterTextChanged(Editable s) {
	}

    /*public static final String TAG = "CustomAutoCompleteTextChangedListener.java";
    Context context;
    
    public CustomerAutoCompleteTextChangedListener(Context context){
        this.context = context;
    }
    
    @Override
    public void afterTextChanged(Editable s) {
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count,
            int after) {
    }

    @Override
    public void onTextChanged(CharSequence userInput, int start, int before, int count) {

        // if you want to see in the logcat what the user types
        Log.e(TAG, "User input: " + userInput);

        HOSUpdateActivity mainActivity = ((HOSUpdateActivity) context);
        
        // query the database based on the user input
        mainActivity.customer_item = mainActivity.getCusomerItemsFromDb(userInput.toString());
        
        // update the adapater
        mainActivity.customerAdapter.notifyDataSetChanged();
        mainActivity.customerAdapter = new ArrayAdapter<String>(mainActivity, android.R.layout.simple_dropdown_item_1line, mainActivity.customer_item);
        
       // mainActivity.customerAutoComplete.setAdapter(mainActivity.customerAdapter);
        
    }*/

    
}
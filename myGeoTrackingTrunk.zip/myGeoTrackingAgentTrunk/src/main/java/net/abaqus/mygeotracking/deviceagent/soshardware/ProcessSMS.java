package net.abaqus.mygeotracking.deviceagent.soshardware;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import net.abaqus.mygeotracking.deviceagent.bgthread.HOSBackgroundService;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

/**
 * Created by root on 16/12/16.
 */

public class ProcessSMS {
    private static final String TAG = ProcessSMS.class.getSimpleName();
    String hosStageId;
    String hosStageDesc;
    Context mContext;
    SendSMSReceiver sendSMSReceiver;
    SMSDeliveryReceiver smsDeliveryReceiver;
    public ProcessSMS() {}

    public void sendNow(Context context, String toPhoneNumber, String smsBody, String hosStageIdParam, String hosStageDescParam){
        mContext = context.getApplicationContext();
        hosStageId = hosStageIdParam;
        hosStageDesc = hosStageDescParam;


        callSMSIntent(toPhoneNumber,smsBody,hosStageDescParam,hosStageIdParam);

        if(hosStageId.equals("7"))
            new HOSBackgroundService().processHOS(context, "Safety Alert Triggered", hosStageId);
        else
            new HOSBackgroundService().processHOS(context, hosStageDesc, hosStageId);


//        Intent sentIntent = new Intent(SENT);
//        PendingIntent sentPI = PendingIntent.getBroadcast(
//                context.getApplicationContext(), 0, sentIntent,
//                PendingIntent.FLAG_UPDATE_CURRENT);
//
//
//        Intent deliveryIntent = new Intent(DELIVERED);
//        PendingIntent deliverPI = PendingIntent.getBroadcast(
//                context.getApplicationContext(), 0, deliveryIntent,
//                PendingIntent.FLAG_UPDATE_CURRENT);
//        sendSMSReceiver = new SendSMSReceiver();
//        smsDeliveryReceiver = new SMSDeliveryReceiver();
//
//        mContext.registerReceiver(sendSMSReceiver, new IntentFilter(SENT));
//        mContext.registerReceiver(smsDeliveryReceiver, new IntentFilter(DELIVERED));
//
//        SmsManager smsManager = SmsManager.getDefault();
//        smsManager.sendTextMessage(toPhoneNumber, null, smsBody, sentPI, deliverPI);
    }


    private void callSMSIntent(String toPhoneNumber, String smsBody, String hosParam,String hosStageIdParam) {

        Log.d(TAG,"INTENTURI "+toPhoneNumber + "PHJS "+smsBody + "HOSPARAM "+hosStageIdParam);

        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("smsto:" + Uri.encode(toPhoneNumber)));
        //intent.setData(Uri.parse("smsto:" + Uri.encode("8867621928")));
        intent.putExtra("sms_body", smsBody);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP |
                Intent.FLAG_ACTIVITY_CLEAR_TOP);
        mContext.startActivity(intent);



    }

    class SendSMSReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            mContext.unregisterReceiver(sendSMSReceiver);
            String result = "";
            switch (getResultCode()) {

                case Activity.RESULT_OK:
                    DebugLog.debug(TAG, "Success");
                    Toast.makeText(mContext, "Message sending success!",
                            Toast.LENGTH_SHORT).show();
                    break;
                case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                    result = "Message sending failed!";
                    keepInBackLog(context, result);
                    break;
                case SmsManager.RESULT_ERROR_RADIO_OFF:
                    result = "Message sending failed!";
                    keepInBackLog(context, result);
                    break;
                case SmsManager.RESULT_ERROR_NULL_PDU:
                    result = "Message sending failed!";
                    keepInBackLog(context, result);
                    break;
                case SmsManager.RESULT_ERROR_NO_SERVICE:
                    result = "No messaging service available!";
                    keepInBackLog(context, result);
                    break;
            }

        }

        private void keepInBackLog(Context context, String result) {
            DebugLog.debug(TAG, "MGT_SMS_SERVICE" + result);
            Toast.makeText(mContext, result,
                    Toast.LENGTH_LONG).show();
            if(hosStageId.equals("7"))
                new HOSBackgroundService().processHOS(context, "Safety Alert Triggered", hosStageId);
            else
                new HOSBackgroundService().processHOS(context, hosStageDesc, hosStageId);
        }
    }


    class SMSDeliveryReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            mContext.unregisterReceiver(smsDeliveryReceiver);
            switch(getResultCode()){
                case Activity.RESULT_OK:
                    DebugLog.debug(TAG, "MGT_SMS_SERVICE" + "Message delivered");
                    break;

                case Activity.RESULT_CANCELED:
                    DebugLog.debug(TAG, "MGT_SMS_SERVICE" + "Delivery failed");
                    String result = "Message delivery failed";
                    keepInBackLog(context, result);
                    new HOSBackgroundService().processHOS(context, hosStageDesc, hosStageId);
                    break;
            }
        }
        private void keepInBackLog(Context context, String result) {
            DebugLog.debug(TAG, "MGT_SMS_SERVICE" + result);
            Toast.makeText(mContext, result,
                    Toast.LENGTH_SHORT).show();
            if(hosStageId.equals("7"))
                new HOSBackgroundService().processHOS(context, "Safety Alert Triggered", hosStageId);
            else
                new HOSBackgroundService().processHOS(context, hosStageDesc, hosStageId);
        }
    }
}

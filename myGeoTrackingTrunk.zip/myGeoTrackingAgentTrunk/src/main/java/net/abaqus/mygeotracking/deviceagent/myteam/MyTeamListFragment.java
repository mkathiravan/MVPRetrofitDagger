package net.abaqus.mygeotracking.deviceagent.myteam;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by bm on 2/6/15.
 */
public class MyTeamListFragment extends ListFragment{

    private static final String TAG = MyTeamListFragment.class.getSimpleName();

    public static OnListSelectionListener mCallback;

    public static OnMenuItemClicked menuCallback;


    private ListView listView;
    private List<MyTeamData> myTeamDataList;
    private MyTeamListAdapter adapter;
    private TextView noRecord;

    // Container Activity must implement this interface
    public interface OnListSelectionListener {
        public void onItemChecked(int position);
        public void onSingleItemClick(int position);
    }


    //Menu Item implement this interface
    public interface OnMenuItemClicked{
        public void sendnotes();
        public void team_refresh();
        public void myteamMapView();
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        try {
            mCallback = (OnListSelectionListener) activity;
            menuCallback = (OnMenuItemClicked) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnHeadlineSelectedListener");
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        setHasOptionsMenu(true);

        View mainView;
        mainView = inflater.inflate(R.layout.myteam_list_fragment, container, false);

        noRecord = (TextView)mainView.findViewById(R.id.no_record);
        listView = (ListView) mainView.findViewById(android.R.id.list);

        setListViewAdapter();
        DebugLog.debug(TAG, "Call happened in OncreateView fragment");

        return mainView;

    }

    public int getMyTeamDataListCount() {
        if(myTeamDataList != null) return myTeamDataList.size(); else return 0;
    }

    public void clearMyTeamDataList(){if(myTeamDataList != null)myTeamDataList.clear();}

    public void updateListView(){getExtrasAndAssignTOList();}

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        mCallback.onItemChecked(position);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        getExtrasAndAssignTOList();


        DebugLog.debug(TAG, "Call happened in On View Created in Fragment");

    }


    private void getExtrasAndAssignTOList() {
        try{
            // Get the Bundle Object
            Bundle bundleObject = getActivity().getIntent().getExtras();

            myTeamDataList = (ArrayList<MyTeamData>) bundleObject.getSerializable(MyTeamActivity.MY_TEAM_BUNDLE_LIST);
            if(myTeamDataList.size() == 0)
            {
                noRecord.setVisibility(View.VISIBLE);
                listView.setVisibility(View.GONE);
            }
            else
            {
                adapter.setDataset(myTeamDataList);
            }

            // Get ArrayList Bundle
            adapter.setDataset(myTeamDataList);

        } catch(Exception e){
            e.printStackTrace();
        }
    }


    private void setListViewAdapter() {
        myTeamDataList = new ArrayList<>();
        adapter = new MyTeamListAdapter(getActivity(), myTeamDataList);
        listView.setAdapter(adapter);

    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.myteam_new_menu, menu);
        MenuItem myTeammap =  menu.findItem(R.id.myteam_map);
        if(myTeamDataList.size() == 0)
        {
            myTeammap.setVisible(false);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.myteam_notes:
                menuCallback.sendnotes();
                return true;

            case R.id.myteam_refresh:
                menuCallback.team_refresh();
                return true;

            case R.id.myteam_map:
                menuCallback.myteamMapView();
                return true;

        }
        return super.onOptionsItemSelected(item);
    }




}

package net.abaqus.mygeotracking.deviceagent.utils;

import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class ByteUtils {
	static String IV = "AAAAAAAAAAAAAAAA";
	static String Aplaintext1 = "1d56e33a@@@@@@@@",
							Aplaintext2 = "d398@@@@@@@@@@@@",
							Aplaintext3 = "11e2@@@@@@@@@@@@",
							Aplaintext4 = "a809@@@@@@@@@@@@",
							Aplaintext5 = "22000aaa1c49@@@@",
									AplaintextPASS = "61a01e33@@@@@@@@";
	static String encryptionKey1 = "MyMySecretKeyKey";
	static String encryptionKey2 = "MyMySecretKeyKey";
	static String encryptionKey3 = "MyMySecretKeyKey";
	static String encryptionKey4 = "MyMySecretKeyKey";
	static String encryptionKey5 = "MyMySecretKeyKey";
	private static byte[] key = { 0x4d, 0x79, 0x4d, 0x79, 0x73, 0x41, 0x53, 0x65, 0x63, 0x72, 0x65, 0x74, 0x4b, 0x65, 0x79, 0x4b, 0x65, 0x79 }; //"MySecretKey";
	public ByteUtils() {
		try {
			System.out.println("==Java==");
			System.out.println("plain: " + Aplaintext1 + ", len: " + Aplaintext1.length());
			System.out.println("plain: " + Aplaintext2 + ", len: " + Aplaintext2.length());
			System.out.println("plain: " + Aplaintext3 + ", len: " + Aplaintext3.length());
			System.out.println("plain: " + Aplaintext4 + ", len: " + Aplaintext4.length());
			System.out.println("plain: " + Aplaintext5 + ", len: " + Aplaintext5.length());
			System.out.println("plain: " + AplaintextPASS + ", len: " + AplaintextPASS.length());

			byte[] cipher1 = encrypt(Aplaintext1, encryptionKey1);
			System.out.println("cipher: " + Arrays.toString(cipher1));
			
			byte[] cipher2 = encrypt(Aplaintext2, encryptionKey2);
			System.out.println("cipher: " + Arrays.toString(cipher2));
			
			byte[] cipher3 = encrypt(Aplaintext3, encryptionKey3);
			System.out.println("cipher: " + Arrays.toString(cipher3));
			
			byte[] cipher4 = encrypt(Aplaintext4, encryptionKey4);
			System.out.println("cipher: " + Arrays.toString(cipher4));
			
			byte[] cipher5 = encrypt(Aplaintext5, encryptionKey5);
			System.out.println("cipher: " + Arrays.toString(cipher5));
			
			byte[] cipher6 = encrypt(AplaintextPASS, encryptionKey5);
			System.out.println("cipher: " + Arrays.toString(cipher6));

			String decrypted1 = decrypt(cipher1, encryptionKey1);
			System.out.println("decrypt: " + decrypted1 + ", len: " + decrypted1.length());
			
			String decrypted2 = decrypt(cipher2, encryptionKey2);
			System.out.println("decrypt: " + decrypted2+ ", len: " + decrypted2.length());
			
			String decrypted3 = decrypt(cipher3, encryptionKey3);
			System.out.println("decrypt: " + decrypted3 + ", len: " + decrypted3.length());
			
			String decrypted4 = decrypt(cipher4, encryptionKey4);
			System.out.println("decrypt: " + decrypted4 + ", len: " + decrypted4.length());
			
			String decrypted5 = decrypt(cipher5, encryptionKey5);
			System.out.println("decrypt: " + decrypted5 + ", len: " + decrypted5.length());
			
			String decryptedPASS = decrypt(cipher6, encryptionKey5);
			System.out.println("decrypt pass: " + decryptedPASS + ", len: " + decryptedPASS.length());
			
			System.out.println("decrypted joined as API_KEY: " + decrypted1+"-"+decrypted2+"-"+decrypted3+"-"+decrypted4+"-"+decrypted5+"-" + ", len: " + decrypted1.length()+decrypted2.length()+decrypted3.length()+decrypted4.length()+decrypted5.length());

			
			String reconstructed = decrypted1+"-"+decrypted2+"-"+decrypted3+"-"+decrypted4+"-"+decrypted5+"-" + ", len: " + decrypted1.length()+decrypted2.length()+decrypted3.length()+decrypted4.length()+decrypted5.length();
			System.out.println("reconstructed : " +reconstructed.replaceAll("@", ""));
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static byte[] encrypt(String plainText, String encryptionKey) throws Exception {
		// Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding", "SunJCE");
		Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
		// Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
		SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"), "AES");
		cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(IV.getBytes("UTF-8")));	
		return cipher.doFinal(plainText.getBytes("UTF-8"));
	}

	public static String decrypt(byte[] cipherText, String encryptionKey) throws Exception{
		// Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding", "SunJCE");
		Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
		// Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
		SecretKeySpec key = new SecretKeySpec(encryptionKey.getBytes("UTF-8"), "AES");
		cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(IV.getBytes("UTF-8")));
		return new String(cipher.doFinal(cipherText),"UTF-8");
	}
}

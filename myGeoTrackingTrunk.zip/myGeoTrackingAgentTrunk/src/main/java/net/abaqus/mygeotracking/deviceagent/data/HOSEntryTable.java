package net.abaqus.mygeotracking.deviceagent.data;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

public class HOSEntryTable {

	
	
	private static final String TAG = "MGT_Database";

	
    //The columns we'll include in the dictionary table
	public static final String COLUMN_ID = "_id";
    //public static final String HOS_ENTRY_STATE = "hos_entry_state";
    //public static final String HOS_ENTRY_LAT = "hos_entry_lat";
    //public static final String HOS_ENTRY_LON = "hos_entry_lon";
    //public static final String HOS_ENTRY_CUSTOMER_ID = "hos_entry_cus_id";
    //public static final String HOS_ENTRY_JOB_ID = "hos_entry_job_id";
    //public static final String HOS_ENTRY_ACCURACY = "hos_entry_accuracy";
    //public static final String HOS_ENTRY_TIME = "hos_entry_time";
    //public static final String HOS_ENTRY_NEW_CUSTOMER = "hos_entry_new_customer";
    //public static final String HOS_ENTRY_NEW_JOB = "hos_entry_new_job";
    //public static final String HOS_ENTRY_DEVICE_METHOD_LOC = "hos_entry_device_method_loc";
    //public static final String HOS_ENTRY_MESSAGE_BODY = "hos_entry_message_body";
	//public static final String HOS_ENTRY_QR_RESULT = "hos_entry_qr_result";

	public static final String HOS_ENTRY_XML = "hos_entry_xml";
	public static final String HOS_ENTRY_NO_OF_TRIES = "hos_no_of_tries";
	public static final String HOS_ENTRY_FORM_POST_DATA = "hos_entry_form_post_data";
    public static final String HOS_ENTRY_TABLE = "hosentrytable";
	
	
	
	  

	  // Database creation SQL statement
    
	  private static final String HOS_ENTRY_TABLE_CREATE = "create table " 
	      + HOS_ENTRY_TABLE
	      + "(" 
	      + COLUMN_ID + " integer primary key autoincrement, " 
	     // + HOS_ENTRY_STATE + " text null, "
	      //+ HOS_ENTRY_LAT + " text null,"
	      //+ HOS_ENTRY_LON + " text null,"
	      //+ HOS_ENTRY_CUSTOMER_ID + " text null,"
	      //+HOS_ENTRY_JOB_ID + " text null,"
	      //+HOS_ENTRY_ACCURACY + " text null,"
	      //+ HOS_ENTRY_TIME + " text null,"
	      //+ HOS_ENTRY_NEW_CUSTOMER + " text null,"
	      //+ HOS_ENTRY_NEW_JOB + " text null,"
	      //+ HOS_ENTRY_MESSAGE_BODY + " text null,"
	      //+ HOS_ENTRY_DEVICE_METHOD_LOC + " text null,"
		  //+ HOS_ENTRY_QR_RESULT + " text null,"
			  + HOS_ENTRY_XML + " text null,"
			  + HOS_ENTRY_NO_OF_TRIES + " int not null,"
			  + HOS_ENTRY_FORM_POST_DATA + " text null,"
			  + " text null"
	      + ");";

	  public static void onCreate(SQLiteDatabase database) {
		  DebugLog.debug(TAG, "Creating database ");
	    database.execSQL(HOS_ENTRY_TABLE_CREATE);
	  }

	  public static void onUpgrade(SQLiteDatabase database, int oldVersion,
	      int newVersion) {
	    DebugLog.debug(TAG, "Upgrading database from version "
				+ oldVersion + " to " + newVersion
				+ ", which will destroy all old data");
	    database.execSQL("DROP TABLE IF EXISTS " + HOS_ENTRY_TABLE);
	    onCreate(database);

	  }
	
}

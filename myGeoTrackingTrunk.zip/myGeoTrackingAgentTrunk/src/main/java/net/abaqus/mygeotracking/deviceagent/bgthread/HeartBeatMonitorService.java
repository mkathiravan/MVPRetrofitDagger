package net.abaqus.mygeotracking.deviceagent.bgthread;

import net.abaqus.mygeotracking.deviceagent.heartbeat.ConstructHeartBeat;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HBTask;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;

public class HeartBeatMonitorService extends Service{

	private Context mContext;

	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {

	    this.mContext = this;
		new ConstructHeartBeat(mContext).processHBEntries("HeartBeatMonitorService");

	    if (NetworkConnectionInfo.isOnline(mContext))
	    	new HBTask(mContext).execute();
	    else
	    {
			SharedPreferences sh_prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
			SharedPreferences.Editor sh_prefs_edit = sh_prefs.edit();
			sh_prefs_edit.putBoolean(MDACons.HB_SENT_STATUS, false);
			sh_prefs_edit.apply();
	    }
		return START_STICKY;
	}
}

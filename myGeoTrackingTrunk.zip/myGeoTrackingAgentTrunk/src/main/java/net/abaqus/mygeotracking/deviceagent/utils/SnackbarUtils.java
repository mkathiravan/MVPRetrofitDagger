package net.abaqus.mygeotracking.deviceagent.utils;


import android.support.annotation.ColorInt;
import android.support.annotation.LayoutRes;
import android.support.design.widget.Snackbar;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import java.lang.ref.WeakReference;

/**
 * Created by root on 26/5/17.
 */

public final class SnackbarUtils {

    private SnackbarUtils() {
        throw new UnsupportedOperationException("u can't instantiate me...");
    }

    private static WeakReference<Snackbar> snackbarWeakReference;

    /**
     *
     *
     * @param parent
     * @param text
     * @param textColor
     * @param bgColor
     */
    public static void showShort(View parent,
                                 CharSequence text,
                                 @ColorInt int textColor,
                                 @ColorInt int bgColor) {
        show(parent,
                text,
                Snackbar.LENGTH_SHORT,
                textColor,
                bgColor,
                null,
                -1,
                null);
    }

    /**
     *
     * @param parent
     * @param text
     * @param textColor
     * @param bgColor
     * @param actionText
     * @param actionTextColor
     * @param listener
     */
    public static void showShort(View parent,
                                 CharSequence text,
                                 @ColorInt int textColor,
                                 @ColorInt int bgColor,
                                 CharSequence actionText,
                                 @ColorInt int actionTextColor,
                                 View.OnClickListener listener) {
        show(parent,
                text,
                Snackbar.LENGTH_SHORT,
                textColor,
                bgColor,
                actionText,
                actionTextColor,
                listener);
    }

    /**
     *
     * @param parent
     * @param text
     * @param textColor
     * @param bgColor
     */
    public static void showLong(View parent,
                                CharSequence text,
                                @ColorInt int textColor,
                                @ColorInt int bgColor) {
        show(parent,
                text,
                Snackbar.LENGTH_LONG,
                textColor,
                bgColor,
                null,
                -1,
                null);
    }

    /**
     *
     * @param parent
     * @param text
     * @param textColor
     * @param bgColor
     * @param actionText
     * @param actionTextColor
     * @param listener
     */
    public static void showLong(View parent,
                                CharSequence text,
                                @ColorInt int textColor,
                                @ColorInt int bgColor,
                                CharSequence actionText,
                                @ColorInt int actionTextColor,
                                View.OnClickListener listener) {
        show(parent,
                text,
                Snackbar.LENGTH_LONG,
                textColor,
                bgColor,
                actionText,
                actionTextColor,
                listener);
    }

    /**
     *
     * @param parent
     * @param text
     * @param textColor
     * @param bgColor
     */
    public static void showIndefinite(View parent,
                                      CharSequence text,
                                      @ColorInt int textColor,
                                      @ColorInt int bgColor) {
        show(parent,
                text,
                Snackbar.LENGTH_INDEFINITE,
                textColor,
                bgColor,
                null,
                -1,
                null);
    }

    /**
     *
     * @param parent
     * @param text
     * @param textColor
     * @param bgColor
     * @param actionText
     * @param actionTextColor
     * @param listener
     */
    public static void showIndefinite(View parent,
                                      CharSequence text,
                                      @ColorInt int textColor,
                                      @ColorInt int bgColor,
                                      CharSequence actionText,
                                      @ColorInt int actionTextColor,
                                      View.OnClickListener listener) {
        show(parent,
                text,
                Snackbar.LENGTH_INDEFINITE,
                textColor,
                bgColor,
                actionText,
                actionTextColor,
                listener);
    }

    /**
     *
     * @param parent
     * @param text
     * @param duration
     * @param textColor
     * @param bgColor
     * @param actionText
     * @param actionTextColor
     * @param listener
     */
    private static void show(View parent,
                             CharSequence text,
                             int duration,
                             @ColorInt int textColor,
                             @ColorInt int bgColor,
                             CharSequence actionText,
                             @ColorInt int actionTextColor,
                             View.OnClickListener listener) {
        SpannableString spannableString = new SpannableString(text);
        ForegroundColorSpan colorSpan = new ForegroundColorSpan(textColor);
        spannableString.setSpan(colorSpan, 0, spannableString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        snackbarWeakReference = new WeakReference<>(Snackbar.make(parent, spannableString, duration));
        Snackbar snackbar = snackbarWeakReference.get();
        View view = snackbar.getView();
        view.setBackgroundColor(bgColor);
        if (actionText != null && actionText.length() > 0 && listener != null) {
            snackbar.setActionTextColor(actionTextColor);
            snackbar.setAction(actionText, listener);
        }
        snackbar.show();
    }

    /**
     *
     * @param layoutId
     * @param index
     */
    public static void addView(@LayoutRes int layoutId, int index) {
        Snackbar snackbar = snackbarWeakReference.get();
        if (snackbar != null) {
            View view = snackbar.getView();
            Snackbar.SnackbarLayout layout = (Snackbar.SnackbarLayout) view;
            View child = LayoutInflater.from(view.getContext()).inflate(layoutId, null);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            params.gravity = Gravity.CENTER_VERTICAL;
            layout.addView(child, index, params);
        }
    }

    /**
     *
     * @param child
     * @param index
     * @param params
     */
    public static void addView(View child, int index, ViewGroup.LayoutParams params) {
        Snackbar snackbar = snackbarWeakReference.get();
        if (snackbar != null) {
            View view = snackbar.getView();
            Snackbar.SnackbarLayout layout = (Snackbar.SnackbarLayout) view;
            layout.addView(child, index, params);
        }
    }

    public static void dismiss() {
        if (snackbarWeakReference != null && snackbarWeakReference.get() != null) {
            snackbarWeakReference.get().dismiss();
            snackbarWeakReference = null;
        }
    }
}
package net.abaqus.mygeotracking.deviceagent.data;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

/**
 * Created by bm on 20/10/15.
 */
public class ImageAttachmentTable {
    private static final String TAG = "IMAGE_ATTACHMENT_TABLE";
    //The columns we'll include in the dictionary table
    public static final String COLUMN_ID = "_id";
    public static final String IMAGE_ATTACHMENT_PATH = "image_attachment_path";
    public static final String IMAGE_ATTACHMENT_ID = "image_attachment_id";
    public static final String IMAGE_ATTACHMENT_NAME = "image_attachment_name";
    public static final String IMAGE_ATTACHMENT_SIZE = "image_attachment_size";
    public static final String IMAGE_ATTACHMENT_TYPE = "image_attachment_type";
    public static final String IMAGE_ATTACHMENT_MD5 = "image_attachment_md5";
    public static final String IMAGE_ATTACHMENT_ORIGINAL_METADATA = "image_attachment_original_metadata";
    public static final String IMAGE_ATTACHMENT_ENTRY_NO_OF_TRIES = "attachment_no_of_tries";
    public static final String IMAGE_ATTACHMENT_TABLE = "imagestable";

    // Database creation SQL statement
    private static final String IMAGES_TABLE_CREATE = "create table "
            + IMAGE_ATTACHMENT_TABLE
            + "("
            + COLUMN_ID + " integer primary key autoincrement, "
            + IMAGE_ATTACHMENT_PATH + " text null,"
            + IMAGE_ATTACHMENT_ID + " text not null,"
            + IMAGE_ATTACHMENT_NAME + " text null,"
            + IMAGE_ATTACHMENT_SIZE + " text null,"
            + IMAGE_ATTACHMENT_TYPE + " text null,"
            + IMAGE_ATTACHMENT_MD5 + " text null,"
            + IMAGE_ATTACHMENT_ORIGINAL_METADATA + " text null,"
            + IMAGE_ATTACHMENT_ENTRY_NO_OF_TRIES + " int not null,"
            + " UNIQUE("+IMAGE_ATTACHMENT_ID+") ON CONFLICT REPLACE"

            + ");";

    public static void onCreate(SQLiteDatabase database) {
        DebugLog.debug(TAG, "Creating database ");
        database.execSQL(IMAGES_TABLE_CREATE);
    }

    public static void onUpgrade(SQLiteDatabase database, int oldVersion,
                                 int newVersion) {
        DebugLog.debug(TAG, "Upgrading database from version "
                + oldVersion + " to " + newVersion
                + ", which will destroy all old data");
            database.execSQL("DROP TABLE IF EXISTS " + IMAGE_ATTACHMENT_TABLE);
        onCreate(database);

    }
}

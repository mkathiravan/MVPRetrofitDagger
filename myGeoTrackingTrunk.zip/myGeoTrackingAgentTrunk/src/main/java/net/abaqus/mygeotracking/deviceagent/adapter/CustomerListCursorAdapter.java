package net.abaqus.mygeotracking.deviceagent.adapter;

import net.abaqus.mygeotracking.deviceagent.MGTScheduleStatus;
import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobTable;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v4.widget.CursorAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.TextView;

public class CustomerListCursorAdapter extends CursorAdapter{

	private static final String TAG = CustomerListCursorAdapter.class.getSimpleName();

	private LayoutInflater mInflater;

	public CustomerListCursorAdapter(Context context, Cursor c, int flags) {
	super(context, c, flags);
		DebugLog.debug(TAG, "CustomerListCursorAdapter() ");
		mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	@Override
	public void bindView(View view, Context context, Cursor cursor) {
	TextView nameText = (TextView) view.findViewById(R.id.text1);
	TextView siteIDText = (TextView) view.findViewById(R.id.text2);
	nameText.setText(cursor.getString(cursor.getColumnIndex(HOSCustomerANDJobTable.HOS_CJ_NAME)));
	siteIDText.setText(cursor.getString(cursor.getColumnIndex(HOSCustomerANDJobTable.HOS_CJ_SITE_ID)));
	DebugLog.debug(TAG, "Applied Customer name: "+nameText.getText());
	DebugLog.debug(TAG, "Applied Customer ID: "+siteIDText.getText());
	}

	@Override
	public View newView(Context context, Cursor cursor, ViewGroup parent) {
	DebugLog.debug(TAG, "CustomerListCursorAdapter() newView()");
	return mInflater.inflate(R.layout.hos_cj_listview_content, parent, false);
	}
	
}

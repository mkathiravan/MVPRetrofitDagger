package net.abaqus.mygeotracking.deviceagent.data;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

public class AgentEmployeeDetailsTable {

	
	
	private static final String TAG = "MGT_Database";

	
    //The columns we'll include in the dictionary table
	public static final String COLUMN_ID = "_id";
    public static final String EMPLOYEE_AKEY = "employee_key";
    public static final String EMPLOYEE_PCODE = "employee_pcode";
    public static final String EMPLOYEE_EKEY = "employee_ekey";
    public static final String EMPLOYEE_TABLE = "mgtagentemployeetable";
	
	
	
	  

	  // Database creation SQL statement
    
	  private static final String EMPLOYEE_TABLE_CREATE = "create table " 
	      + EMPLOYEE_TABLE
	      + "(" 
	      + COLUMN_ID + " integer primary key autoincrement, " 
	      + EMPLOYEE_AKEY + " text null, " 
	      + EMPLOYEE_PCODE + " text null," 
	      + EMPLOYEE_EKEY
	      + " text null" 
	      + ");";

	  public static void onCreate(SQLiteDatabase database) {
		  DebugLog.debug(TAG, "Creating database ");
	    database.execSQL(EMPLOYEE_TABLE_CREATE);
	  }

	  public static void onUpgrade(SQLiteDatabase database, int oldVersion,
	      int newVersion) {
	    DebugLog.debug(TAG, "Upgrading database from version "
	        + oldVersion + " to " + newVersion
	        + ", which will destroy all old data");
	    database.execSQL("DROP TABLE IF EXISTS " + EMPLOYEE_TABLE);
	    onCreate(database);
	  }
	
}

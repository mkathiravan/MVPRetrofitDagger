package net.abaqus.mygeotracking.deviceagent.notes;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by bm on 15/10/15.
 */
public class ImageAttachment implements Parcelable {

    private String uniqueID, size, type, md5, path, name, originalMetadata;


    public ImageAttachment() {
        this.uniqueID = "";
        this.size = "";
        this.type = "";
        this.md5 = "";
        this.path = "";
        this.name = "";
        this.originalMetadata = "";

    }

    public int describeContents() {
        return this.hashCode();
    }
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(uniqueID);
        parcel.writeString(size);
        parcel.writeString(type);
        parcel.writeString(md5);
        parcel.writeString(originalMetadata);
        parcel.writeString(path);
        parcel.writeString(name);
    }

    private void readFromParcel(Parcel source) {
        uniqueID = source.readString();
        size = source.readString();
        type = source.readString();
        md5 = source.readString();
        originalMetadata = source.readString();
        path = source.readString();
        name = source.readString();
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        public ImageAttachment createFromParcel(Parcel source) {
            return new ImageAttachment(source);
        }
        public ImageAttachment[] newArray(int size) {
            return new ImageAttachment[size];
        }
    };

    public ImageAttachment(Parcel source) {
        this.uniqueID = source.readString();
        this.size = source.readString();
        this.type = source.readString();
        this.md5 = source.readString();
        this.originalMetadata = source.readString();
        this.path = source.readString();
        this.name = source.readString();
    }

    public ImageAttachment(String uniqueID, String size, String type, String md5, String path, String name, String originalMetadata) {
        this.uniqueID = uniqueID;
        this.size = size;
        this.type = type;
        this.md5 = md5;
        this.originalMetadata = originalMetadata;
        this.path = path;
        this.name = name;
    }

    public String getPath() {
        return path;
    }

    public String getName() {
        return name;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUniqueID() {
        return uniqueID;
    }

    public String getSize() {
        return size;
    }

    public String getType() {
        return type;
    }

    public String getMd5() {
        return md5;
    }


    public void setUniqueID(String uniqueID) {
        this.uniqueID = uniqueID;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public String getOriginalMetadata() {
        return originalMetadata;
    }

    public void setOriginalMetadata(String originalMetadata) {
        this.originalMetadata = originalMetadata;
    }
}

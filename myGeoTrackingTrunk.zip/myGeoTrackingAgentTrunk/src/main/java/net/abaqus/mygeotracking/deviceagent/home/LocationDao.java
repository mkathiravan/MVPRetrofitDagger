package net.abaqus.mygeotracking.deviceagent.home;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

@Dao
public interface LocationDao {

    @Query("SELECT * FROM locationtable")
    List<LocationTable> getAll();


    @Insert
    void insert(LocationTable... locations);





}

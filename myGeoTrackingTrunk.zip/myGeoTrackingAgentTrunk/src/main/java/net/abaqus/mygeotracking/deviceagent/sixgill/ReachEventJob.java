package net.abaqus.mygeotracking.deviceagent.sixgill;

import android.content.Context;
import android.os.Bundle;

import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.Lifetime;
import com.firebase.jobdispatcher.RetryStrategy;
import com.firebase.jobdispatcher.Trigger;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

public class ReachEventJob {

    private static final String KEY_TRIGGER_SOURCE = "triggerSource";
    private static ReachEventJob uniqueInstance;

    //private constructor.
    private ReachEventJob(){
        //Prevent form the reflection.
        if (uniqueInstance != null){
            throw new RuntimeException("Use getInstance() method to get the single instance of this class.");
        }
    }

    public static synchronized ReachEventJob getInstance() {
        if (uniqueInstance == null) {
            uniqueInstance = new ReachEventJob();
        }
        return uniqueInstance;
    }

    public void justTrack(Context applicationContext, String source) {
        DebugLog.debug("Started tracking!", "with one time track");

        Bundle bundle = new Bundle();

        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(applicationContext));
        Job myJob = dispatcher.newJobBuilder()
                .setService(ReachTrackService.class)
                .setTag("location_tracking")
                .setExtras(bundle)
                .setRecurring(false)
                .setLifetime(Lifetime.FOREVER)
                .setTrigger(Trigger.NOW)
                .setReplaceCurrent(false)
                .setRetryStrategy(RetryStrategy.DEFAULT_EXPONENTIAL)
                .build();
        dispatcher.schedule(myJob);
    }
}

package net.abaqus.mygeotracking.deviceagent.bgthread;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.Settings;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.Log;

import com.sixgill.protobuf.Ingress;
import com.sixgill.sync.sdk.Reach;
import com.sixgill.sync.sdk.ReachLocationCallback;

import net.abaqus.mygeotracking.deviceagent.data.HOSEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSEntryTable;
import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.hos.HOSActivity;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.FetchLocationForHOS;
import net.abaqus.mygeotracking.deviceagent.utils.HOSEntryConstruction;
import net.abaqus.mygeotracking.deviceagent.utils.HOSPushTask;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkDeviceStatus;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import io.nlopez.smartlocation.OnLocationUpdatedListener;
import io.nlopez.smartlocation.SmartLocation;
import io.nlopez.smartlocation.location.config.LocationParams;

/**
 * Created by root on 29/6/16.
 */

public class HOSBackgroundService{

    private Context mContext;
    private static final String TAG = HOSBackgroundService.class.getSimpleName();


    public void processHOS(Context con, String hosStageDesc, String hosStageID) {
        this.mContext = con;
        DebugLog.debug(TAG, "HOSBackgroundService Has been called");
        SharedPreferences sh_prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
        SharedPreferences.Editor edit_prefs = sh_prefs.edit();
        String time = "";

        try {

            time = CurrentDateAndTime.getDateTime(new SimpleDateFormat(
                    "yyyy/MM/dd'T'HH:mm:ssZ", Locale.getDefault()));
        } catch (Exception e) {
        }
        // DebugLog.debug(TAG,("getTag", Integer.parseInt(v.getTag().toString()) + "");
        // DebugLog.debug(TAG,("getTag", v.getTag() + "");


        edit_prefs.putInt(MDACons.HOS_SELECTION,
                Integer.parseInt(hosStageID));
        edit_prefs.putString(MDACons.HOS_SELECTION_NAME,
                hosStageDesc);

        edit_prefs.putString(MDACons.HOS_TIME, time);
        edit_prefs.putString(MDACons.HOS_CUSTOMER_SELECTED_ID, "");
        edit_prefs.putString(MDACons.HOS_JOB_SELECTED_ID, "");
        edit_prefs.putString(MDACons.HOS_CUSTOMER_SELECTED_NEW, "");
        edit_prefs.putString(MDACons.HOS_JOB_SELECTED_NEW, "");
        edit_prefs.commit();
        getLocation(mContext.getApplicationContext(),
                myGeoTrackingDevieAgentApplication.AUTH_TOKEN, 500, 60);

    }









    public void getLocation(Context ctx, String token, int accuracy, int timeout) {
        Log.e("TAG", "on Get Location called");
        try {
            // If Condition is working for if user disabled location and GPS permission.
            if (ContextCompat.checkSelfPermission(mContext,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                if (NetworkConnectionInfo.isOnline(mContext))
                    pushHOSEntrytoDB();
                new HOSPushTask(mContext).execute();
                // new HOSPushTask(mContext).executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);

            }
            else
            {
                //Check the condition for SDK 27 and more because ZOS is not supporting the 27 and above.

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
//                {
//                    reach_call_location();
//                }
//                else
//                {
//                    native_call_location();
//                }
//                
                if(Build.VERSION.SDK_INT >= 26)
                {
                    native_call_location();
                }
                else
                {
                    reach_call_location();
                }




            }





        } catch (Exception e) {
            Log.e("TAG", "Exception requesting location shot - " + e.getMessage());
        }
    }


    private void native_call_location()
    {

        SmartLocation.with(mContext).location()
                .oneFix()
                .config(LocationParams.LAZY)
                .start(new OnLocationUpdatedListener() {
                    @Override
                    public void onLocationUpdated(Location location) {

                        FetchLocationForHOS.setAccuracy(location.getAccuracy() + "");
                        String methodParam = NetworkDeviceStatus.checkNetworkStatus(mContext);
                        FetchLocationForHOS.setDeviceMethod(methodParam);
                        FetchLocationForHOS.setCurrentLatitude(Double.valueOf(location.getLatitude()));
                        FetchLocationForHOS.setCurrentLongitude(Double.valueOf(location.getLongitude()));

                        String timeFormatted = "";
                        try {
                            DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd'T'HH:mm:ssZ");
                            timeFormatted = formatter.format(location.getTime());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        FetchLocationForHOS.setTimestampToSend(timeFormatted);

                        pushHOSEntrytoDB();
                        if (NetworkConnectionInfo.isOnline(mContext))
                            new HOSPushTask(mContext).execute();


                    }
                });
    }


    private void reach_call_location()
    {

        Reach.getLocation(mContext, new ReachLocationCallback(){
            @Override
            public void onLocationSuccess(Ingress.Location location) {

                FetchLocationForHOS.setAccuracy(location.getAccuracy() + "");
               // String methodParam = NetworkDeviceStatus.checkNetworkStatus(mContext);
                String methodParam = NetworkDeviceStatus.checkNetworkStatus(mContext);

                FetchLocationForHOS.setDeviceMethod(methodParam);
                FetchLocationForHOS.setCurrentLatitude(Double.valueOf(location.getLatitude()));
                FetchLocationForHOS.setCurrentLongitude(Double.valueOf(location.getLongitude()));

                String timeFormatted = "";
                try {
                    DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd'T'HH:mm:ssZ");
                    timeFormatted = formatter.format(location.getTimestamp());
                } catch (Exception e) {
                    e.printStackTrace();
                }

                FetchLocationForHOS.setTimestampToSend(timeFormatted);

                pushHOSEntrytoDB();
                if (NetworkConnectionInfo.isOnline(mContext))
                    new HOSPushTask(mContext).execute();

            }
            @Override
            public void onLocationFailure(Ingress.Error error) {

                Log.d(TAG,"Location failure");
            }
        });




    }




    private void pushHOSEntrytoDB() {
        SharedPreferences sh_prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
        SharedPreferences.Editor edit_prefs = sh_prefs.edit();

        String hos_value_to_push = "" + sh_prefs.getInt(MDACons.HOS_SELECTION, -1);
        String hos_time_to_push = "" + sh_prefs.getString(MDACons.HOS_TIME, "");

        // save data into database
        ContentValues initialValues = new ContentValues();
        String deviceId = sh_prefs.getString(MDACons.DEVICE_NUMBER, "");
        initialValues.put(HOSEntryTable.HOS_ENTRY_XML,
                HOSEntryConstruction.constructHOSEntryBlock(mContext.getApplicationContext(), deviceId, hos_value_to_push, hos_time_to_push,
                        FetchLocationForHOS.getCurrentLatitude(), FetchLocationForHOS.getCurrentLongitude(), FetchLocationForHOS.getAccuracy(), FetchLocationForHOS.getDeviceMethod(),FetchLocationForHOS.getTimestampToSend(),
                        sh_prefs.getString(MDACons.HOS_JOB_SELECTED_ID, ""),
                        sh_prefs
                                .getString(MDACons.HOS_WORK_SELECTED_ID, ""),
                        sh_prefs
                                .getString(MDACons.HOS_CUSTOMER_SELECTED_ID, ""), "", "", "", sh_prefs
                                .getString(MDACons.DEVICE_GUID, ""), null, ""));
        initialValues.put(HOSEntryTable.HOS_ENTRY_FORM_POST_DATA, "");
        initialValues.put(HOSEntryTable.HOS_ENTRY_NO_OF_TRIES, 0);
        mContext.getContentResolver().insert(HOSEntryContentProvider.CONTENT_URI,
                initialValues);
    }
}

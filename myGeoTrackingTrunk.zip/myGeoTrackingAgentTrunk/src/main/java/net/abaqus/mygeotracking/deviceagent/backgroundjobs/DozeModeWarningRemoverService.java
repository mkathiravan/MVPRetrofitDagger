package net.abaqus.mygeotracking.deviceagent.backgroundjobs;


import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

import static net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder.NOTIFICATION_ACTION_WHITELIST;
import static net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder.NOTIFICATION_ID_DOZEMODE;


/**
 * Created by user on 14-06-2018.
 */

public class DozeModeWarningRemoverService extends JobService {


    @Override
    public boolean onStartJob(JobParameters job) {
        DebugLog.debug("Started job!", "DozeModeWarningRemoverJob Service");
        //AgentNotificationBuilder.showPowerSaveModeNotification(getApplicationContext(), "From Warning Schedular", "Am I getting triggered immediately?", NOTIFICATION_ID_DOZEMODE, NOTIFICATION_ACTION_WHITELIST);
        AgentNotificationBuilder.dismissNotification(getApplicationContext(), AgentNotificationBuilder.NOTIFICATION_ID_DOZEMODE);
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters job) {
        return false;
    }
}

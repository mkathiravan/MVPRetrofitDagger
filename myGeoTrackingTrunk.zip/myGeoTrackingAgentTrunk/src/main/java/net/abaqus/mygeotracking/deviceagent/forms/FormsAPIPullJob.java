package net.abaqus.mygeotracking.deviceagent.forms;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.activeandroid.query.Select;
import com.activeandroid.util.SQLiteUtils;
import com.android.volley.Request;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import net.abaqus.mygeotracking.deviceagent.networking.VolleyHelper;
import net.abaqus.mygeotracking.deviceagent.utils.DownloadFiles;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.List;

import okhttp3.ResponseBody;
import okio.BufferedSink;
import okio.Okio;
import retrofit2.Response;
import rx.Observable;
import rx.Subscriber;

public class FormsAPIPullJob {


    interface FormsPullListener {
        void formPullCompleted(boolean formPullStatus, String errorMessage);
    }

    private static final String TAG = FormsAPIPullJob.class.getSimpleName();
    Context mContext;
    private SharedPreferences sh_prefs;
    String device_number = "";
    private FormsPullListener formsPullListener;

    //Volley Functionality
    public void load_form_data(Context contextParam, FormsPullListener formsPullListenerParam) {
        mContext = contextParam;
        formsPullListener = formsPullListenerParam;

        this.sh_prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
        device_number = sh_prefs.getString(MDACons.DEVICE_NUMBER, "");
        String url = MDACons.BASE_URL + "/track/mobile/v1/device/" + device_number + "/forms";
        StringRequest request = new StringRequest(Request.Method.GET, url, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d(TAG, "ONRESP " + response);

                SQLiteUtils.execSql("DELETE FROM " + FormsTable.class.getSimpleName());
                SQLiteUtils.execSql("DELETE FROM " + FormsPrefillTable.class.getSimpleName());
                SQLiteUtils.execSql("DELETE FROM " + FormFieldsTable.class.getSimpleName());

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String statusCode = jsonObject.getString("StatusCode");
                    if(statusCode.equals("200"))
                    {
                        String device = jsonObject.getString("Device");
                        JSONArray formArray = jsonObject.getJSONArray("forms");
                        Log.d(TAG, "FORMAR " + formArray);
                        for (int index = 0; index < formArray.length(); index++) {
                            FormsTable formsTable = new FormsTable();
                            JSONObject obj = formArray.getJSONObject(index);
                            Log.d("ISNEIR ", "ISNEIR " + obj);

                            //Inserting values into local database table(FormsTable) using ActiveAndroid
                            formsTable.setFormId(obj.getString("formId"));
                            formsTable.setFormType(obj.getString("formType"));
                            formsTable.setFormURL(obj.getString("formURL"));
                            formsTable.setFormLinkURL(obj.getString("formLinkURL"));
                            formsTable.setFormName(obj.getString("formName"));
                            formsTable.setFormToken(obj.getString("Token"));
                            formsTable.save();

                            String formPrefill = obj.getString("FormPreFill");

                            //If the formPrefill object is not empty
                            if (!formPrefill.equals("") || !formPrefill.isEmpty()) {
                                JSONObject formPrefillobj = new JSONObject(formPrefill);
                                JSONArray formPrefillDataArray = formPrefillobj.getJSONArray("FormPreFillData");
                                Log.d(TAG, "FORMPREFILLDATAARRA" + formPrefillDataArray);
                                for (int index1 = 0; index1 < formPrefillDataArray.length(); index1++) {
                                    FormsPrefillTable formsPrefillTable = new FormsPrefillTable();
                                    JSONObject FormPreFillDataobj = formPrefillDataArray.getJSONObject(index1);
                                    Log.d(TAG, "IDADD " + FormPreFillDataobj);
                                    formsPrefillTable.setFormId(obj.getString("formId"));
                                    formsPrefillTable.setPrefillKey(FormPreFillDataobj.getString("PreFillkey"));
                                    formsPrefillTable.setFormPrefillDescription(FormPreFillDataobj.getString("Prefilldescription"));
                                    formsPrefillTable.save();

                                    // To getting field list from the form list
                                    String formfield = FormPreFillDataobj.getString("Fields");

                                    if (!formfield.equals("") || !formfield.isEmpty()) {
                                        JSONObject formFieldobj = new JSONObject(formfield);
                                        JSONArray formFieldDataArray = formFieldobj.getJSONArray("Field");
                                        Log.d(TAG, "FORMFIELDARR" + formFieldDataArray);

                                        for (int index2 = 0; index2 < formFieldDataArray.length(); index2++) {
                                            FormFieldsTable formFieldsTable = new FormFieldsTable();
                                            JSONObject FormFieldsDataobj = formFieldDataArray.getJSONObject(index2);
                                            formFieldsTable.setPreFillkey(FormPreFillDataobj.getString("PreFillkey"));
                                            formFieldsTable.setFieldName(FormFieldsDataobj.getString("name"));
                                            formFieldsTable.setFieldValue(FormFieldsDataobj.getString("value"));
                                            formFieldsTable.save();
                                        }
                                    }

                                }


                            }

                        }
                        downLoadFiles();
                        //TODO: Make the interface listener call here to inform the activity about download completion
                        if(formsPullListener != null) {
                            EventBus.getDefault().post(new FormsRefreshEvent());
                            formsPullListener.formPullCompleted(true, "");
                        }

                    }
                    else
                    {
                        String status = jsonObject.getString("Status");
                        String errorMsg = jsonObject.getString("ErrorMsg");
                        //TODO: Make the interface listener call here to inform the activity about download completion with error and error message
                        if(formsPullListener != null) {
                            EventBus.getDefault().post(new FormsRefreshEvent());
                            formsPullListener.formPullCompleted(false, errorMsg);
                        }

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Log.d(TAG, "ERRORMSG" + error.getMessage());
                //TODO: Make the interface listener call here to inform the activity about download completion failure with HTTP error
                if(formsPullListener != null) {
                    EventBus.getDefault().post(new FormsRefreshEvent());
                    formsPullListener.formPullCompleted(false, "Failed to load forms!");
                }

            }
        });

        VolleyHelper.getInstance(mContext).addToRequestQueue(request);

    }





    //TODO format the code based on the guideline document or CTRL+ALT+L for this block
    public void downLoadFiles() {

        List<FormsTable> formsTableArrayList = getFormsData();

        for(FormsTable myFormTable:formsTableArrayList)
        {
            DownloadFiles.downloadZipFileRx(myFormTable,mContext);
        }
    }

    private List<FormsTable> getFormsData() {
        return new Select()
                .from(FormsTable.class)
                .execute();
    }

    //TODO Remove unused methods from this class. Below methods are unused
    //TODO Also remove commented code pieces
    private Observable<File> saveToDiskRx(final Response<ResponseBody> response, final FormsTable myFormTable) {
        return Observable.create(new Observable.OnSubscribe<File>() {
            @Override
            public void call(Subscriber<? super File> subscriber) {
                try {


                    File destinationFile = new File("/data/data/" + mContext.getPackageName() +"/" + myFormTable.formId+".html");
                    Log.d(TAG, "MYFILE :  " +destinationFile.toString());
                    BufferedSink bufferedSink = Okio.buffer(Okio.sink(destinationFile));
                    bufferedSink.writeAll(response.body().source());
                    bufferedSink.close();

                    subscriber.onNext(destinationFile);
                    subscriber.onCompleted();
                } catch (IOException e) {
                    e.printStackTrace();
                    subscriber.onError(e);
                }
            }
        });
    }

}

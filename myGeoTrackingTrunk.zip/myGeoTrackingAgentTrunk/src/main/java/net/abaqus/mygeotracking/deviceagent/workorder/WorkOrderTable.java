package net.abaqus.mygeotracking.deviceagent.workorder;

import android.graphics.ColorSpace;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;


@Table(name = "WorkOrderTable", id = "_id")
public class WorkOrderTable extends Model {

    @Column(name = "woId")
    public String woId;

    @Column(name = "woNumber")
    public String woNumber;

    @Column(name = "status")
    public String status;

    @Column(name = "startTime")
    public String startTime;

    @Column(name = "endTime")
    public String endTime;

    @Column(name = "customerName")
    public String customerName;

    @Column(name = "taskName")
    public String taskName;

    @Column(name = "schedule")
    public String schedule;

    @Column(name = "address")
    public String address;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }



    public String getWoId() {
        return woId;
    }

    public void setWoId(String woId) {
        this.woId = woId;
    }

    public String getWoNumber() {
        return woNumber;
    }

    public void setWoNumber(String woNumber) {
        this.woNumber = woNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }




}

package net.abaqus.mygeotracking.deviceagent.workorder;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class WorkOrderData implements Parcelable {

    @SerializedName("woId")
    String woId;
    @SerializedName("woNumber")
    String woNumber;
    @SerializedName("status")
    String status;

    protected WorkOrderData(Parcel in) {
        woId = in.readString();
        woNumber = in.readString();
        status = in.readString();
        startTime = in.readString();
        endTime = in.readString();
        customerName = in.readString();
        taskName = in.readString();
        schedule = in.readString();
        address = in.readString();
        dateName = in.readString();
    }

    public static final Creator<WorkOrderData> CREATOR = new Creator<WorkOrderData>() {
        @Override
        public WorkOrderData createFromParcel(Parcel in) {
            return new WorkOrderData(in);
        }

        @Override
        public WorkOrderData[] newArray(int size) {
            return new WorkOrderData[size];
        }
    };

    public WorkOrderData() {
    }

    public String getWoId() {
        return woId;
    }

    public void setWoId(String woId) {
        this.woId = woId;
    }

    public String getWoNumber() {
        return woNumber;
    }

    public void setWoNumber(String woNumber) {
        this.woNumber = woNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    @SerializedName("startTime")
    String startTime;
    @SerializedName("endTime")
    String endTime;
    @SerializedName("customerName")
    String customerName;
    @SerializedName("taskName")
    String taskName;
    @SerializedName("schedule")
    String schedule;

    public static Creator<WorkOrderData> getCREATOR() {
        return CREATOR;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @SerializedName("address")
    String address;
    String dateName;

    public String getDateName() {
        return dateName;
    }

    public void setDateName(String dateName) {
        this.dateName = dateName;
    }



    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(woId);
        dest.writeString(woNumber);
        dest.writeString(status);
        dest.writeString(startTime);
        dest.writeString(endTime);
        dest.writeString(customerName);
        dest.writeString(taskName);
        dest.writeString(schedule);
        dest.writeString(address);
        dest.writeString(dateName);
    }
}

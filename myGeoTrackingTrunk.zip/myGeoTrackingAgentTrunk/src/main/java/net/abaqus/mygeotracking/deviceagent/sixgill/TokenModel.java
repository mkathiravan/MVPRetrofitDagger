package net.abaqus.mygeotracking.deviceagent.sixgill;

import com.google.gson.annotations.SerializedName;

public class TokenModel {

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @SerializedName("token")
    private String token;
}

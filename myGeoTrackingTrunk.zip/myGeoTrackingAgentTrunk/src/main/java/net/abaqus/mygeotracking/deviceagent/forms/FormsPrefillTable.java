package net.abaqus.mygeotracking.deviceagent.forms;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;

/**
 * Created by user on 04-07-2018.
 */


@Table(name = "FormsPrefillTable",id = "_id")
public class FormsPrefillTable extends Model {

    @Column(name = "formId")
    public String formId = "";

    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId;
    }

    public String getPrefillKey() {
        return PrefillKey;
    }

    public void setPrefillKey(String prefillKey) {
        PrefillKey = prefillKey;
    }

    public String getFormPrefillDescription() {
        return formPrefillDescription;
    }

    public void setFormPrefillDescription(String formPrefillDescription) {
        this.formPrefillDescription = formPrefillDescription;
    }

    @Column(name = "PreFillkey")
    public String PrefillKey = "";

    @Column(name = "Prefilldescription")
    public String formPrefillDescription = "";


}

package net.abaqus.mygeotracking.deviceagent.bgthread;

import android.content.ContentValues;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Point;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.graphics.Palette;
import android.util.Base64;
import android.util.Log;
import android.util.Xml;
import android.widget.ImageView;

import com.drew.imaging.ImageMetadataReader;
import com.drew.metadata.Directory;
import com.drew.metadata.Metadata;
import com.drew.metadata.Tag;
import com.drew.metadata.exif.ExifSubIFDDirectory;
import com.facebook.network.connectionclass.DeviceBandwidthSampler;

import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobTable;
import net.abaqus.mygeotracking.deviceagent.data.ImageAttachmentContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.ImageAttachmentTable;
import net.abaqus.mygeotracking.deviceagent.notes.ImageAttachment;
import net.abaqus.mygeotracking.deviceagent.notes.ImageUtils;
import net.abaqus.mygeotracking.deviceagent.utils.ConnectionManager;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import org.apache.http.HttpEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlSerializer;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.UUID;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

/**
 * Created by bm on 21/10/15.
 */
public class AttachmentPushTask extends AsyncTask<String, Void, Boolean> {
    //**FIELDS**//

    private Context mContext;
    private SharedPreferences prefs;
    SAXParserFactory spf = null;
    SAXParser sp = null;
    /* Get the XMLReader of the SAXParser we created. */
    XMLReader xr = null;
    /* Create a new ContentHandler and apply it to the XML-Reader*/
    AttachmentPushXmlHandler attachmentPushXmlHandler =null;

    private static final String TAG = AttachmentPushTask.class.getSimpleName();

    public AttachmentPushTask(Context con) {
        this.mContext = con;
        this.prefs = con.getSharedPreferences(MDACons.PREFS, 0);
        attachmentPushXmlHandler =new AttachmentPushXmlHandler();
        DebugLog.debug(TAG, "AttachmentPushTask");
    }

    protected void onPreExecute() {
        DeviceBandwidthSampler.getInstance().startSampling();
    }


    protected void onPostExecute(Boolean success) {
        DeviceBandwidthSampler.getInstance().stopSampling();
        if (attachmentPushXmlHandler.error_occured){
            ContentValues initialValues = new ContentValues();
            Cursor eCursor = getImageAttachemntEntries();
            if (eCursor.moveToLast()){


                initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_ENTRY_NO_OF_TRIES, Integer.parseInt(eCursor.getString(eCursor
                        .getColumnIndexOrThrow(ImageAttachmentTable.IMAGE_ATTACHMENT_ENTRY_NO_OF_TRIES)))+1);
                this.mContext.getContentResolver().update(ImageAttachmentContentProvider.CONTENT_URI, initialValues, ImageAttachmentTable.COLUMN_ID+" = '"+ eCursor.getString(eCursor
                        .getColumnIndexOrThrow(ImageAttachmentTable.COLUMN_ID))+"'", null);
            }
            eCursor.close();
        }else{
            Cursor eCursor = getImageAttachemntEntries();
            if (eCursor.moveToLast()){


                    /*ContextWrapper cw = new ContextWrapper(mContext.getApplicationContext());
                    // path to /data/data/yourapp/app_data/imageDir
                    File directory = cw.getDir("images", Context.MODE_PRIVATE);
                    // Create imageDir
                    File mypath = new File(directory, eCursor.getString(eCursor
                            .getColumnIndexOrThrow(ImageAttachmentTable.IMAGE_ATTACHMENT_NAME)));
                    mypath.delete();*/

                    this.mContext.getContentResolver().delete(ImageAttachmentContentProvider.CONTENT_URI, ImageAttachmentTable.COLUMN_ID + " = '" + eCursor.getString(eCursor
                            .getColumnIndexOrThrow(ImageAttachmentTable.COLUMN_ID)) + "'", null);

            }
            eCursor.close();
            Cursor entryCursor = getImageAttachemntEntries();
            if (entryCursor != null && entryCursor.getCount() > 0){
                    new AttachmentPushTask(this.mContext).execute();
            }else{
			}
            entryCursor.close();
        }
    }

    protected Boolean doInBackground(String... urls) {

        try{
            Cursor entriesCursor = getImageAttachemntEntries();
            ConnectionManager cm;
            if (entriesCursor.moveToLast()){

                DebugLog.debug(TAG, MDACons.SERVER_URL + "saveAttachment");
                cm = new ConnectionManager();
                cm.setupHttpPost(MDACons.SERVER_URL + "saveAttachment");
                cm.setHttpHeader("Content-Type", "application/xml");

                String filePath = entriesCursor.getString(entriesCursor
                .getColumnIndexOrThrow(ImageAttachmentTable.IMAGE_ATTACHMENT_PATH));
                String fileName = entriesCursor.getString(entriesCursor
                                .getColumnIndexOrThrow(ImageAttachmentTable.IMAGE_ATTACHMENT_NAME));

                String originalMetaData = entriesCursor.getString(entriesCursor.getColumnIndexOrThrow(ImageAttachmentTable.IMAGE_ATTACHMENT_ORIGINAL_METADATA));

                Bitmap bmp = getBitmap(filePath, fileName);

                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                if(entriesCursor.getString(entriesCursor
                        .getColumnIndexOrThrow(ImageAttachmentTable.IMAGE_ATTACHMENT_NAME)).contains(".png")) {
                    bmp = ImageUtils.waterMarkIt(mContext, bmp, "@mGT: " + originalMetaData, new Point(10, bmp.getHeight()-40), Color.BLACK, 100, 12, false);
                    bmp.compress(Bitmap.CompressFormat.PNG, 50, stream);
                }
                else {
                    bmp = ImageUtils.waterMarkIt(mContext, bmp, "@mGT: " + originalMetaData, new Point(10, bmp.getHeight()-40), Color.WHITE, 100, 12, false);
                    bmp.compress(Bitmap.CompressFormat.JPEG, 75, stream);
                }
                byte[] byteArray = stream.toByteArray();

                String encodedImage = "";
                if(byteArray != null)
                     encodedImage = Base64.encodeToString(byteArray, Base64.DEFAULT);

                        if(Integer.parseInt(entriesCursor.getString(entriesCursor
                                .getColumnIndexOrThrow(ImageAttachmentTable.IMAGE_ATTACHMENT_ENTRY_NO_OF_TRIES))) >= 5)
                        {
                            attachmentPushXmlHandler.error_occured = false;
                            return true;
                        }

                XmlSerializer serializer = Xml.newSerializer();
                StringWriter writer = new StringWriter();
                try {
                    serializer.setOutput(writer);
                    serializer.startDocument("UTF-8", true);
                    serializer.startTag(null, "MGTRequest");
                    serializer.startTag(null, "Attachments");
                    serializer.startTag(null, "Attachment");

                    serializer.startTag(null, "Id");
                    serializer.text(entriesCursor.getString(entriesCursor
                            .getColumnIndexOrThrow(ImageAttachmentTable.IMAGE_ATTACHMENT_ID)));
                    serializer.endTag(null, "Id");

                    serializer.startTag(null, "deviceID");
                    serializer.text(prefs.getString(MDACons.DEVICE_NUMBER,""));
                    serializer.endTag(null, "deviceID");

                    serializer.startTag(null, "WorkOrderID");
                    serializer.text(prefs.getString(MDACons.WORK_ORDER_NUMBER,""));
                    serializer.endTag(null, "WorkOrderID");


                    serializer.startTag(null,"CustomerID");
                    serializer.text(prefs.getString(MDACons.HOS_CUSTOMER_SELECTED_ID,""));
                    serializer.endTag(null,"CustomerID");

                    if(encodedImage != null) {
                        serializer.startTag(null, "Data");
                        serializer.text(encodedImage);
                        serializer.endTag(null, "Data");
                    }

                    serializer.startTag(null, "MD5");
                    serializer.text(entriesCursor.getString(entriesCursor
                            .getColumnIndexOrThrow(ImageAttachmentTable.IMAGE_ATTACHMENT_MD5)));
                    serializer.endTag(null, "MD5");

                    serializer.endTag(null, "Attachment");
                    serializer.endTag(null, "Attachments");
                    serializer.endTag(null, "MGTRequest");
                    serializer.endDocument();
                }
                catch (Exception e) {}
                HttpEntity en = null;
                try {
                    en = new StringEntity(writer.toString());
                }
                catch (UnsupportedEncodingException e2) {
                    e2.printStackTrace();
                }
                try {
                     Log.i("REQUEST", EntityUtils.toString(en));
                }
                catch (Exception e1) {
                    e1.printStackTrace();
                }




                cm.setHttpPostEntity(en);


                try {
                    InputSource m_is = cm.makeRequestGetResponse();
                    spf = SAXParserFactory.newInstance();
                    sp = spf.newSAXParser();

		        /* Get the XMLReader of the SAXParser we created. */
                    xr = sp.getXMLReader();
                    xr.setContentHandler(attachmentPushXmlHandler);
                    xr.parse(m_is);


                }catch (Exception e)
                {
                    attachmentPushXmlHandler.error_occured = true;
                    e.printStackTrace();
                }
                entriesCursor.close();
                return true;
            }else{
                entriesCursor.close();
                return false;
            }

        }catch(Exception e){
            e.printStackTrace();
            return false;
        }

    }
    public static int getDominantColor(Bitmap bitmap) {
        Bitmap newBitmap = Bitmap.createScaledBitmap(bitmap, 1, 1, true);
        final int color = newBitmap.getPixel(0, 0);
        newBitmap.recycle();
        return color;
    }

    private Bitmap loadBitmapFromStorage(String path, String fileName)
    {
        Bitmap bitmap = null;
        try {
            File f=new File(path, fileName);
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inTempStorage = new byte[56568];
            options.inPreferQualityOverSpeed = true;
            bitmap = BitmapFactory.decodeStream(new FileInputStream(f), null, options);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        return bitmap;
    }



    private Bitmap getBitmap(String path, String fileName) {


        InputStream in = null;
        File f = new File(path, fileName);
        try {
            final int IMAGE_MAX_SIZE = 1200000; // 1.2MP
            in = new FileInputStream(f);

            // Decode image size
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(in, null, o);
            in.close();


            int scale = 1;
            while ((o.outWidth * o.outHeight) * (1 / Math.pow(scale, 2)) >
                    IMAGE_MAX_SIZE) {
                scale++;
            }
            Log.d("IMAGE_TAG", "scale = " + scale + ", orig-width: " + o.outWidth + ",orig-height: " + o.outHeight);

            Bitmap b = null;
            in = new FileInputStream(f);
            if (scale > 1) {
                scale = 1;
                // scale to max possible inSampleSize that still yields an image
                // larger than target
                o = new BitmapFactory.Options();
                o.inSampleSize = scale;
                b = BitmapFactory.decodeStream(in, null, o);

                // resize to desired dimensions
                int height = b.getHeight();
                int width = b.getWidth();
                Log.d("IMAGE_TAG", "1th scale operation dimenions - width: " + width + ",height: " + height);

                double y = Math.sqrt(IMAGE_MAX_SIZE
                        / (((double) width) / height));
                double x = (y / height) * width;

                Bitmap scaledBitmap = Bitmap.createScaledBitmap(b, (int) x,
                        (int) y, true);
                b.recycle();
                b = scaledBitmap;

                System.gc();
            } else {
                //b = BitmapFactory.decodeStream(in);
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inTempStorage = new byte[56568];
                options.inPreferQualityOverSpeed = true;
                b = BitmapFactory.decodeStream(new FileInputStream(f), null, options);
            }
            in.close();

            Log.d("IMAGE_TAG", "bitmap size - width: " + b.getWidth() + ", height: " +
                    b.getHeight());
            return b;
        } catch (IOException e) {
            Log.e("IMAGE_TAG", e.getMessage(), e);
            return null;
        }
    }

    private Cursor getImageAttachemntEntries() {

        Cursor cursor = this.mContext.getContentResolver().query(Uri.parse(ImageAttachmentContentProvider.CONTENT_URI.toString()), null, null, null,
                null);

        return cursor;
    }

    public static String error_message = "";

    public class AttachmentPushXmlHandler extends DefaultHandler{
        private boolean GTS_RES_TAG = false;
        private boolean CMNT_TAG = false;

        public boolean error_occured = false;

        public String getErrorMSG(){
            return error_message;
        }

        @Override
        public void startDocument() throws SAXException {

        }

        @Override
        public void endDocument() throws SAXException {
            // Nothing to do
        }

        public void startElement(String namespaceURI, String localName,
                                 String qName, Attributes atts) throws SAXException {

            if (localName.equals("MGTResponse")) {
                this.GTS_RES_TAG = true;
                if(atts.getValue("result").equalsIgnoreCase("error"))
                {
                    error_occured = true;
                }
            }else if (localName.equals("Comment")) {
                this.CMNT_TAG = true;
            }
        } /* startELement */

        @Override
        public void endElement(String namespaceURI, String localName, String qName)
                throws SAXException {
            if (localName.equals("MGTResponse")) {
                this.GTS_RES_TAG = false;
            }else if (localName.equals("Comment")) {
                this.CMNT_TAG = false;
            }
        }

        @Override
        public void characters(char ch[], int start, int length) {
            if (GTS_RES_TAG && CMNT_TAG)
            {
                if (error_occured)
                    error_message = new String(ch,start,length);

            }

        }/* characters*/
    }


}
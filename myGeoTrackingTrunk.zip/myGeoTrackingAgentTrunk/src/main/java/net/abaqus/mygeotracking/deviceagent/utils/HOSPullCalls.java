package net.abaqus.mygeotracking.deviceagent.utils;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;

import net.abaqus.mygeotracking.deviceagent.bgthread.RegistrationTaskMGT;
import net.abaqus.mygeotracking.deviceagent.forms.FormsAPIPullJob;
import net.abaqus.mygeotracking.deviceagent.listeners.TaskCompleteListener;

import java.util.concurrent.ExecutionException;

public class HOSPullCalls implements TaskCompleteListener{

	private TaskCompleteListener listener;
	private Context mContext;

	public static void makeHOSInitializeCalls(final Context con, Handler thisHandler)
	{
		if(thisHandler != null) {
			RegistrationTaskMGT registrationTaskMGT = new RegistrationTaskMGT(null, con);
			registrationTaskMGT.execute("");
		}

		AsyncTask.execute(new Runnable() {
			@Override
			public void run() {
				new FormsAPIPullJob().load_form_data(con, null);
			}
		});
			HOSCustomerIDJobIDPullTask customers = new HOSCustomerIDJobIDPullTask(
					con, HOSCustomerIDJobIDPullTask.CustomerJob.CUSTOMER);
			customers.execute();

			HOSCustomerIDJobIDPullTask jobs = new HOSCustomerIDJobIDPullTask(con,
					HOSCustomerIDJobIDPullTask.CustomerJob.JOB);
			jobs.execute();

			HOSLabelPULLTask re1 = new HOSLabelPULLTask(con);
			re1.setPullTaskHandler(thisHandler);
			re1.execute();

	}
	
	public static void makeHOSInitializeCallsInBg(final Context con, boolean showProgress)
	{
		RegistrationTaskMGT registrationTaskMGT = new RegistrationTaskMGT(null, con);
		registrationTaskMGT.execute("");
		AsyncTask.execute(new Runnable() {
			@Override
			public void run() {
				new FormsAPIPullJob().load_form_data(con, null);
			}
		});
			HOSCustomerIDJobIDPullTask customers = new HOSCustomerIDJobIDPullTask(
					con, HOSCustomerIDJobIDPullTask.CustomerJob.CUSTOMER);
			customers.execute();

			HOSCustomerIDJobIDPullTask jobs = new HOSCustomerIDJobIDPullTask(con,
					HOSCustomerIDJobIDPullTask.CustomerJob.JOB);
			jobs.execute();

			HOSLabelPULLTask re1 = new HOSLabelPULLTask(con, true);
			re1.setPullTaskHandler(null);
			re1.execute();

	}
	
	public void makeHOSInitializeCallsWithResult(Context con, TaskCompleteListener taskListener)
	{

		this.listener = taskListener;
		this.mContext = con;
		RegistrationTaskMGT registrationTaskMGT = new RegistrationTaskMGT(this, mContext);
		registrationTaskMGT.execute("");
		try {
			if(listener != null)
				listener.onTaskCompleted(registrationTaskMGT.get());
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void onTaskCompleted(boolean success) {


		AsyncTask.execute(new Runnable() {
			@Override
			public void run() {
				new FormsAPIPullJob().load_form_data(mContext, null);
			}
		});
			new HOSLabelPULLTask(this.mContext).execute();
			//lab_result.execute();
			new HOSCustomerIDJobIDPullTask(this.mContext, HOSCustomerIDJobIDPullTask.CustomerJob.JOB).execute();
			//jobs_result.execute();
			new HOSCustomerIDJobIDPullTask(this.mContext, HOSCustomerIDJobIDPullTask.CustomerJob.CUSTOMER).execute();
			//customer_result.execute();


	}
}

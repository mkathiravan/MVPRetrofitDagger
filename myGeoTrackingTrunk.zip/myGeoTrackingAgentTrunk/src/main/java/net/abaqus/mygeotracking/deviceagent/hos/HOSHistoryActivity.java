package net.abaqus.mygeotracking.deviceagent.hos;

import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.activeandroid.query.Select;
import com.activeandroid.util.SQLiteUtils;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiClient;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiInterface;
import net.abaqus.mygeotracking.deviceagent.data.HOSHistoryEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSHistoryEntryTable;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HeartBeat;
import net.abaqus.mygeotracking.deviceagent.heartbeat.TriggerSource;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.SnackbarUtils;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Created by user on 22-06-2018.
 */

public class HOSHistoryActivity extends ReceiverActivity {

    @BindView(R.id.recyclerView)
    RecyclerView mRecyclerView;
    @BindView(R.id.errorViewLayout)
    LinearLayout errorViewLayout;
    @BindView(R.id.swipeContainer)
    SwipeRefreshLayout swipeContainer;
    @BindView(R.id.last_updated_info_layout)
    LinearLayout lastUpdatedInfoLayout;
    @BindView(R.id.last_update)
    TextView lastUpdatedTextView;
    @BindView(R.id.tvTotalHours)
    TextView totalHoursText;
    @BindView(R.id.todayTotalHours)
    TextView todaytotalHoursText;
    @BindView(R.id.recyclerViewLayout)
    LinearLayout recyclerViewLayout;
    @BindView(R.id.root_layout)
    LinearLayout rootLayout;

    private RecyclerView.LayoutManager mLayoutManager;
    private HOSHistoryAdapter mAdapter;
    private SharedPreferences sh_prefs;
    private SharedPreferences.Editor editor_sh_prefs;
    List<HOSHistoryDetail> hoshistoryList;
    private List<ScanQRTable> scanQRList;
    String device_number = "";
    private Cursor hosHistoryValues;
    private SimpleDateFormat requestQueryDateFormat = new SimpleDateFormat("yyyy/MM/dd");
    private String requestQueryDate = CurrentDateAndTime.getDate(requestQueryDateFormat);
    private static final String TAG = HOSHistoryActivity.class.getSimpleName();
   // private String fromDate = "";
    private String fromDate = "", weekly_distance = "", daily_distance = "", weekly_hours = "", daily_hours = "";


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hos_history);
        ButterKnife.bind(this);

        // To get the date from sunday to today
        Calendar c=Calendar.getInstance();
        c.set(Calendar.DAY_OF_WEEK,Calendar.SUNDAY);
        c.set(Calendar.HOUR_OF_DAY,0);
        c.set(Calendar.MINUTE,0);
        c.set(Calendar.SECOND,0);
        DateFormat df=new SimpleDateFormat("yyyy/MM/dd");
        System.out.println(df.format(c.getTime()));      // This past Sunday [ May include today ]
        fromDate = df.format(c.getTime());

        sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
        editor_sh_prefs = sh_prefs.edit();

        device_number = sh_prefs.getString(MDACons.DEVICE_NUMBER, "");

        mRecyclerView.setHasFixedSize(true);
        hoshistoryList = new ArrayList<>();

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new HOSHistoryAdapter(this, hoshistoryList);
        mRecyclerView.setAdapter(mAdapter);


        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                if (!NetworkConnectionInfo.isOnline(HOSHistoryActivity.this)) {
                    SnackbarUtils.showShort(rootLayout, getString(R.string.msg_internet_disabled_please_try_later), Color.WHITE, ContextCompat.getColor(HOSHistoryActivity.this, R.color.alert));
                    offlineData();
                    return;
                }

                SnackbarUtils.showIndefinite(rootLayout, "Refreshing. Please wait.", Color.BLACK, ContextCompat.getColor(HOSHistoryActivity.this, R.color.yellow));
                swipeRefreshData();
            }
        });

        if (!this.sh_prefs.getString(MDACons.DEVICE_NUMBER, "").equals("")) {
            if (NetworkConnectionInfo.isOnline(this)) {
                swipeContainer.setRefreshing(true);
                SnackbarUtils.showIndefinite(rootLayout, "Loading. Please wait.", Color.BLACK, ContextCompat.getColor(HOSHistoryActivity.this, R.color.yellow));
                swipeRefreshData();
            } else {
                offlineData();
            }

        }

        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(R.color.blue,
                R.color.blue_dullish,
                R.color.yellow);


        ActionBar actionBar = initActionBar();
        setPageTitle(actionBar);




    }

    private void offlineData() {
        swipeContainer.setRefreshing(false);
        updateUI();
    }


    @NonNull
    private ActionBar initActionBar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        return actionBar;
    }


    private void setPageTitle(ActionBar actionBar) {
        if (this.sh_prefs.getString(MDACons.HOS_GROUP_ID, "").equals("Mobile"))
            actionBar.setTitle("Time Clock Report");
        else
            actionBar.setTitle("Hours-Of-Service Report");
    }




    private String getTotalhours(List<HOSHistoryDetail> hoshistoryList) {
        int finalMins = 0;
        for (int index = 0; index < hoshistoryList.size(); index++) {
            String service_hour = "";
            service_hour = hoshistoryList.get(index).getServiceHour();
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

            int middleIndex = service_hour.indexOf(":");
            int hours = Integer.parseInt(service_hour.substring(0, middleIndex));
            int minutes = Integer.parseInt(service_hour.substring(middleIndex + 1, service_hour.length()));
            int totalMins = (hours * 60) + minutes;
            finalMins = finalMins + totalMins;

        }

        int hours = finalMins / 60; //since both are ints, you get an int
        int minutes = finalMins % 60;

        return hours + ":" + minutes;
    }

    private String getTodayhours(List<HOSHistoryDetail> hoshistoryList)
    {
        int finalMins = 0;
        for(int index = 0; index < hoshistoryList.size(); index++)
        {
            Date todaysDate = new Date(hoshistoryList.get(index).getStageTime());
            SimpleDateFormat onFormat = new SimpleDateFormat("yyyy/MM/dd");
            String convert_todayDate = onFormat.format(todaysDate);
            if(requestQueryDate.equals(convert_todayDate))
            {
                String service_hour = "";
                service_hour = hoshistoryList.get(index).getServiceHour();
                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

                int middleIndex = service_hour.indexOf(":");
                int hours = Integer.parseInt(service_hour.substring(0, middleIndex));
                int minutes = Integer.parseInt(service_hour.substring(middleIndex + 1, service_hour.length()));
                int totalMins = (hours * 60) + minutes;
                finalMins = finalMins + totalMins;
            }

        }
        int hours = finalMins / 60; //since both are ints, you get an int
        int minutes = finalMins % 60;

        return hours + ":" + minutes;
    }


    private void swipeRefreshData() {
        Log.d(TAG,"SWIPRFRE ");


        hideRefreshView();
        load_hos_services(fromDate,requestQueryDate);
        //load_hos_services(fromDate, requestQueryDate);
        hoshistoryList.clear();
        mAdapter.notifyDataSetChanged();
    }



    private long insertHOSHistoryEnteryInDB(HOSHistoryDetail hoshistoryDetail) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(HOSHistoryEntryTable.HOS_HISTORY_STAGETIME, hoshistoryDetail.getStageTime());
        initialValues.put(HOSHistoryEntryTable.HOS_HISTORY_STAGEID, hoshistoryDetail.getStageId());
        initialValues.put(HOSHistoryEntryTable.HOS_HISTORY_STAGEDESC, hoshistoryDetail.getStageDesc());
        initialValues.put(HOSHistoryEntryTable.HOS_HISTORY__SERVICEHOUR, hoshistoryDetail.getServiceHour());
        initialValues.put(HOSHistoryEntryTable.HOS_TEXT_NOTES, hoshistoryDetail.getTextNotes());
        initialValues.put(HOSHistoryEntryTable.HOS_ADDRESS,hoshistoryDetail.getAddress());
        Uri uri = this.getContentResolver().insert(HOSHistoryEntryContentProvider.CONTENT_URI, initialValues);
        return Long.valueOf(uri.getLastPathSegment());
    }


    private void load_hos_services(String fromDate, String toDate) {
        final ApiInterface requestInterface = ApiClient.getClient();
        //TODO: Need to remove hardcoded date and device number
        Call<HOSHistoryResponse> call = requestInterface.getHosHistory(device_number,fromDate,toDate,"0");
        call.enqueue(new Callback<HOSHistoryResponse>() {
            @Override
            public void onResponse(Call<HOSHistoryResponse> call, Response<HOSHistoryResponse> response) {

                if(response.isSuccessful())
                {
                    swipeContainer.setRefreshing(false);
                    SnackbarUtils.dismiss();
                    editor_sh_prefs.putString(MDACons.HOS_HISTORY_UPDATED_TIME, CurrentDateAndTime.getCurrentTime(new SimpleDateFormat("yyyy/MM/dd, HH:mm:ss")));
                    editor_sh_prefs.apply();

                    // If the response code is 200 we are showing the data
                    if (response.code() == 200) {

                        if (response.body().getStatusCode().equalsIgnoreCase("72")) {
                            showErrorView();
                        }
                        else if(response.body().getStatusCode().equalsIgnoreCase("200")){
                            hoshistoryList = response.body().getHos();
                            daily_hours = response.body().getTotal().getDailyHrs();
                            weekly_hours = response.body().getTotal().getWeeklyHrs();
                            daily_distance = response.body().getTotal().getDailyDistance();
                            weekly_distance = response.body().getTotal().getWeeklyDistance();

                            Log.d(TAG,"IDRELDF "+daily_distance + "WEEKLYDISTAMCE "+weekly_distance);
                            Log.d(TAG,"WEEKLY_DAILY_HRS "+ weekly_hours + " DAILY " +daily_hours);

                            //Clear the existing entries in both HOSHistory Table and ScanQR Table
                            SQLiteUtils.execSql("DELETE FROM " + ScanQRTable.class.getSimpleName());
                            getApplicationContext().getContentResolver().delete(HOSHistoryEntryContentProvider.CONTENT_URI, null, null);

                            for (HOSHistoryDetail hosHistoryEntry : hoshistoryList) {
                                if(hosHistoryEntry.getStageDesc().isEmpty())
                                    hosHistoryEntry.setStageDesc("Unknown Stage");

                                if(hosHistoryEntry.getServiceHour() == null || hosHistoryEntry.getServiceHour().isEmpty())
                                    hosHistoryEntry.setServiceHour("00:00");

                                long hosEntryTableRowId = insertHOSHistoryEnteryInDB(hosHistoryEntry);

                                if(!hosHistoryEntry.getScanNotes().isEmpty())
                                {
                                    insertScanNotesInDB(hosHistoryEntry.getScanNotes(), hosEntryTableRowId);

                                }


                            }

                            runOnUiThread(new Runnable() {
                                public void run() {

                                    hideErrorView();
                                    updateUI();
                                }
                            });

                        }
                        else {
                            showErrorView();
                        }
                    }
                    else
                    {
                        Toast.makeText(HOSHistoryActivity.this,MDACons.ERROR_PROTOCOL_ERROR,Toast.LENGTH_SHORT).show();
                    }
                }

                else {
                    Toast.makeText(HOSHistoryActivity.this, "Server returned an error", Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onFailure(Call<HOSHistoryResponse> call, Throwable t) {
                swipeContainer.setRefreshing(false);
                SnackbarUtils.dismiss();
                SnackbarUtils.showShort(rootLayout, t.getMessage(), Color.WHITE, ContextCompat.getColor(HOSHistoryActivity.this, R.color.alert));

                Log.d(TAG,"EXVEPTUONTHIRE "+t.getMessage());
                if(call.isCanceled())
                {
                    Log.e(TAG, "request was cancelled");
                }

                if(t instanceof SocketTimeoutException){
                    String message = "Socket Time out. Please try again.";
                    Toast.makeText(HOSHistoryActivity.this,message,Toast.LENGTH_SHORT).show();
                }
                else if(t instanceof IOException)
                {
                    Toast.makeText(HOSHistoryActivity.this, "this is an actual network failure :( inform the user and possibly retry", Toast.LENGTH_SHORT).show();

                }
                else {
                    Toast.makeText(HOSHistoryActivity.this, "conversion issue! big problems :(", Toast.LENGTH_SHORT).show();
                    // todo log to some central bug tracking service
                }

            }
        });


    }

    private void insertScanNotesInDB(List<ScanNotes> scanNotes, long hosEntryTableIdParam) {

        for (int index = 0; index < scanNotes.size(); index++)
        {
            ScanQRTable scanQRTable = new ScanQRTable();
            scanQRTable.setQR(scanNotes.get(index).getQR());
            scanQRTable.setHistory_info_id(Long.toString(hosEntryTableIdParam));
            scanQRTable.save();

        }
    }


    private void showErrorView() {
        errorViewLayout.setVisibility(View.VISIBLE);
        recyclerViewLayout.setVisibility(View.GONE);
        lastUpdatedInfoLayout.setVisibility(View.GONE);
    }

    private void hideRefreshView()
    {
        recyclerViewLayout.setVisibility(View.GONE);
        lastUpdatedInfoLayout.setVisibility(View.GONE);
    }

    private void hideErrorView() {
        errorViewLayout.setVisibility(View.GONE);
        recyclerViewLayout.setVisibility(View.VISIBLE);
        lastUpdatedInfoLayout.setVisibility(View.VISIBLE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.timeclocking_menu, menu);
        MenuItem menuHistoryItem = menu.findItem(R.id.action_hos_history);
        menuHistoryItem.setVisible(false);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                finish();

            case R.id.action_timeclocking_refresh:
                if (!NetworkConnectionInfo.isOnline(HOSHistoryActivity.this)) {
                    SnackbarUtils.showShort(rootLayout, getString(R.string.msg_internet_disabled_please_try_later), Color.WHITE, ContextCompat.getColor(HOSHistoryActivity.this, R.color.alert));
                    break;
                }
                if (!swipeContainer.isRefreshing()) {
                    swipeContainer.setRefreshing(true);
                    SnackbarUtils.showIndefinite(rootLayout, "Refreshing. Please wait.", Color.BLACK, ContextCompat.getColor(HOSHistoryActivity.this, R.color.yellow));
                    swipeRefreshData();
                    break;
                }
        }
        return super.onOptionsItemSelected(item);
    }


    private void updateUI() {
        hosHistoryValues = fetchHOSHistoryData();
        constructHOSHistoryArray(hosHistoryValues);

        if (hoshistoryList.size() <= 0) {
            showErrorView();
            return;
        }
        hideErrorView();

        lastUpdatedTextView.setText("Last updated: " + sh_prefs.getString(MDACons.HOS_HISTORY_UPDATED_TIME, "Unknown"));

        totalHoursText.setText(weekly_hours+ " / " + weekly_distance);
        todaytotalHoursText.setText(daily_hours + " / " + daily_distance);


        mAdapter.updateDataSet(hoshistoryList);
        mAdapter.notifyDataSetChanged();
    }


    private void constructHOSHistoryArray(Cursor mCursor) {

        if (mCursor != null) {
            hoshistoryList.clear();
            String stage_time = "", stage_id = "", stage_desc = "", service_hour = "", text_notes = "", address = "",rowId = "";
            HOSHistoryDetail hos_history_detail = new HOSHistoryDetail();
            for (int i = 0; i < mCursor.getCount(); i++) {
                mCursor.moveToPosition(i);
                stage_time = mCursor.getString(mCursor.getColumnIndexOrThrow(HOSHistoryEntryTable.HOS_HISTORY_STAGETIME));
                stage_id = mCursor.getString(mCursor.getColumnIndexOrThrow(HOSHistoryEntryTable.HOS_HISTORY_STAGEID));
                stage_desc = mCursor.getString(mCursor.getColumnIndexOrThrow(HOSHistoryEntryTable.HOS_HISTORY_STAGEDESC));
                service_hour = mCursor.getString(mCursor.getColumnIndexOrThrow(HOSHistoryEntryTable.HOS_HISTORY__SERVICEHOUR));
                text_notes = mCursor.getString(mCursor.getColumnIndexOrThrow(HOSHistoryEntryTable.HOS_TEXT_NOTES));
                address = mCursor.getString(mCursor.getColumnIndexOrThrow(HOSHistoryEntryTable.HOS_ADDRESS));
                rowId = mCursor.getString(mCursor.getColumnIndexOrThrow(HOSHistoryEntryTable.COLUMN_ID));
                HOSHistoryDetail hoshistroyDetail = new HOSHistoryDetail(stage_time, stage_id, stage_desc, service_hour,text_notes,address);

                List<ScanNotes> scanNotesArrayList = new ArrayList<>();
                scanQRList = getQRData(rowId);

                ScanNotes scanNotesModel;

                for (int index = 0; index < scanQRList.size(); index++) {
                    scanNotesModel = new ScanNotes();
                    scanNotesModel.setQR(scanQRList.get(index).getQR());
                    scanNotesArrayList.add(scanNotesModel);
                }

                hoshistroyDetail.setScanNotes(scanNotesArrayList);

                hoshistoryList.add(hoshistroyDetail);
            }
        }

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private Cursor fetchHOSHistoryData() {
        String[] projection = {HOSHistoryEntryTable.COLUMN_ID, HOSHistoryEntryTable.HOS_HISTORY_STAGETIME, HOSHistoryEntryTable.HOS_HISTORY_STAGEID,
                HOSHistoryEntryTable.HOS_HISTORY_STAGEDESC, HOSHistoryEntryTable.HOS_HISTORY__SERVICEHOUR, HOSHistoryEntryTable.HOS_TEXT_NOTES,HOSHistoryEntryTable.HOS_ADDRESS};
        Cursor cursor = getContentResolver().query(Uri.parse(HOSHistoryEntryContentProvider.CONTENT_URI.toString()),
                projection, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                try {
                    Log.d("mgtagentempdbfirst",
                            cursor.getString(cursor
                                    .getColumnIndexOrThrow(HOSHistoryEntryTable.HOS_HISTORY__SERVICEHOUR)));
                    Log.d("mgtagentempdbfirst",
                            cursor.getString(cursor
                                    .getColumnIndexOrThrow(HOSHistoryEntryTable.HOS_HISTORY_STAGEDESC)));
                } catch (NullPointerException e) {
                    e.printStackTrace();
                }
            }
        }
        return cursor;
    }


    // To getting data from ScanQRTable to display the notes items
    private List<ScanQRTable> getQRData(String rowId) {
        return new Select().from(ScanQRTable.class).where("history_info_id = ?", rowId).execute();
    }


}


package net.abaqus.mygeotracking.deviceagent.sixgill;

import android.os.AsyncTask;
import android.util.Log;

import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;

public class ReachTrackService extends JobService {

    private static final String TAG = ReachTrackService.class.getSimpleName();
    public ReachReceiver reachReceiver;

    @Override
    public boolean onStartJob(JobParameters job) {

        DebugLog.debug("Tracking job!", "Should be recurring - Reach Track Service");


        AsyncTask.execute(  new Runnable() {
            @Override
            public void run() {

                setInfoData();
            }
        });
        return false;
    }

    public void setInfoData() {

        try
        {
            reachReceiver = ReachReceiver.getInstance(ReachTrackService.this);
            reachReceiver.registerReachReceiver();
        }
        catch (Exception e)
        {
            Log.d(TAG,"REACHEXCEPTION ");
            e.printStackTrace();

        }
    }

    @Override
    public boolean onStopJob(JobParameters job) {
        Log.d(TAG,"ONSTOOPPED ");
        reachReceiver.unregisterReachReceiver();
        return false;

    }
}

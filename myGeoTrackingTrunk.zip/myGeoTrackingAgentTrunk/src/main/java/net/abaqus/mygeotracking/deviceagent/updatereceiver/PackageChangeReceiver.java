package net.abaqus.mygeotracking.deviceagent.updatereceiver;


import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;

public class PackageChangeReceiver extends BroadcastReceiver {
	
	
	private static String TAG = PackageChangeReceiver.class.getSimpleName();

	@Override
	public void onReceive(Context context, Intent intent) {
//		DebugLog.debug(TAG,"" + intent);
//		String pkgName = intent.getDataString().substring(
//				intent.getData().getScheme().length());
//		if (Intent.ACTION_MY_PACKAGE_REPLACED.equals(intent.getAction())) {
//			DebugLog.debug(TAG ,"ACTION_PACKAGE_REPLACED:" + intent.getExtras());
//			DebugLog.debug(TAG ,"ACTION_PACKAGE_REPLACED:" + pkgName);
//			DebugLog.debug(TAG ,"ACTION_PACKAGE_REPLACED Orig:"+context.getApplicationContext().getPackageName());
//			if(pkgName.equals(context.getApplicationContext().getPackageName())){
//				DebugLog.debug(TAG ,"ZOS Service triggered again");
//				ZDAListener.getInstance().initialize(context.getApplicationContext(), null, null, null);
//
//			}
//			//SystemEvent.fireEvent(SystemEvent.EVENT_TYPE_APP_CHANGE);
		//}
	}

	
}
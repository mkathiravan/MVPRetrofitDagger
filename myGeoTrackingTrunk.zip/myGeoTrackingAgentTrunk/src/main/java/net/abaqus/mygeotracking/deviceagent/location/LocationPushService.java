package net.abaqus.mygeotracking.deviceagent.location;


import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.util.Xml;

import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;
import com.sixgill.protobuf.Ingress;
import com.sixgill.sync.sdk.Reach;
import com.sixgill.sync.sdk.ReachLocationCallback;

import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.hos.HOSActivity;
import net.abaqus.mygeotracking.deviceagent.sixgill.FusedProvider;
import net.abaqus.mygeotracking.deviceagent.sixgill.GPSTracker;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.utils.ConnectionManager;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.LocationPUSHTask;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkDeviceStatus;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;

import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.xml.sax.InputSource;
import org.xmlpull.v1.XmlSerializer;

import java.awt.font.TextAttribute;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import javax.xml.parsers.SAXParserFactory;

import io.nlopez.smartlocation.OnLocationUpdatedListener;
import io.nlopez.smartlocation.OnReverseGeocodingListener;
import io.nlopez.smartlocation.SmartLocation;
import io.nlopez.smartlocation.location.config.LocationParams;

public class LocationPushService extends JobService {

    private static final String TAG = LocationPushService.class.getSimpleName();
    private Context mContext;
    String timeStamp = "";
    @Override
    public boolean onStartJob(JobParameters job) {

        DebugLog.debug("Started Locating Job!", "LocationPushService");
        //First Locate and store it in db then once the Locate action is finished then check internet availability and push the data to
        //Server

        //Check Location Permission

        //Check Location Provider availability

        //See if you can wake up WiFi and do a location fetch

        //Post a notification in case of Permission is denied, in case of Location sensors are disabled
        final String timeStamp = job.getExtras().getString("timestamp");
        mContext = this;
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {

                if (ContextCompat.checkSelfPermission( mContext, android.Manifest.permission.ACCESS_COARSE_LOCATION ) != PackageManager.PERMISSION_GRANTED ) {
                    sendErrorResponseToServer(mContext, "Location Permission Denied", timeStamp);
                    return;
                }

                if (!SmartLocation.with(mContext).location().state().locationServicesEnabled()) {
                    sendErrorResponseToServer(mContext, "Location Service Disabled", timeStamp);
                    return;
                }
                Log.d("SDKVERSION ","SDKVERSION" +Build.VERSION.SDK_INT + " ID "+Build.VERSION_CODES.LOLLIPOP);


//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
//                {
//                    reach_call_location();
//                }
//                else
//                {
//                    native_call();
//                }

                if(Build.VERSION.SDK_INT >= 26)
                {
                    native_call();
                }
                else
                {
                    reach_call_location();
                }





            }
        });
        return false;
    }


    private void native_call() {


        SmartLocation.with(mContext).location()
                .oneFix()
                .start(new OnLocationUpdatedListener() {
                    @Override
                    public void onLocationUpdated(Location location) {

                        CurrentDateAndTime.setLatLonValues(
                                location.getLatitude(),
                                location.getLongitude());
                        String methodParam = NetworkDeviceStatus.checkNetworkStatus(mContext);
                        CurrentDateAndTime.setDeviceMethod(methodParam);
                        CurrentDateAndTime.setAccuracyValue(location.getAccuracy() + "");

                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                new LocationPUSHTask(getApplicationContext(), timeStamp).execute();
                            }
                        }, 5000);
                    }
                });

    }


    private void reach_call_location()
    {
        Reach.getLocation(getApplicationContext(), new ReachLocationCallback(){
            @Override
            public void onLocationSuccess(Ingress.Location location) {
                Log.d("Success condition","Success condition");

                String accuracyParam = location.getAccuracy() + "";
                Float latitudeParam = location.getLatitude();
                Float longitudeParam = location.getLongitude();
                long timestampParam = location.getTimestamp();

                CurrentDateAndTime.setLatLonValues(Double.valueOf(location.getLatitude()), Double.valueOf(location.getLongitude()));
                String methodParam = NetworkDeviceStatus.checkNetworkStatus(mContext);
                CurrentDateAndTime.setDeviceMethod(methodParam);
                CurrentDateAndTime.setAccuracyValue(location.getAccuracy() + "");

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        new LocationPUSHTask(mContext, timeStamp).execute();
                    }
                }, 5000);



            }
            @Override
            public void onLocationFailure(Ingress.Error error) {
                Log.d("Location failure","Location failure"+error.getErrorMessage());
                Log.d("CONTRESER ","CONTRESER "+getApplicationContext());
                if(error.getErrorMessage().equals("No location found"))
                {
                    Log.d("INSIDEERRBLG ","INSIDEERRBLG ");
                    // native_call_location();

                    native_call();

                }


                }
        });




    }

    @Override
    public boolean onStopJob(JobParameters job) {
        DebugLog.debug("Stopped Locating Job!", "LocationPushService");
        return false;
    }


    private void sendErrorResponseToServer(final Context mContext, final String errorResponse, final String requestedTimestamp) {

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                SharedPreferences prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);

                ConnectionManager cm = new ConnectionManager();
                cm.setupHttpPost(MDACons.SERVER_URL+"updateEventData");
                cm.setHttpHeader("Content-Type", "application/xml");


                XmlSerializer serializer = Xml.newSerializer();
                StringWriter writer = new StringWriter();
                try{
                    serializer.setOutput(writer);

                    serializer.startDocument("UTF-8", true);
                    serializer.startTag(null, "MGTRequest");
                    serializer.startTag(null, "DeviceLocation");

                    serializer.startTag(null, "Device");
                    serializer.text(prefs.getString(MDACons.DEVICE_NUMBER, ""));
                    serializer.endTag(null,"Device");

                    serializer.startTag(null, "ErrorMessage");
                    serializer.text(errorResponse);
                    serializer.endTag(null,"ErrorMessage");

                    serializer.startTag(null, "Time");
                    serializer.text(CurrentDateAndTime.getDateTime(new SimpleDateFormat("yyyy:MM:dd,HH:mm:ss")));
                    serializer.endTag(null,"Time");

                    serializer.startTag(null, "RequestedTime");
                    serializer.text(requestedTimestamp);
                    serializer.endTag(null,"RequestedTime");


                    serializer.startTag(null, "UUID");
                    serializer.text(prefs.getString(MDACons.DEVICE_GUID, ""));
                    serializer.endTag(null,"UUID");

                    String versionName = "";
                    String bundleid = "";
                    try {
                        bundleid = mContext.getPackageManager()
                                .getPackageInfo(mContext.getPackageName(), 0).packageName;
                        versionName =mContext.getPackageManager()
                                .getPackageInfo(mContext.getPackageName(), 0).versionName;
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }

                    serializer.startTag(null, "AgentVersion");
                    serializer.text(versionName);
                    serializer.endTag(null,"AgentVersion");

                    serializer.startTag(null, "BundleID");
                    serializer.text(bundleid);
                    serializer.endTag(null,"BundleID");

                    serializer.startTag(null, "Platform");
                    serializer.text("Android");
                    serializer.endTag(null,"Platform");


                    serializer.endTag(null, "DeviceLocation");
                    serializer.endTag(null,"MGTRequest");
                    serializer.endDocument();
                }catch (Exception e) {

                }
                HttpEntity en = null;
                try {
                    en = new StringEntity(writer.toString());
                } catch (UnsupportedEncodingException e2) {
                    e2.printStackTrace();
                }
                try {
                    Log.i("REQUEST", EntityUtils.toString(en));
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
                cm.setHttpPostEntity(en);


                try {
                    cm.makeRequestGetResponse();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


    }
}
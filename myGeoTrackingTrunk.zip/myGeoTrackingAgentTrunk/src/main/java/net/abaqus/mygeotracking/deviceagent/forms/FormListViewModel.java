package net.abaqus.mygeotracking.deviceagent.forms;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by user on 13-07-2018.
 */

public class FormListViewModel {
    String form_id;

    public String getForm_id() {
        return form_id;
    }

    public void setForm_id(String form_id) {
        this.form_id = form_id;
    }

    public String getForm_name() {
        return form_name;
    }

    public void setForm_name(String form_name) {
        this.form_name = form_name;
    }

    public List<FormPrefillListViewModel> getFormPrefillListViewModelList() {
        return formPrefillListViewModelList;
    }

    public void setFormPrefillListViewModelList(List<FormPrefillListViewModel> formPrefillListViewModelList) {
        this.formPrefillListViewModelList = formPrefillListViewModelList;
    }

    String form_name;
    List<FormPrefillListViewModel> formPrefillListViewModelList = new ArrayList<>();

}

package net.abaqus.mygeotracking.deviceagent.data;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

/**
 * Created by root on 29/9/16.
 */

public class FormTable {
    private static final String TAG = "MGT_Database";


    //The columns we'll include in the dictionary table
    public static final String COLUMN_ID = "_id";
    public static final String FORM_NAME = "form_name";
    public static final String FORM_ID = "form_id";

    public static final String FORM_TABLE = "formtable";




    // Database creation SQL statement

    private static final String FORM_TABLE_CREATE = "create table "
            + FORM_TABLE
            + "("
            + COLUMN_ID + " integer primary key autoincrement, "
            + FORM_NAME + " text null,"
            + FORM_ID + " text not null,"
            + " text null"
            + ");";

    public static void onCreate(SQLiteDatabase database) {
        DebugLog.debug(TAG, "Creating database ");
        database.execSQL(FORM_TABLE_CREATE);
    }

    public static void onUpgrade(SQLiteDatabase database, int oldVersion,
                                 int newVersion) {
        DebugLog.debug(TAG, "Upgrading database from version "
                + oldVersion + " to " + newVersion
                + ", which will destroy all old data");
        database.execSQL("DROP TABLE IF EXISTS " + FORM_TABLE);
        onCreate(database);

    }

}

package net.abaqus.mygeotracking.deviceagent.utils;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Build;
import android.support.multidex.MultiDex;
import android.support.v7.app.AppCompatDelegate;
import android.util.Log;
import com.activeandroid.ActiveAndroid;
import com.crashlytics.android.Crashlytics;
import com.facebook.network.connectionclass.ConnectionClassManager;
import com.facebook.network.connectionclass.ConnectionQuality;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.security.ProviderInstaller;
import com.google.firebase.FirebaseApp;
import com.sixgill.protobuf.Ingress;
import com.sixgill.sync.sdk.Reach;
import net.abaqus.mygeotracking.deviceagent.BuildConfig;
import net.abaqus.mygeotracking.deviceagent.heartbeat.TriggerSource;
import net.abaqus.mygeotracking.deviceagent.receivers.PowerConnectionReceiver;
import net.abaqus.mygeotracking.deviceagent.receivers.PowerSaveModeChangeReceiver;
import net.abaqus.mygeotracking.deviceagent.sixgill.LocationCall;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReachEventJob;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReachReceiver;


public class myGeoTrackingDevieAgentApplication extends Application implements ConnectionClassManager.ConnectionClassStateChangeListener,LocationCall {

    private static final String TAG = myGeoTrackingDevieAgentApplication.class.getSimpleName();

    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    private static myGeoTrackingDevieAgentApplication instance = null;
    public static final String API_KEY = "1d56e33a-d398-11e2-a809-22000aaa1c49";
    public static final String SIXGILL_API_KEY = "66c0d9f139d55c134825d38881";
    public static final String PASSWORD = "61a01e33";
    public static String AUTH_TOKEN = "";
    public static String SIXGILL_AUTH_TOKEN = "";
    public static String SIXGILL_DEVICE_ID = "";
    private PowerSaveModeChangeReceiver powerSaveModeChangeReceiver;
    private PowerConnectionReceiver powerConnectionReceiver;
    private static boolean mainAcivityVisible;
    protected
    ReachReceiver reachReceiver;
    String  device_number = "";



    @Override
    public void onCreate()
    {
        Log.d(TAG,"ONCREATECALLED ");
        //turnOnStrictMode();
        super.onCreate();
        //JobManager.create(this).addJobCreator(new HOSJobCreator());
        ConnectionClassManager.getInstance().register(this);
        FirebaseApp.initializeApp(this);

        if(!BuildConfig.DEBUG)
        {
            Crashlytics.log("Inside Register Activity. Should Display welcome screen is TRUE");

        }


//        if(BuildConfig.DEBUG)
//        {
//            FirebaseCrash.setCrashCollectionEnabled(false);
//        }
//        else
//        {
//            //FirebaseCrash.setCrashCollectionEnabled(true);
//           // Fabric.with(this, new Crashlytics());
//            Crashlytics.log("Release Mode");
//
//
//        }

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                ActiveAndroid.initialize(myGeoTrackingDevieAgentApplication.this);
                try {
                    ProviderInstaller.installIfNeeded(getApplicationContext());
                } catch (GooglePlayServicesRepairableException e) {
                    e.printStackTrace();
                } catch (GooglePlayServicesNotAvailableException e) {
                    e.printStackTrace();
                }
            }
        });
        instance = this;
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(){
            @Override
            public void uncaughtException(Thread thread, Throwable ex) {
                // FirebaseCrash.report(ex);
                Crashlytics.log("Thread uncaughtException");
            }
        });

        //Receive Doze mode changes to display doze mode warning notification
        powerSaveModeChangeReceiver = new PowerSaveModeChangeReceiver();
        registerReceiver(powerSaveModeChangeReceiver, new IntentFilter("android.os.action.POWER_SAVE_MODE_CHANGED"));


        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O)
        {
            Log.d(TAG,"SIXGILLCONDR ");
            Reach.enable(myGeoTrackingDevieAgentApplication.this);
            ReachEventJob reachEventJob = ReachEventJob.getInstance();
            reachEventJob.justTrack(getApplicationContext(), TriggerSource.APP_LAUNCHED);



        }


        //Receive Battery changes to remove doze mode warning notification
        powerConnectionReceiver = new PowerConnectionReceiver();
        registerReceiver(powerConnectionReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));







//
//        //Receive Battery changes to remove doze mode warning notification
//        powerConnectionReceiver = new PowerConnectionReceiver();
//        registerReceiver(powerConnectionReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
//
//        Reach.enable(myGeoTrackingDevieAgentApplication.this);
//
////        reachReceiver = ReachReceiver.getInstance(myGeoTrackingDevieAgentApplication.this);
////        reachReceiver.registerReachReceiver();
//
//        ReachEventJob reachEventJob = ReachEventJob.getInstance();
//        reachEventJob.justTrack(getApplicationContext(), TriggerSource.APP_LAUNCHED);


    }

//    @Override
//    public void onConfigurationChanged(Configuration newConfig) {
//        super.onConfigurationChanged(newConfig);
//
//        Log.d(TAG,"ONCREATECALLED ");
//        //turnOnStrictMode();
//        super.onCreate();
//        //JobManager.create(this).addJobCreator(new HOSJobCreator());
//        ConnectionClassManager.getInstance().register(this);
//        FirebaseApp.initializeApp(this);
//
//        if(!BuildConfig.DEBUG)
//        {
//            Crashlytics.log("Inside Register Activity. Should Display welcome screen is TRUE");
//        }
//
//
//        AsyncTask.execute(new Runnable() {
//            @Override
//            public void run() {
//                ActiveAndroid.initialize(myGeoTrackingDevieAgentApplication.this);
//                try {
//                    ProviderInstaller.installIfNeeded(getApplicationContext());
//                } catch (GooglePlayServicesRepairableException e) {
//                    e.printStackTrace();
//                } catch (GooglePlayServicesNotAvailableException e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//        instance = this;
//        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(){
//            @Override
//            public void uncaughtException(Thread thread, Throwable ex) {
//                FirebaseCrash.report(ex);
//            }
//        });
//
//
//
//        //Receive Doze mode changes to display doze mode warning notification
//        powerSaveModeChangeReceiver = new PowerSaveModeChangeReceiver();
//        registerReceiver(powerSaveModeChangeReceiver, new IntentFilter("android.os.action.POWER_SAVE_MODE_CHANGED"));
//
//        //Receive Battery changes to remove doze mode warning notification
//        powerConnectionReceiver = new PowerConnectionReceiver();
//        registerReceiver(powerConnectionReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
//
//        Reach.enable(myGeoTrackingDevieAgentApplication.this);
//
////        reachReceiver = ReachReceiver.getInstance(myGeoTrackingDevieAgentApplication.this);
////        reachReceiver.registerReachReceiver();
//
//        ReachEventJob reachEventJob = ReachEventJob.getInstance();
//        reachEventJob.justTrack(getApplicationContext(), TriggerSource.APP_LAUNCHED);
//
//    }


    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(this);
    }


    @Override
    public void onBandwidthStateChange(ConnectionQuality bandwidthState) {
        DebugLog.debug(TAG, bandwidthState.name());
    }

    public static Context getAppContext()
    {


        if (instance != null) {
            return instance.getApplicationContext();
        }
        return null;
    }

    public static boolean isMainAcitivityVisible(){
        return mainAcivityVisible;
    }

    public static void mainActivityResumed(){
        mainAcivityVisible = true;
    }

    public static void mainActivityPaused(){
        mainAcivityVisible = false;
    }


    private static Ingress.Location mLocationData;



    public static Ingress.Location getLocationData(){
        return mLocationData;
    }


    @Override
    public void getLocationValue(Ingress.Location location) {
        mLocationData= location;
    }


}
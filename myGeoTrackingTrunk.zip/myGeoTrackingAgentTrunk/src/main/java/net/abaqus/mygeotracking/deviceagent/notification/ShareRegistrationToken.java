package net.abaqus.mygeotracking.deviceagent.notification;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.preference.PreferenceManager;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.firebase.iid.FirebaseInstanceId;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.networking.VolleyHelper;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import static net.abaqus.mygeotracking.deviceagent.ui.RegisterDeviceActivity.PROPERTY_APP_VERSION;
import static net.abaqus.mygeotracking.deviceagent.ui.RegisterDeviceActivity.PROPERTY_REG_ID_MGT;

/**
 * Created by root on 13/6/16.
 */
public class ShareRegistrationToken {
    private static final String TAG = ShareRegistrationToken.class.getSimpleName();

    /**
     * Persist registration to third-party servers.
     *
     * Modify this method to associate the user's GCM registration token with any server-side account
     * maintained by your application.
     *
     */

    public static void sendRefreshTokenToServer(final Context context,String token)
    {
        SharedPreferences sh_prefs = context.getSharedPreferences(MDACons.PREFS, 0);
        if (sh_prefs.getString(MDACons.DEVICE_NUMBER, "").isEmpty()) {
            DebugLog.debug(TAG, "Device number is empty - So returning immediately without sharing the fcm token with server");
            return;
        }

        String tokenToZOS = "";
        String tokenToMGT = token;
//        try {
//            tokenToMGT = FirebaseInstanceId.getInstance().getToken("734770498401", "FCM");
//            DebugLog.debug(TAG, "FCM Registration Token MGT: " + tokenToMGT);
////            tokenToZOS = FirebaseInstanceId.getInstance().getToken("882772620367", "FCM");
////            DebugLog.debug(TAG, "FCM Registration Token ZOS: " + tokenToZOS);
//        } catch (IOException ioe) {
//            DebugLog.debug(TAG, "FCM Registration Token fetching failed due to IO Exception ");
//        }
        storeRegistrationId(context, tokenToMGT);
        // Add custom implementation, as needed.
        // Share the Registration token with ZOS Server
        SharedPreferences sharedPreferences = getDefaultPreferences(context);
        final SharedPreferences.Editor sharEditor = sharedPreferences.edit();
//        if(!tokenToZOS.isEmpty()) {
//            ZDAEventService zdaService = ZDAClassFactory.getEventService(context);
//            zdaService.onPushRegistered(tokenToZOS);
//            sharEditor.putBoolean(NotificationPreferences.SENT_TOKEN_TO_ZOS_SERVER, true);
//            sharEditor.commit();
//            DebugLog.debug(TAG, "FCM Token for ZOS is available - processing ZOS FCM Registration");
//        }
//        else {
//            DebugLog.debug(TAG, "FCM Token for ZOS is empty - So returning immediately without ZOS FCM Registration");
//        }

        if (tokenToMGT.isEmpty()) {
            DebugLog.debug(TAG, "FCM Token for MGT is empty - So returning immediately without gcmRegister API Call");
            return;
        } else {
            DebugLog.debug(TAG, "FCM Token for MGT is available - processing gcmRegister API Call");
        }
        // Share the Registration token with ZOS Server
        String url = MDACons.SERVER_URL_REST+"gcmRegister";

        JSONObject apiPayload = new JSONObject();
        try {
            String device_number = getGcmPreferences(context).getString(MDACons.DEVICE_NUMBER, "");
            String versionName = "";
            try {
                versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
            }
            catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
            boolean tabletSize = context.getResources().getBoolean(R.bool.isTablet);

            apiPayload.put("gcm_registration_id", tokenToMGT);
            apiPayload.put("device_id", device_number);
            JSONObject deviceDetails = new JSONObject();
            deviceDetails.put("platform", "Android");
            deviceDetails.put("app_version", versionName);
            deviceDetails.put("os_version", Build.VERSION.RELEASE);
            deviceDetails.put("package_name", context.getApplicationContext().getPackageName());
            if (tabletSize) {
                deviceDetails.put("device_type", "Tablet");
            } else {
                deviceDetails.put("device_type", "Phone");
            }
            deviceDetails.put("uuid", getGcmPreferences(context).getString(MDACons.DEVICE_GUID, ""));

            JSONArray jsonArray = new JSONArray();
            jsonArray.put(deviceDetails);

            apiPayload.put("device_details", deviceDetails);

            DebugLog.debug(TAG, "API_PAYLOAD" + apiPayload.toString());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest jsObjRequest = new JsonObjectRequest
                (Request.Method.POST, url, apiPayload, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        DebugLog.debug(TAG, "API_PAYLOAD" + response.toString());
                        try {
                            if (response.get("message").equals("Success"))
                                sharEditor.putBoolean(NotificationPreferences.SENT_TOKEN_TO_MGT_SERVER, true);
                            else
                                sharEditor.putBoolean(NotificationPreferences.SENT_TOKEN_TO_MGT_SERVER, false);
                            sharEditor.commit();
                        }catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        DebugLog.debug(TAG, "API_PAYLOAD" + error.toString());
                        sharEditor.putBoolean(NotificationPreferences.SENT_TOKEN_TO_MGT_SERVER, false);
                        sharEditor.commit();
                    }
                });
        // Access the RequestQueue through your singleton class.
        VolleyHelper.getInstance(context).addToRequestQueue(jsObjRequest);

    }



    public static void sendRegistrationToServer(final Context context) {

        SharedPreferences sh_prefs = context.getSharedPreferences(MDACons.PREFS, 0);
        if (sh_prefs.getString(MDACons.DEVICE_NUMBER, "").isEmpty()) {
            DebugLog.debug(TAG, "Device number is empty - So returning immediately without sharing the fcm token with server");
            return;
        }

        String tokenToZOS = "";
        String tokenToMGT = "";
        try {
            tokenToMGT = FirebaseInstanceId.getInstance().getToken("734770498401", "FCM");
            DebugLog.debug(TAG, "FCM Registration Token MGT: " + tokenToMGT);
//            tokenToZOS = FirebaseInstanceId.getInstance().getToken("882772620367", "FCM");
//            DebugLog.debug(TAG, "FCM Registration Token ZOS: " + tokenToZOS);
        } catch (IOException ioe) {
            DebugLog.debug(TAG, "FCM Registration Token fetching failed due to IO Exception ");
        }
        storeRegistrationId(context, tokenToMGT);
        // Add custom implementation, as needed.
        // Share the Registration token with ZOS Server
        SharedPreferences sharedPreferences = getDefaultPreferences(context);
        final SharedPreferences.Editor sharEditor = sharedPreferences.edit();
//        if(!tokenToZOS.isEmpty()) {
//            ZDAEventService zdaService = ZDAClassFactory.getEventService(context);
//            zdaService.onPushRegistered(tokenToZOS);
//            sharEditor.putBoolean(NotificationPreferences.SENT_TOKEN_TO_ZOS_SERVER, true);
//            sharEditor.commit();
//            DebugLog.debug(TAG, "FCM Token for ZOS is available - processing ZOS FCM Registration");
//        }
//        else {
//            DebugLog.debug(TAG, "FCM Token for ZOS is empty - So returning immediately without ZOS FCM Registration");
//        }

        if (tokenToMGT.isEmpty()) {
            DebugLog.debug(TAG, "FCM Token for MGT is empty - So returning immediately without gcmRegister API Call");
            return;
        } else {
            DebugLog.debug(TAG, "FCM Token for MGT is available - processing gcmRegister API Call");
        }
        // Share the Registration token with ZOS Server
        String url = MDACons.SERVER_URL_REST+"gcmRegister";

        JSONObject apiPayload = new JSONObject();
        try {
            String device_number = getGcmPreferences(context).getString(MDACons.DEVICE_NUMBER, "");
            String versionName = "";
            try {
                versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
            }
            catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
            boolean tabletSize = context.getResources().getBoolean(R.bool.isTablet);

            apiPayload.put("gcm_registration_id", tokenToMGT);
            apiPayload.put("device_id", device_number);
            JSONObject deviceDetails = new JSONObject();
            deviceDetails.put("platform", "Android");
            deviceDetails.put("app_version", versionName);
            deviceDetails.put("os_version", Build.VERSION.RELEASE);
            deviceDetails.put("package_name", context.getApplicationContext().getPackageName());
            if (tabletSize) {
                deviceDetails.put("device_type", "Tablet");
            } else {
                deviceDetails.put("device_type", "Phone");
            }
            deviceDetails.put("uuid", getGcmPreferences(context).getString(MDACons.DEVICE_GUID, ""));

            JSONArray jsonArray = new JSONArray();
            jsonArray.put(deviceDetails);

            apiPayload.put("device_details", deviceDetails);

            DebugLog.debug(TAG, "API_PAYLOAD" + apiPayload.toString());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest jsObjRequest = new JsonObjectRequest
                (Request.Method.POST, url, apiPayload, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        DebugLog.debug(TAG, "API_PAYLOAD" + response.toString());
                        Log.d(TAG,"GETTING_RESPONSE_SERVER " + response.toString());
                        try {
                            if (response.get("message").equals("Success"))
                                sharEditor.putBoolean(NotificationPreferences.SENT_TOKEN_TO_MGT_SERVER, true);
                            else
                                sharEditor.putBoolean(NotificationPreferences.SENT_TOKEN_TO_MGT_SERVER, false);
                            sharEditor.commit();
                        }catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        DebugLog.debug(TAG, "API_PAYLOAD" + error.toString());
                        sharEditor.putBoolean(NotificationPreferences.SENT_TOKEN_TO_MGT_SERVER, false);
                        sharEditor.commit();
                    }
                });
        // Access the RequestQueue through your singleton class.
        VolleyHelper.getInstance(context).addToRequestQueue(jsObjRequest);
    }


    /**
     * Subscribe to any GCM topics of interest, as defined by the TOPICS constant.
     *
     * @param token GCM token
     * @throws IOException if unable to reach the GCM PubSub service
     */
    // [START subscribe_topics]
    private void subscribeTopics(String token) throws IOException {
/*
        GcmPubSub pubSub = GcmPubSub.getInstance(this);
        for (String topic : TOPICS) {
            pubSub.subscribe(token, "/topics/" + topic, null);
        }
*/
    }
    // [END subscribe_topics]


    private static void storeRegistrationId(Context context, String tokenToMGT) {
        Log.i(MDACons.LOG_TAG, "store regID in local");
        final SharedPreferences prefs = getGcmPreferences(context);
        int appVersion = getAppVersion(context);
        Log.i(MDACons.LOG_TAG, "Saving regId on app version " + appVersion);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(PROPERTY_REG_ID_MGT, tokenToMGT);
        editor.putInt(PROPERTY_APP_VERSION, appVersion);
        editor.commit();
    }

    /**
     * @return Application's {@code SharedPreferences}.
     */
    private static SharedPreferences getGcmPreferences(Context context) {
        /** store the regID*/
        return context.getSharedPreferences(MDACons.PREFS, Context.MODE_PRIVATE);
    }

    /**
     * @return Application's {@code SharedPreferences}.
     */
    private static SharedPreferences getDefaultPreferences(Context context) {
        /** store the regID*/
        return PreferenceManager.getDefaultSharedPreferences(context);

    }

    private static int getAppVersion(Context context) {
        int versionCode = 0;
        try {
            versionCode = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return versionCode;
    }
}

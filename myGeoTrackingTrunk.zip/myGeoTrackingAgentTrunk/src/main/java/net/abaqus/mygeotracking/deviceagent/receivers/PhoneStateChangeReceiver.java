package net.abaqus.mygeotracking.deviceagent.receivers;

import android.content.Context;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;

import net.abaqus.mygeotracking.deviceagent.listeners.PhoneStateChangeListener;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

/**
 * Created by root on 14/11/17.
 */

public class PhoneStateChangeReceiver extends PhoneStateListener {
    private final String LOG_TAG = "PhoneStateChange";
    private Context mContext;
    private PhoneStateChangeListener phoneStateChangeListener;

    public PhoneStateChangeReceiver(Context mContext, PhoneStateChangeListener phoneStateChangeListener) {
        this.mContext = mContext;
        this.phoneStateChangeListener = phoneStateChangeListener;
    }

    @Override
    public void onServiceStateChanged(ServiceState serviceState) {
        super.onServiceStateChanged(serviceState);
        switch (serviceState.getState()) {
            case ServiceState.STATE_EMERGENCY_ONLY:
                DebugLog.debug(LOG_TAG, "EMERGENCY ONLY");
/*
                CONNECTIVITY_STATUS = false;
                showNoConnectivityWarning();
*/
                phoneStateChangeListener.onNetworkDisconnected();
                break;
            case ServiceState.STATE_IN_SERVICE:
                DebugLog.debug(LOG_TAG, "STATE IN SERVICE");
/*
                CONNECTIVITY_STATUS = true;
                showNoConnectivityWarning();
                enableHOSSOSButtons();
*/
                phoneStateChangeListener.onNetworkConnected();
                break;
            case ServiceState.STATE_OUT_OF_SERVICE:
                DebugLog.debug(LOG_TAG, "STATE OUT OF SERVICE");
/*
                CONNECTIVITY_STATUS = false;
                showNoConnectivityWarning();
*/
                phoneStateChangeListener.onNetworkDisconnected();
                break;
            case ServiceState.STATE_POWER_OFF:
                DebugLog.debug(LOG_TAG, "STATE POWER OFF");
/*
                CONNECTIVITY_STATUS = false;
                showNoConnectivityWarning();
*/
                phoneStateChangeListener.onNetworkDisconnected();
                break;
        }
    }

    @Override
    public void onSignalStrengthsChanged(SignalStrength signalStrength) {
        super.onSignalStrengthsChanged(signalStrength);

        if (signalStrength.isGsm()) {
            DebugLog.debug(LOG_TAG, signalStrength.getGsmSignalStrength() + "asu GSM");
            if (signalStrength.getGsmSignalStrength() <= 5) {
/*
                CONNECTIVITY_STATUS = false;
                showNoConnectivityWarning();
*/
                phoneStateChangeListener.onNetworkDisconnected();
            } else {
/*
                CONNECTIVITY_STATUS = true;
                enableHOSSOSButtons();
*/
                phoneStateChangeListener.onNetworkConnected();
            }
        } else {
            DebugLog.debug(LOG_TAG, signalStrength.getCdmaDbm() + "dBm CDMA");
            if (signalStrength.getCdmaDbm() <= -100) {
/*
                CONNECTIVITY_STATUS = false;
                showNoConnectivityWarning();
*/
                phoneStateChangeListener.onNetworkDisconnected();
            } else {
/*
                CONNECTIVITY_STATUS = true;
                enableHOSSOSButtons();
*/
                phoneStateChangeListener.onNetworkConnected();
            }
        }

    }
}
package net.abaqus.mygeotracking.deviceagent.workorder;



import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import net.abaqus.mygeotracking.deviceagent.forms.FormsList;

import java.util.List;

public class WorkOrderReponse{

    @SerializedName("deviceId")
    String deviceId;
    @SerializedName("deviceName")
    String deviceName;
    @SerializedName("StatusCode")
    String StatusCode;
    List<WorkOrderData> workOrders;


    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getStatusCode() {
        return StatusCode;
    }

    public void setStatusCode(String statusCode) {
        this.StatusCode = statusCode;
    }

    public List<WorkOrderData> getWorkOrders() {
        return workOrders;
    }

    public void setWorkOrders(List<WorkOrderData> workOrders) {
        this.workOrders = workOrders;
    }



}

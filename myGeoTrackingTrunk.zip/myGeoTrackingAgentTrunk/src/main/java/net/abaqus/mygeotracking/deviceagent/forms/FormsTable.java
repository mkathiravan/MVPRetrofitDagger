package net.abaqus.mygeotracking.deviceagent.forms;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;

/**
 * Created by root on 4/10/16.
 */

@Table(name = "FormsTable", id = "_id")
public class FormsTable extends Model{
    @Column(name = "formId")
    public String formId;
    @Column (name = "formType")
    public String formType = "";
    @Column(name = "formURL")
    public String formURL = "";
    @Column (name = "formLinkURL")
    public String formLinkURL = "";
    @Column(name = "formName")
    public String formName = "";
    @Column(name = "formToken")
    public String formToken = "";

    public String getFormName() {
        return formName;
    }

    public void setFormName(String formName) {
        this.formName = formName;
    }

    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId;
    }

    public String getFormToken() {
        return formToken;
    }

    public void setFormToken(String formToken) {
        this.formToken = formToken;
    }

    public String getFormURL() {
        return formURL;
    }

    public void setFormURL(String formURL) {
        this.formURL = formURL;
    }

    public String getFormType() {
        return formType;
    }

    public void setFormType(String formType) {
        this.formType = formType;
    }

    public String getFormLinkURL() {
        return formLinkURL;
    }

    public void setFormLinkURL(String formLinkURL) {
        this.formLinkURL = formLinkURL;
    }




}

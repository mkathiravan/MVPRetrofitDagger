package net.abaqus.mygeotracking.deviceagent.utils;

import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlSerializer;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;

public class PINOptinSendTask extends AsyncTask<String, Void, Boolean> {
	//**FIELDS**//
	private static final String TAG = PINOptinSendTask.class.getSimpleName();

	private Context mContext;
	ProgressDialog m_ProgressDialog;
	private SharedPreferences settings;
	private SharedPreferences.Editor edit_prefs;
	private AlertDialog.Builder builder;
	private final int ERROR_OCCURED = 0;
	private final int OPTIN_SUCCESS = 1;
	private final int PIN_EMPTY = 2;
	
	
	private boolean pin_empty;
	
	SAXParserFactory spf = null; 
    SAXParser sp = null;
    /* Get the XMLReader of the SAXParser we created. */ 
    XMLReader xr = null;
    /* Create a new ContentHandler and apply it to the XML-Reader*/ 
    LoginXmlHandler loginXMLHandler=null;
	
	//CONS
	private static final String PROG_TITLE = "Please Wait";
	private static final String PROG_MSG = "Processing...";
	
	
	public PINOptinSendTask(Context con) {
		this.mContext = con;
		this.settings = con.getSharedPreferences(MDACons.PREFS, 0);
		this.edit_prefs = settings.edit();
		this.m_ProgressDialog = new ProgressDialog(con);
		
	        loginXMLHandler=new LoginXmlHandler();
	    
	}
	
	protected void onPreExecute() {
		m_ProgressDialog = ProgressDialog.show(mContext, PROG_TITLE, PROG_MSG , true);
	}

		
	protected void onPostExecute(Boolean success) {
		if(m_ProgressDialog.isShowing())
		m_ProgressDialog.dismiss();
		if (!loginXMLHandler.error_occured)
			doCreateDialog(OPTIN_SUCCESS);
		else if (!success)
			doCreateDialog(PIN_EMPTY);
		else
			doCreateDialog(ERROR_OCCURED);
		
	}
	
	protected Boolean doInBackground(String... urls) {
		SharedPreferences mda_prefs = this.mContext.getSharedPreferences(MDACons.PREFS, 0);
		DebugLog.debug(TAG,MDACons.SERVER_URL+"submitDevicePIN");
		String optin_pin_local_string = mda_prefs.getString(MDACons.PIN_NUMBER, "");
		
		if (!optin_pin_local_string.equals("")){
			
		
		pin_empty = false;
		ConnectionManager cm = new ConnectionManager();
		cm.setupHttpPost(MDACons.SERVER_URL+"submitDevicePIN");
		cm.setHttpHeader("Content-Type", "application/xml");
		
		
		
		XmlSerializer serializer = Xml.newSerializer();
		StringWriter writer = new StringWriter();
		try{   
		serializer.setOutput(writer);
        
		serializer.startDocument("UTF-8", true);
        serializer.startTag(null, "MGTRequest");
        /*serializer.startTag(null, "Account");
        serializer.text("Demo");
        serializer.endTag(null,"Account");*/
        serializer.startTag(null, "Device");
        
        
       
        
        serializer.startTag(null, "DeviceID");
        serializer.text(mda_prefs.getString(MDACons.DEVICE_NUMBER, ""));
        serializer.endTag(null,"DeviceID");
        serializer.startTag(null, "Pin");
        serializer.text(optin_pin_local_string);
        serializer.endTag(null,"Pin");
        
        
        serializer.startTag(null, "UUID");
	    serializer.text(settings.getString(MDACons.DEVICE_GUID, ""));
	    serializer.endTag(null,"UUID");
	     
	    String versionName = "";
        String bundleid = "";
		try {
			bundleid = mContext.getPackageManager()
					.getPackageInfo(mContext.getPackageName(), 0).packageName;
			versionName =mContext.getPackageManager()
					.getPackageInfo(mContext.getPackageName(), 0).versionName;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
	    
	    serializer.startTag(null, "AgentVersion");
	    serializer.text(versionName);
	    serializer.endTag(null,"AgentVersion");
	    
	    serializer.startTag(null, "BundleID");
	    serializer.text(bundleid);
	    serializer.endTag(null,"BundleID");
	    
	    serializer.startTag(null, "Platform");
	    serializer.text("Android");
	    serializer.endTag(null,"Platform");
        
        serializer.endTag(null,"Device");
        serializer.endTag(null,"MGTRequest");
        serializer.endDocument();
		}catch (Exception e) {
			
		}
        HttpEntity en = null;
		try {
			en = new StringEntity(writer.toString());
		} catch (UnsupportedEncodingException e2) {
			e2.printStackTrace();
		}
    	try {
			Log.i("REQUEST",EntityUtils.toString(en));
		} catch (Exception e1) {
			e1.printStackTrace();	
		} 	
		cm.setHttpPostEntity(en);
		
		
		try {
			InputSource m_is = cm.makeRequestGetResponse();
			 spf = SAXParserFactory.newInstance(); 
		        sp = spf.newSAXParser(); 
		
		        /* Get the XMLReader of the SAXParser we created. */ 
		        xr = sp.getXMLReader(); 
			 xr.setContentHandler(loginXMLHandler);
			xr.parse(m_is);
			
			
		}catch (Exception e)
		{
			e.printStackTrace();
		}
		return true;
		}else
		{
			pin_empty = true;
			return false;
		}
	}

	public void doCreateDialog(int id) {
		String errmsg="";
		switch(id){
		
		
			case ERROR_OCCURED:
				builder = new AlertDialog.Builder(mContext);
				builder.setTitle("myGeoTracking Agent");
				
				if (!pin_empty)
				errmsg = loginXMLHandler.getErrorMSG();
				else
					errmsg = "PIN is Blank";
				if(errmsg==null)
				{
					builder.setMessage("No Network");
				}
				else{
					if(errmsg.equalsIgnoreCase("Authorization Failed"))
						builder.setMessage("Login Failed");
					else
				builder.setMessage(errmsg);
				}
				builder.setIcon(android.R.drawable.ic_dialog_info);
				builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					
				
					public void onClick(DialogInterface dialog, int which) {
						
				        
				        
				        
				       
					}
				});
				break;
			case OPTIN_SUCCESS:
				builder = new AlertDialog.Builder(mContext);
				builder.setTitle("myGeoTracking Agent");
				
				if (!pin_empty)
				errmsg = loginXMLHandler.getErrorMSG();
				else
					errmsg = "PIN is Blank";
				if(errmsg==null)
				{
					builder.setMessage("No Network");
				}
				else{
					if(errmsg.equalsIgnoreCase("Authorization Failed"))
						builder.setMessage("Login Failed");
					else
				builder.setMessage(errmsg);
				}
				builder.setIcon(android.R.drawable.ic_dialog_info);
				builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					
				
					public void onClick(DialogInterface dialog, int which) {
						
				        
				        
				        
				       
					}
				});
				break;
			case PIN_EMPTY:
				builder = new AlertDialog.Builder(mContext);
				builder.setTitle("myGeoTracking Agent");
				
				if (pin_empty)
				errmsg = "PIN is Blank";
				
				builder.setMessage(errmsg);
				
				builder.setIcon(android.R.drawable.ic_dialog_info);
				builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {}});
				break;
				
		}
		builder.show();
		
    }
	
	 /*HttpEntity createAssetListEntityForPostRequestLogged(String user, String pass, String account){
	    	try{
	    		XmlSerializer serializer = Xml.newSerializer();
	    		StringWriter writer = new StringWriter();
			    serializer.setOutput(writer);
		        serializer = MGDCons.doServerRequestHeader(serializer,account,user,pass,MGDCons.CMD_LOGIN);
		        serializer.endTag(null,"GTSRequest");
		        serializer.endDocument();
	            return new StringEntity(writer.toString());
	    	} catch (Exception e){
	    		e.printStackTrace();
	    	}
		return null;
	    }*/
	
	public static String error_message = "", last_logged_value="", auth_token = "";
	
	public class LoginXmlHandler extends DefaultHandler{

		private boolean in_GTSResponseTag = false;
		private boolean in_Comment = false;
		
		

		
		public boolean error_occured = false;
		// =========================================================== 
	    // Methods 
	    // =========================================================== 
		public String getValue() {
			return last_logged_value;
		}
		public String getToken() {
			return auth_token;
		}
		public String getErrorMSG(){
			return error_message;
		}
		
		@Override 
	    public void startDocument() throws SAXException { 
	         
	    } 

	    @Override 
	    public void endDocument() throws SAXException { 
	         // Nothing to do 
	    }
	    
	    public void startElement(String namespaceURI, String localName, 
	              String qName, Attributes atts) throws SAXException { 
	    	
	    	if (localName.equals("MGTResponse")) { 
	            this.in_GTSResponseTag = true;
	            if(atts.getValue("result").equalsIgnoreCase("error"))
	            {
	            	error_occured = true;
	            }
	       }else if (localName.equals("Comment")) { 
	           this.in_Comment = true; 
	      }
	    	
	       
	    } /* startELement */
	    
	    @Override 
	    public void endElement(String namespaceURI, String localName, String qName) 
	              throws SAXException { 
	    	if (localName.equals("MGTResponse")) { 
	            this.in_GTSResponseTag = false;
	       }else if (localName.equals("Comment")) { 
	            this.in_Comment = false; 
	       }
	       
	    } 

	    @Override 
	   public void characters(char ch[], int start, int length) { 
	    	if (in_GTSResponseTag && in_Comment )
	    	{
	    		if (error_occured)
	    		error_message = new String(ch,start,length);
	    		else
	    		error_message = "Optin PIN Sent to server Successfully.";
	    	}
	    	
	    }/* characters*/
	}

	
}

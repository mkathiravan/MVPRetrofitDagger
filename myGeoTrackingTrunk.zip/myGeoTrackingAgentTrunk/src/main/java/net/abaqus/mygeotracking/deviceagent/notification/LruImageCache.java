package net.abaqus.mygeotracking.deviceagent.notification;

/**
 * Created by root on 23/5/16.
 */

import android.graphics.Bitmap;
import android.support.v4.util.LruCache;

import com.android.volley.toolbox.ImageLoader;

/**
 * LRU cache implementation of a Volley library image cache.
 */
public class LruImageCache implements ImageLoader.ImageCache {

    private LruCache<String, Bitmap> mMemoryCache;

    public LruImageCache() {
        // Naive calculation of available memory: Use 1/8th of memory for cache
        int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);
        int cacheSize = maxMemory / 8;
        mMemoryCache = new LruCache<String, Bitmap>(cacheSize) {
            @Override
            protected int sizeOf(String key, Bitmap bitmap) {
                return bitmap.getByteCount() / 1024;
            }
        };
    }

    @Override
    public Bitmap getBitmap(String url) {
        return mMemoryCache.get(url);
    }

    @Override
    public void putBitmap(String url, Bitmap bitmap) {
        mMemoryCache.put(url, bitmap);
    }

}
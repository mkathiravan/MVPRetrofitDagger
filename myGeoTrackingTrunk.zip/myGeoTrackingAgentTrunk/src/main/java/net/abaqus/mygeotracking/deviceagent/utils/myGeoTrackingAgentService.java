//package net.abaqus.mygeotracking.deviceagent.utils;
//
//import android.app.IntentService;
//import android.content.Intent;
//import android.os.Handler;
//import android.os.IBinder;
//import android.os.Message;
//import android.util.Log;
//import android.view.View;
//
//public class myGeoTrackingAgentService extends IntentService{
//
//	private static final String TAG = myGeoTrackingAgentService.class.getSimpleName();
//
//	public static final int SERVICE_RUNNING = 1;
//	public static final int SERVICE_NOT_RUNNING = 2;
//
//	public myGeoTrackingAgentService() {
//		super("RestartAgnetService");
//	}
//
//
//
//	@Override
//	public int onStartCommand(Intent intent, int flags, int startId) {
//		return START_STICKY;
//	}
//
//
//	@Override
//	protected void onHandleIntent(Intent intent) {
//	}
//
//
//
//
//
//
//}

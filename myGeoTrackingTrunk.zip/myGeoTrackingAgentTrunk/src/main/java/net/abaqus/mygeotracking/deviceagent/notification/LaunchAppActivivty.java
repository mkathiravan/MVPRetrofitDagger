package net.abaqus.mygeotracking.deviceagent.notification;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import net.abaqus.mygeotracking.deviceagent.ui.RegisterDeviceActivity;

/**
 * Created by root on 22/6/16.
 */
public class LaunchAppActivivty extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AgentNotificationBuilder.DismissNotifications(this);
        Intent intent = new Intent(this, RegisterDeviceActivity.class);
        startActivity(intent);
        finish();
    }
}
package net.abaqus.mygeotracking.deviceagent.utils;


import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;

import com.facebook.network.connectionclass.DeviceBandwidthSampler;

import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobRelationContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobRelationsTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobTable;
import net.abaqus.mygeotracking.deviceagent.exception.SendExceptionLogToServerTask;

import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlSerializer;

import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class HOSCustomerIDJobIDPullTask extends AsyncTask<String, Void, Boolean> {
    private static final String TAG = HOSCustomerIDJobIDPullTask.class.getSimpleName();
    //**FIELDS**//

    public static String error_message = "";

    ;
    SAXParserFactory spf = null;
    SAXParser sp = null;
    /* Get the XMLReader of the SAXParser we created. */
    XMLReader xr = null;
    /* Create a new ContentHandler and apply it to the XML-Reader*/
    HOSCJPullXmlHandler hosCJPullXMLHandler = null;
    private CustomerJob objType;
    private Context mContext;
    private SharedPreferences prefs;


    public HOSCustomerIDJobIDPullTask(Context con, CustomerJob objType) {
        this.objType = objType;
        this.mContext = con;
        this.prefs = con.getSharedPreferences(MDACons.PREFS, 0);

        hosCJPullXMLHandler = new HOSCJPullXmlHandler();

        SharedPreferences.Editor prefs_edit = prefs.edit();
        prefs_edit.putString(MDACons.HOS_CUSTOMER_SELECTED, "");
        prefs_edit.putString(MDACons.HOS_JOB_SELECTED, "");
        prefs_edit.commit();
    }

    protected void onPreExecute() {
        // Clear old data from database
        // Clear Show HOS Menu from Shared Preferences
        DeviceBandwidthSampler.getInstance().startSampling();

        deleteRelationsTable();
    }

    private void deleteRelationsTable() {
        try {
            mContext.getContentResolver().delete(HOSCustomerANDJobRelationContentProvider.CONTENT_URI, null, null);
        } catch (Exception es) {
            DebugLog.debug(TAG, "Relations table delete. Issue : " + es.toString());
        }
    }

    protected void onPostExecute(Boolean success) {
        DeviceBandwidthSampler.getInstance().stopSampling();

        // this is for which argument to match   with TYPE=1 and delete row
        String selection = "" + HOSCustomerANDJobTable.HOS_CJ_WHICH + "=?";
        if (objType == CustomerJob.JOB)
            this.mContext.getContentResolver().delete(HOSCustomerANDJobContentProvider.CONTENT_URI, selection, new String[]{"Job"});
        else if (objType == CustomerJob.CUSTOMER)
            this.mContext.getContentResolver().delete(HOSCustomerANDJobContentProvider.CONTENT_URI, selection, new String[]{"Customer"});

        //check for response and delete or keep the value in database

        if (!hosCJPullXMLHandler.error_occured) {
            //Read all the valuse and store it to database
            //Say Yes for Showing HOS menu in Shared Preferences

            for (int i = 0; i < hosCJPullXMLHandler.getCJList().size(); i++) {

                ContentValues initialValues = new ContentValues();
                initialValues.put(HOSCustomerANDJobTable.HOS_CJ_ID, hosCJPullXMLHandler.getCJList().get(i).getID());
                initialValues.put(HOSCustomerANDJobTable.HOS_CJ_REF_ID, hosCJPullXMLHandler.getCJList().get(i).getRef_id());
                initialValues.put(HOSCustomerANDJobTable.HOS_CJ_NAME, hosCJPullXMLHandler.getCJList().get(i).getName());
                initialValues.put(HOSCustomerANDJobTable.HOS_CJ_STATUS, hosCJPullXMLHandler.getCJList().get(i).getStatus());

                if (hosCJPullXMLHandler.getCJList().get(i).getName().equalsIgnoreCase("karthik"))
                    DebugLog.debug(TAG, hosCJPullXMLHandler.getCJList().get(i).getID());

                initialValues.put(HOSCustomerANDJobTable.HOS_CJ_WHICH, hosCJPullXMLHandler.getCJList().get(i).getWhich());
                initialValues.put(HOSCustomerANDJobTable.HOS_CJ_SOURCE_ID, hosCJPullXMLHandler.getCJList().get(i).getSource_ID());
                initialValues.put(HOSCustomerANDJobTable.HOS_CJ_SITE_ID, hosCJPullXMLHandler.getCJList().get(i).getSiteId());
                this.mContext.getContentResolver().insert(HOSCustomerANDJobContentProvider.CONTENT_URI, initialValues);
            }
        } else {
        }
        //Read the error and react based on that
        //If the error says no HOS For this device then add no HOS in Shared Preferences
        //If any other error messages being caught , react based on that

    }

    protected Boolean doInBackground(String... urls) {

        if (prefs.getString(MDACons.DEVICE_NUMBER, "").isEmpty())
            return false;

        //DebugLog.debug(TAG,("REQUEST", MDACons.SERVER_URL + "getExtJobsANDCUSTOMER");
        ConnectionManager cm = new ConnectionManager();
        if (objType == CustomerJob.JOB)
            cm.setupHttpPost(MDACons.SERVER_URL + "getCustomerTasks");
        else if (objType == CustomerJob.CUSTOMER)
            cm.setupHttpPost(MDACons.SERVER_URL + "getCustomers");

        cm.setHttpHeader("Content-Type", "application/xml");
        XmlSerializer serializer = Xml.newSerializer();
        StringWriter writer = new StringWriter();
        buildRequestXML(serializer, writer);
        HttpEntity en = null;

        try {
            en = new StringEntity(writer.toString());
        } catch (UnsupportedEncodingException e2) {
            //new SendExceptionLogToServerTask(mContext).execute(e2.toString());
        }

        try {
            Log.i("REQUEST", EntityUtils.toString(en));
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        cm.setHttpPostEntity(en);

        try {
            InputSource m_is = cm.makeRequestGetResponse();
            spf = SAXParserFactory.newInstance();
            sp = spf.newSAXParser();
            /* Get the XMLReader of the SAXParser we created. */
            xr = sp.getXMLReader();
            xr.setContentHandler(hosCJPullXMLHandler);
            xr.parse(m_is);
        } catch (Exception e) {
            //new SendExceptionLogToServerTask(mContext).execute(e.toString());
        }
        return true;
    }

    private void buildRequestXML(XmlSerializer serializer, StringWriter writer) {
        try {
            serializer.setOutput(writer);
            serializer.startDocument("UTF-8", true);
            serializer.startTag(null, "MGTRequest");
            serializer.startTag(null, "Device");

            serializer.startTag(null, "DeviceID");
            serializer
                    .text(prefs.getString(MDACons.DEVICE_NUMBER, "")/*"4084726652"*/);
            serializer.endTag(null, "DeviceID");

            serializer.startTag(null, "UUID");
            serializer.text(prefs.getString(MDACons.DEVICE_GUID, ""));
            serializer.endTag(null, "UUID");

            String versionName = "";
            String bundleid = "";
            try {
                bundleid = mContext.getPackageManager().getPackageInfo(
                        mContext.getPackageName(), 0).packageName;
                versionName = mContext.getPackageManager().getPackageInfo(
                        mContext.getPackageName(), 0).versionName;
            } catch (NameNotFoundException e) {
                e.printStackTrace();
            }

            serializer.startTag(null, "AgentVersion");
            serializer.text(versionName);
            serializer.endTag(null, "AgentVersion");

            serializer.startTag(null, "BundleID");
            serializer.text(bundleid);
            serializer.endTag(null, "BundleID");

            serializer.startTag(null, "Platform");
            serializer.text("Android");
            serializer.endTag(null, "Platform");

            serializer.endTag(null, "Device");
            serializer.endTag(null, "MGTRequest");
            serializer.endDocument();
        } catch (Exception e) {
            new SendExceptionLogToServerTask(mContext).execute(e.toString());
        }
    }


    public enum CustomerJob {CUSTOMER, JOB}

    public class HOSCJPullXmlHandler extends DefaultHandler {

        public ArrayList<HOSCJValues> HhosCJValuesList = new ArrayList<HOSCJValues>();
        public boolean error_occured = false;
        StringBuilder builder;
        List<String> items;
        private boolean in_GTSResponseTag = false;
        private boolean in_Comment = false;
        private boolean in_Customer_Updated_Time = false;
        private boolean in_Job_Update_Time = false;
        private boolean in_Customers = false;
        private boolean in_Customer = false;
        private boolean in_SourceID = false;
        private boolean in_SiteID = false;
        private boolean in_Id = false;
        private boolean in_RefID = false;
        private boolean in_Name = false;
        private boolean in_Status = false;
        private boolean in_Jobs = false;
        private boolean in_Job = false;
        // ===========================================================
        // Methods
        // ===========================================================
        private HOSCJValues hosCJValuesObject;

        public String getErrorMSG() {
            return error_message;
        }

        public ArrayList<HOSCJValues> getCJList() {
            return HhosCJValuesList;
        }

        @Override
        public void startDocument() throws SAXException {
            HhosCJValuesList.clear();
            hosCJValuesObject = new HOSCJValues();
        }

        @Override
        public void endDocument() throws SAXException {
            // Nothing to do
        }

        public void startElement(String namespaceURI, String localName,
                                 String qName, Attributes atts) throws SAXException {

            builder = new StringBuilder();
            if (localName.equals("MGTResponse")) {
                this.in_GTSResponseTag = true;
                if (atts.getValue("result").equalsIgnoreCase("error")) {
                    error_occured = true;
                } else if (localName.equals("Comment")) {
                    this.in_Comment = true;
                }
            } else if (localName.equals("Customers")) {
                this.in_Customers = true;

            } else if (localName.equals("Jobs")) {
                this.in_Jobs = true;
            } else if (localName.equals("Customer")) {
                this.in_Customer = true;
                hosCJValuesObject.setWhich(localName);
            } else if (localName.equals("Job")) {
                this.in_Job = true;
                hosCJValuesObject.setWhich(localName);
            } else if (localName.equals("SrcID")) {
                this.in_SourceID = true;
            } else if (localName.equals("Id")) {
                this.in_Id = true;
            } else if (localName.equals("RefID")) {
                this.in_RefID = true;
            } else if (localName.equals("SiteID")) {
                this.in_SiteID = true;
            } else if (localName.equals("Name")) {
                this.in_Name = true;
            } else if (localName.equals("Status")) {
                this.in_Status = true;
            } else if (localName.equals(HOSTagValues.HOS_JOB_UPDATE_TIME_TAG_NAME)) {
                this.in_Job_Update_Time = true;
            } else if (localName.equals(HOSTagValues.HOS_CUSTOMER_UPDATE_TIME_TAG_NAME)) {
                this.in_Customer_Updated_Time = true;
            }


        } /* startELement */

        @Override
        public void endElement(String namespaceURI, String localName, String qName)
                throws SAXException {
            if (localName.equals("MGTResponse")) {
                this.in_GTSResponseTag = false;
            } else if (localName.equals("Comment")) {
                this.in_Comment = false;
            } else if (localName.equals("Customers")) {
                this.in_Customers = false;
            } else if (localName.equals("Jobs")) {
                this.in_Jobs = false;
            } else if (localName.equals("Customer")) {
                this.in_Customer = false;
                HhosCJValuesList.add(hosCJValuesObject);
                hosCJValuesObject = new HOSCJValues();
            } else if (localName.equals("Job")) {
                this.in_Job = false;
                HhosCJValuesList.add(hosCJValuesObject);
                hosCJValuesObject = new HOSCJValues();
            } else if (localName.equals("SrcID")) {
                this.in_SourceID = false;
                hosCJValuesObject.setSource_ID(builder.toString());
            } else if (localName.equals("Id")) {
                this.in_Id = false;
                hosCJValuesObject.setID(builder.toString());
            } else if (localName.equals("RefID")) {
                this.in_RefID = false;
                hosCJValuesObject.setRef_id(builder.toString());
            } else if (localName.equals("SiteID")) {
                this.in_SiteID = false;
                hosCJValuesObject.setSiteId(builder.toString());
            } else if (localName.equals("Name")) {
                this.in_Name = false;
                hosCJValuesObject.setName(builder.toString());

            } else if (localName.equals("Status")) {
                this.in_Status = false;
                hosCJValuesObject.setStatus(builder.toString());
            } else if (localName.equals("Tasks")) {

                updateCUSJobRelationsTable(hosCJValuesObject.getID(), builder.toString());
            } else if (localName.equals(HOSTagValues.HOS_JOB_UPDATE_TIME_TAG_NAME)) {
                this.in_Job_Update_Time = false;
            } else if (localName.equals(HOSTagValues.HOS_CUSTOMER_UPDATE_TIME_TAG_NAME)) {
                this.in_Customer_Updated_Time = false;
            }
        }

        private void updateCUSJobRelationsTable(String cusID, String data) {


            items = Arrays.asList(data.split("\\s*,\\s*"));
            for (int i = 0; i < items.size(); i++) {

                ContentValues initialValues = new ContentValues();
                initialValues.put(HOSCustomerANDJobRelationsTable.HOS_CJ_REL_CUS_ID, cusID);
                initialValues.put(HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID, items.get(i));
                mContext.getContentResolver().insert(HOSCustomerANDJobRelationContentProvider.CONTENT_URI, initialValues);
            }

            items = null;
        }


        @Override
        public void characters(char ch[], int start, int length) {


            if (in_GTSResponseTag && in_Comment) {
                if (error_occured)
                    error_message = new String(ch, start, length);

            } else if (in_GTSResponseTag) {
                String tempString = new String(ch, start, length);
                builder.append(tempString);
            } else if (in_GTSResponseTag && in_Job_Update_Time) {
                SharedPreferences.Editor prefs_edit = prefs.edit();
                prefs_edit.putLong(MDACons.JOB_SITE_LAST_UPDATED_TIME, Long.valueOf(/*new String(ch, start, length)*/0));
                prefs_edit.commit();
            } else if (in_GTSResponseTag && in_Customer_Updated_Time) {
                SharedPreferences.Editor prefs_edit = prefs.edit();
                prefs_edit.putLong(MDACons.CUSTOMER_LAST_UPDATED_TIME, Long.valueOf(/*new String(ch, start, length)*/0));
                prefs_edit.commit();
            }

        }/* characters*/
    }

    class HOSCJValues {


        private String id, ref_id, name, source_ID, status, which, site_id;

        public HOSCJValues() {
            super();
            this.id = "";
            this.ref_id = "";
            this.name = "";
            this.source_ID = "";
            this.status = "";
            this.which = "";
            this.site_id = "";
        }

        public String getID() {
            return id;
        }

        public void setID(String insertValue) {
            this.id = insertValue;
        }

        public String getRef_id() {
            return ref_id;
        }

        public void setRef_id(String insertValue) {

            this.ref_id = insertValue;
        }

        public String getName() {
            return name;
        }

        public void setName(String insertValue) {

            this.name = insertValue;
        }

        public String getSource_ID() {
            return source_ID;
        }

        public void setSource_ID(String insertValue) {

            this.source_ID = insertValue;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String insertValue) {

            this.status = insertValue;
        }

        public String getWhich() {
            return which;
        }

        public void setWhich(String insertValue) {

            this.which = insertValue;
        }

        public String getSiteId() {
            return site_id;
        }

        public void setSiteId(String insertValue) {

            //String name_temp = "";
            DebugLog.debug(TAG, new String(insertValue));
            this.site_id = insertValue;
        }

    }

    public class HOSTagValues {

        public static final String HOS_JOB_UPDATE_TIME_TAG_NAME = "jobsLastUpdateTime";
        public static final String HOS_CUSTOMER_UPDATE_TIME_TAG_NAME = "customerLastUpdateTime";
    }

}

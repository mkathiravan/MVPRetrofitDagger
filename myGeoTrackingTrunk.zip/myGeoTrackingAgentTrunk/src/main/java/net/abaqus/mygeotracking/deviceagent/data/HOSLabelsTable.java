package net.abaqus.mygeotracking.deviceagent.data;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

public class HOSLabelsTable {

	
	
	private static final String TAG = "MGT_Database";

	
    //The columns we'll include in the dictionary table
	public static final String COLUMN_ID = "_id";
    public static final String HOS_LABEL = "hos_label";
    public static final String HOS_LABEL_VALUE = "hos_label_value";
    public static final String HOS_SMS_COMMAND = "hos_sms_command";

    public static final String HOS_LABELS_TABLE = "hoslabelstable";
	
	
	
	  

	  // Database creation SQL statement
    
	  private static final String HOS_LABELS_TABLE_CREATE = "create table " 
	      + HOS_LABELS_TABLE
	      + "(" 
	      + COLUMN_ID + " integer primary key autoincrement, " 
	      + HOS_LABEL + " text null, " 
	      + HOS_LABEL_VALUE + " text null," 
	      + HOS_SMS_COMMAND + " text null,"

	      + " text null" 
	      + ");";

	  public static void onCreate(SQLiteDatabase database) {
		  DebugLog.debug(TAG, "Creating database ");
	    database.execSQL(HOS_LABELS_TABLE_CREATE);
	  }

	  public static void onUpgrade(SQLiteDatabase database, int oldVersion,
	      int newVersion) {
	    DebugLog.debug(TAG, "Upgrading database from version "
	        + oldVersion + " to " + newVersion
	        + ", which will destroy all old data");
	    database.execSQL("DROP TABLE IF EXISTS " + HOS_LABELS_TABLE);
	    onCreate(database);
	  }
	
}

package net.abaqus.mygeotracking.deviceagent.backgroundjobs;

import android.content.Context;


import com.firebase.jobdispatcher.Constraint;
import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.Lifetime;
import com.firebase.jobdispatcher.RetryStrategy;
import com.firebase.jobdispatcher.Trigger;


import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

/**
 * Created by user on 14-06-2018.
 */

public class DozeModeWarningRemoverJob {

    private static DozeModeWarningRemoverJob uniqueInstance;

    //private constructor
    private DozeModeWarningRemoverJob()
    {
        if(uniqueInstance!= null)
        {
            throw new RuntimeException("Use getInstance() method to get the single instance of this class.");
        }
    }

    public static synchronized DozeModeWarningRemoverJob getInstance()
    {
        if(uniqueInstance == null)
        {
            uniqueInstance = new DozeModeWarningRemoverJob();
        }
        return uniqueInstance;
    }

    public void removeNotification(Context applicationContext)
    {
        DebugLog.debug("Start Notifiying","with the notification");

        FirebaseJobDispatcher jobDispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(applicationContext));
        Job myJob = jobDispatcher.newJobBuilder()
                .setService(DozeModeWarningRemoverService.class)
                .setTag("dozemode_warning_remover")
                .setRecurring(false)
                .setLifetime(Lifetime.FOREVER)
                .setTrigger(Trigger.NOW)
                .setReplaceCurrent(true)
                .setConstraints(Constraint.DEVICE_CHARGING)
                .setRetryStrategy(RetryStrategy.DEFAULT_EXPONENTIAL)
                .build();
      jobDispatcher.schedule(myJob);

    }


}

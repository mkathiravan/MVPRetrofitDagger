package net.abaqus.mygeotracking.deviceagent.analytics;

public class AnalyticsEvent {

    public static final String FORM_ATTACHMENT_EVENT = "FORM_ATTACHMENT_EVENT";
    public static final String RE_REGISTRATION_EVENT = "RE_REGISTRATION_EVENT";
    public static final String SEND_DEBUG_INFO_EVENT = "SEND_DEBUG_INFO_EVENT";
    public static final String HELP_CENTER_CLICK_EVENT = "HELP_CENTER_CLICK_EVENT";
    public static final String WORK_ORDER_CLICK_EVENT = "WORK_ORDER_CLICK_EVENT";
    public static final String WORK_ORDER_YESTERDAY_CLICK_EVENT = "WORK_ORDER_YESTERDAY_CLICK_EVENT";
    public static final String WORK_ORDER_TODAY_CLICK_EVENT = "WORK_ORDER_TODAY_CLICK_EVENT";
    public static final String WORK_ORDER_TOMORROW_CLICK_EVENT = "WORK_ORDER_TOMORROW_CLICK_EVENT";
}

package net.abaqus.mygeotracking.deviceagent.heartbeat;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.Lifetime;
import com.firebase.jobdispatcher.RetryStrategy;
import com.firebase.jobdispatcher.Trigger;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

/**
 * Created by bmandyam on 1/16/18.
 */

public class HeartBeat {

    private static final String KEY_TRIGGER_SOURCE = "triggerSource";
    private static HeartBeat uniqueInstance;

    //private constructor.
    private HeartBeat(){
        //Prevent form the reflection.
        if (uniqueInstance != null){
            throw new RuntimeException("Use getInstance() method to get the single instance of this class.");
        }
    }

    public static synchronized HeartBeat getInstance() {
        if (uniqueInstance == null) {
            uniqueInstance = new HeartBeat();
        }
        return uniqueInstance;
    }

    public void startBeating(Context applicationContext) {
        SharedPreferences sh_prefs = applicationContext.getSharedPreferences(MDACons.PREFS, 0);
        int interval = Integer.parseInt(sh_prefs.getString(MDACons.HB_INTERVAL, "30"));
        DebugLog.debug("Started beating!", "with interval of :" + interval);

        if(interval < 15)
            interval = 15;

        Bundle bundle = new Bundle();
        bundle.putString(KEY_TRIGGER_SOURCE, TriggerSource.SCHEDULE);

        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(applicationContext));
        Job myJob = dispatcher.newJobBuilder()
                .setService(HeartBeatService.class)
                .setTag("heart_beat_with_mgt")
                .setExtras(bundle)
                .setRecurring(true)
                .setLifetime(Lifetime.FOREVER)
                .setTrigger(Trigger.executionWindow(5,interval*60))
                .setReplaceCurrent(true)
                .setRetryStrategy(RetryStrategy.DEFAULT_EXPONENTIAL)
                .build();
        dispatcher.schedule(myJob);
    }

    public void justOneBeat(Context applicationContext, String source) {
        DebugLog.debug("Started beating!", "with one time beat");


        Bundle bundle = new Bundle();
        bundle.putString(KEY_TRIGGER_SOURCE, source);

        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(applicationContext));
        Job myJob = dispatcher.newJobBuilder()
                .setService(HeartBeatService.class)
                .setTag("heart_beat_with_mgt_onetime")
                .setExtras(bundle)
                .setRecurring(false)
                .setLifetime(Lifetime.FOREVER)
                .setTrigger(Trigger.NOW)
                .setReplaceCurrent(false)
                .setRetryStrategy(RetryStrategy.DEFAULT_EXPONENTIAL)
                .build();
        dispatcher.schedule(myJob);
    }




}

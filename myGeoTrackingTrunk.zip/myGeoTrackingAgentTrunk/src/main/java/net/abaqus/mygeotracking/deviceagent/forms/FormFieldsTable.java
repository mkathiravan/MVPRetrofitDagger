package net.abaqus.mygeotracking.deviceagent.forms;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;

/**
 * Created by user on 04-07-2018.
 */

@Table(name = "FormFieldsTable", id = "_id")
public class FormFieldsTable extends Model {
    public String getPreFillkey() {
        return PreFillkey;
    }

    public void setPreFillkey(String preFillkey) {
        PreFillkey = preFillkey;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(String fieldValue) {
        this.fieldValue = fieldValue;
    }

    @Column(name = "PreFillkey")
    public String PreFillkey;
    @Column(name = "name")
    public String fieldName;
    @Column(name = "value")
    public String fieldValue;
}

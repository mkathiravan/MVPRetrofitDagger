package net.abaqus.mygeotracking.deviceagent.hos;

import com.google.gson.annotations.SerializedName;

public class ScanNotes {

    public String getQR() {
        return QR;
    }

    public void setQR(String QR) {
        this.QR = QR;
    }

    @SerializedName("QR")
    String QR = "";

}

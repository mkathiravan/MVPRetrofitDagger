package net.abaqus.mygeotracking.deviceagent.receivers;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

import net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder;

import static net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder.NOTIFICATION_ID_DOZEMODE;

/**
 * Created by bmandyam on 4/3/18.
 */

public class DozeModeNotificationActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

        int notificationId = intent.getIntExtra("notificationId", 0);

        switch (notificationId) {
            case NOTIFICATION_ID_DOZEMODE:
                //Cancelling the notification and route it to settings screen
                AgentNotificationBuilder.dismissNotification(context, NOTIFICATION_ID_DOZEMODE);

                Intent move = new Intent();
                move.setAction(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                context.startActivity(move);
                break;


        }
    }


    }
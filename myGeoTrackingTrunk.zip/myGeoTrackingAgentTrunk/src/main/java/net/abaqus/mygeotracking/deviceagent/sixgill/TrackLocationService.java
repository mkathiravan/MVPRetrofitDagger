package net.abaqus.mygeotracking.deviceagent.sixgill;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.BatteryManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.util.Xml;

import com.crashlytics.android.Crashlytics;
import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiClient;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiInterface;
import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.utils.ConnectionManager;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkDeviceStatus;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.xmlpull.v1.XmlSerializer;

import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TrackLocationService extends JobService {

    private static final String TAG = TrackLocationService.class.getSimpleName();
    private Context mContext;
    String timeStamp = "", device_number = "";
    SharedPreferences sh_prefs;
    double latitude, longtitude;
    ProviderModel provider = new ProviderModel();

    @Override
    public boolean onStartJob(JobParameters job) {

        DebugLog.debug("Started Locating Job!", "TrackLocationService");
        final String timeStamp = job.getExtras().getString("timestamp");
        final boolean screenOn = job.getExtras().getBoolean("screen_state", false);

        sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
        device_number = sh_prefs.getString(MDACons.DEVICE_NUMBER, "");


        Log.d(TAG,"IOSDERMKDR "+screenOn);

        mContext = this;
        AsyncTask.execute(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void run() {

                location_call();

            }
        });
        return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void location_call()
    {

        provider.setProvider("push");
        provider.setRegionCode("");
        provider.setRegionCountry("");
        provider.setStatusCode(12450);
        provider.setStatusMessage("");
        String connect_method = NetworkDeviceStatus.checkNetworkStatus(this);
        provider.setLocateMethod(connect_method);
        provider.setNationalNumber("");
        provider.setCoOrdinateFormat("");
        provider.setCountryCode("");
        provider.setDeviceId(device_number);

        String reg_timeFormat = "";
        try {
            DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US);
            reg_timeFormat = formatter.format(Calendar.getInstance().getTime().getTime());

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }


        provider.setLocateTime(reg_timeFormat);



        GeoModel geo = new GeoModel();

        FusedProvider fusedProvider = MDAMainActivity.getInstanceLocation();
        latitude = fusedProvider.getLatitude();
        longtitude = fusedProvider.getLongitude();

        geo.setAccuracy(fusedProvider.getAccuracy());
        geo.setAltitude(0);
        geo.setDirection("");
        geo.setLatitude((float) latitude);
        geo.setLongitude((float) longtitude);
        provider.setGeo(geo);




        PropertyModel property = new PropertyModel();


        property.setManufacturer(Build.MANUFACTURER);
        property.setModel(Build.MODEL);
        property.setOs("Android");
        property.setOsVersion(String.valueOf(Build.VERSION.SDK_INT));
        property.setSensors("activity");
        property.setSoftwareVersion("1.1");
        property.setType("Android");
        provider.setProperty(property);


        DeviceModel device = new DeviceModel();

        BatteryManager bm = (BatteryManager)getSystemService(BATTERY_SERVICE);
        int batLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);

        String methodParam = NetworkDeviceStatus.checkNetworkStatus(this);


        device.setMethod(methodParam);
        device.setSpeed("");
        device.setMovementDetected("");
        device.setBatteryLevel(0);
        device.setBatteryLife(batLevel);
        device.setCharging(false);
        provider.setDevice(device);




        AddressModel address = new AddressModel();
        Geocoder geocoder;
        List<Address> addresses;
        geocoder = new Geocoder(this, Locale.getDefault());
        Crashlytics.log("Calling GeoCoding for the following params: Lat:" + latitude + ", Long:" + longtitude + "MaxResults: 1");

        try {

            String street_address,city,state,country,postalCode,full_address,knownName,locationName,countryCode = null;
            addresses = geocoder.getFromLocation(latitude, longtitude, 1);
            full_address = addresses.get(0).getAddressLine(0);
            Log.wtf(TAG,"ADDRED "+address + "SAMODRE "+addresses);
            street_address = addresses.get(0).getFeatureName() +" " +addresses.get(0).getThoroughfare();
            city = addresses.get(0).getLocality();
            state = addresses.get(0).getAdminArea();
            country = addresses.get(0).getCountryName();

            if(addresses.get(0).getPostalCode() == null || addresses.get(0).getPostalCode().isEmpty())
            {
                postalCode = "0";
            }
            else
            {
                postalCode = addresses.get(0).getPostalCode();
            }
            knownName = addresses.get(0).getFeatureName();
            countryCode = addresses.get(0).getCountryCode();
            Double lat = addresses.get(0).getLatitude();
            Double lang = addresses.get(0).getLongitude();

            address.setSetStreetAddress(street_address);
            address.setCity(city);
            address.setState(state);
            address.setPostalCode(postalCode);
            address.setCountry(country);
            address.setAddress(full_address);
            provider.setAddress(address);

        }catch (Exception e)
        {
            Crashlytics.logException(e);
            Log.wtf(TAG,"SAMException ");
            e.printStackTrace();
        }


        if (NetworkConnectionInfo.isOnline(this)) {

            AsyncTask.execute(new Runnable() {
                @Override
                public void run() {
                    load_tracking_data(provider);
                }
            });

        }



    }



    public void load_tracking_data(final  ProviderModel provider)
    {
        Log.d(TAG,"PUSHLOCATIONTRACKINGCALLED ");
        final String locate_time = provider.getLocateTime();
        final ApiInterface requestInterface = ApiClient.getProductionClient();

        Void result = null;
        Response<Void> execute;
        boolean isRequestSuccess = false;
        Call<Void> call = requestInterface.loadLocationInfo(provider);
        try {
            execute = call.execute();
            isRequestSuccess = execute.isSuccessful();
            result = execute.body();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(isRequestSuccess) {

            Log.d(TAG,"DATA SEND SUCCESSFULLY ");

        }
    }


    @Override
    public boolean onStopJob(JobParameters job) {
        DebugLog.debug("Stopped Locating Job!", "TrackLocationService");
        return false;
    }

    private void sendErrorResponseToServer(final Context mContext, final String errorResponse, final String requestedTimestamp) {

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                SharedPreferences prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);

                ConnectionManager cm = new ConnectionManager();
                cm.setupHttpPost(MDACons.SERVER_URL+"updateEventData");
                cm.setHttpHeader("Content-Type", "application/xml");


                XmlSerializer serializer = Xml.newSerializer();
                StringWriter writer = new StringWriter();
                try{
                    serializer.setOutput(writer);

                    serializer.startDocument("UTF-8", true);
                    serializer.startTag(null, "MGTRequest");
                    serializer.startTag(null, "DeviceLocation");

                    serializer.startTag(null, "Device");
                    serializer.text(prefs.getString(MDACons.DEVICE_NUMBER, ""));
                    serializer.endTag(null,"Device");

                    serializer.startTag(null, "ErrorMessage");
                    serializer.text(errorResponse);
                    serializer.endTag(null,"ErrorMessage");

                    serializer.startTag(null, "Time");
                    serializer.text(CurrentDateAndTime.getDateTime(new SimpleDateFormat("yyyy:MM:dd,HH:mm:ss")));
                    serializer.endTag(null,"Time");

                    serializer.startTag(null, "RequestedTime");
                    serializer.text(requestedTimestamp);
                    serializer.endTag(null,"RequestedTime");


                    serializer.startTag(null, "UUID");
                    serializer.text(prefs.getString(MDACons.DEVICE_GUID, ""));
                    serializer.endTag(null,"UUID");

                    String versionName = "";
                    String bundleid = "";
                    try {
                        bundleid = mContext.getPackageManager()
                                .getPackageInfo(mContext.getPackageName(), 0).packageName;
                        versionName =mContext.getPackageManager()
                                .getPackageInfo(mContext.getPackageName(), 0).versionName;
                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }

                    serializer.startTag(null, "AgentVersion");
                    serializer.text(versionName);
                    serializer.endTag(null,"AgentVersion");

                    serializer.startTag(null, "BundleID");
                    serializer.text(bundleid);
                    serializer.endTag(null,"BundleID");

                    serializer.startTag(null, "Platform");
                    serializer.text("Android");
                    serializer.endTag(null,"Platform");


                    serializer.endTag(null, "DeviceLocation");
                    serializer.endTag(null,"MGTRequest");
                    serializer.endDocument();
                }catch (Exception e) {

                }
                HttpEntity en = null;
                try {
                    en = new StringEntity(writer.toString());
                } catch (UnsupportedEncodingException e2) {
                    e2.printStackTrace();
                }
                try {
                    Log.i("REQUEST", EntityUtils.toString(en));
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
                cm.setHttpPostEntity(en);


                try {
                    cm.makeRequestGetResponse();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


    }


}

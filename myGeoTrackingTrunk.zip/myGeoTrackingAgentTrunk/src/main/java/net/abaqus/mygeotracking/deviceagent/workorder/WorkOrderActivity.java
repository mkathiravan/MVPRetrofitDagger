package net.abaqus.mygeotracking.deviceagent.workorder;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.activeandroid.query.Select;
import com.activeandroid.util.SQLiteUtils;
import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.google.firebase.analytics.FirebaseAnalytics;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiClient;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiInterface;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsCons;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsEvent;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsKey;
import net.abaqus.mygeotracking.deviceagent.bgthread.HOSBackgroundService;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HeartBeat;
import net.abaqus.mygeotracking.deviceagent.heartbeat.TriggerSource;
import net.abaqus.mygeotracking.deviceagent.home.MainActivityHelper;
import net.abaqus.mygeotracking.deviceagent.hos.HOSActivity;
import net.abaqus.mygeotracking.deviceagent.notes.NotesComposeFragment;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.soshardware.ProcessSMS;
import net.abaqus.mygeotracking.deviceagent.utils.AccountUtils;
import net.abaqus.mygeotracking.deviceagent.utils.DeviceUtils;
import net.abaqus.mygeotracking.deviceagent.utils.FragmentTransactionBaseClass;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkUtils;
import net.abaqus.mygeotracking.deviceagent.utils.SnackbarUtils;

import java.net.SocketTimeoutException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Date;
import java.util.List;


import butterknife.BindView;
import butterknife.ButterKnife;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class WorkOrderActivity extends ReceiverActivity {
    private final static String TAG = WorkOrderActivity.class.getSimpleName();
    private SharedPreferences sh_prefs;
    private SharedPreferences.Editor editor_sh_prefs;
    String device_number = "";
    @BindView(R.id.workorder_recycler_view)
    RecyclerView mrecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    public WorkOrderItemAdapter adapter;
    @BindView(R.id.tabs)
    TabLayout tabLayout;
    List<WorkOrderData> workorderList = new ArrayList<>();
    private List<WorkOrderTable> workorderTableArrayList;
    List<WorkOrderData> workOrderDataListToday = new ArrayList<>();
    List<WorkOrderData> workOrderDataListYesterday = new ArrayList<>();
    List<WorkOrderData> workOrderDataListTomorrow = new ArrayList<>();
    @BindView(R.id.errorViewLayout)
    LinearLayout errorLayout;
    @BindView(R.id.workorder_rootLayout)
    LinearLayout rootLayout;
    @BindView(R.id.no_record_found)
    TextView noRecord;
    int tabPosition = 0;
    @BindView(R.id.floatingActionButtonText)
    TextView btn_menu_sos;
    @BindView(R.id.button_timeclock_menu)
    ImageView btn_menu_timecloking;
    @BindView(R.id.button_messages_menu)
    ImageView btn_menu_messages;
    public boolean isExpand = false;
    private FirebaseAnalytics mFirebaseAnalytics;
    private FragmentManager mFragmentManager;
    @BindView(R.id.fragment_container)
    FrameLayout frag;
    private NotesComposeFragment mDetailFragment = null;
    public final String FRAGMENT_NOTES_TAG = "fragment_notes";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_layout_view);
        ButterKnife.bind(this);

        HeartBeat heartBeat = HeartBeat.getInstance();
        heartBeat.justOneBeat(this, TriggerSource.APP_LAUNCHED);
        heartBeat.startBeating(this);

        sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
        editor_sh_prefs = sh_prefs.edit();
        device_number = sh_prefs.getString(MDACons.DEVICE_NUMBER, "");
        mrecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mrecyclerView.setLayoutManager(mLayoutManager);
        setupTabIcons();
        if (!NetworkConnectionInfo.isOnline(WorkOrderActivity.this)) {
            SnackbarUtils.showShort(rootLayout, getString(R.string.msg_internet_disabled_please_try_later), Color.WHITE, ContextCompat.getColor(WorkOrderActivity.this, R.color.alert));
            offlineData();
        } else {
            SnackbarUtils.showShort(rootLayout, "Refreshing. Please wait.", Color.BLACK, ContextCompat.getColor(WorkOrderActivity.this, R.color.yellow));
            load_work_data();
        }

        initializeComposeMsgDependencies();
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        mFirebaseAnalytics.setUserId(DeviceUtils.getAndroidID(WorkOrderActivity.this));
        mFirebaseAnalytics.setUserProperty("mgt_track_id", DeviceUtils.getAndroidID(WorkOrderActivity.this));
        mFirebaseAnalytics.setCurrentScreen(this, "WORKORDERACTIVITY", null /* class override */);


        if(AccountUtils.isSOSAvailable(sh_prefs))
        {
            btn_menu_sos.setVisibility(View.VISIBLE);
            btn_menu_sos.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sosAlertDialogView();
                }
            });
        }
        else
        {
            btn_menu_sos.setVisibility(View.INVISIBLE);
        }



        btn_menu_timecloking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                launchTimeClockingView();

            }
        });

        btn_menu_messages.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                openNotesComposer();
            }
        });


        tabLayout.getTabAt(1).select();
        tabPosition = 1;
        // little hack to prevent unnecessary tab scrolling
        tabLayout.clearOnTabSelectedListeners();
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                tabPosition = tab.getPosition();
                FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(WorkOrderActivity.this);
                Bundle bundle = new Bundle();
                switch (tabPosition) {
                    case 0:
                        setAdapter();
                        isExpand = false;
                        bundle.putString(AnalyticsKey.EVENT_STATE, AnalyticsCons.ITEM_SUBMITTED);
                        mFirebaseAnalytics.logEvent(AnalyticsEvent.WORK_ORDER_YESTERDAY_CLICK_EVENT, bundle);
                        break;
                    case 1:
                        setAdapter();
                        isExpand = false;
                        bundle.putString(AnalyticsKey.EVENT_STATE, AnalyticsCons.ITEM_SUBMITTED);
                        mFirebaseAnalytics.logEvent(AnalyticsEvent.WORK_ORDER_TODAY_CLICK_EVENT, bundle);
                        break;
                    case 2:
                        setAdapter();
                        isExpand = false;
                        bundle.putString(AnalyticsKey.EVENT_STATE, AnalyticsCons.ITEM_SUBMITTED);
                        mFirebaseAnalytics.logEvent(AnalyticsEvent.WORK_ORDER_TOMORROW_CLICK_EVENT, bundle);
                        break;


                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
    }


    private void initializeComposeMsgDependencies() {
        //DebugLog.debug(TAG, "initializeComposeMsgDependencies Called");

        /*Code block for in app notes implementation*/
        mFragmentManager = getSupportFragmentManager();
        mFragmentManager.addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
            @SuppressLint("NewApi")
            @Override
            public void onBackStackChanged() {
                if (getFragmentManager().getBackStackEntryCount() == 0)
                    if (frag.getVisibility() == View.VISIBLE)
                        frag.setVisibility(View.GONE);
            }
        });
        frag.setVisibility(View.GONE);
        /*Code block for in app notes implementation*/
    }


    @SuppressLint("NewApi")
    public void openNotesComposer() {
        //DebugLog.debug(TAG, "openNotesComposer Called. ");

        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        FragmentTransactionBaseClass.animateTransition(transaction, FragmentTransactionBaseClass.TRANSITION_VERTICAL);
        mDetailFragment = new NotesComposeFragment();
        Bundle b = new Bundle();
        mDetailFragment.setArguments(b);
        if (mFragmentManager.findFragmentByTag(FRAGMENT_NOTES_TAG) == null) {
            transaction.replace(R.id.fragment_container, mDetailFragment,
                    FRAGMENT_NOTES_TAG)
                    .commitAllowingStateLoss();
        } else {
            transaction.replace(R.id.fragment_container, mDetailFragment,
                    FRAGMENT_NOTES_TAG).commitAllowingStateLoss();
        }
        FrameLayout frag = (FrameLayout) findViewById(R.id.fragment_container);
        frag.setVisibility(View.VISIBLE);
        invalidateOptionsMenuItems();
    }


    private void closeComposeView() {
        //DebugLog.debug(TAG, "closeComposeView Called. ");

        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction trans = manager.beginTransaction();
        trans.remove(mDetailFragment);
        trans.commit();
        manager.popBackStack();
        FrameLayout frag = (FrameLayout) findViewById(R.id.fragment_container);
        frag.setVisibility(View.GONE);
        mDetailFragment = null;
        invalidateOptionsMenuItems();
    }

    @SuppressLint("NewApi")
    private void invalidateOptionsMenuItems() {
        invalidateOptionsMenu();
    }


    //Methods for Launching views
    protected void launchTimeClockingView() {
        //DebugLog.debug(TAG, "launchTimeClockingView Called. ");

        Intent hos_activity_intent = new Intent(getApplicationContext(), HOSActivity.class);
        startActivity(hos_activity_intent);
    }

    private void sosAlertDialogView() {

        new MaterialDialog.Builder(WorkOrderActivity.this)
                .title("Send SOS")
                .content("Please Confirm.")
                .positiveText("Yes")
                .negativeText("Cancel")
                .autoDismiss(true)
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        SharedPreferences sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
                        String hos_Selection_stage_name = sh_prefs.getString(MDACons.HOS_SELECTION_NAME, "");
                        Bundle bundle = new Bundle();
                        bundle.putString("TC_CLICKED_STAGE", "SOS");
                        bundle.putString("TC_PREVIOUS_STAGE", hos_Selection_stage_name);
                        bundle.putString("TC_EVENT_SOURCE", "Manual Click");
                        mFirebaseAnalytics.logEvent("TC_EVENT", bundle);

                        //IF No Internet at all - then process as SMS immediately
                        //IF Internet available - then check for connection quality
                        //IF Connection quality is POOR - then process as SMS
                        //IF Connection quality is GOOD and FAST - then process ausual with API Request
                        if(!NetworkConnectionInfo.isOnline(WorkOrderActivity.this) && isSMSPermissionGranted()) {
                            processSOSAsSMS();
                        } else {
                            if(AccountUtils.isSOSAvailable(sh_prefs) && !NetworkUtils.isConnectedFast(WorkOrderActivity.this) && isSMSPermissionGranted()) {
                                processSOSAsSMS();
                            } else {
                                new HOSBackgroundService().processHOS(WorkOrderActivity.this, "Safety Alert Triggered", "7");
                                if(!isSMSPermissionGranted())
                                    askForSMSPermission();
                            }
                        }
                        try {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    updateUI();
                                }
                            });
                        }catch (Exception e) {e.printStackTrace();}
                        SnackbarUtils.showLong(rootLayout, "Safety Alert Triggered.", Color.BLACK, ContextCompat.getColor(WorkOrderActivity.this, R.color.yellow));
                    }
                })
                .show();
    }


    private void askForSMSPermission() {
        if (!isSMSPermissionGranted()) {
            MainActivityHelper mainActivityHelper = new MainActivityHelper(WorkOrderActivity.this, WorkOrderActivity.this);
            mainActivityHelper.checkSMSPersmission();
        }
    }

    private boolean isSMSPermissionGranted() {
        return ContextCompat.checkSelfPermission(WorkOrderActivity.this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }


    private void processSOSAsSMS() {
        SharedPreferences sharedPreferences = getSharedPreferences(MDACons.PREFS, 0);
        String toPhoneNumber = sharedPreferences.getString(MDACons.TWILIO_SHORT_CODE, "+18032327769");
        String sosCommand = sharedPreferences.getString(MDACons.SOS_EMER_COMMAND, "SOS");
        SharedPreferences.Editor edit_prefs = sharedPreferences.edit();
        edit_prefs.putInt(MDACons.HOS_SELECTION,
                Integer.parseInt("7"));
        edit_prefs.putString(MDACons.HOS_SELECTION_NAME,
                "Safety Alert Triggered");
        edit_prefs.commit();

        new ProcessSMS().sendNow(WorkOrderActivity.this, toPhoneNumber, sosCommand, "7", "");
    }



    private void offlineData() {
        updateUI();
    }

    private void updateUI() {
        try {
            setWorkData();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("NewApi")
    @Override
    public void onBackPressed() {
        //DebugLog.debug(TAG, "onBackPressed Called. ");


        if (mDetailFragment != null) {
            if(mDetailFragment.isClosable()) {
                closeComposeView();
            } else {
                showWarningOnBackPress();
            }
        } else {
            super.onBackPressed();
        }
    }




    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (mDetailFragment != null) {
            menu.findItem(R.id.action_close).setVisible(true);
            menu.findItem(R.id.expand_items).setVisible(false);
            menu.findItem(R.id.work_order_refresh).setVisible(false);
            return true;
        } else {
            return super.onPrepareOptionsMenu(menu);
        }
    }




    private void showWarningOnBackPress() {
        //DebugLog.debug(TAG, "showWarningOnBackPress Called. ");

        new MaterialDialog.Builder(WorkOrderActivity.this)
                .title(R.string.title_warning_backbtn_press)
                .content(R.string.msg_warning_backbtn_press_notes_compose)
                .positiveText(R.string.action_discard)
                .negativeText(R.string.action_stay)
                .autoDismiss(true)
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        closeComposeView();
                    }
                })
                .show();
    }



    private void setupTabIcons() {
        View tabOne = LayoutInflater.from(WorkOrderActivity.this).inflate(R.layout.custom_tab_btn_graph, null);
        TextView txtTab1 = tabOne.findViewById(R.id.tab);
        txtTab1.setText("Yesterday");
        TabLayout.Tab tab = tabLayout.newTab();
        tabLayout.addTab(tab);
        tab.setCustomView(tabOne);
        tabOne.setBackgroundResource(R.drawable.rounded_cornor_tab);
        View tabTwo = LayoutInflater.from(WorkOrderActivity.this).inflate(R.layout.custom_tab_btn_graph, null);
        TextView txtTab2 = tabTwo.findViewById(R.id.tab);
        txtTab2.setText("Today");
        TabLayout.Tab tab1 = tabLayout.newTab();
        tabLayout.addTab(tab1);
        tab1.setCustomView(tabTwo);
        tabTwo.setBackgroundResource(R.drawable.rounded_cornor_tab_normal);
        View tabThree = LayoutInflater.from(WorkOrderActivity.this).inflate(R.layout.custom_tab_btn_graph, null);
        TextView txtTab3 = tabThree.findViewById(R.id.tab);
        txtTab3.setText("Tomorrow");
        TabLayout.Tab tab2 = tabLayout.newTab();
        tabLayout.addTab(tab2);
        tab2.setCustomView(tabThree);
        tabThree.setBackgroundResource(R.drawable.rounded_cornor_tab_right);
    }


//    private void load_work_order_data() {
//        ApiInterface requestInterface = ApiClient.getClientRX();
//        CompositeDisposable mCompositeDisposable = new CompositeDisposable();
//        mCompositeDisposable.add(requestInterface.getWorkOrderData(device_number)
//                .observeOn(AndroidSchedulers.mainThread())
//                .subscribeOn(io.reactivex.schedulers.Schedulers.io())
//                .subscribeWith(new DisposableObserver<WorkOrderReponse>() {
//
//                    @Override
//                    public void onNext(WorkOrderReponse workOrderReponse) {
//                        SnackbarUtils.dismiss();
//                        SQLiteUtils.execSql("DELETE FROM " + WorkOrderTable.class.getSimpleName());
//
//                        if (workOrderReponse.getStatusCode().equalsIgnoreCase("74")) {
//                            errorLayout.setVisibility(View.VISIBLE);
//                            noRecord.setText("No Assignments for Yesterday");
//                            mrecyclerView.setVisibility(View.GONE);
//                        }
//                        else if (workOrderReponse.getStatusCode().equalsIgnoreCase("200")) {
//                            workorderList = workOrderReponse.getWorkOrders();
//                            //Clear the existing entries in WorkOrder Table
//
//                            for (int i = 0; i < workorderList.size(); i++) {
//                                WorkOrderTable workOrderTable = new WorkOrderTable();
//                                workOrderTable.setWoId(workorderList.get(i).getWoId());
//                                workOrderTable.setWoNumber(workorderList.get(i).getWoNumber());
//                                workOrderTable.setStatus(workorderList.get(i).getStatus());
//                                workOrderTable.setStartTime(workorderList.get(i).getStartTime());
//                                workOrderTable.setEndTime(workorderList.get(i).getEndTime());
//                                workOrderTable.setCustomerName(workorderList.get(i).getCustomerName());
//                                workOrderTable.setTaskName(workorderList.get(i).getTaskName());
//                                workOrderTable.setSchedule(workorderList.get(i).getSchedule());
//                                workOrderTable.setAddress(workorderList.get(i).getAddress());
//                                workOrderTable.save();
//                            }
//                        }
//
//                        try {
//                            setWorkData();
//                        } catch (ParseException e) {
//                            e.printStackTrace();
//                        }
//
//
//                    }
//
//                    @Override
//                    public void onError(Throwable e) {
//
//                        SnackbarUtils.dismiss();
//                    }
//
//                    @Override
//                    public void onComplete() {
//                        SnackbarUtils.dismiss();
//
//                    }
//                }));
//    }


    private void load_work_data() {
        final ApiInterface requestInterface = ApiClient.getClient();
        //TODO: Need to remove hardcoded date and device number
        Call<WorkOrderReponse> call = requestInterface.getWorkOrder(device_number);
        call.enqueue(new Callback<WorkOrderReponse>() {
            @Override
            public void onResponse(Call<WorkOrderReponse> call, Response<WorkOrderReponse> response) {

                if(response.isSuccessful())
                {
                    SnackbarUtils.dismiss();
                    // If the response code is 200 we are showing the data
                    if (response.code() == 200) {
                        SQLiteUtils.execSql("DELETE FROM " + WorkOrderTable.class.getSimpleName());
                        if (response.body().getStatusCode().equalsIgnoreCase("74")) {
                            errorLayout.setVisibility(View.VISIBLE);
                            noRecord.setText("No Assignments for Yesterday");
                            mrecyclerView.setVisibility(View.GONE);
                        } else if (response.body().getStatusCode().equalsIgnoreCase("200")) {
                            workorderList = response.body().getWorkOrders();
                            //Clear the existing entries in WorkOrder Table

                            for (int i = 0; i < workorderList.size(); i++) {
                                WorkOrderTable workOrderTable = new WorkOrderTable();
                                workOrderTable.setWoId(workorderList.get(i).getWoId());
                                workOrderTable.setWoNumber(workorderList.get(i).getWoNumber());
                                workOrderTable.setStatus(workorderList.get(i).getStatus());
                                workOrderTable.setStartTime(workorderList.get(i).getStartTime());
                                workOrderTable.setEndTime(workorderList.get(i).getEndTime());
                                workOrderTable.setCustomerName(workorderList.get(i).getCustomerName());
                                workOrderTable.setTaskName(workorderList.get(i).getTaskName());
                                workOrderTable.setSchedule(workorderList.get(i).getSchedule());
                                workOrderTable.setAddress(workorderList.get(i).getAddress());
                                workOrderTable.save();
                            }
                        }
                        try {
                            setWorkData();
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                }
                else {
                    Toast.makeText(WorkOrderActivity.this, "Server returned an error", Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<WorkOrderReponse> call, Throwable t) {
                //  progress.hide();

                SnackbarUtils.dismiss();
                SnackbarUtils.showShort(rootLayout, t.getMessage(), Color.WHITE, ContextCompat.getColor(WorkOrderActivity.this, R.color.alert));

                if(t instanceof SocketTimeoutException){
                    String message = "Socket Time out. Please try again.";
                    Toast.makeText(WorkOrderActivity.this,message,Toast.LENGTH_SHORT).show();
                }

                if(call.isCanceled())
                {
                    Log.e(TAG, "request was cancelled");
                }
            }
        });
    }

    private List<WorkOrderTable> getWorksData() {
        return new Select().from(WorkOrderTable.class).execute();
    }

    private void setWorkData() throws ParseException {
        workorderTableArrayList = getWorksData();
        workOrderDataListToday.clear();
        workOrderDataListYesterday.clear();
        workOrderDataListTomorrow.clear();
        for (int index = 0; index < workorderTableArrayList.size(); index++) {

            Date today = new Date();
            String todayDate= new SimpleDateFormat("yyyy/MM/dd").format(today);

            Date startWorkingDate = new Date(workorderTableArrayList.get(index).getStartTime());
            Date endWorkingDate = new Date(workorderTableArrayList.get(index).getEndTime());



            DateFormat df = new SimpleDateFormat("yyyy/MM/dd, hh:mm:ss");
            String stDate= df.format(startWorkingDate);
            String edDate = df.format(endWorkingDate);


            Date startWorkDate = new SimpleDateFormat("yyyy/MM/dd").parse(stDate);
            Date endWorkDate = new SimpleDateFormat("yyyy/MM/dd").parse(edDate);
            Date todayWorkDate = new SimpleDateFormat("yyyy/MM/dd").parse(todayDate);


            //Segreggating Date with Day Wise and put into Today Work Order List

            if((todayWorkDate.before(endWorkDate) && todayWorkDate.after(startWorkDate)) || (todayWorkDate.equals(startWorkDate) || todayWorkDate.equals(endWorkDate)))
            {
                WorkOrderData workOrderData = new WorkOrderData();
                workOrderData.setWoId(workorderTableArrayList.get(index).getWoId());
                workOrderData.setWoNumber(workorderTableArrayList.get(index).getWoNumber());
                workOrderData.setStatus(workorderTableArrayList.get(index).getStatus());
                workOrderData.setStartTime(workorderTableArrayList.get(index).getStartTime());
                workOrderData.setEndTime(workorderTableArrayList.get(index).getEndTime());
                workOrderData.setCustomerName(workorderTableArrayList.get(index).getCustomerName());
                workOrderData.setTaskName(workorderTableArrayList.get(index).getTaskName());
                workOrderData.setSchedule(workorderTableArrayList.get(index).getSchedule());
                workOrderData.setAddress(workorderTableArrayList.get(index).getAddress());
                workOrderDataListToday.add(workOrderData);

            }

            //Segreggating Date with Day Wise and put into Yesterday Work Order List

            if(todayWorkDate.after(startWorkDate))
            {
                WorkOrderData workOrderData = new WorkOrderData();
                workOrderData.setWoId(workorderTableArrayList.get(index).getWoId());
                workOrderData.setWoNumber(workorderTableArrayList.get(index).getWoNumber());
                workOrderData.setStatus(workorderTableArrayList.get(index).getStatus());
                workOrderData.setStartTime(workorderTableArrayList.get(index).getStartTime());
                workOrderData.setEndTime(workorderTableArrayList.get(index).getEndTime());
                workOrderData.setCustomerName(workorderTableArrayList.get(index).getCustomerName());
                workOrderData.setTaskName(workorderTableArrayList.get(index).getTaskName());
                workOrderData.setSchedule(workorderTableArrayList.get(index).getSchedule());
                workOrderData.setAddress(workorderTableArrayList.get(index).getAddress());
                workOrderDataListYesterday.add(workOrderData);
            }

            //Segreggating Date with Day Wise and put into Tomorrow Work Order List

            if(todayWorkDate.before(endWorkDate))
            {

                WorkOrderData workOrderData = new WorkOrderData();
                workOrderData.setWoId(workorderTableArrayList.get(index).getWoId());
                workOrderData.setWoNumber(workorderTableArrayList.get(index).getWoNumber());
                workOrderData.setStatus(workorderTableArrayList.get(index).getStatus());
                workOrderData.setStartTime(workorderTableArrayList.get(index).getStartTime());
                workOrderData.setEndTime(workorderTableArrayList.get(index).getEndTime());
                workOrderData.setCustomerName(workorderTableArrayList.get(index).getCustomerName());
                workOrderData.setTaskName(workorderTableArrayList.get(index).getTaskName());
                workOrderData.setSchedule(workorderTableArrayList.get(index).getSchedule());
                workOrderData.setAddress(workorderTableArrayList.get(index).getAddress());
                workOrderDataListTomorrow.add(workOrderData);
            }

        }
        setAdapter();
    }

    public void expandGroup() {

        if(adapter != null)
        {
            for (int i = adapter.getGroups().size() - 1; i >= 0; i--) {
                if (adapter.isGroupExpanded(i)) {
                    return;
                }
                adapter.toggleGroup(i);
                isExpand = true;
            }
        }


    }


    private void setAdapter() {
        List<Genre> genres = new ArrayList<>();
        if (tabPosition == 0) {
            genres = getGenresYesterday();
        } else if (tabPosition == 1) {
            genres = getGenresToday();
        } else if (tabPosition == 2) {
            genres = getGenresTomorrow();
        }

        if (genres.size() == 0 && tabPosition == 0) {
            errorLayout.setVisibility(View.VISIBLE);
            noRecord.setText("No Assignments for Yesterday");
            mrecyclerView.setVisibility(View.GONE);
        } else if (genres.size() == 0 && tabPosition == 1) {
            errorLayout.setVisibility(View.VISIBLE);
            noRecord.setText("No Assignments for Today");
            mrecyclerView.setVisibility(View.GONE);
        } else if (genres.size() == 0 && tabPosition == 2) {
            errorLayout.setVisibility(View.VISIBLE);
            noRecord.setText("No Assignments for Tomorrow");
            mrecyclerView.setVisibility(View.GONE);
        } else {
            mrecyclerView.setVisibility(View.VISIBLE);
            errorLayout.setVisibility(View.GONE);
            adapter = new WorkOrderItemAdapter(WorkOrderActivity.this, genres);
            mrecyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }
    }

    public List<Genre> getGenresToday() {
        List<Genre> genreList = new ArrayList<>();
        for (int index = 0; index < workOrderDataListToday.size(); index++) {
            List<WorkOrderData> singleList = new ArrayList<>();
            singleList.add(workOrderDataListToday.get(index));
            Genre genre = new Genre(workOrderDataListToday.get(index).getWoNumber(), index, workOrderDataListToday.get(index).getWoId(),workOrderDataListToday.get(index).getWoNumber(),
                    workOrderDataListToday.get(index).getStartTime(), workOrderDataListToday.get(index).getCustomerName(), singleList);
            genreList.add(genre);
        }
        return genreList;
    }

    public List<Genre> getGenresYesterday() {
        List<Genre> genreList = new ArrayList<>();
        for (int index = 0; index < workOrderDataListYesterday.size(); index++) {
            List<WorkOrderData> singleList = new ArrayList<>();
            singleList.add(workOrderDataListYesterday.get(index));
            Genre genre = new Genre(workOrderDataListYesterday.get(index).getWoNumber(), index, workOrderDataListYesterday.get(index).getWoId(),workOrderDataListYesterday.get(index).getWoNumber(),
                    workOrderDataListYesterday.get(index).getStartTime(), workOrderDataListYesterday.get(index).getCustomerName(),singleList);
            genreList.add(genre);
        }
        return genreList;
    }

    public List<Genre> getGenresTomorrow() {
        List<Genre> genreList = new ArrayList<>();
        for (int index = 0; index < workOrderDataListTomorrow.size(); index++) {
            List<WorkOrderData> singleList = new ArrayList<>();
            singleList.add(workOrderDataListTomorrow.get(index));
            Genre genre = new Genre(workOrderDataListTomorrow.get(index).getWoNumber(), index, workOrderDataListTomorrow.get(index).getWoId(),workOrderDataListTomorrow.get(index).getWoNumber(),
                    workOrderDataListTomorrow.get(index).getStartTime(), workOrderDataListTomorrow.get(index).getCustomerName(),singleList);
            genreList.add(genre);
        }
        return genreList;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.work_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
            case R.id.work_order_refresh:
                if (!NetworkConnectionInfo.isOnline(WorkOrderActivity.this)) {
                    SnackbarUtils.showShort(rootLayout, getString(R.string.msg_internet_disabled_please_try_later), Color.WHITE, ContextCompat.getColor(WorkOrderActivity.this, R.color.alert));
                    break;
                } else {
                    SnackbarUtils.showIndefinite(rootLayout, "Refreshing. Please wait.", Color.BLACK, ContextCompat.getColor(WorkOrderActivity.this, R.color.yellow));
                    load_work_data();
                    break;
                }


            case R.id.action_close:
                closeComposeView();
                return true;


            case R.id.expand_items:
                Log.d(TAG,"EXPANDVAL "+isExpand);
                if (isExpand) {
                    Log.d(TAG,"INSIDEIFSTAT ");
                    isExpand = false;
                    setAdapter();
                } else {
                    Log.d(TAG,"ELSEPARTISECT ");
                    expandGroup();
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
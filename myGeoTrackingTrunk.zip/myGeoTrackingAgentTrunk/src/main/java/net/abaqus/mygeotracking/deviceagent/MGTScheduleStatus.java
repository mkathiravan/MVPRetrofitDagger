package net.abaqus.mygeotracking.deviceagent;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by Manjappa on 09-03-2018.
 */

public class MGTScheduleStatus {

    private static final String TAG = MGTScheduleStatus.class.getSimpleName();

    private static MGTScheduleStatus instance = null;
    private static SharedPreferences sh_prefs;
    private static SharedPreferences.Editor sh_prefs_edit;

    //private constructor.
    private MGTScheduleStatus(){
        //Prevent form the reflection.
        if (instance != null){
            throw new RuntimeException("Use getInstance() method to get the single instance of this class.");
        }
    }


    public static synchronized MGTScheduleStatus getInstance(Context mContext) {
        if (instance == null) {
            instance = new MGTScheduleStatus();
            sh_prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
            sh_prefs_edit = sh_prefs.edit();
        }
        return instance;
    }


    public void setScheduleStatus(boolean value) {
        sh_prefs_edit.putBoolean(MDACons.SCHEDULE_STATUS, value);
        sh_prefs_edit.apply();
    }


    public boolean isScheduleRunning() {
        return sh_prefs.getBoolean(MDACons.SCHEDULE_STATUS, false);
    }


    public void comparTripTimes() {
        try {
            long startTime = Long.parseLong(sh_prefs.getString(MDACons.DEVICE_TRIP_START_TIME, ""));
            long endTime = Long.parseLong(sh_prefs.getString(MDACons.DEVICE_TRIP_END_TIME, ""));
            Log.d(TAG,"IODRESE "+startTime + "NESER "+endTime);
           // long endTime = sh_prefs.getLong(MDACons.DEVICE_TRIP_END_TIME, -1);
            if (startTime > 0 && endTime > 0) {
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
                sdf.setTimeZone(TimeZone.getDefault());
                Calendar calender = Calendar.getInstance();
                calender.setTimeInMillis(startTime * 1000);
                Date inTime = calender.getTime();
                sdf.format(inTime);

                calender.setTimeInMillis(endTime * 1000);
                Date outTime = calender.getTime();
                sdf.format(outTime);

                Calendar c = Calendar.getInstance();
                System.out.println("Current time => " + c.getTime());

                String currentDateString = sdf.format(c.getTime());
                Date currentDate = c.getTime();
                DebugLog.debug(TAG, inTime.compareTo(currentDate) + "");
                DebugLog.debug(TAG, outTime.compareTo(currentDate) + "");
                if (currentDate.compareTo(inTime) <= 0) {
                    DebugLog.debug(TAG, "Still time is there to start the trip");
                    setScheduleStatus(false);
                } else if (currentDate.compareTo(outTime) > 0) {
                    DebugLog.debug(TAG, "Should have closed the trip");
                    setScheduleStatus(false);
                } else {
                    setScheduleStatus(true);
                }
            } else {
                setScheduleStatus(false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

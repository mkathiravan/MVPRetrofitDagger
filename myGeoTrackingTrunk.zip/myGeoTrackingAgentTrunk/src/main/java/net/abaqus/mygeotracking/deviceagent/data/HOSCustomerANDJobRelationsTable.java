package net.abaqus.mygeotracking.deviceagent.data;

/**
 * Created by bm on 17/7/15.
 */

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;


public class HOSCustomerANDJobRelationsTable {



    private static final String TAG = "CUSJOB_Relations_Table";


    //The columns we'll include in the dictionary table
    public static final String COLUMN_ID = "_id";
    public static final String HOS_CJ_REL_CUS_ID = "hos_cj_rel_cus_id";
    public static final String HOS_CJ_REL_TASK_ID = "hos_cj_rel_task_id";
    public static final String HOS_CJ_REL_TABLE = "mgtagenthoscjrelationstable";





    // Database creation SQL statement

    private static final String HOS_CJ_REL_TABLE_CREATE = "create table "
            + HOS_CJ_REL_TABLE
            + "("
            + COLUMN_ID + " integer primary key autoincrement, "
            + HOS_CJ_REL_CUS_ID + " text null, "
            + HOS_CJ_REL_TASK_ID + " text null"
            + ");";

    public static void onCreate(SQLiteDatabase database) {
        DebugLog.debug(TAG, "Creating database ");
        database.execSQL(HOS_CJ_REL_TABLE_CREATE);
    }

    public static void onUpgrade(SQLiteDatabase database, int oldVersion,
                                 int newVersion) {
        DebugLog.debug(TAG, "Upgrading database from version "
                + oldVersion + " to " + newVersion
                + ", which will destroy all old data");
        database.execSQL("DROP TABLE IF EXISTS " + HOS_CJ_REL_TABLE);
        onCreate(database);
    }

}

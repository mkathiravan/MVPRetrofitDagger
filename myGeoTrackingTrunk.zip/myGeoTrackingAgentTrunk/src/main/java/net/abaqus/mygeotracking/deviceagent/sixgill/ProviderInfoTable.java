package net.abaqus.mygeotracking.deviceagent.sixgill;

import android.arch.persistence.room.PrimaryKey;
import android.util.Log;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;

@Table(name = "ProviderInfoTable", id = "_id")
public class ProviderInfoTable extends Model{

    @Column(name = "provider")
    public String provider;
    @Column (name = "statusCode")
    public int statusCode;
    @Column(name = "statusMsg")
    public String statusMsg = "";
    @Column (name = "deviceID")
    public String deviceID = "";
    @Column(name = "regionCode")
    public String regionCode = "";

    @Column(name = "countryCode")
    public String countryCode = "";
    @Column(name = "regionCountry")
    public String regionCountry = "";
    @Column(name = "nationalNumber")
    public String nationalNumber = "";


    @Column(name = "locateTime")
    public String locateTime = "";

    @Column(name = "locateMethod")
    public String locateMethod = "";
    @Column(name = "coordinateFormat")
    public String coordinateFormat = "";


    @Column(name = "altitude")
    public float altitude;
    @Column (name = "direction")
    public String direction;
    @Column(name = "accuracy")
    public float accuracy;
    @Column (name = "latitude")
    public float latitude;
    @Column(name = "longitude")
    public float longitude;



    @Column(name = "manufacturer")
    public String manufacturer;
    @Column (name = "model")
    public String model = "";
    @Column(name = "os")
    public String os = "";
    @Column (name = "os_version")
    public String os_version = "";
    @Column(name = "sensors")
    public String sensors = "";
    @Column(name = "software_version")
    public String software_version = "";
    @Column(name = "type")
    public String type = "";



    @Column(name = "method")
    public String method;
    @Column(name = "speed")
    public String speed;
    @Column(name = "movementDetected")
    public String movementDetected;
    @Column(name = "batteryLevel")
    public float batteryLevel;
    @Column (name = "battery_life")
    public long battery_life;
    @Column(name = "charging")
    public boolean charging;

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    public String getMovementDetected() {
        return movementDetected;
    }

    public void setMovementDetected(String movementDetected) {
        this.movementDetected = movementDetected;
    }

    public float getBatteryLevel() {
        return batteryLevel;
    }

    public void setBatteryLevel(float batteryLevel) {
        this.batteryLevel = batteryLevel;
    }

    public long getBattery_life() {
        return battery_life;
    }

    public void setBattery_life(long battery_life) {
        this.battery_life = battery_life;
    }

    public boolean isCharging() {
        return charging;
    }

    public void setCharging(boolean charging) {
        this.charging = charging;
    }


    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMsg() {
        return statusMsg;
    }

    public void setStatusMsg(String statusMsg) {
        this.statusMsg = statusMsg;
    }

    public String getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getRegionCountry() {
        return regionCountry;
    }

    public void setRegionCountry(String regionCountry) {
        this.regionCountry = regionCountry;
    }

    public String getNationalNumber() {
        return nationalNumber;
    }

    public void setNationalNumber(String nationalNumber) {
        this.nationalNumber = nationalNumber;
    }

    public String getLocateTime() {
        return locateTime;
    }

    public void setLocateTime(String locateTime) {
        this.locateTime = locateTime;
    }

    public String getLocateMethod() {
        return locateMethod;
    }

    public void setLocateMethod(String locateMethod) {
        this.locateMethod = locateMethod;
    }

    public String getCoordinateFormat() {
        return coordinateFormat;
    }

    public void setCoordinateFormat(String coordinateFormat) {
        this.coordinateFormat = coordinateFormat;
    }

    public float getAltitude() {
        return altitude;
    }

    public void setAltitude(float altitude) {
        this.altitude = altitude;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public float getAccuracy() {
        return accuracy;
    }

    public void setAccuracy(float accuracy) {
        this.accuracy = accuracy;
    }

    public float getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
        Log.d("LATIDIR ","LATIDIR" +latitude);
    }

    public float getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public String getOs_version() {
        return os_version;
    }

    public void setOs_version(String os_version) {
        this.os_version = os_version;
    }

    public String getSensors() {
        return sensors;
    }

    public void setSensors(String sensors) {
        this.sensors = sensors;
    }

    public String getSoftware_version() {
        return software_version;
    }

    public void setSoftware_version(String software_version) {
        this.software_version = software_version;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }







}

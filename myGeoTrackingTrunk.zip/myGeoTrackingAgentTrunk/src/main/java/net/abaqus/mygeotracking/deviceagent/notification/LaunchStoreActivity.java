package net.abaqus.mygeotracking.deviceagent.notification;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by root on 22/6/16.
 */
public class LaunchStoreActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AgentNotificationBuilder.DismissNotifications(this);
        Intent intentLaunch = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName()));
        startActivity(intentLaunch);
        finish();
    }
}

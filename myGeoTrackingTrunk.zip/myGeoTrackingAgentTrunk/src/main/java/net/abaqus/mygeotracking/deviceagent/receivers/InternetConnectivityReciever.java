package net.abaqus.mygeotracking.deviceagent.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import net.abaqus.mygeotracking.deviceagent.listeners.InternetChangeListener;

/**
 * Created by root on 3/11/17.
 */

public class InternetConnectivityReciever extends BroadcastReceiver{

    private InternetChangeListener internetChangeListener;

    public InternetConnectivityReciever(InternetChangeListener internetChangeListener) {
        this.internetChangeListener = internetChangeListener;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if(internetChangeListener != null)
            internetChangeListener.onInternetChanged();
    }
}

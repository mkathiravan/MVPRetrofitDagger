package net.abaqus.mygeotracking.deviceagent.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.bgthread.HeartBeatMonitorService;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryTable;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HBTask;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HeartBeat;
import net.abaqus.mygeotracking.deviceagent.notes.UploadNotesTask;

import java.sql.Timestamp;
import java.util.Calendar;

public class InternetConnectionReceiver extends BroadcastReceiver {
    
    
    private State mState;
    private NetworkInfo mNetworkInfo;
    private NetworkInfo mOtherNetworkInfo;
    
    @Override
    public void onReceive(Context context, Intent intent) {
        System.gc();
	 String action = intent.getAction().toString();
	 SharedPreferences sh_prefs = context.getSharedPreferences(MDACons.PREFS, 0);
	 SharedPreferences.Editor sh_prefs_edit = sh_prefs.edit();
	 
	 boolean noConnectivity = intent.getBooleanExtra(ConnectivityManager.EXTRA_NO_CONNECTIVITY, false);




        Timestamp storedDate = new Timestamp(sh_prefs.getLong(
                MDACons.CUSTOMER_LAST_UPDATED_TIME, -1));

        Timestamp recentDate = new Timestamp(Calendar.getInstance().getTime().getTime());
        if (storedDate.before(recentDate)
                || storedDate.equals(-1)) {
            //DO_I_NEED_TO_UPDATE_CUS_DETAILS = true;
        }
        SharedPreferences.Editor prefs_edit = sh_prefs.edit();
        prefs_edit.putLong(MDACons.CUSTOMER_LAST_UPDATED_TIME, Calendar.getInstance().getTime().getTime());
        prefs_edit.commit();

        if(storedDate.compareTo(recentDate) > 2){


            if (noConnectivity) {
                mState = State.NOT_CONNECTED;
            } else {
                mState = State.CONNECTED;
            }
            if (mState == State.CONNECTED){
                //DebugLog.debug(TAG,("INTERNET_CONNECTION_LOG", "Connected called"+" HB Status : "+sh_prefs.getBoolean(MDACons.HB_SENT_STATUS, true));
                if (!sh_prefs.getBoolean(MDACons.HB_SENT_STATUS, true)) {
                    new HBTask(context).execute();
                    sh_prefs_edit.putBoolean(MDACons.HB_SENT_STATUS, true);
                    sh_prefs_edit.commit();
                }
                if (sh_prefs.getBoolean(MDACons.HOS_QUEUE_AVAILABLE, true)) {
                    new HOSPushTask(context).execute();
                    sh_prefs_edit.putBoolean(MDACons.HOS_QUEUE_AVAILABLE, false);
                    sh_prefs_edit.commit();
                }

                Cursor notesCursor = getNotesEntries(context);
                if(notesCursor != null)
                    if(notesCursor.getCount() > 0)
                        new UploadNotesTask(context).execute();
                notesCursor.close();
            }

            if (!action.equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
                //DebugLog.debug(TAG,("INTERNET_CONNECTION_LOG", "onReceived() called with " + mState.toString() + " and " + intent);
                return;
            }

        }


     }






    private Cursor getNotesEntries(Context mContext) {
        String[] projection = {
                NotesEntryTable.NOTES_ENTRY_XML, NotesEntryTable.COLUMN_ID};
        Cursor cursor = mContext.getContentResolver().query(Uri.parse(NotesEntryContentProvider.CONTENT_URI.toString()), projection, null, null,
                null);

        return cursor;
    }

    public enum State {
        UNKNOWN,

        /** This state is returned if there is connectivity to any network **/
        CONNECTED,
        /**
         * This state is returned if there is no connectivity to any network. This is set
         * to true under two circumstances:
         * <ul>
         * <li>When connectivity is lost to one network, and there is no other available
         * network to attempt to switch to.</li>
         * <li>When connectivity is lost to one network, and the attempt to switch to
         * another network fails.</li>
         */
        NOT_CONNECTED
    }
  } 
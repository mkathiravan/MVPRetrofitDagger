package net.abaqus.mygeotracking.deviceagent.sixgill;

import com.sixgill.protobuf.Ingress;

public interface LocationCall {

    public void getLocationValue(Ingress.Location location);
}

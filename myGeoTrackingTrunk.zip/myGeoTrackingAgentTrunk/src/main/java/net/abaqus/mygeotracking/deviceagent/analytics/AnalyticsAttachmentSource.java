package net.abaqus.mygeotracking.deviceagent.analytics;

public class AnalyticsAttachmentSource {

public static final String SOURCE_NOTES_SCREEN = "Notes Screen";
public static final String SOURCE_HOS_SCREEN = "HOS Screen";

}

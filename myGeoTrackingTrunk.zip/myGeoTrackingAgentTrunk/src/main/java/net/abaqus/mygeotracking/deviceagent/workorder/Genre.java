package net.abaqus.mygeotracking.deviceagent.workorder;




import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;

import java.util.List;

public class Genre extends ExpandableGroup<WorkOrderData> {

    String workOrderId;

    int position;

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }



    public void setWorkOrderId(String workOrderId) {
        this.workOrderId = workOrderId;
    }


    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    String startTime;

    public String getJobSite() {
        return jobSite;
    }

    public void setJobSite(String jobSite) {
        this.jobSite = jobSite;
    }

    String jobSite;

    public String getWorkOrderNumber() {
        return workOrderNumber;
    }

    public void setWorkOrderNumber(String workOrderNumber) {
        this.workOrderNumber = workOrderNumber;
    }

    String workOrderNumber;

    public String getWorkOrderId()
    {
        return workOrderId;
    }



    public Genre(String title, int position, String workOrderId, String workOrderNumber, String startTime, String jobsite,List<WorkOrderData> items) {
        super(title, items);
        this.position = position;
        this.workOrderId=workOrderId;
        this.workOrderNumber=workOrderNumber;
        this.startTime = startTime;
        this.jobSite = jobsite;

    }
}

package net.abaqus.mygeotracking.deviceagent.sixgill;


import android.app.Activity;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;

import com.activeandroid.query.Delete;
import com.activeandroid.query.Select;
import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;

import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiClient;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiInterface;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LocationTrackService extends JobService {
    private static final String TAG = LocationTrackService.class.getSimpleName();
    private List<ProviderInfoTable> providerInfoTableList;
    private SharedPreferences.Editor sh_prefs_edit;


    @Override
    public boolean onStartJob(JobParameters job) {
        DebugLog.debug("Started job!", "Should be recurring - Location Track Service");

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {

                setInfoData();
            }
        });


        return false;
    }


    public List<ProviderInfoTable> getInfoData() {
        return new Select().from(ProviderInfoTable.class).execute();
    }

    public void setInfoData() {

        providerInfoTableList = getInfoData();
        retrivevalues(providerInfoTableList);
    }

    public void retrivevalues(List<ProviderInfoTable> providerInfoTableList) {
        Log.d(TAG,"RETRIEVECALL ");

        try
        {
           // final ProviderModel provider = new ProviderModel();
            Log.d(TAG,"PROSIZE "+providerInfoTableList.size());

            for (int index = 0; index < providerInfoTableList.size(); index++)
            {
                final ProviderModel provider = new ProviderModel();
                provider.setProvider(providerInfoTableList.get(index).getProvider());
                provider.setRegionCode(providerInfoTableList.get(index).getRegionCode());
                provider.setRegionCountry(providerInfoTableList.get(index).getRegionCountry());
                provider.setStatusCode(providerInfoTableList.get(index).getStatusCode());
                provider.setStatusMessage(providerInfoTableList.get(index).getStatusMsg());
                provider.setLocateMethod(providerInfoTableList.get(index).getLocateMethod());
                provider.setNationalNumber(providerInfoTableList.get(index).getNationalNumber());
                provider.setCoOrdinateFormat(providerInfoTableList.get(index).getCoordinateFormat());
                provider.setCountryCode(providerInfoTableList.get(index).getCountryCode());
                provider.setDeviceId(providerInfoTableList.get(index).getDeviceID());
                provider.setLocateTime(providerInfoTableList.get(index).getLocateTime());

                Log.d(TAG,"TIMEDETAILSOFVBIEW "+providerInfoTableList.get(index).getLocateTime());
                GeoModel geo = new GeoModel();

                geo.setAccuracy(providerInfoTableList.get(index).getAccuracy());
                geo.setAltitude(0);
                geo.setDirection("");
                geo.setLatitude(providerInfoTableList.get(index).getLatitude());
                geo.setLongitude(providerInfoTableList.get(index).getLongitude());
                provider.setGeo(geo);

                PropertyModel property = new PropertyModel();

                property.setManufacturer(providerInfoTableList.get(index).getManufacturer());
                property.setModel(providerInfoTableList.get(index).getModel());
                property.setOs(providerInfoTableList.get(index).getOs());
                property.setOsVersion(providerInfoTableList.get(index).getOs_version());
                property.setSensors(providerInfoTableList.get(index).getSensors());
                property.setSoftwareVersion(providerInfoTableList.get(index).getSoftware_version());
                property.setType(providerInfoTableList.get(index).getType());
                provider.setProperty(property);

                DeviceModel device = new DeviceModel();

                device.setMethod(providerInfoTableList.get(index).getMethod());
                device.setSpeed(providerInfoTableList.get(index).getSpeed());
                device.setMovementDetected(providerInfoTableList.get(index).getMovementDetected());
                device.setBatteryLevel(0);
                device.setBatteryLife(providerInfoTableList.get(index).getBattery_life());
                device.setCharging(providerInfoTableList.get(index).isCharging());
                provider.setDevice(device);

                AddressModel address = new AddressModel();
                Geocoder geocoder;
                List<Address> addresses;
                geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());

                try {

                    String street_address,city,state,country,postalCode,full_address,knownName,locationName,countryCode = null;

                    addresses = geocoder.getFromLocation(providerInfoTableList.get(index).getLatitude(), providerInfoTableList.get(index).getLongitude(), 1);
                    full_address = addresses.get(0).getAddressLine(0);
                    Log.wtf(TAG,"ADDRED "+address + "SAMODRE "+addresses);
                    street_address = addresses.get(0).getFeatureName() +" " +addresses.get(0).getThoroughfare();
                    city = addresses.get(0).getLocality();
                    state = addresses.get(0).getAdminArea();
                    country = addresses.get(0).getCountryName();

                    if(addresses.get(0).getPostalCode() == null || addresses.get(0).getPostalCode().isEmpty())
                    {
                        postalCode = "0";
                    }
                    else
                    {
                        postalCode = addresses.get(0).getPostalCode();
                    }
                    knownName = addresses.get(0).getFeatureName();
                    countryCode = addresses.get(0).getCountryCode();
                    Double lat = addresses.get(0).getLatitude();
                    Double lang = addresses.get(0).getLongitude();

                    address.setSetStreetAddress(street_address);
                    address.setCity(city);
                    address.setState(state);
                    address.setPostalCode(postalCode);
                    address.setCountry(country);
                    address.setAddress(full_address);
                    provider.setAddress(address);

                }catch (Exception e)
                {
                    Log.wtf(TAG,"SAMException ");
                    e.printStackTrace();
                }





                AsyncTask.execute(new Runnable() {
                    @Override
                    public void run() {

                        load_tracking_data(provider);


                    }

                });

        }



        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }


    public void load_tracking_data(final ProviderModel provider) {

        Log.d(TAG,"TRACKINGAPICALLED ");
        final String locate_time = provider.getLocateTime();
        final ApiInterface requestInterface = ApiClient.getProductionClient();

        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(MDACons.PREFS, 0);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(MDACons.SIXGILL_POSTING_EVENT_TIME, locate_time);
        editor.commit();

        Call<Void> call = requestInterface.loadLocationInfo(provider);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                // If the response code is 200 we are showing the data
                if (response.code() == 200) {
                    new Delete().from(ProviderInfoTable.class).where("locateTime = ?",locate_time).execute();

                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.wtf(TAG,"EROE "+t.getMessage());

            }
        });

    }


    @Override
    public boolean onStopJob(JobParameters job) {
        DebugLog.debug("Stopped job!", "Should be recurring - Location Track Service");
        return false;
    }



}

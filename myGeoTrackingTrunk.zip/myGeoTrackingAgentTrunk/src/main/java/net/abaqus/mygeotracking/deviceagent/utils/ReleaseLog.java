package net.abaqus.mygeotracking.deviceagent.utils;

import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.BuildConfig;

/**
 * Created by Karthikraj Duraisamy on 27/10/17.
 */

public class ReleaseLog {

    /**
     * Prints given tag and text as debug log, even in release builds.
     * @param tag - Tag to be set for logs
     * @param text - Log message
     */
    public static void debug(String tag, String text) {
            Log.d(tag, text);
    }

    /**
     * Prints given tag and text as warning log, even in release builds.
     * @param tag - Tag to be set for logs
     * @param text - Log message
     */
    public static void warn(String tag, String text) {
            Log.w(tag, text);
    }

    /**
     * Prints given tag and text as error log, even in release builds.
     * @param tag - Tag to be set for logs
     * @param text - Log message
     */
    public static void error(String tag, String text) {
            Log.e(tag, text);
    }

    /**
     * Prints given tag, message, and exception as error log, even in release builds.
     * @param tag - Tag to be set for logs
     * @param msg - Log message
     * @param ex  - Exception to be logged
     */
    public static void error(String tag, String msg, Throwable ex) {
            Log.e(tag, msg, ex);
    }

    /**
     * Prints given tag and exception as error log, even in release builds.
     * @param tag - Tag to be set for logs
     * @param ex  - Exception to be logged
     */
    public static void error(String tag, Throwable ex) {
            error(tag, "", ex);
    }
}

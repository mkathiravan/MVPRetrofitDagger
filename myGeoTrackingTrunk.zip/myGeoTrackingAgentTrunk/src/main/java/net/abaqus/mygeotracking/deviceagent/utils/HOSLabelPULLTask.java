package net.abaqus.mygeotracking.deviceagent.utils;


import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;
import android.util.Xml;
import android.widget.Toast;

import com.facebook.network.connectionclass.DeviceBandwidthSampler;

import net.abaqus.mygeotracking.deviceagent.data.HOSLabelsTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSLabelseContentProvider;
import net.abaqus.mygeotracking.deviceagent.hos.HOSActivity;

import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlSerializer;

import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class HOSLabelPULLTask extends AsyncTask<String, Void, Boolean> {
	//**FIELDS**//
	private static final String TAG = HOSLabelPULLTask.class.getSimpleName();

	public static String eror_message_to_Show = "";
	private Context mContext;
	private SharedPreferences prefs;
	ProgressDialog m_ProgressDialog;
	private SharedPreferences.Editor edit_prefs;
	SAXParserFactory spf = null; 
	SAXParser sp = null;
	boolean dontShowProgress = false;
	/* Get the XMLReader of the SAXParser we created. */ 
	XMLReader xr = null;
	/* Create a new ContentHandler and apply it to the XML-Reader*/ 
	HOSLabelPullXmlHandler hosLabelPULLXMLHandler=null;
	Handler pullFinishHandler;
	
	
	
	public HOSLabelPULLTask(Context con) {
		this.mContext = con;
		this.prefs = con.getSharedPreferences(MDACons.PREFS, 0);
		this.edit_prefs = prefs.edit();
		this.m_ProgressDialog = new ProgressDialog(con);
		/* 
         * Prepare the SAX Parser
         * Assign the XMLHandler
         */
        hosLabelPULLXMLHandler=new HOSLabelPullXmlHandler();
		Log.d(getClass().getSimpleName(), getClass().getSimpleName());
	     
	}
	
	
	public HOSLabelPULLTask(Context con, boolean canShowProgressDialog) {
	this.mContext = con;
	this.prefs = con.getSharedPreferences(MDACons.PREFS, 0);
	this.edit_prefs = prefs.edit();
	dontShowProgress = canShowProgressDialog;
	
	/* 
   * Prepare the SAX Parser
   * Assign the XMLHandler
   */
 
        hosLabelPULLXMLHandler=new HOSLabelPullXmlHandler();
     
}
	
	protected void onPreExecute() {
		// Clear old data from database
		// Clear Show HOS Menu from Shared Preferences
	/*if(!dontShowProgress){
	    	m_ProgressDialog.setCancelable(false);
		m_ProgressDialog = ProgressDialog.show(mContext, "Progressing", "Refreshing..." , true);
	}
		DebugLog.debug(TAG,("REQUEST","getHOSStages onPreExecute");*/
		DeviceBandwidthSampler.getInstance().startSampling();

	}
	
		
	protected void onPostExecute(Boolean success) {


		DeviceBandwidthSampler.getInstance().stopSampling();

		DebugLog.debug(TAG, "REQUEST" + "getHOSStages onPostExecute");
			
		HOSLabelPULLTask.eror_message_to_Show = "";
		if (!hosLabelPULLXMLHandler.error_occured){
			if(hosLabelPULLXMLHandler.getLabelsList().size() > 0) {
				this.mContext.getContentResolver().delete(HOSLabelseContentProvider.CONTENT_URI, null, null);
				this.edit_prefs.putBoolean(MDACons.HOS_SHOW_MENU, true);
				this.edit_prefs.commit();
			}

		    for (int i = 0; i < hosLabelPULLXMLHandler.getLabelsList().size(); i++) {
				ContentValues initialValues = new ContentValues();
				initialValues.put(HOSLabelsTable.HOS_LABEL,
				hosLabelPULLXMLHandler.getLabelsList().get(i)
					.getLabel());
				initialValues.put(HOSLabelsTable.HOS_LABEL_VALUE,
				hosLabelPULLXMLHandler.getLabelsList().get(i)
					.getValue());
				initialValues.put(HOSLabelsTable.HOS_SMS_COMMAND,
				hosLabelPULLXMLHandler.getLabelsList().get(i)
					.getSmsCommand());

				Log.d(TAG,"SOSSTARTE "+hosLabelPULLXMLHandler.getLabelsList().get(i)
						.getSmsCommand() + "LABLE LOG"+hosLabelPULLXMLHandler.getLabelsList().get(i)
						.getLabel());

				if(!hosLabelPULLXMLHandler.getLabelsList().get(i).getLabel().trim().isEmpty())
				{
					this.mContext.getContentResolver().insert(
							HOSLabelseContentProvider.CONTENT_URI, initialValues);
				}

			DebugLog.debug(TAG, hosLabelPULLXMLHandler.getLabelsList().get(i)
				.getLabel());
			DebugLog.debug(TAG, hosLabelPULLXMLHandler.getLabelsList().get(i)
				.getValue());
			DebugLog.debug(TAG, "success");
		    }
		}
		
		else{
			DebugLog.debug(TAG, "error");
			this.edit_prefs.putBoolean(MDACons.HOS_SHOW_MENU, false);
			this.edit_prefs.commit();
			
			if (hosLabelPULLXMLHandler.getErrorMSG().contains("Can not find a account for the Device with"))
			{
				HOSLabelPULLTask.eror_message_to_Show = hosLabelPULLXMLHandler.getErrorMSG();
				//Toast.makeText(mContext.getApplicationContext(), hosLabelPULLXMLHandler.getErrorMSG(), Toast.LENGTH_LONG).show();
			}
			else if (hosLabelPULLXMLHandler.getErrorMSG().contains("Multiple account for the Device")){
				//Toast.makeText(mContext.getApplicationContext(), hosLabelPULLXMLHandler.getErrorMSG(), Toast.LENGTH_LONG).show();
				HOSLabelPULLTask.eror_message_to_Show = hosLabelPULLXMLHandler.getErrorMSG();
			}
		}
			//Read the error and react based on that
			//If the error says no HOS For this device then add no HOS in Shared Preferences
			//If any other error messages being caught , react based on that
		/*if (this != null && !dontShowProgress)
			if(m_ProgressDialog.isShowing())
			m_ProgressDialog.dismiss();*/
		
		if ((mContext).getClass().equals(HOSActivity.class)){
			DebugLog.debug(TAG, "YEs it is");
			if (pullFinishHandler != null) {
				pullFinishHandler.sendMessage(pullFinishHandler
						.obtainMessage(101108));
			}
		}
	}
	
	protected Boolean doInBackground(String... urls) {


		if(prefs.getString(MDACons.DEVICE_NUMBER, "").isEmpty())
			return false;


		DebugLog.debug(TAG, "REQUEST" + MDACons.SERVER_URL+"getHOSStages");
		ConnectionManager cm = new ConnectionManager();
		cm.setupHttpPost(MDACons.SERVER_URL+"getHOSStages");
		cm.setHttpHeader("Content-Type", "application/xml");
		XmlSerializer serializer = Xml.newSerializer();
		StringWriter writer = new StringWriter();
		try{   
		serializer.setOutput(writer);
        	serializer.startDocument("UTF-8", true);
        	serializer.startTag(null, "MGTRequest");
        	serializer.startTag(null, "Device");
        	serializer.startTag(null, "DeviceID");
                serializer.text(prefs.getString(MDACons.DEVICE_NUMBER, ""));
                serializer.endTag(null,"DeviceID");
                serializer.startTag(null, "UUID");
                serializer.text(prefs.getString(MDACons.DEVICE_GUID, ""));
                serializer.endTag(null,"UUID");
        	     
        	String versionName = "";
                String bundleid = "";
        		try {
        			bundleid = mContext.getPackageManager()
        					.getPackageInfo(mContext.getPackageName(), 0).packageName;
        			versionName =mContext.getPackageManager()
        					.getPackageInfo(mContext.getPackageName(), 0).versionName;
    		} catch (NameNotFoundException e) {
    			e.printStackTrace();
    		}
	    
	    serializer.startTag(null, "AgentVersion");
	    serializer.text(versionName);
	    serializer.endTag(null,"AgentVersion");
	    
	    serializer.startTag(null, "BundleID");
	    serializer.text(bundleid);
	    serializer.endTag(null,"BundleID");
	    
	    serializer.startTag(null, "Platform");
	    serializer.text("Android");
	    serializer.endTag(null,"Platform");
        
            serializer.endTag(null,"Device");
            serializer.endTag(null,"MGTRequest");
            serializer.endDocument();
		}catch (Exception e) {
		    //new SendExceptionLogToServerTask(mContext).execute(e.toString());
		}
        HttpEntity en = null;
		try {
			en = new StringEntity(writer.toString());
		} catch (UnsupportedEncodingException e2) {
			e2.printStackTrace();
		}
    	try {
			Log.i("REQUEST",EntityUtils.toString(en));
		} catch (Exception e1) {
			e1.printStackTrace();
		} 
		cm.setHttpPostEntity(en);
		
		
		try {
			InputSource m_is =  cm.makeRequestGetResponse(); 
			
			
			
			spf = SAXParserFactory.newInstance(); 
		        sp = spf.newSAXParser(); 
		
		        /* Get the XMLReader of the SAXParser we created. */ 
		        xr = sp.getXMLReader(); 
			xr.setContentHandler(hosLabelPULLXMLHandler);
			xr.parse(m_is);
			
			
		}catch (Exception e)
		{
		    //new SendExceptionLogToServerTask(mContext).execute(e.toString());
		}
		return true;
	}

	public static String error_message = "";
	public class HOSLabelPullXmlHandler extends DefaultHandler{
		
		private boolean in_GTSResponseTag = false;
		private boolean in_Comment = false;
		private boolean in_HOS_STAGE = false;
		private boolean in_HOS_STAGE_NAME = false;
		private boolean in_HOS_STAGE_ID = false;
		private boolean in_HOS_STAGE_SMS_COMMAND = false;
		private boolean in_HOS_GROUP_ID = false;


		
		public ArrayList<HOSLabels> HOSLabelsList = new ArrayList<HOSLabels>();
		private HOSLabels hosLabelsObject;
		
		public boolean error_occured = false;
		// =========================================================== 
	    // Methods 
	    // =========================================================== 
		
		public String getErrorMSG(){
			return error_message;
		}
		
		public ArrayList<HOSLabels> getLabelsList(){
			return HOSLabelsList;
		}
		
		@Override 
	    public void startDocument() throws SAXException { 
			HOSLabelsList.clear();
	        hosLabelsObject = new HOSLabels();
	    } 

	    @Override 
	    public void endDocument() throws SAXException { 
	         // Nothing to do 
	    }
	    
	    public void startElement(String namespaceURI, String localName, 
	              String qName, Attributes atts) throws SAXException { 
	    	
	    	if (localName.equals("MGTResponse")) { 
	    		edit_prefs.putString(MDACons.HOS_GROUP_ID, "");
				edit_prefs.commit();
	            this.in_GTSResponseTag = true;
	            if(atts.getValue("result").equalsIgnoreCase("error"))
	            {
	            	error_occured = true;
	            } else {
					edit_prefs.putBoolean(MDACons.MGT_CONFIGURATION_STATUS, true);
					edit_prefs.apply();
				}
	            
	            
	            
	       }else if (localName.equals("HOS")) { 
	            this.in_HOS_GROUP_ID = true; 
	            edit_prefs.putString(MDACons.HOS_GROUP_ID, atts.getValue("GroupID"));
				edit_prefs.commit();

				edit_prefs.putBoolean(MDACons.SOS_STAGE_PRESENT, false);
				edit_prefs.commit();

			} else if (localName.equals("Comment")) {
	            this.in_Comment = true; 
	       } else if (localName.equals("HOSStage")) {
	           this.in_HOS_STAGE = true; 
	      } else if (localName.equals("StageName")) {
	           this.in_HOS_STAGE_NAME = true; 
	      } else if (localName.equals("StageID")) {
	           this.in_HOS_STAGE_ID = true; 
	      } else if (localName.equals("SMSCommand")) {
	           this.in_HOS_STAGE_SMS_COMMAND = true;
	      }
	    	
	       
	    } /* startELement */
/*		<formURL><![CDATA[http://192.168.1.16:8080/track/htmlform]]></formURL>
		<formID><![CDATA[ad050f80-4587-4073-b19e-b35e0fe8b0a2]]></formID>
		<Token><![CDATA[004ae438-f120-4d01-a9fa-172e9525c94d]]></Token>*/
	    @Override 
	    public void endElement(String namespaceURI, String localName, String qName) 
	              throws SAXException { 
	    	if (localName.equals("MGTResponse")) { 
	            this.in_GTSResponseTag = false;
	       }else if (localName.equals("Comment")) { 
	            this.in_Comment = false; 
	       }


	       
	       else if (localName.equals("HOSStage")) { 
	           this.in_HOS_STAGE = false;

				if(hosLabelsObject.getValue().equals("7") && !hosLabelsObject.getLabel().trim().isEmpty())
				{
					SharedPreferences sharedPreferences = mContext.getSharedPreferences(MDACons.PREFS, 0);
					SharedPreferences.Editor editor = sharedPreferences.edit();
					editor.putBoolean(MDACons.SOS_STAGE_PRESENT, true);
					editor.commit();
				}
	           HOSLabelsList.add(hosLabelsObject);
	    	   hosLabelsObject = new HOSLabels();
	      }else if (localName.equals("HOS GroupID")) { 
	            this.in_HOS_GROUP_ID = false; 
	       }else if (localName.equals("StageName")) { 
	           this.in_HOS_STAGE_NAME = false; 
	      }else if (localName.equals("StageID")) { 
	           this.in_HOS_STAGE_ID = false; 
	      }else if (localName.equals("SMSCommand")) {
				this.in_HOS_STAGE_SMS_COMMAND = false;
			}
	       
	    } 

	    @Override 
	   public void characters(char ch[], int start, int length) { 
	    	if (in_GTSResponseTag && in_Comment )
	    	{
	    		if (error_occured)
	    		error_message = new String(ch,start,length);
	    		
	    	}else if (in_GTSResponseTag && in_HOS_GROUP_ID && !in_HOS_STAGE) { 
	    		
		      }else if (in_GTSResponseTag && in_HOS_STAGE && in_HOS_STAGE_NAME) { 
		          hosLabelsObject.setLabel(new String(ch,start,length));
		      }else if (in_GTSResponseTag && in_HOS_STAGE && in_HOS_STAGE_ID) { 
		    	  hosLabelsObject.setValue(new String(ch,start,length)); 
		      }else if (in_GTSResponseTag && in_HOS_STAGE_SMS_COMMAND) {
		    	  hosLabelsObject.setSmsCommand(new String(ch,start,length));
		      }
	    	
	    }/* characters*/
	}
	
	class HOSLabels {

		
		public String getLabel() {
			return label;
		}

		public void setLabel(String labelName) {
			this.label = labelName;
		}

		public String getValue() {
			return value;
		}

		public void setValue(String labelValue) {

			this.value = labelValue;
		}

		public String getSmsCommand() {
			return smsCommand;
		}

		public void setSmsCommand(String smsCommand) {
			this.smsCommand = smsCommand;
		}

		public HOSLabels() {
			super();
			this.label = "";
			this.value = "";
			this.smsCommand = "";
		}
		
		private String label;
		private String value;
		private String smsCommand;
	}

	public void setPullTaskHandler(Handler pullLabelsHandler) {
		this.pullFinishHandler = pullLabelsHandler;
		
	}


	
}

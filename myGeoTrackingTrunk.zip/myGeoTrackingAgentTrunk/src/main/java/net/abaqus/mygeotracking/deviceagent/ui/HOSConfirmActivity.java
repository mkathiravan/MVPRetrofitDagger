package net.abaqus.mygeotracking.deviceagent.ui;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatDelegate;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.fragments.HOSConfirmFragment;
import net.abaqus.mygeotracking.deviceagent.notes.Attachments;
import net.abaqus.mygeotracking.deviceagent.notes.ImageAttachment;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import org.apache.http.util.EncodingUtils;

import java.util.ArrayList;

/**
 * Created by bm on 22/10/15.
 */
public class HOSConfirmActivity extends FragmentActivity{

    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    TextView hosStageNameText;
    Button cancelButton, submitButton;
    HOSConfirmFragment hosConfirmFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hos_confirm);

        hosConfirmFragment = (HOSConfirmFragment)
                getSupportFragmentManager().findFragmentById(R.id.confirmation_fragment);

        hosStageNameText = (TextView) findViewById(R.id.tvHOSStageConfirm);
        hosStageNameText.setText("Please confirm: "+getIntent().getStringExtra("stage"));

        cancelButton = (Button) findViewById(R.id.btnHOSConfirmCancel);
        submitButton = (Button) findViewById(R.id.btnHOSConfirmSubmit);

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(Activity.RESULT_CANCELED);
                finish();
            }
        });
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
                Intent i = hosConfirmFragment.getResultValues();
                ArrayList<ImageAttachment> ATTACHMENT_BLOCK = i.getParcelableArrayListExtra("attach");

                String QR_RESULT_TEXT = i.getStringExtra("scan").toString();
                String TYPED_MESSAGE = i.getStringExtra("message").toString();
                String FORM_RESULT = i.getStringExtra("form").toString();
                String FORM_UID = i.getStringExtra("fdUID").toString();
                if (sh_prefs.getBoolean(MDACons.IS_NOTES_MANDATORY, false)) {

                    if (FORM_RESULT.length() > 0 ||TYPED_MESSAGE.length() > 0 || ATTACHMENT_BLOCK.size() > 0 || QR_RESULT_TEXT.length() > 0) {
                        setResult(Activity.RESULT_OK, i);
                        finish();
                    } else {
                        Toast.makeText(HOSConfirmActivity.this, "Please enter notes to proceed!", Toast.LENGTH_LONG).show();
                    }
                } else {
                    setResult(Activity.RESULT_OK, i);
                    finish();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {

        if(hosConfirmFragment.isClosable()) {
            setResult(RESULT_CANCELED);
            super.onBackPressed();
        } else {
            showWarningOnBackPress();
        }
    }

    private void showWarningOnBackPress() {
        new MaterialDialog.Builder(HOSConfirmActivity.this)
                .title(R.string.title_warning_backbtn_press)
                .content(R.string.msg_warning_backbtn_press_notes_compose)
                .positiveText(R.string.action_discard)
                .negativeText(R.string.action_stay)
                .autoDismiss(true)
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        setResult(Activity.RESULT_CANCELED);
                        finish();
                    }
                })
                .show();
    }
}

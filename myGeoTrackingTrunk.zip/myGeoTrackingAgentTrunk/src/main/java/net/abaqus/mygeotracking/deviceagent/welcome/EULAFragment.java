package net.abaqus.mygeotracking.deviceagent.welcome;

/**
 * Created by bm on 1/1/16.
 */

import android.app.AlertDialog;
import android.app.Notification;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.Snackbar;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiClient;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiInterface;
import net.abaqus.mygeotracking.deviceagent.bgthread.RegistrationTaskMGT;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HeartBeat;
import net.abaqus.mygeotracking.deviceagent.heartbeat.TriggerSource;
import net.abaqus.mygeotracking.deviceagent.listeners.TaskCompleteListener;
import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.sixgill.RegistrationToken;
import net.abaqus.mygeotracking.deviceagent.sixgill.TokenModel;
import net.abaqus.mygeotracking.deviceagent.ui.SetIdentitiesActivity;
import net.abaqus.mygeotracking.deviceagent.utils.AppSettingsUtils;
import net.abaqus.mygeotracking.deviceagent.utils.HOSPullCalls;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;

import android.support.design.widget.TextInputEditText;

import com.crashlytics.android.Crashlytics;
import com.sixgill.sync.sdk.Reach;
import com.sixgill.sync.sdk.ReachCallback;
import com.sixgill.sync.sdk.ReachConfig;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * The EULA fragment in the welcome screen.
 */
public class EULAFragment extends WelcomeFragment implements WelcomeActivity.WelcomeActivityContent, TaskCompleteListener {
    private static final String TAG = EULAFragment.class.toString();

    StringBuffer loadedStringBuffer = new StringBuffer();

    public static ProgressDialog pDialog;
    public String errorMsg;
    private String CONS_PROCESSING = "Processing...";
    private String CONS_SETTING_PHONE_NUMBER = "Setting phone number value...";
    private String CONS_INSTALLED_SUCCESSFULLY = "You have successfully installed and activated the myGeoTracking agent.";
    private String CONS_REGISTER_FAILED = "Registration failed. Please try again.";
    private String CONS_LATER_MESSAGE = "You can register your phone number under Settings at anytime.";

    AlertDialog.Builder builder;
    private SharedPreferences prefs;


    @Override
    public boolean shouldDisplay(Context context) {
        return !AppSettingsUtils.isEulaAccepted(context);
    }

    @Override
    protected View.OnClickListener getPositiveListener() {
        return new WelcomeFragmentOnClickListener(mActivity) {
            @Override
            public void onClick(View v) {
                // Ensure we don't run this fragment again
                Log.d(TAG, "Marking Eula flag.");
                if(AppSettingsUtils.isCheckboxAccepted(mActivity)) {
                    TextInputEditText phonenumberET = (TextInputEditText) mActivity.findViewById(R.id.etPhoneNumberWelcome);
                    TextInputEditText callingCodeEt = (TextInputEditText) mActivity.findViewById(R.id.etCallingCodeWelcome);
                    String callingCode = callingCodeEt.getText().toString().replaceFirst("^0+(?!$)", "");
                    if (callingCode.length() <= 0 || callingCode.equals("0")) {
                        callingCode = "1";
                    }
                    if (phonenumberET.getText().length() >= 3) {
                        registerDeviceNumber(callingCode, phonenumberET.getText().toString(), v);
                    } else {
                        Snackbar.make(v, "Please enter valid device number.", Snackbar.LENGTH_SHORT).show();
                    }

                } else {
                    Snackbar.make(v, "Please accept Terms and Conditions.", Snackbar.LENGTH_SHORT).show();
                }


            }
        };
    }

    @Override
    protected CompoundButton.OnCheckedChangeListener getTCCheckedListener() {
        return new WelcomeFragmentOnCheckListener(mActivity) {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.d(TAG, "Marking Eula flag.");
                AppSettingsUtils.markCheckboxAccepted(mActivity, isChecked);
                //onChecked();
            }
        };
    }

    @Override
    protected View.OnClickListener getNegativeListener() {
        return new WelcomeFragmentOnClickListener(mActivity) {
            @Override
            public void onClick(View v) {
                // Ensure we don't run this fragment again
                Log.d(TAG, "Need to accept Tos.");
                doFinish();
            }
        };
    }

    @Override
    protected String getPositiveText() {
        Log.d(TAG, "Getting Accept string.");
        return getResourceString(R.string.button_register);
    }

    @Override
    protected String getNegativeText() {
        Log.d(TAG, "Getting Decline string.");
        //return getResourceString(R.string.decline);
        return "";
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        loadedStringBuffer = loadEulaText();
        // Inflate the layout for this fragment.
        return inflater.inflate(R.layout.welcome_eula_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        PackageInfo versionInfo = getPackageInfo();
        String title = mActivity.getString(R.string.app_name) + " v"+ versionInfo.versionName;
        TextView titleTextview = (TextView) getView().findViewById(R.id.tvEulaTitle);
        titleTextview.setText(title);
        TextView bodyTextview = (TextView) getView().findViewById(R.id.tvEulaBody);
        bodyTextview.setText(loadedStringBuffer);



        pDialog = null;
        SharedPreferences mda_prefs = mActivity.getSharedPreferences(
                MDACons.PREFS, 0);
        SharedPreferences.Editor prefs_edit = mda_prefs.edit();
        prefs_edit.putBoolean(MDACons.LOCATION_ENABLE_DISABLE, true);
        prefs_edit.putBoolean(MDACons.AUTO_RELAUNCH_ENABLED_STATUS, true);
        prefs_edit.commit();
    }

    private StringBuffer loadEulaText() {
        BufferedReader br = null;
        StringBuffer messageToShowEula = new StringBuffer();
        try {
            br = new BufferedReader(new InputStreamReader(mActivity.getAssets().open("eula.txt")));
            String temp;
            while ((temp = br.readLine()) != null)
                messageToShowEula.append(temp + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                br.close(); // stop reading
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return messageToShowEula;
    }

    private PackageInfo getPackageInfo() {
        PackageInfo pi = null;
        try {
            pi = mActivity.getPackageManager().getPackageInfo(mActivity.getPackageName(), PackageManager.GET_ACTIVITIES);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return pi;
    }


    // Do the Initialization of the Reach SDK
    public void doInitialize(String device_number) {

        Log.d(TAG,"DRIVDRENIUNE ");
        Log.d(TAG,"DEviceNumbe "+device_number);


        ReachConfig config = new ReachConfig();

        //custom notification builder for sticky notification
        config.setStickyNotificationTitle("MyGeoTracking");
        config.setStickyNotificationBody("myGeoTracking is using GPS information");
        config.setStickyNotificationIcon(R.drawable.notification);
        config.setNotificationIcon(R.drawable.notification);

        Map<String, String> aliases = new HashMap<>();
        aliases.put("phone", device_number);
        config.setAliases(aliases);




        config.setIngressURL("https://sense-ingress-api.sixgill.com");
        config.setSendEvents(false);


        //custom notification builder for sticky notification
//        config.setStickyNotificationTitle("MyGeoTracking");
//        config.setStickyNotificationBody("myGeoTracking is using GPS information");
//        config.setStickyNotificationIcon(R.drawable.notification_icon);
//
//        // custom notification builder for any notification
//        config.setNotificationIcon(R.drawable.notification_icon);
        // pass this config object to initWithAPIKey call





        Reach.initWithAPIKey(getActivity(), "66c0d9f139d55c134825d38881", config, new ReachCallback() {
            @Override
            public void onReachSuccess() {
                Log.wtf(TAG,"Success Reach Initialization");
                Reach.enable(getActivity());
                getSixgillToken();
                setDeviceValue();
                HeartBeat heartBeat = HeartBeat.getInstance();
                heartBeat.justOneBeat(getActivity(), TriggerSource.APP_LAUNCHED);
                heartBeat.startBeating(getActivity());



            }

            @Override
            public void onReachFailure(String s) {
                Log.wtf(TAG,"FAILIED Reach Initialization ");
                Crashlytics.log("Failed Reach Initialization with reason: " + s);
                Crashlytics.logException(new SDKRegistrationFailureException("Failed Initializing With SDK Partner"));
                //Toast.makeText(getActivity(), "Failed to register the SDK", Toast.LENGTH_LONG).show();

            }
        });


    }

    public void getSixgillToken() {

        RegistrationToken registrationToken = new RegistrationToken();
        registrationToken.setEmail("badari@abaq.us");
        registrationToken.setPassword("Bman1547$#");


        final ApiInterface requestInterface = ApiClient.getCallSixgill();
        //TODO: Need to remove hardcoded date and device number
        Call<TokenModel> call = requestInterface.getLoginInfo(registrationToken);
        Log.d(TAG, "REQIESERCALL " + call.request());
        call.enqueue(new Callback<TokenModel>() {
            @Override
            public void onResponse(Call<TokenModel> call, Response<TokenModel> response) {
                Log.d(TAG, "GETTOKENRES " + response);
                // If the response code is 200 we are showing the data
                if (response.code() == 200) {

                    myGeoTrackingDevieAgentApplication.SIXGILL_AUTH_TOKEN = response.body().getToken();
                    Log.d(TAG, "GETTOKEN " + myGeoTrackingDevieAgentApplication.SIXGILL_AUTH_TOKEN);

                    //get_cadence_apiCall(response.body().getToken());


                }
            }

            @Override
            public void onFailure(Call<TokenModel> call, Throwable t) {
                //  progress.hide();
                Log.d(TAG, "ERRRESITD " + t.getMessage());
            }
        });



    }




    private void registerDeviceNumber(String callingCode, String deviceNumber, View v) {
        if (NetworkConnectionInfo
                .isOnline(mActivity)) {
            View view = mActivity.getCurrentFocus();
            if(view != null) {
                InputMethodManager imm = (InputMethodManager) mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }


            pDialog = new ProgressDialog(mActivity);
            pDialog.setTitle(CONS_PROCESSING);
            pDialog.setMessage(CONS_SETTING_PHONE_NUMBER);
            pDialog.setCancelable(true);
            pDialog.show();


            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O)
            {
                Log.d(TAG,"SIXGILLINITIALIZE ");
                doInitialize(deviceNumber);
            }
            else
            {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        setDeviceValue();
                    }
                },10000);

            }


            String devNumber = "+" + callingCode + deviceNumber;
            AppSettingsUtils.markEulaAccepted(mActivity, true);
            SharedPreferences mda_prefs = mActivity.getSharedPreferences(
                    MDACons.PREFS, 0);

            devNumber = devNumber.replace("+", "");
/*
            if(mda_prefs.getString(MDACons.DEVICE_NUMBER, "").length() == 10 && deviceNumber.length() > 10)
                deviceNumber = deviceNumber.substring(deviceNumber.length() - 10);
*/

            if (callingCode.equals("1") && devNumber.length() > 10)
                devNumber = devNumber.substring(devNumber.length() - 10, devNumber.length());


            SharedPreferences.Editor prefs_edit = mda_prefs.edit();
            prefs_edit.putString(MDACons.DEVICE_NUMBER, devNumber.replace("+", ""));
            prefs_edit.putString(MDACons.DEVICE_NUMBER_COUNTRY_CALLING_CODE, callingCode);
            prefs_edit.commit();
        }else{
            Snackbar.make(v, getString(R.string.msg_internet_disabled_please_try_later), Snackbar.LENGTH_SHORT).show();
        }

    }

    public void setDeviceValue() {

        Log.d(TAG,"SETDECICENUMBER ");
        new RegistrationTaskMGT(this, getActivity()).execute();


    }

    // * Used to update the UI. *//*
    Handler thisHandler = new Handler() {
        public void handleMessage(Message msg) {
            if (msg.what == 10) {
                SharedPreferences mda_prefs = mActivity.getSharedPreferences(
                        MDACons.PREFS, 0);
                SharedPreferences.Editor prefs_edit = mda_prefs.edit();
                prefs_edit.putString(MDACons.HB_INTERVAL_OLD, "");
                prefs_edit.putBoolean(MDACons.LOCATION_ENABLE_DISABLE, true);
                prefs_edit.commit();
                new HOSPullCalls().makeHOSInitializeCallsWithResult(mActivity, EULAFragment.this);
            } else if (msg.what == 20) {
                String reason = (String) msg.obj;
                errorMsg = "";
                errorMsg = reason;
                //Toast.makeText(mActivity, errorMsg, Toast.LENGTH_SHORT).show();
                //if (this != null)
                //showDialog(101);
            }
        }
    };



    @Override
    public void onTaskCompleted(boolean success) {
        Log.d(TAG,"SUCCESSRESPONZE " + success);
        if (pDialog.isShowing())
            pDialog.dismiss();

        if (this != null && success) {

            onRegisterSuccessAlert();


        }else{
            Toast.makeText(mActivity, CONS_REGISTER_FAILED, Toast.LENGTH_SHORT).show();
        }

    }



    class SDKRegistrationFailureException extends Exception{
        SDKRegistrationFailureException(String s){
            super(s);
        }
    }

    void onRegisterSuccessAlert() {
        prefs = mActivity.getSharedPreferences(MDACons.PREFS, 0);
        String deviceId = prefs.getString(MDACons.DEVICE_NUMBER, "");
        String accountInfo = prefs.getString(MDACons.ACCOUNT_TYPE_NAME, "");
        Log.d(TAG, "agent devide id" + accountInfo);
        builder = new AlertDialog.Builder(getActivity(), R.style.CustomDialogTheme);
        // create a dialog with AlertDialog builder
        builder.setTitle("Success");
        builder.setIcon(R.drawable.success_icon);
        if (accountInfo.equalsIgnoreCase("webdemolead") || accountInfo.equalsIgnoreCase("nil") || accountInfo.equalsIgnoreCase("null") || accountInfo.equalsIgnoreCase("")) {
            String some_string = "\n <br> Your device using  " + "<b>" + deviceId + "</b>" + " is successfully registered.\n ";
            builder.setMessage(Html.fromHtml(some_string));
        } else {
            String some_string = "account " + "<b>" + accountInfo + "</b>";
            String device_info = "\n <br>Your device using " + "<b>" + deviceId + "</b>" + " is successfully registered with " + "account " + "<b>" + accountInfo + "</b>";
            builder.setMessage(Html.fromHtml(device_info));
        }
        builder.setPositiveButton("Proceed",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // dismiss alert dialog, update preferences
                        Intent intent = new Intent(mActivity, MDAMainActivity.class);
                        startActivity(intent);
                        mActivity.finish();
                        Log.d("myTag", "positive button clicked");
                        dialog.dismiss();
                    }
                });
//        String negativeText = getString(android.R.string.cancel);
//        builder.setNegativeButton("Cancel",
//                new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        // dismiss dialog, start counter again
//
//                        dialog.dismiss();
//                        Log.d("myTACCOUNT_TYPE_NAMEag", "negative button clicked");
//                    }
//                });
        AlertDialog alertDialog = builder.create();
// display dialog
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.setCancelable(false);
        alertDialog.show();
    }



    }

package net.abaqus.mygeotracking.deviceagent.heartbeat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.provider.Settings;
import android.support.v4.content.ContextCompat;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobRelationContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobRelationsTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSEntryTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSLabelsTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSLabelseContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryTable;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

import java.util.List;

public class HeartBeatMetaData {
	private static String LOG_TAG = "Gps Listener MGT";
	Context con = null;
	
	IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
	Intent batteryStatus;
	
	public HeartBeatMetaData(Context con) {
		this.con = con;
		batteryStatus = con.registerReceiver(null, ifilter);
		DebugLog.debug("getGPSAvailability() : "+getGPSAvailability());
		DebugLog.debug("getGpsStatus() : "+getGpsStatus());
		DebugLog.debug("checkMobileNetworkAvailable() : "+checkMobileNetworkAvailable());
		DebugLog.debug("getWifiAvailability() : "+getWifiAvailability());
		DebugLog.debug("getBatteryChargingState() : "+ getBatteryChargingState());
		DebugLog.debug("getHowBatteryIsCharging() : "+ getHowBatteryIsCharging());
		DebugLog.debug("getBatteryLevel() : "+ getBatteryLevel());
		DebugLog.debug("getCustomersCount() : "+ getCustomersCount());
		DebugLog.debug("getTaskssCount() : "+ getTaskssCount());
		DebugLog.debug("getRelationsCount() : "+ getRelationsCount());
		DebugLog.debug("getHOSEntryCount() : "+ getHOSEntryCount());
		DebugLog.debug("getHOSLabelsCount() : "+ getHOSLabelsCount());
		DebugLog.debug("getNotesEntryCount() : "+ getNotesEntryCount());

	}
	
	public boolean getGPSAvailability(){
		PackageManager pm = con.getPackageManager();
		return pm.hasSystemFeature(PackageManager.FEATURE_LOCATION_GPS);
	}
	

	
		
	public boolean getGpsStatus(){
		LocationManager mlocManager = (LocationManager) con.getSystemService(Context.LOCATION_SERVICE);;
	      return mlocManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
	}
	
	public boolean getLocationPermission(){
		if (ContextCompat.checkSelfPermission(con,
				Manifest.permission.ACCESS_FINE_LOCATION)
				!= PackageManager.PERMISSION_GRANTED) {
				return false;
		}else{
			return true;
		}
	}

	public boolean getStoragePermission(){
		if (ContextCompat.checkSelfPermission(con,
				Manifest.permission.WRITE_EXTERNAL_STORAGE)
				!= PackageManager.PERMISSION_GRANTED) {
				return false;
		}else{
			return true;
		}
	}

	public boolean getCameraPermission(){
		if (ContextCompat.checkSelfPermission(con,
				Manifest.permission.CAMERA)
				!= PackageManager.PERMISSION_GRANTED) {
				return false;
		}else{
			return true;
		}
	}


	public String checkMobileNetworkAvailable(){
      String isMobileNetworkAvailable = "OFF";
      ConnectivityManager cm = (ConnectivityManager) con.getSystemService(Context.CONNECTIVITY_SERVICE);
      NetworkInfo[] networks = cm.getAllNetworkInfo();
      for(int i=0;i<networks.length;i++){
       if(networks[i].getType() == ConnectivityManager.TYPE_MOBILE){
             if(networks[i].isAvailable()){
               isMobileNetworkAvailable = "ON";
             }
           }
       }

   return isMobileNetworkAvailable;
}
	
	
	public String getWifiAvailability(){
	WifiManager wifi = (WifiManager)con.getSystemService(Context.WIFI_SERVICE);
	if (wifi.isWifiEnabled()){
		ConnectivityManager cm = (ConnectivityManager) con.getSystemService(Context.CONNECTIVITY_SERVICE);
		    NetworkInfo wifiNetwork = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		    if (wifiNetwork != null && wifiNetwork.isConnected())
		    {
		        return "CONNECTED";
		    }else
			  return "DISCONNECTED";
		}else{
			return "OFF";
		}
	}
	
	
	
	public boolean getBatteryChargingState() {

		// Are we charging / charged?
		try {
			int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
			boolean isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
					status == BatteryManager.BATTERY_STATUS_FULL;
			return isCharging;
		} catch(Exception e) {
			return false;
		}
	}
	
	
	public float getBatteryLevel() {

		try {
			int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
			int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

			float batteryPct = level / (float) scale;
			DebugLog.debug(batteryPct + "");

			return ((float) level / (float) scale) * 100.0f;
		} catch(Exception e) {
			return 0.0f;
		}
	}
	
	public String getHowBatteryIsCharging() {

		String result = "UNKNOWN";

		// How are we charging?
		try {
			int chargePlug = batteryStatus.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
			boolean usbCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_USB;
			boolean acCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_AC;

			if (usbCharge) {
				result = "USB";
			} else if (acCharge) {
				result = "AC";
			}
			return result;
		} catch(Exception e) {
			return result;
		}
	}

	public String getCustomersCount(){
		String returnString = "";

		String[] projection_cus = { HOSCustomerANDJobTable.COLUMN_ID,
				HOSCustomerANDJobTable.HOS_CJ_NAME,
				HOSCustomerANDJobTable.HOS_CJ_SITE_ID,
				HOSCustomerANDJobTable.HOS_CJ_WHICH};


		Cursor mCursor = con.getContentResolver().query(Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI.toString()), projection_cus, HOSCustomerANDJobTable.HOS_CJ_WHICH+" LIKE ?", new String[]{"Customer"},
					HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");

		if(mCursor != null)
			returnString = mCursor.getCount()+"";

		mCursor.close();
		return returnString;
	}

	public String getTaskssCount(){
		String returnString = "";

		String[] projection = { HOSCustomerANDJobTable.COLUMN_ID,
				HOSCustomerANDJobTable.HOS_CJ_NAME,
				HOSCustomerANDJobTable.HOS_CJ_WHICH};

		Cursor mCursor = con.getContentResolver().query(Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI.toString()), projection, HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ?", new String[]{"Job"},
				HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");
		if(mCursor != null)
			returnString = mCursor.getCount()+"";

		mCursor.close();
		return returnString;
	}

	public String getRelationsCount(){

		int i = 0;
		String[] projection = {
				HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID, HOSCustomerANDJobRelationsTable.HOS_CJ_REL_CUS_ID};
		Cursor cursor = con.getContentResolver().query(Uri.parse(HOSCustomerANDJobRelationContentProvider.CONTENT_URI.toString()), projection, HOSCustomerANDJobRelationsTable.HOS_CJ_REL_CUS_ID + " LIKE ?", new String[]{""},
				null);
		String resultString = "";
		if (cursor != null) {
			while (cursor.moveToNext()) {
				try {
					resultString  = resultString + cursor.getString(cursor
							.getColumnIndexOrThrow(HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID));
					i++;
				} catch (Exception e) {
				}
			}
		}
		cursor.close();
		return resultString;
	}

	public String getHOSEntryCount(){
		String returnString = "";
		String[] projection =
				{ HOSEntryTable.HOS_ENTRY_XML, HOSEntryTable.COLUMN_ID, HOSEntryTable.HOS_ENTRY_NO_OF_TRIES};

		Cursor cursor = con.getContentResolver().query(
				Uri.parse(HOSEntryContentProvider.CONTENT_URI.toString()),
				projection, null, null, null);
		if(cursor != null)
			returnString = cursor.getCount()+"";

		cursor.close();
		return returnString;
	}

	public String getHOSLabelsCount(){
		String returnString = "";
		String[] projection =
				{ HOSLabelsTable.COLUMN_ID,
						HOSLabelsTable.HOS_LABEL,
				};

		Cursor cursor = con.getContentResolver().query(
				Uri.parse(HOSLabelseContentProvider.CONTENT_URI.toString()),
				projection, null, null, null);
		if(cursor != null)
			returnString = cursor.getCount()+"";

		cursor.close();
		return returnString;
	}

	public String getNotesEntryCount(){
		String returnString = "";
		String[] projection = {
					NotesEntryTable.NOTES_ENTRY_XML, NotesEntryTable.COLUMN_ID};
		Cursor cursor = con.getContentResolver().query(Uri.parse(NotesEntryContentProvider.CONTENT_URI.toString()), projection, null, null,
					null);
		if(cursor != null)
			returnString = cursor.getCount()+"";

		cursor.close();
		return returnString;
	}


	public static boolean isMockSettingsON(Context context) {
		// returns true if mock location enabled, false if not enabled.
		if (Settings.Secure.getString(context.getContentResolver(),
				Settings.Secure.ALLOW_MOCK_LOCATION).equals("0"))
			return false;
		else
			return true;
	}



	public static int noOfMockPermissionApps(Context context) {

		int count = 0;

		PackageManager pm = context.getPackageManager();
		List<ApplicationInfo> packages =
				pm.getInstalledApplications(PackageManager.GET_META_DATA);

		for (ApplicationInfo applicationInfo : packages) {
			try {
				PackageInfo packageInfo = pm.getPackageInfo(applicationInfo.packageName,
						PackageManager.GET_PERMISSIONS);

				// Get Permissions
				String[] requestedPermissions = packageInfo.requestedPermissions;

				if (requestedPermissions != null) {
					for (int i = 0; i < requestedPermissions.length; i++) {
						if (requestedPermissions[i]
								.equals("android.permission.ACCESS_MOCK_LOCATION")
								&& !applicationInfo.packageName.equals(context.getPackageName())) {
							count++;
						}
					}
				}
			} catch (PackageManager.NameNotFoundException e) {
				Log.e("Got exception ","");
			}
		}

		return count;
	}

}
package net.abaqus.mygeotracking.deviceagent.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

public class AboutActivity extends AppCompatActivity implements OnClickListener {

	private static final String TAG = AboutActivity.class.getSimpleName();
	private TextView version_text, email_text, web_link_textview, enduserlicenseText,terms_text,copy_righttext;

	Animation mAnimation;
	MDAEula mdula;
	public String CONS_FOR_ADDITIONAL_INFO = "<font color=#000>For additional Information: </font><font color=#1589FF><u>info@abaq.us</u></font>";
	public String CONS_WEB_APPLICATION = "<font size=12 color=#000000><b><p>Web Application: </b></p></font></br><font size=12 color=#000000><b><p><a href=http://www.mygeotracking.com>www.mygeotracking.com</a></p></font>";
	public String CONS_TERMS_APPLICATION = "<font size=12 color=#000000><b><p>Terms of Use: </b></p></font></br><font size=12 color=#000000><b><p><a href=https://www.mygeotracking.com/mGT-Terms>www.mygeotracking.com/mGT-Terms</a></p></font>";
	public String CONS_INFO_ABAQUS_MAIL_ID = "info@abaq.us";
	public String CONS_TYPE_PLAIN_TEXT = "plain/text";
	public String CONS_COPY_RIGHT = "Copyright (c) 2018 Abaqus Inc.";

	
	/*private View selected_item = null;
    private int offset_x = 0;
    private int offset_y = 0;*/
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about_layout);

		mdula = new MDAEula(AboutActivity.this);

		mAnimation = AnimationUtils.loadAnimation(this,
				R.anim.dropfromdownanimation);

		version_text = (TextView) findViewById(R.id.appversionname);
		email_text = (TextView) findViewById(R.id.mail_abaqus);
		terms_text = (TextView)findViewById(R.id.terms_text);
		web_link_textview = (TextView) findViewById(R.id.web_link_text);
		enduserlicenseText = (TextView) findViewById(R.id.enduserlicenselink);
		copy_righttext = (TextView)findViewById(R.id.copy_right);

		String versionName = "", versionCode = "";
		try {
			versionName = AboutActivity.this.getPackageManager()
					.getPackageInfo(AboutActivity.this.getPackageName(), 0).versionName;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}

		version_text.setText(getString(R.string.app_name) + " " + versionName + "(170)");
		email_text.setText(Html.fromHtml(CONS_FOR_ADDITIONAL_INFO));
		email_text.setOnClickListener(this);
        terms_text.setMovementMethod(LinkMovementMethod.getInstance());
		terms_text.setText(Html.fromHtml(CONS_TERMS_APPLICATION));
		web_link_textview.setMovementMethod(LinkMovementMethod.getInstance());
		web_link_textview.setText(Html.fromHtml(CONS_WEB_APPLICATION));
		copy_righttext.setText(Html.fromHtml(CONS_COPY_RIGHT));
		//enduserlicenseText.setText(Html.fromHtml("<font size=12 color=#000000><b><p><a>End user license agreement</a></p></font>"));
		enduserlicenseText.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				mdula.show(true);
			}
		});
	}

	public void onClick(View v) {
		Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
		String aEmailList[] = { CONS_INFO_ABAQUS_MAIL_ID };
		emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, aEmailList);
		emailIntent.setType(CONS_TYPE_PLAIN_TEXT);
		startActivity(Intent.createChooser(emailIntent,
				MDACons.MSG_SEND_YOUR_EMAIL_IN));
	}


	@Override
	protected void onResume() {
		super.onResume();
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case android.R.id.home:
				finish();
				return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
	}
}
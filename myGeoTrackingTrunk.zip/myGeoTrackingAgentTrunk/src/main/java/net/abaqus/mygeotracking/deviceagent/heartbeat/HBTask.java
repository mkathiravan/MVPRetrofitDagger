package net.abaqus.mygeotracking.deviceagent.heartbeat;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;

import com.facebook.network.connectionclass.DeviceBandwidthSampler;

import net.abaqus.mygeotracking.deviceagent.MGTScheduleStatus;
import net.abaqus.mygeotracking.deviceagent.data.HeartBeatContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HeartBeatTable;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryTable;
import net.abaqus.mygeotracking.deviceagent.forms.FormsAPIPullJob;
import net.abaqus.mygeotracking.deviceagent.notes.UploadNotesTask;
import net.abaqus.mygeotracking.deviceagent.notification.NotificationCommands;
import net.abaqus.mygeotracking.deviceagent.notification.ShareRegistrationToken;
import net.abaqus.mygeotracking.deviceagent.utils.ConnectionManager;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.HOSCustomerIDJobIDPullTask;
import net.abaqus.mygeotracking.deviceagent.utils.HOSCustomerIDJobIDPullTask.CustomerJob;
import net.abaqus.mygeotracking.deviceagent.utils.HOSCustomerIDJobIDPullTask.HOSTagValues;
import net.abaqus.mygeotracking.deviceagent.utils.HOSPushTask;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;

import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlSerializer;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;


public class HBTask extends AsyncTask<String, Void, Boolean> {
	// **FIELDS**//

	private static final String TAG = HBTask.class.getSimpleName();


	private Context			mContext    = null;
	private SharedPreferences	prefs		= null;
	SAXParserFactory			spf		= null;
	SAXParser				sp		= null;
	/* Get the XMLReader of the SAXParser we created. */
	XMLReader				xr		= null;
	/* Create a new ContentHandler and apply it to the XML-Reader */
	HBXmlHandler			HBHandler	= null;
	String				HB_INTERVAL	= "";
	public static String	error_message	= "";


	public HBTask(Context con) {
		this.mContext = con;
		this.prefs = con.getSharedPreferences(MDACons.PREFS, 0);
		HBHandler = new HBXmlHandler();
	}

	protected void onPreExecute() {
		DeviceBandwidthSampler.getInstance().startSampling();
		DebugLog.debug(TAG, "onPreExecute HBTask");
		Cursor eCursor = getHBEntries();
		if (eCursor.getCount() > 0) {
			eCursor.moveToLast();
			if(Integer.parseInt(eCursor.getString(eCursor
					.getColumnIndexOrThrow(HeartBeatTable.HEARTBEAT_ENTRY_NO_OF_TRIES))) >= 5)
			this.mContext.getContentResolver().delete(HeartBeatContentProvider.CONTENT_URI, HeartBeatTable.COLUMN_ID + " = '" + eCursor.getString(eCursor
					.getColumnIndexOrThrow(HeartBeatTable.COLUMN_ID)) + "'", null);
		}
		eCursor.close();
	}

	protected void onPostExecute(Boolean success) {

		if (NetworkConnectionInfo.isOnline(mContext))
		try {
			DeviceBandwidthSampler.getInstance().stopSampling();
			MGTScheduleStatus.getInstance(mContext).comparTripTimes();
		}catch (Exception e){e.printStackTrace();}

		if (HBHandler.shouldIUpdateJob()) {
			new HOSCustomerIDJobIDPullTask(mContext, CustomerJob.JOB).execute();
		}

		if (HBHandler.shouldIUpdateCustomer()) {
			new HOSCustomerIDJobIDPullTask(mContext, CustomerJob.CUSTOMER)
					.execute();
		}
		if (HBHandler.shouldIUpdateForms()) {

			AsyncTask.execute(new Runnable() {
				@Override
				public void run() {
					new FormsAPIPullJob().load_form_data(mContext, null);
				}
			});
		}

		if (HBHandler.error_occured) {

			ContentValues initialValues = new ContentValues();
			Cursor eCursor = getHBEntries();
			if (eCursor.getCount() > 0) {
				eCursor.moveToLast();
				initialValues.put(HeartBeatTable.HEARTBEAT_ENTRY_NO_OF_TRIES, Integer.parseInt(eCursor.getString(eCursor
						.getColumnIndexOrThrow(HeartBeatTable.HEARTBEAT_ENTRY_NO_OF_TRIES)))+1);
				this.mContext.getContentResolver().update(HeartBeatContentProvider.CONTENT_URI, initialValues, HeartBeatTable.COLUMN_ID+" = '"+ eCursor.getString(eCursor
						.getColumnIndexOrThrow(HeartBeatTable.COLUMN_ID))+"'", null);
			}
			eCursor.close();

			if (HBHandler.getErrorMSG().contains(
					"Can not find a account for the Device with")) {
				//Toast.makeText(mContext.getApplicationContext(),
						//HBHandler.getErrorMSG(), Toast.LENGTH_LONG)
						//.show();
			}
			else if (HBHandler.getErrorMSG().contains(
					"Multiple account for the Device")) {
				//Toast.makeText(mContext.getApplicationContext(),
						//HBHandler.getErrorMSG(), Toast.LENGTH_LONG)
						//.show();
			}
		} else {
			Cursor eCursor = getHBEntries();
			if (eCursor.getCount() > 0){
				eCursor.moveToLast();
				this.mContext.getContentResolver().delete(HeartBeatContentProvider.CONTENT_URI, HeartBeatTable.COLUMN_ID+" = '"+ eCursor.getString(eCursor
						.getColumnIndexOrThrow(HeartBeatTable.COLUMN_ID))+"'" ,null);
			}
			eCursor.close();

			Cursor entryCursor = getHBEntries();
			if (entryCursor.getCount() > 0){

				new HBTask(this.mContext).execute();
			}
			entryCursor.close();
		}


		if (prefs.getBoolean(MDACons.HOS_QUEUE_AVAILABLE, true)) {
			new HOSPushTask(mContext).execute();
		}

		Cursor notesCursor = getNotesEntries();
		if(notesCursor != null)
			if(notesCursor.getCount() > 0)
				new UploadNotesTask(mContext).execute();
		notesCursor.close();
	}


    private Cursor getNotesEntries() {
		String[] projection = {
				NotesEntryTable.NOTES_ENTRY_XML, NotesEntryTable.COLUMN_ID};
		Cursor cursor = mContext.getContentResolver().query(Uri.parse(NotesEntryContentProvider.CONTENT_URI.toString()), projection, null, null,
				null);

		return cursor;
	}
	private Cursor getHBEntries() {
		DebugLog.debug(TAG, "getHBEntries HBTask");
		String[] projection = {
				HeartBeatTable.HEARTBEAT_ENTRY_XML, HeartBeatTable.COLUMN_ID, HeartBeatTable.HEARTBEAT_ENTRY_NO_OF_TRIES};
		Cursor cursor = mContext.getContentResolver().query(Uri.parse(HeartBeatContentProvider.CONTENT_URI.toString()), projection, null, null,
				null);
		DebugLog.debug(TAG, "getHBEntries HBTask Count : "+ cursor.getCount());
		return cursor;
	}

	private String getHBXMLEntry() {
		DebugLog.debug(TAG, "getHBXMLEntry HBTask");
		String returnString = "";
		String[] projection = {
				HeartBeatTable.HEARTBEAT_ENTRY_XML, HeartBeatTable.COLUMN_ID, HeartBeatTable.HEARTBEAT_ENTRY_NO_OF_TRIES};
		Cursor cursor = this.mContext.getContentResolver().query(Uri.parse(HeartBeatContentProvider.CONTENT_URI.toString()), projection, null, null,
				null);

		if (cursor != null && cursor.getCount() > 0) {
			cursor.moveToLast();
			returnString = cursor.getString(cursor
					.getColumnIndexOrThrow(HeartBeatTable.HEARTBEAT_ENTRY_XML));
		}
		DebugLog.debug(TAG, "getHBXMLEntry HBTask Entry : " + returnString);
		cursor.close();
		return returnString;
	}

	protected Boolean doInBackground(String... urls) {

		String heartBeatEntry = getHBXMLEntry();
		DebugLog.debug(TAG, MDACons.SERVER_URL + "heartbeat");
		ConnectionManager cm = new ConnectionManager();
		cm.setupHttpPost(MDACons.SERVER_URL + "heartbeat");
		cm.setHttpHeader("Content-Type", "application/xml");
		XmlSerializer serializer = Xml.newSerializer();
		/*StringWriter writer = new StringWriter();
			try {
				serializer.setOutput(writer);
				serializer.startDocument("UTF-8", true);
				serializer.startTag(null, "MGTRequest");
				generateXMLReqBlock(serializer);
				serializer.endTag(null, "MGTRequest");
				serializer.endDocument();
			}
			catch (Exception e) {}*/
		if(heartBeatEntry.length() <= 0)
			return false;
		HttpEntity en = null;
			try {
				en = new StringEntity(heartBeatEntry);
			}
			catch (UnsupportedEncodingException e2) {
				e2.printStackTrace();
			}
			try {
				DebugLog.debug(TAG, EntityUtils.toString(en));
			}
			catch (Exception e1) {
				e1.printStackTrace();
			}
		cm.setHttpPostEntity(en);
			try {
				InputSource m_is = cm.makeRequestGetResponse();
				spf = SAXParserFactory.newInstance();
				sp = spf.newSAXParser();
				xr = sp.getXMLReader();
				xr.setContentHandler(HBHandler);
				xr.parse(m_is);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		return true;
	}


	public class HBXmlHandler extends DefaultHandler {

		private boolean	in_GTSResponseTag				= false;
		private boolean	in_Comment					= false;
		private boolean	HEARTBEATINTERVAL				= false;
		private boolean	DO_I_NEED_TO_UPDATE_JOB_DETAILS	= false;
		private boolean	DO_I_NEED_TO_UPDATE_CUS_DETAILS	= false;
		private boolean DO_I_NEED_TO_UPDATE_FORMS_DETAILS = false;
		private boolean	TAG_JOB_SITE_TIME				= false;
		private boolean	TAG_CUSTOMER_TIME				= false;
		private boolean	TAG_FORMS_UPDATED_TIME				= false;
		private boolean TAG_START_TRIP_SECONDS           = false;
		private boolean TAG_END_TRIP_SECONDS             = false;
		private boolean	JOB_SITE_MANDATORY_TAG				= false;
		private boolean	CUSTOMER_MANDATORY_TAG				= false;
		private boolean	NOTES_MANDATORY_TAG				= false;
		private boolean	DEVICE_FREQ				= false;
		private boolean	DEVICE_LOCATE_START_TIME				= false;
		private boolean	DEVICE_LOCATE_END_TIME				= false;
		private boolean GCMIDSTATUS    = false;
		public boolean	error_occured				= false;


		public String getErrorMSG() {
			return error_message;
		}

		public boolean shouldIUpdateJob() {
			return DO_I_NEED_TO_UPDATE_JOB_DETAILS;
		}

		public boolean shouldIUpdateCustomer() {
			return DO_I_NEED_TO_UPDATE_CUS_DETAILS;
		}

		public boolean shouldIUpdateForms() {
			return DO_I_NEED_TO_UPDATE_FORMS_DETAILS;
		}

		@Override
		public void startDocument() throws SAXException {}

		@Override
		public void endDocument() throws SAXException {}

		public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {
			SharedPreferences sh_prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
			SharedPreferences.Editor sh_prefs_edit = sh_prefs.edit();
			if (localName.equals("MGTResponse")) {
				this.in_GTSResponseTag = true;
				if (atts.getValue("result").equalsIgnoreCase("error")) {
					error_occured = true;
					sh_prefs_edit.putBoolean(MDACons.HB_SENT_STATUS, false);
					sh_prefs_edit.commit();
				}
				else {
					sh_prefs_edit.putBoolean(MDACons.HB_SENT_STATUS, true);
					sh_prefs_edit.commit();
				}
			}
			else if (localName.equals("Comment")) {
				this.in_Comment = true;
			}
			else if (localName
					.equals(HOSTagValues.HOS_JOB_UPDATE_TIME_TAG_NAME)) {
				this.TAG_JOB_SITE_TIME = true;
			}
			else if (localName
					.equals(HOSTagValues.HOS_CUSTOMER_UPDATE_TIME_TAG_NAME)) {
				this.TAG_CUSTOMER_TIME = true;
			}
			else if (localName
					.equals("formsLastUpdateTime")) {
				this.TAG_FORMS_UPDATED_TIME = true;
			}
			else if (localName.equals("HeartbeatInterval")) {
				this.HEARTBEATINTERVAL = true;
			}else if (localName.equals("isTaskMandatory")) {
				this.JOB_SITE_MANDATORY_TAG = true;
			}
			else if (localName.equals("isCustomerMandatory")) {
				this.CUSTOMER_MANDATORY_TAG = true;
			}
			else if (localName.equals("isNotesMandatory")) {
				this.NOTES_MANDATORY_TAG = true;
			}else if (localName.equals("atFrequency")) {
				this.DEVICE_FREQ = true;
			}
			else if (localName.equals("tripStartTime")) {
				this.DEVICE_LOCATE_START_TIME = true;
			}
			else if (localName.equals("tripEndTime")) {
				this.DEVICE_LOCATE_END_TIME = true;
			}
			else if(localName.equals("tripStartSeconds"))
			{
				this.TAG_START_TRIP_SECONDS = true;
			}
			else if(localName.equals("tripEndSeconds"))
			{
				this.TAG_END_TRIP_SECONDS = true;
			}
			else if(localName.equals("GCMIdStatus"))
			{
				this.GCMIDSTATUS = true;
			}

		} /* startELement */

		@Override
		public void endElement(String namespaceURI, String localName,
				String qName) throws SAXException {
			if (localName.equals("MGTResponse")) {
				this.in_GTSResponseTag = false;
				// new HeartBeatAlarmManager(mContext);
			}
			else if (localName.equals("Comment")) {
				this.in_Comment = false;
			}
			else if (localName.equals("HeartbeatInterval")) {
				this.HEARTBEATINTERVAL = false;
			}
			else if (localName
					.equals(HOSTagValues.HOS_JOB_UPDATE_TIME_TAG_NAME)) {
				this.TAG_JOB_SITE_TIME = false;
			}
			else if (localName
					.equals(HOSTagValues.HOS_CUSTOMER_UPDATE_TIME_TAG_NAME)) {
				this.TAG_CUSTOMER_TIME = false;
			}else if (localName
					.equals("formsLastUpdateTime")) {
				this.TAG_FORMS_UPDATED_TIME = false;
			}else if (localName.equals("isTaskMandatory")) {
				this.JOB_SITE_MANDATORY_TAG = false;
			}
			else if (localName.equals("isCustomerMandatory")) {
				this.CUSTOMER_MANDATORY_TAG = false;
			}
			else if (localName.equals("isNotesMandatory")) {
				this.NOTES_MANDATORY_TAG = false;
			}else if (localName.equals("atFrequency")) {
				this.DEVICE_FREQ = false;
			}
			else if (localName.equals("tripStartTime")) {
				this.DEVICE_LOCATE_START_TIME = false;
			}
			else if (localName.equals("tripEndTime")) {
				this.DEVICE_LOCATE_END_TIME = false;
			}
			else if(localName.equals("tripStartSeconds"))
			{
				this.TAG_START_TRIP_SECONDS = false;
			}
			else if(localName.equals("tripEndSeconds"))
			{
				this.TAG_END_TRIP_SECONDS = false;
			}

			else if(localName.equals("GCMIdStatus"))
			{
				this.GCMIDSTATUS = false;
			}

		}

		@Override
		public void characters(char ch[], int start, int length) {
			if (in_GTSResponseTag && in_Comment) {
				if (error_occured) {
					error_message = new String(ch, start, length);
					//MDAMainActivity
						//	.pinOptinErrorCloseButtonPressedFromAsyncTask(error_message);

				}
				else
					error_message = "Optin PIN Sent to server Successfully.";
			}
			else if (in_GTSResponseTag && HEARTBEATINTERVAL) {
				HB_INTERVAL = new String(ch, start, length);
				SharedPreferences.Editor prefs_edit = prefs.edit();

				prefs_edit.putString(MDACons.HB_INTERVAL, HB_INTERVAL);
				prefs_edit.commit();
				DebugLog.debug(TAG,
						"Serevr Interval Response : "
								+ prefs.getString(
										MDACons.HB_INTERVAL, ""));
			}
			else if (in_GTSResponseTag && TAG_JOB_SITE_TIME) {
				Timestamp jobDateBefore = new Timestamp(prefs.getLong(
						MDACons.JOB_SITE_LAST_UPDATED_TIME, -1));
				Timestamp jobDateNow = new Timestamp(Long.valueOf(new String(
						ch, start, length)));
				if (jobDateBefore.before(jobDateNow)
						|| jobDateBefore.equals(-1)) {

					DO_I_NEED_TO_UPDATE_JOB_DETAILS = true;
				}
				DebugLog.debug(TAG,"Do i need to update job details "+ DO_I_NEED_TO_UPDATE_JOB_DETAILS);

				SharedPreferences.Editor prefs_edit = prefs.edit();
				prefs_edit.putLong(MDACons.JOB_SITE_LAST_UPDATED_TIME, Long.valueOf(new String(ch, start, length)));
				prefs_edit.commit();



			}
			else if (in_GTSResponseTag && TAG_CUSTOMER_TIME) {

				Timestamp cusDateBefore = new Timestamp(prefs.getLong(
						MDACons.CUSTOMER_LAST_UPDATED_TIME, -1));
				Timestamp cusDateNow = new Timestamp(Long.valueOf(new String(
						ch, start, length)));
				if (cusDateBefore.before(cusDateNow)
						|| cusDateBefore.equals(-1)) {
					DO_I_NEED_TO_UPDATE_CUS_DETAILS = true;
				}
				DebugLog.debug(TAG,"Do i need to update customer details "+ DO_I_NEED_TO_UPDATE_CUS_DETAILS);
				SharedPreferences.Editor prefs_edit = prefs.edit();
				prefs_edit.putLong(MDACons.CUSTOMER_LAST_UPDATED_TIME, Long.valueOf(new String(ch, start, length)));
				prefs_edit.commit();
			}else if (in_GTSResponseTag && TAG_FORMS_UPDATED_TIME) {

				Timestamp cusDateBefore = new Timestamp(prefs.getLong(
						MDACons.FORMS_LAST_UPDATED_TIME, -1));
				Timestamp cusDateNow = new Timestamp(Long.valueOf(new String(
						ch, start, length)));
				if (cusDateBefore.before(cusDateNow)
						|| cusDateBefore.equals(-1)) {
					DO_I_NEED_TO_UPDATE_FORMS_DETAILS = true;
				}
				DebugLog.debug(TAG,"Do i need to update forms details "+ DO_I_NEED_TO_UPDATE_FORMS_DETAILS);
				SharedPreferences.Editor prefs_edit = prefs.edit();
				prefs_edit.putLong(MDACons.FORMS_LAST_UPDATED_TIME, Long.valueOf(new String(ch, start, length)));
				prefs_edit.commit();
			}else if (in_GTSResponseTag && JOB_SITE_MANDATORY_TAG) {

				SharedPreferences.Editor prefs_edit = prefs.edit();
				prefs_edit.putBoolean(MDACons.IS_JOB_SITE_MANDATORY, Boolean.valueOf(new String(ch, start, length)));
				prefs_edit.commit();
			}else if (in_GTSResponseTag && CUSTOMER_MANDATORY_TAG) {

				SharedPreferences.Editor prefs_edit = prefs.edit();
				prefs_edit.putBoolean(MDACons.IS_CUSTOMER_MANDATORY, Boolean.valueOf(new String(ch, start, length)));
				prefs_edit.commit();
			}else if (in_GTSResponseTag && NOTES_MANDATORY_TAG) {

				SharedPreferences.Editor prefs_edit = prefs.edit();
				prefs_edit.putBoolean(MDACons.IS_NOTES_MANDATORY, Boolean.valueOf(new String(ch, start, length)));
				prefs_edit.commit();
			}else if (in_GTSResponseTag && DEVICE_FREQ) {

				SharedPreferences.Editor prefs_edit = prefs.edit();
				prefs_edit.putString(MDACons.DEVICE_LOCATE_FREQUENCY, new String(ch, start, length));

				// The following line is added to get the frequency from the response and set in the preference.
				prefs_edit.putString(MDACons.TRACKING_FREQUENCY,new String(ch, start, length));
				prefs_edit.commit();



			}
			else if(in_GTSResponseTag && TAG_START_TRIP_SECONDS)
			{
				SharedPreferences.Editor prefs_edit = prefs.edit();
				Log.d("START_TR ","START_TR " + new String(ch, start, length));
				prefs_edit.putLong(MDACons.TRIP_STARTS_SECONDS, Long.valueOf(new String(ch, start, length)));
				prefs_edit.commit();
			}
			else if(in_GTSResponseTag && TAG_END_TRIP_SECONDS)
			{
				SharedPreferences.Editor prefs_edit = prefs.edit();
				Log.d("END_TR ","END_TR " + new String(ch, start, length));
				prefs_edit.putLong(MDACons.TRIP_END_SECONDS, Long.valueOf(new String(ch, start, length)));
				prefs_edit.commit();
			}

			else if (in_GTSResponseTag && DEVICE_LOCATE_START_TIME) {
				SharedPreferences.Editor prefs_edit = prefs.edit();
				prefs_edit.putString(MDACons.DEVICE_TRIP_START_TIME, new String(ch, start, length));
				prefs_edit.commit();
			}else if (in_GTSResponseTag && DEVICE_LOCATE_END_TIME) {

				SharedPreferences.Editor prefs_edit = prefs.edit();
				prefs_edit.putString(MDACons.DEVICE_TRIP_END_TIME, new String(ch, start, length));
				prefs_edit.commit();
			}

			else if(in_GTSResponseTag && GCMIDSTATUS)
			{
				String gcmstatus = new String(ch, start, length);
				if(gcmstatus.equalsIgnoreCase("InActive"))
				{
					try {
						ShareRegistrationToken.sendRegistrationToServer(mContext);
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}

				}
			}

		}/* characters */
	}
}

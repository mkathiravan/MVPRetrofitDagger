package net.abaqus.mygeotracking.deviceagent.analytics;

public class AnalyticsCons {

    /*Image or Button clicked state*/
    public static final String ITEM_CLICKED = "ITEM_CLICKED";
    /*Particualar selected item subimtted*/
    public static final String ITEM_SUBMITTED = "ITEM_SUBMITTED";
    /*Particualar selected item subimisson successful*/
    public static final String ITEM_SUCCUESS = "ITEM_SUCCESS_AFTER_SUBMIT";

}

package net.abaqus.mygeotracking.deviceagent.home;

import com.google.gson.annotations.SerializedName;

class GeoModel {
    @SerializedName("altitude")
    private float altitude;

    @SerializedName("direction")
    private String direction;

    @SerializedName("accuracy")
    private float accuracy;

    @SerializedName("latitude")
    private float latitude;

    @SerializedName("longitude")
    private float longitude;



    public float getAltitude() {
        return altitude;
    }

    public void setAltitude(float altitude) {
        this.altitude = altitude;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public float getAccuracy() {
        return accuracy;
    }

    public void setAccuracy(float accuracy) {
        this.accuracy = accuracy;
    }

    public float getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public float getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }


}

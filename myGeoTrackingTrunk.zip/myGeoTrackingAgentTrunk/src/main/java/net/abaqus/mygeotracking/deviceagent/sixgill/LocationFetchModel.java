package net.abaqus.mygeotracking.deviceagent.sixgill;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class LocationFetchModel implements Parcelable{

    @SerializedName("altitude")
    private double altitude;

    @SerializedName("direction")
    private double direction;

    @SerializedName("accuracy")
    private float accuracy;

    @SerializedName("latitude")
    private double latitude;

    @SerializedName("longitude")
    private double longitude;

    @SerializedName("timestamp")
    private long timeStamp;

    protected LocationFetchModel(Parcel in) {
        altitude = in.readDouble();
        direction = in.readDouble();
        accuracy = in.readFloat();
        latitude = in.readDouble();
        longitude = in.readDouble();
        timeStamp = in.readLong();
    }

    public static final Creator<LocationFetchModel> CREATOR = new Creator<LocationFetchModel>() {
        @Override
        public LocationFetchModel createFromParcel(Parcel in) {
            return new LocationFetchModel(in);
        }

        @Override
        public LocationFetchModel[] newArray(int size) {
            return new LocationFetchModel[size];
        }
    };

    public LocationFetchModel() {
    }

    public double getAltitude() {
        return altitude;
    }

    public void setAltitude(double altitude) {
        this.altitude = altitude;
    }

    public double getDirection() {
        return direction;
    }

    public void setDirection(double direction) {
        this.direction = direction;
    }

    public float getAccuracy() {
        return accuracy;
    }

    public void setAccuracy(float accuracy) {
        this.accuracy = accuracy;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeDouble(altitude);
        dest.writeDouble(direction);
        dest.writeFloat(accuracy);
        dest.writeDouble(latitude);
        dest.writeDouble(longitude);
        dest.writeLong(timeStamp);
    }
}
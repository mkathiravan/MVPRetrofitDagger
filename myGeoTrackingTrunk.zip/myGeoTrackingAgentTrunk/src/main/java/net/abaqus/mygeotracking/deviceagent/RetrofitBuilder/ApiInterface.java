package net.abaqus.mygeotracking.deviceagent.RetrofitBuilder;


import net.abaqus.mygeotracking.deviceagent.hos.HOSHistoryResponse;
import net.abaqus.mygeotracking.deviceagent.sixgill.ProviderModel;
import net.abaqus.mygeotracking.deviceagent.sixgill.RegistrationToken;
import net.abaqus.mygeotracking.deviceagent.sixgill.TokenModel;
import net.abaqus.mygeotracking.deviceagent.workorder.WorkOrderReponse;


import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;


/**
 * Created by user on 22-06-2018.
 */

public interface ApiInterface {

    @GET("/track/mobile/v1/device/{deviceId}/hos")
    Call<HOSHistoryResponse> getHosHistory(@Path("deviceId") String deviceId, @Query("fromDate") String fromDate , @Query("toDate") String toDate , @Query("offset") String offset);


    @GET("/track/mobile/v1/device/{deviceId}/wo")
    Call<WorkOrderReponse> getWorkOrder(@Path("deviceId") String deviceId);


    @POST("v2/login")
    Call<TokenModel> getLoginInfo(@Body RegistrationToken registrationToken);

    @POST("tlpdcs/api/location")
    Call<Void> loadLocationInfo(@Body ProviderModel value);


    @POST("tlpdcs/api/location")
    Call<Void> sentLocationInfo(@Body net.abaqus.mygeotracking.deviceagent.home.ProviderModel value);



}

package net.abaqus.mygeotracking.deviceagent.sixgill;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;
import com.sixgill.protobuf.Ingress;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;

public class EventResponse {
    private static final String TAG = EventResponse.class.getSimpleName();
    Context context;
    SharedPreferences sh_prefs;
    private SharedPreferences.Editor edit_prefs;
    String device_number = "", country_code_phone = "";
    private static EventResponse evenResponse;
    InsertEventValues insertEventValues;
    RetriveEventValuesDb retriveEventValuesDb;
    long last_event_time;


    public static EventResponse getInstance(Context context) {
        if (evenResponse == null) {
            evenResponse = new EventResponse(context);
        }
        return evenResponse;
    }

    public EventResponse(Context context) {
        this.context = context;
        sh_prefs = context.getSharedPreferences(MDACons.PREFS, 0);
        edit_prefs = sh_prefs.edit();
        device_number = sh_prefs.getString(MDACons.DEVICE_NUMBER, "");
        final String callingCountryCode = sh_prefs.getString(MDACons.DEVICE_NUMBER_COUNTRY_CALLING_CODE, "");
        country_code_phone = "+" + callingCountryCode + device_number;
    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void eventDataResponse(final Ingress.Event event) {


        long time = event.getConfigurations().getCadence();
        Log.d(TAG,"CADENCESETTING "+time);
        edit_prefs.putString(MDACons.CADENCE_SETTING_VALUE, String.valueOf(time));
        edit_prefs.commit();



        // This following snippet for to insert the data based on the location event time

//        try {
//            last_event_time = Long.parseLong(sh_prefs.getString(MDACons.SIXGILL_LAST_LOCATION_EVENT_TIME,"0"));
//            if(event.getLocationsList() != null && event.getLocationsList().size() > 0)
//            {
//                Ingress.Location location = event.getLocations(event.getLocationsList().size() - 1);
//                long current_location_timeStamp = location.getTimestamp() /1000;
//
//                Log.d(TAG,"LASTEVNETIM "+last_event_time);
//                Log.d(TAG,"CURRENTTIMESTAMP "+ current_location_timeStamp + " LASTLOCATION "+last_event_time);
//
//                long last_location_event_time = last_event_time/1000;
//
//                if(current_location_timeStamp != last_location_event_time)
//                {
//
//                    Log.d(TAG,"Original value");
//                    insertEventValues = new InsertEventValues(context, event);
//                    insertEventValues.insert_data(event);
//
//
//                    if (NetworkConnectionInfo.isOnline(context)) {
//                        LocationTrack locationTrack = LocationTrack.getInstance();
//                        locationTrack.justTrack(context, TriggerSource.APP_LAUNCHED);
//                    }
//                }
//                else
//                {
//                    Log.d(TAG,"Duplicate event occured");
//                }
//
//            }
//            else
//            {
//                insertEventValues = new InsertEventValues(context, event);
//                insertEventValues.insert_data(event);
//
//
//                if (NetworkConnectionInfo.isOnline(context)) {
//                    LocationTrack locationTrack = LocationTrack.getInstance();
//                    locationTrack.justTrack(context, TriggerSource.APP_LAUNCHED);
//                }
//
//            }
//
//           // long current_timeStamp = event.getTimestamp() /10000;
//
//
//            // The following snippet is used for checking the condition if last location and current location should not be same time.
//
//
//
////            Log.d(TAG," LASTISDTIME "+last_location_event_time + " CURLSTIME "+ current_timeStamp + " BOLLFALG "+(current_timeStamp != last_location_event_time));
////
////            if(current_timeStamp != last_location_event_time)
////            {
////
////                Log.d(TAG,"Original value");
////                insertEventValues = new InsertEventValues(context, event);
////                insertEventValues.insert_data(event);
////
////
////                if (NetworkConnectionInfo.isOnline(context)) {
////                    LocationTrack locationTrack = LocationTrack.getInstance();
////                    locationTrack.justTrack(context, TriggerSource.APP_LAUNCHED);
////                }
////            }
////            else
////            {
////                Log.d(TAG,"Duplicate event occured");
////            }
//
//
//           //  The following snippet is ignore the duplicate event based on the cadence.
//
////            if((current_timeStamp/1000 - last_event_time/1000) > (cadence_value/1000))
////            {
////
////                insertEventValues = new InsertEventValues(context, event);
////                insertEventValues.insert_data(event);
////
////
////                if (NetworkConnectionInfo.isOnline(context)) {
////                    LocationTrack locationTrack = LocationTrack.getInstance();
////                    locationTrack.justTrack(context, TriggerSource.APP_LAUNCHED);
////                }
////
////
////           }
//
//
//        }
//        catch (Exception e)
//        {
//            e.printStackTrace();
//        }


        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {

                insertEventValues = new InsertEventValues(context, event);
                insertEventValues.insert_data(event);



            }

        });



        if (NetworkConnectionInfo.isOnline(context)) {

            retriveEventValuesDb = new RetriveEventValuesDb(context);
            //retriveEventValuesDb.read_data_fromDb();




        }






    }






}
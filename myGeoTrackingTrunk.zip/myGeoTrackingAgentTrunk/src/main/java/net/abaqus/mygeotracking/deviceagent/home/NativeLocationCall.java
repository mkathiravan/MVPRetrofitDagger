package net.abaqus.mygeotracking.deviceagent.home;

import android.location.Location;

public interface NativeLocationCall {

    public void getLocation(Location location);
}

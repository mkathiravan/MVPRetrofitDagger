package net.abaqus.mygeotracking.deviceagent.notes;

/**
 * Created by bm on 3/2/16.
 */
public class FormAttachment {

    private String postableData, fdUID;

    public FormAttachment(){
        this.postableData = "";
        this.fdUID = "";
    }


    public FormAttachment(String postableData, String fdUID){
        this.postableData = postableData;
        this.fdUID = fdUID;
    }

    public String getPostableData() {
        return postableData;
    }

    public void setPostableData(String postableData) {
        this.postableData = postableData;
    }

    public String getFdUID() {
        return fdUID;
    }

    public void setFdUID(String fdUID) {
        this.fdUID = fdUID;
    }
}

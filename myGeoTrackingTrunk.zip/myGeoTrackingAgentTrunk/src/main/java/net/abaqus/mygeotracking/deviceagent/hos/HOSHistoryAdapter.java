package net.abaqus.mygeotracking.deviceagent.hos;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import net.abaqus.mygeotracking.deviceagent.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by user on 22-06-2018.
 */

public class HOSHistoryAdapter extends RecyclerView.Adapter<HOSHistoryAdapter.MyViewHolder> {

    private static final String TAG = HOSHistoryAdapter.class.getSimpleName();

    Context context;
    List<HOSHistoryDetail> hoshistoryList;

    public HOSHistoryAdapter(Context context, List<HOSHistoryDetail> hoshistoryList) {
        this.context = context;
        this.hoshistoryList = hoshistoryList;
    }

    @Override
    public HOSHistoryAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.hos_history_adapter_item,parent,false);
        return new HOSHistoryAdapter.MyViewHolder(v);
    }


    public void updateDataSet(List<HOSHistoryDetail> hoshistoryList) {
        this.hoshistoryList = hoshistoryList;
    }


    @Override
    public void onBindViewHolder(HOSHistoryAdapter.MyViewHolder holder, final int position) {


        final HOSHistoryDetail hos_history_detail = hoshistoryList.get(position);
        //Preapre and display image status circle either blue or green
        if(position == 0) {
            holder.imageStatusCircleBlue.setVisibility(View.GONE);
        } else {
            holder.imageStatusCircleBlue.setVisibility(View.VISIBLE);
        }

        Log.d(TAG,"SERVIHRS "+hos_history_detail.getServiceHour());

        //Prepare and display Total hours
        String orginal_service_hour = hos_history_detail.getServiceHour();
        String hoursText = orginal_service_hour.substring(0, orginal_service_hour.indexOf(":"));
        String minsText = orginal_service_hour.substring(orginal_service_hour.indexOf(":") + 1, orginal_service_hour.length());

        if (Integer.parseInt(hoursText) == 0) {
            holder.stageHours.setText("Total hours: " + minsText + "min");
        } else {
            holder.stageHours.setText("Total hours: " + hoursText + "hrs " + minsText + "min");
        }


        //Prepare and display stage desc
        String original_Value = hos_history_detail.getStageDesc();
        String stageDesc = original_Value;

        //TODO: Review the logic of substring
        if(original_Value.contains("(") && original_Value.contains(")")) {

            stageDesc = original_Value.substring(0, original_Value.indexOf("("));
            String hrsValue = original_Value.substring(original_Value.indexOf("(") + 1, original_Value.indexOf(")"));
            String exactHoursValue = hrsValue.substring(0, hrsValue.indexOf(" "));
            if (exactHoursValue.equals(orginal_service_hour)) {
                stageDesc = stageDesc.substring(0, original_Value.indexOf("("));
            }
        }
        holder.stageDesc.setText(stageDesc+":");
        Log.d(TAG,"ADDRESSVALE "+hos_history_detail.getAddress());

        if(hos_history_detail.getAddress().isEmpty())
        {
            holder.addressLayout.setVisibility(View.GONE);
        }
        else
        {
            holder.addressLayout.setVisibility(View.VISIBLE);
            holder.address_desc.setText(hos_history_detail.getAddress());
        }



        //Prepare and display stage actual time
        Date todaysDate = new Date(hos_history_detail.getStageTime());
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd, hh:mm:ss");
        String dateAndTime = df.format(todaysDate);
        holder.stageTime.setText(dateAndTime);


        //Prepare and display sinceTime
        SimpleDateFormat inFormat = new SimpleDateFormat("hh:mm a");
        SimpleDateFormat onFormat = new SimpleDateFormat("yyyy-MM-dd");
        String sinceTime = inFormat.format(todaysDate);
        String onDate = onFormat.format(todaysDate);
        holder.sinceTimeText.setText(sinceTime + " on " + onDate);


        Log.d(TAG,"NOTESDEAT "+hos_history_detail.getTextNotes());

        String textNotes = hos_history_detail.getTextNotes();
        String scanNotes = "";

        Log.d(TAG,"TYENE "+textNotes + "SCN "+scanNotes);


        if(textNotes.isEmpty() && hos_history_detail.getScanNotes().isEmpty())
        {
            holder.notes_lable.setVisibility(View.GONE);
            holder.text_notes.setVisibility(View.GONE);

        }
        else
        {
            holder.notes_lable.setVisibility(View.VISIBLE);
            holder.text_notes.setVisibility(View.VISIBLE);

            if(hos_history_detail.getScanNotes().isEmpty())
            {
                holder.text_notes.setText(textNotes);
            }
            else
            {

                for(int index=0; index < hos_history_detail.getScanNotes().size(); index++)
                {
                    scanNotes = scanNotes + "Scan: " + hos_history_detail.getScanNotes().get(index).getQR() +"\n";
                    holder.text_notes.setText(textNotes + scanNotes);
                }


            }


            }


        }





    @Override
    public int getItemCount() {
        return hoshistoryList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder
    {

        @BindView(R.id.stage_desc)
        TextView stageDesc;
        @BindView(R.id.service_hours)
        TextView stageHours;
        @BindView(R.id.stage_time)
        TextView stageTime;
        @BindView(R.id.tvSinceValue)
        TextView sinceTimeText;
        @BindView(R.id.imageStatusCircleGreen)
        ImageView imageStatusCircleGreen;
        @BindView(R.id.imageStatusCircleBlue)
        ImageView imageStatusCircleBlue;
        @BindView(R.id.notes_view)
        TextView text_notes;
        @BindView(R.id.notes_label_view)
        TextView notes_lable;
        @BindView(R.id.address_desc)
        TextView address_desc;
        @BindView(R.id.address_layout)
        LinearLayout addressLayout;

        public MyViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}

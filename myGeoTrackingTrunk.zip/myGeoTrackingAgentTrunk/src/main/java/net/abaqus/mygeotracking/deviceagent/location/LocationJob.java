package net.abaqus.mygeotracking.deviceagent.location;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.Lifetime;
import com.firebase.jobdispatcher.RetryStrategy;
import com.firebase.jobdispatcher.Trigger;

import net.abaqus.mygeotracking.deviceagent.sixgill.TrackLocationService;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

import java.awt.font.TextAttribute;

public class LocationJob {

    private static LocationJob uniqueInstance;

    //private constructor.
    private LocationJob(){
        //Prevent form the reflection.
        if (uniqueInstance != null){
            throw new RuntimeException("Use getInstance() method to get the single instance of this class.");
        }
    }

    public static synchronized LocationJob getInstance() {
        if (uniqueInstance == null) {
            uniqueInstance = new LocationJob();
        }
        return uniqueInstance;
    }

    public void startReporting(Context applicationContext) {

        //Get the tracking interval information and start scheduling depending on that information.
        //Just to have a value for interval I am going with 5 minutes.
        int interval = 5;

        Bundle bundle = new Bundle();
        bundle.putString("triggerSource", "Schedule");

        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(applicationContext));
        Job myJob = dispatcher.newJobBuilder()
                .setService(LocationPushService.class)
                .setTag("location_job_tracking")
                .setExtras(bundle)
                .setRecurring(true)
                .setLifetime(Lifetime.FOREVER)
                .setTrigger(Trigger.executionWindow(5,interval*60))
                .setReplaceCurrent(true)
                .setRetryStrategy(RetryStrategy.DEFAULT_EXPONENTIAL)
                .build();
        dispatcher.schedule(myJob);
    }

    public void onDemandLocation(Context applicationContext, String source, String timeStamp) {
        DebugLog.debug("Started reporting: ", "with onDemand Location Request");

        Bundle bundle = new Bundle();
        bundle.putString("triggerSource", source);
        bundle.putString("timestamp", timeStamp);

        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(applicationContext));
        Job myJob = dispatcher.newJobBuilder()
                .setService(LocationPushService.class)
                .setTag("location_job_onetime")
                .setExtras(bundle)
                .setRecurring(false)
                .setLifetime(Lifetime.FOREVER)
                .setTrigger(Trigger.NOW)
                .setReplaceCurrent(false)
                .setRetryStrategy(RetryStrategy.DEFAULT_EXPONENTIAL)
                .build();
        dispatcher.schedule(myJob);
    }

    public void onDemandLocationJob(Context applicationContext, String source, String timeStamp)
    {
        DebugLog.debug("Started reporting: ", "Tracking Location Request");
        Bundle bundle = new Bundle();
        bundle.putString("triggerSource", source);
        bundle.putString("timestamp", timeStamp);

        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(applicationContext));
        Job myJob = dispatcher.newJobBuilder()
                .setService(TrackLocationService.class)
                .setTag("location_job_onetime")
                .setExtras(bundle)
                .setRecurring(false)
                .setLifetime(Lifetime.FOREVER)
                .setTrigger(Trigger.NOW)
                .setReplaceCurrent(false)
                .setRetryStrategy(RetryStrategy.DEFAULT_EXPONENTIAL)
                .build();
        dispatcher.schedule(myJob);
    }


}

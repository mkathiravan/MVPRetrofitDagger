package net.abaqus.mygeotracking.deviceagent.notification;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.Log;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.sixgill.sync.sdk.Reach;

import net.abaqus.mygeotracking.deviceagent.MGTScheduleStatus;
import net.abaqus.mygeotracking.deviceagent.bgthread.AttachmentPushTask;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HeartBeat;
import net.abaqus.mygeotracking.deviceagent.heartbeat.TriggerSource;
import net.abaqus.mygeotracking.deviceagent.home.LocationUpdatesService;
import net.abaqus.mygeotracking.deviceagent.location.LocationJob;
import net.abaqus.mygeotracking.deviceagent.notes.UploadNotesTask;
import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.ui.RegisterDeviceActivity;
import net.abaqus.mygeotracking.deviceagent.utils.AppUtils;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;
import net.abaqus.mygeotracking.deviceagent.utils.HOSCustomerIDJobIDPullTask;
import net.abaqus.mygeotracking.deviceagent.utils.HOSLabelPULLTask;
import net.abaqus.mygeotracking.deviceagent.utils.HOSPullCalls;
import net.abaqus.mygeotracking.deviceagent.utils.HOSPushTask;
import net.abaqus.mygeotracking.deviceagent.utils.LocationPUSHTask;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Map;

import static net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder.NOTIFICATION_ACTION_LAUNCH;
import static net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder.NOTIFICATION_ACTION_UPDATE;
import static net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder.NOTIFICATION_ID_LAUNCH_APP;
import static net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder.NOTIFICATION_ID_NORMAL_MESSAGE;
import static net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder.NOTIFICATION_ID_TIMECLOCK_ACTION;
import static net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder.NOTIFICATION_ID_UPDATE_VERSION;

/**
 * Created by root on 8/6/16.
 */

public class AgentGcmListenerService extends FirebaseMessagingService {

    private static final String TAG = AgentGcmListenerService.class.getSimpleName();
    private Context mContext;
    /**
     * Called when message is received.
     *
     */
    // [START receive_message]



    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {

        String from = remoteMessage.getFrom();
        Map<String, String> data = remoteMessage.getData();
        Log.d(TAG, "From: " + from);
        Log.d(TAG, "Message: " + data.toString());
        Log.d(TAG, "PushNotification: " + data.toString());
        Log.d(TAG, "Collapsekey "+remoteMessage.getCollapseKey());

        String pushDataKey = "";
        String pushDataValue = "";
        mContext =this;
        for (Map.Entry<String, String> entry : data.entrySet())
        {
            System.out.println(entry.getKey() + "/" + entry.getValue());
        }



        if (data.get(NotificationCommands.KEY_GCM_MESSAGE_TYPE) != null) {
            if (!data.get(NotificationCommands.KEY_GCM_MESSAGE_TYPE).isEmpty()) {
                pushDataKey = data.get(NotificationCommands.KEY_GCM_MESSAGE_TYPE);
                pushDataValue = data.get(NotificationCommands.KEY_GCM_ACTION_TYPE);
            }
            /**
             * Production applications would usually process the message here.
             * Eg: - Syncing with server.
             *     - Store message in local database.
             *     - Update UI.
             */

            /**
             * In some cases it may be useful to show a notification indicating to the user
             * that a message was received.
             */

            Log.d(TAG, "Push Data Key : " + pushDataKey + ", Push data Value : " + pushDataValue);
            if (NotificationCommands.KEY_GCM_SILENT_PUSH.equalsIgnoreCase(pushDataKey)) {
                Log.d(TAG, "This is silentPush message");
                if (NotificationCommands.VAL_CHECK_INSTALLATION_STATUS.equalsIgnoreCase(pushDataValue)) {
                    Log.d(TAG, "Installation check");
                    //ZDAListener.getInstance().initialize(this.getApplicationContext(), null, null, null);
                } else if (NotificationCommands.VAL_CUSTOMER_SITES_UPDATED.equalsIgnoreCase(pushDataValue)) {
                    Log.d(TAG, "Customer sites updated");

                   // new HOSCustomerIDJobIDPullTask(mContext, HOSCustomerIDJobIDPullTask.CustomerJob.CUSTOMER).execute();


                    Handler handler = new Handler(Looper.getMainLooper());

                    handler.post(new Runnable() {
                        public void run() {
                            new HOSCustomerIDJobIDPullTask(mContext, HOSCustomerIDJobIDPullTask.CustomerJob.CUSTOMER).execute();
                        }
                    });


                } else if (NotificationCommands.VAL_JOB_SITES_UPDATED.equalsIgnoreCase(pushDataValue)) {
                    Log.d(TAG, "Jobsite updated");
                 //   new HOSCustomerIDJobIDPullTask(this, HOSCustomerIDJobIDPullTask.CustomerJob.JOB).execute();


                    Handler handler = new Handler(Looper.getMainLooper());

                    handler.post(new Runnable() {
                        public void run() {
                            new HOSCustomerIDJobIDPullTask(mContext, HOSCustomerIDJobIDPullTask.CustomerJob.JOB).execute();
                        }
                    });

                } else if (NotificationCommands.VAL_HOS_LABELS_UPDATED.equalsIgnoreCase(pushDataValue)) {
                    Log.d(TAG, "HOS Labels updated");
           //         new HOSLabelPULLTask(this.getApplicationContext(), false).execute();

                    Handler handler = new Handler(Looper.getMainLooper());

                    handler.post(new Runnable() {
                        public void run() {
                            new HOSLabelPULLTask(mContext, false).execute();                        }
                    });


                } else if (NotificationCommands.VAL_NOTIFY_CONFIGURATION_CHANGES.equalsIgnoreCase(pushDataValue)) {
                    Log.d(TAG, "Configuration changes happened.");
                    HOSPullCalls.makeHOSInitializeCallsInBg(this, false);
                } else if (NotificationCommands.VAL_REQUEST_DEBUG_INFO.equalsIgnoreCase(pushDataValue)) {
                    Log.d(TAG, "Request debug Info.");
                    //new SendDebugInfoTask(this).execute();
                } else if (NotificationCommands.VAL_REQUEST_HEARTBEAT_DATA.equalsIgnoreCase(pushDataValue)) {
                    Log.d(TAG, "Request HeartBeat Data.");
                    HeartBeat.getInstance().justOneBeat(getApplicationContext(), TriggerSource.PUSH_NOTIFICATION_REQUEST);
                }else if (NotificationCommands.VAL_FORMS_LIST_UPDATED.equalsIgnoreCase(pushDataValue)) {
                    Log.d(TAG, "Request debug Info.");
                    //Add your forms API Call async call here. This should work in background thread and should not affect the main thread because it is running from background.
                } else if (NotificationCommands.VAL_RESTART_CLIENT_APP.equalsIgnoreCase(pushDataValue)) {
                    Log.d(TAG, "Restart client app request has happened.");
                    //ZDAListener.getInstance().initialize(this.getApplicationContext(), null, null, null);
                } else if (NotificationCommands.VAL_REQUEST_CURRENT_LOCATION.equalsIgnoreCase(pushDataValue)) {
                    Log.d(TAG, "Requesting current location through push.");
//                    ZDAEventService zdaService = null;
//                    zdaService = ZDAClassFactory.getEventService(this);
//                    zdaService.requestLocationShot(myGeoTrackingDevieAgentApplication.AUTH_TOKEN, 1000, 40, new ZDAEventHandlerPush());

                    //Removing ZOS Locationshot reliability and adding Native Lookup due to Android Oreo Issues

                    //Based on the push notification the following location API will called

                    String timeStamp = CurrentDateAndTime.getDateTime(new SimpleDateFormat("yyyy:MM:dd,HH:mm:ss"));
                    LocationJob.getInstance().onDemandLocationJob(this, "PushNotifRequest", timeStamp);
//

//                    Intent intent = new Intent(mContext, LocationUpdatesService.class);
//                    startService(intent);


                } else if (NotificationCommands.VAL_NOTIFY_TRACKING_SCHEDULE_CHANGES.equalsIgnoreCase(pushDataValue)) {

                    boolean schedule_track = true;

                    if (data.get(NotificationCommands.KEY_TRACKING_STATE).equals(NotificationCommands.VAL_TRACKING_STARTED)) {
                        Log.d(TAG, "Notifying tracking started." + data.get(NotificationCommands.KEY_TRACKING_FREQUENCY));

                        SharedPreferences sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
                        SharedPreferences.Editor editor = sh_prefs.edit();
                        editor.putString(MDACons.TRACKING_FREQUENCY,data.get(NotificationCommands.KEY_TRACKING_FREQUENCY));
                        editor.putBoolean(MDACons.SCHUDELE_TRACK_STATUS,schedule_track);
                        editor.commit();


                        MGTScheduleStatus.getInstance(this.getApplicationContext()).setScheduleStatus(true);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        {

                            Intent intent = new Intent(mContext, LocationUpdatesService.class);
                            startForegroundService(intent);
                        }
                        else
                        {

                            Reach.enable(mContext);
                        }


//                   ZDAListener.getInstance().toggleNotification();
                    } else if (data.get(NotificationCommands.KEY_TRACKING_STATE).equals(NotificationCommands.VAL_TRACKING_STOPPED))
                    {
                        Log.d(TAG, "Notifying tracking stopped.");

                        MGTScheduleStatus.getInstance(this.getApplicationContext()).setScheduleStatus(false);

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        {
                            Intent intent = new Intent(mContext, LocationUpdatesService.class);
                            stopService(intent);
                        }
                        else
                        {
                            Reach.disable(mContext);
                        }


                        // Get the cadence stopped flag

                        SharedPreferences sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
                        SharedPreferences.Editor editor = sh_prefs.edit();
                        editor.putBoolean(MDACons.SCHUDELE_TRACK_STATUS, false);
                        editor.commit();
                    }
                }
                else if (NotificationCommands.VAL_REQUEST_PENDING_TRANSACTIONS.equalsIgnoreCase(pushDataValue)) {
                    if (data.get(NotificationCommands.KEY_PENDING_TRANSACTIONS_TYPE).equals(NotificationCommands.PENDING_TRANSACTIONS_TYPE_ALL)) {
                        Log.d(TAG, "Requesting to process all kind of pending transactions");


                        Handler handler = new Handler(Looper.getMainLooper());

                        handler.post(new Runnable() {
                            public void run() {
                                new HOSPushTask(mContext).execute();                      }
                        });



                        Handler handler1 = new Handler(Looper.getMainLooper());

                        handler1.post(new Runnable() {
                            public void run() {
                                new UploadNotesTask(mContext).execute();                      }
                        });



                        Handler handler2 = new Handler(Looper.getMainLooper());

                        handler2.post(new Runnable() {
                            public void run() {
                                new AttachmentPushTask(mContext).execute();           }
                        });


                       // new HOSPushTask(this).execute();
                       // new UploadNotesTask(this).execute();
                       // new AttachmentPushTask(this).execute();



                    } else if (data.get(NotificationCommands.KEY_PENDING_TRANSACTIONS_TYPE).equals(NotificationCommands.PENDING_TRANSACTIONS_TYPE_ATTACHMENTS)) {
                        Log.d(TAG, "Requesting to process attachments pending transactions");
                       // new AttachmentPushTask(this).execute();


                        Handler handler = new Handler(Looper.getMainLooper());

                        handler.post(new Runnable() {
                            public void run() {
                                new AttachmentPushTask(mContext).execute();          }
                        });

                    } else if (data.get(NotificationCommands.KEY_PENDING_TRANSACTIONS_TYPE).equals(NotificationCommands.PENDING_TRANSACTIONS_TYPE_HOS)) {
                        Log.d(TAG, "Requesting to process hos pending transactions");


                        Handler handler = new Handler(Looper.getMainLooper());

                        handler.post(new Runnable() {
                            public void run() {
                                new HOSPushTask(mContext).execute()  ;    }
                        });
                      // new HOSPushTask(this).execute();
                    } else if (data.get(NotificationCommands.KEY_PENDING_TRANSACTIONS_TYPE).equals(NotificationCommands.PENDING_TRANSACTIONS_TYPE_NOTES)) {
                        Log.d(TAG, "Requesting to process notes pending transactions");
                       // new UploadNotesTask(this).execute();
                        Handler handler = new Handler(Looper.getMainLooper());

                        handler.post(new Runnable() {
                            public void run() {
                                new UploadNotesTask(mContext).execute();    }
                        });

                    }
                }
            }

            if (NotificationCommands.KEY_GCM_DATA_PUSH.equalsIgnoreCase(pushDataKey)) {
                Log.d(TAG, "This is dataPush message");
                if (NotificationCommands.VAL_INFO_NOTIFIACTIONS.equalsIgnoreCase(pushDataValue)) {
                    Log.d(TAG, "Information notifications");
                    Intent intent = new Intent(this, MDAMainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    AgentNotificationBuilder.showSimpleNotification(this, data.get(NotificationCommands.KEY_GCM_DATA_TITLE), data.get(NotificationCommands.KEY_GCM_DATA_MESSAGE), intent, NOTIFICATION_ID_NORMAL_MESSAGE);
                    //Implement the method to change timeclocking status and time locally
                } else if (NotificationCommands.VAL_NOTIFY_TIMECLOCK_CHANGES.equalsIgnoreCase(pushDataValue)) {
                    //TODO Add way to receive the updated time and act accordingly. If the time is older then the current one then don't do anything
                    Log.d(TAG, "Timeclock changes happened");
                    SharedPreferences sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
                    SharedPreferences.Editor editor = sh_prefs.edit();

                    FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
                    String hos_Selection_stage_name = sh_prefs.getString(MDACons.HOS_SELECTION_NAME, "");
                    Bundle bundle = new Bundle();
                    bundle.putString("TC_NOTIFIED_STAGE", data.get(NotificationCommands.KEY_GCM_HOS_STATE_DESC));
                    bundle.putString("TC_PREVIOUS_STAGE", hos_Selection_stage_name);
                    bundle.putString("TC_EVENT_SOURCE", "Push Notification");
                    mFirebaseAnalytics.logEvent("TC_EVENT", bundle);

                    editor.putInt(MDACons.HOS_SELECTION,
                            Integer.parseInt(data.get(NotificationCommands.KEY_GCM_HOS_STATE_ID)));
                    editor.putString(MDACons.HOS_SELECTION_NAME,
                            data.get(NotificationCommands.KEY_GCM_HOS_STATE_DESC));
                    String time = "";
                    SimpleDateFormat sdf = null;

                    try {
                        sdf = new SimpleDateFormat("yyyy/MMM/dd,HH:mm:ss",
                                Locale.getDefault());
                        time = CurrentDateAndTime.getDateTime(new SimpleDateFormat(
                                "yyyy/MM/dd'T'HH:mm:ssZ", Locale.getDefault()));
                    } catch (Exception e) {
                    }
                    editor.putString(MDACons.HOS_TIME, time);

                    editor.commit();
                    Log.d(TAG, sh_prefs.getInt(MDACons.HOS_SELECTION, -1) + "");
                    Log.d(TAG, sh_prefs.getString(MDACons.HOS_TIME, "Nothing"));
                    Log.d(TAG, sh_prefs.getString(MDACons.HOS_SELECTION_NAME, "Nothing"));
                    Log.d(TAG, data.get(NotificationCommands.KEY_GCM_HOS_STATE_ID));
                    Log.d(TAG, data.get(NotificationCommands.KEY_GCM_HOS_STATE_DESC));
                    Log.d(TAG, time);
                    Intent intent = new Intent(this, MDAMainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    AgentNotificationBuilder.showSimpleNotification(this, data.get(NotificationCommands.KEY_GCM_DATA_TITLE), data.get(NotificationCommands.KEY_GCM_DATA_MESSAGE), intent, NOTIFICATION_ID_NORMAL_MESSAGE);
                }
            }
            if (NotificationCommands.KEY_GCM_ACTIONABLE_PUSH.equalsIgnoreCase(pushDataKey)) {
                Log.d(TAG, "This is actionable message");
                if (NotificationCommands.VAL_REMIND_TO_TIMECLOCK.equalsIgnoreCase(pushDataValue)) {
                    SharedPreferences sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
                    FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
                    String hos_Selection_stage_name = sh_prefs.getString(MDACons.HOS_SELECTION_NAME, "");

                    Bundle bundle = new Bundle();
                    bundle.putString("TC_REMINDED_STAGE", data.get(NotificationCommands.KEY_GCM_HOS_STATE_DESC));
                    bundle.putString("TC_PREVIOUS_STAGE", hos_Selection_stage_name);
                    bundle.putString("TC_EVENT_SOURCE", "Push Notification Reminder");
                    mFirebaseAnalytics.logEvent("TC_EVENT", bundle);


                    Log.d(TAG, "HOS State change reminder with actions.");
                    String hosID = data.get(NotificationCommands.KEY_GCM_HOS_STATE_ID);
                    String hosLabel = data.get(NotificationCommands.KEY_GCM_HOS_STATE_DESC);
                    String notificationMessage = data.get(NotificationCommands.KEY_GCM_DATA_MESSAGE);
                    String notificationTitle = data.get(NotificationCommands.KEY_GCM_DATA_TITLE);
                    Log.d(TAG, "Notification title : " + notificationTitle + ", Notification Message :" + notificationMessage);
                    AgentNotificationBuilder.showTimeClockActionNotification(this, notificationTitle, notificationMessage, NOTIFICATION_ID_TIMECLOCK_ACTION, hosLabel, hosID);

                } else if (NotificationCommands.VAL_REMIND_TO_RELAUNCH.equalsIgnoreCase(pushDataValue)) {

                    Log.d(TAG, "Reminding to relaunch the app");
                    if (!AppUtils.isAppForeground(this)) {
                        String notificationMessage = data.get(NotificationCommands.KEY_GCM_DATA_MESSAGE);
                        String notificationTitle = data.get(NotificationCommands.KEY_GCM_DATA_TITLE);
                        Intent intent =
                                new Intent(this, RegisterDeviceActivity.class);//.setData(dataItemUri);
                        AgentNotificationBuilder.showReLaunchActionNotification(this, notificationTitle, notificationMessage, NOTIFICATION_ID_LAUNCH_APP, NOTIFICATION_ACTION_LAUNCH);
                    }

                } else if (NotificationCommands.VAL_REMIND_ABOUT_UPDATED_VERSION.equalsIgnoreCase(pushDataValue)) {

                    Log.d(TAG, "remind to update the app");
                    String notificationMessage = data.get(NotificationCommands.KEY_GCM_DATA_MESSAGE);
                    String notificationTitle = data.get(NotificationCommands.KEY_GCM_DATA_TITLE);
                    AgentNotificationBuilder.showAppUpdateActionNotification(this, notificationTitle, notificationMessage, NOTIFICATION_ID_UPDATE_VERSION, NOTIFICATION_ACTION_UPDATE);

                }
            }
            if (NotificationCommands.KEY_GCM_INAPP_MESSAGE.equalsIgnoreCase(pushDataKey)) {
                Log.d(TAG, "This is inapp message");
                if (NotificationCommands.VAL_PLAIN_IN_APP_MESSAGE.equalsIgnoreCase(pushDataValue)) {
                    Log.d(TAG, "inapp message message");
                } else if (NotificationCommands.KEY_INAPP_MESSAGE_BODY.equalsIgnoreCase(pushDataValue)) {
                    Log.d(TAG, "inapp message body");
                }
            }

            // [END_EXCLUDE]
/*
            if (!Utils.isAppIsInBackground(this)) {
                String notificationTitle = data.getBundle("notification").getString("title");
                String notificationBody = data.getBundle("notification").getString("body");
                Intent intent = new Intent(this, MDAMainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                AgentNotificationBuilder.showSimpleNotification(this, notificationTitle, notificationBody, intent, 101);
            }
*/
        }

    }

    @Override
    public void onNewToken(final String s) {
        super.onNewToken(s);

        Log.d(TAG,"ONTOKEN_ISCALLED ");

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        try {
            sharedPreferences.edit().putBoolean(NotificationPreferences.SENT_TOKEN_TO_MGT_SERVER, false).apply();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    ShareRegistrationToken.sendRefreshTokenToServer(AgentGcmListenerService.this,s);
                }
            }).start();
            // You should store a boolean that indicates whether the generated token has been
            // sent to your server. If the boolean is false, send the token to your server,
            // otherwise your server should have already received the token.
            // [END register_for_gcm]
        } catch (Exception e) {
            Log.d(TAG, "Failed to complete token refresh", e);
            // If an exception happens while fetching the new token or updating our registration data
            // on a third-party server, this ensures that we'll attempt the update at a later time.
        }
    }

}
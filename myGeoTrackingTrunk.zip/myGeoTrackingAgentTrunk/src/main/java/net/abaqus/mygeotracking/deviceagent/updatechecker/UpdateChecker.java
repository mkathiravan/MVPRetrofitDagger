package net.abaqus.mygeotracking.deviceagent.updatechecker;


import android.app.Activity;
import android.content.SharedPreferences;



/**
 * UpdateChecker is a class that can be used by Android Developers to increase the number of their apps' updates.
 * 
 */
public class UpdateChecker implements StoreCheckTaskResult, UpdateCheckerResult {

    public static final String ROOT_PLAY_STORE_DEVICE = "market://details?id=";
    public static final String PREFS_FILENAME = "updateChecker";
    public static final String DONT_SHOW_AGAIN_PREF_KEY = "dontShow";
    private static final String SUCCESSFUL_CHEKS_PREF_KEY = "nLaunches";

    static Store DEFAULT_STORE = Store.GOOGLE_PLAY;
    static int DEFAULT_SUCCESSFUL_CHECKS_REQUIRED = 5;
    static int DEFAULT_NOTICE_ICON_RES_ID = 0;
    static UpdateViewType DEFAULT_NOTICE = UpdateViewType.NOTIFICATION;

    static Activity mActivity;
    static Store mStore;
    static int mSuccessfulChecksRequired;
    static UpdateViewType mNotice;
    static int mNoticeIconResId;
    static UpdateCheckerResult mLibraryResultCallaback;
    static StoreCheckTaskResult mCheckResultCallback;
    static boolean mCustomImplementation;

    public UpdateChecker(Activity activity) {
        mActivity = activity;
        mStore = DEFAULT_STORE;
        mSuccessfulChecksRequired = DEFAULT_SUCCESSFUL_CHECKS_REQUIRED;
        mNotice = DEFAULT_NOTICE;
        mNoticeIconResId = DEFAULT_NOTICE_ICON_RES_ID;
        mCheckResultCallback = this;
        mLibraryResultCallaback = this;
        mCustomImplementation = false;
    }

    public UpdateChecker(Activity activity, UpdateCheckerResult updateCheckerResult) {
        mActivity = activity;
        mStore = DEFAULT_STORE;
        mSuccessfulChecksRequired = DEFAULT_SUCCESSFUL_CHECKS_REQUIRED;
        mNotice = DEFAULT_NOTICE;
        mNoticeIconResId = DEFAULT_NOTICE_ICON_RES_ID;
        mCheckResultCallback = this;
        mLibraryResultCallaback = updateCheckerResult;
        mCustomImplementation = true;
    }

    /**
     * Set the store where download the app page from. Default is Google Play.
     *
     * @param store Store to set
     *  
     */
    public static void setStore(Store store) {
        mStore = store;
    }

    /**
     * Set the checks successful necessary to show the Notice. Default is 5.
     *
     * @param checksRequired checks required to set
     * 
     */
    public static void setSuccessfulChecksRequired(int checksRequired) {
        mSuccessfulChecksRequired = checksRequired;
    }

    /**
     * Set the type of notice used to alert the user if a new update has been found. Default is Dialog.
     *
     * @param type of view to set.
     */
    public static void setUpdateViewType(UpdateViewType notice) {
        mNotice = notice;
        if (mCustomImplementation) {
            throw new IllegalStateException("You can't set Notice when you choose a custom implementation.\nThe Notice is controlled manually by you with the callbacks.\nTo call setUpdateViewType() use the UpdateChecker constructor with one argument.");
        }
    }

    /**
     * Set the Notifcation or Dialog icon. If you don't call this, the Notifcation will have the default Play Store Notification Icon as icon and the Dialog will have no icon.
     *
     * @param noticeIconResId Res Id of the icon to set.
     */
    public static void setUpdateViewIcon(int noticeIconResId) {
        mNoticeIconResId = noticeIconResId;
        if (mCustomImplementation) {
            throw new IllegalStateException("You can't set the notice Icon when you choose a custom implementation.\nThe Notice is controlled manually by you with the callbacks.\nTo call setNotice() use the UpdateChecker constructor with one argument.");
        }
    }

    /**
     * Start the process
     */
    public static void start() {
        StoreCheckTask asynctask = new StoreCheckTask(mStore, mCheckResultCallback, mActivity);
        asynctask.execute();
    }

    /**
     * If the library found a version available on the Store, 
     * and it's different from the installed one, notify it to the user.
     *
     * @param versionDownloadable String to compare to the version installed of the app.
     */
    @Override
    public void versionDownloadableFound(String versionDownloadable) {
        if (Comparator.isVersionDownloadableNewer(mActivity, versionDownloadable)) {
            if (hasToShowNotice(versionDownloadable) /*&& !hasUserTappedToNotShowNoticeAgain(versionDownloadable)*/) {
                mLibraryResultCallaback.foundUpdateAndShowIt(versionDownloadable);
            } else {
                mLibraryResultCallaback.foundUpdateAndDontShowIt(versionDownloadable);
            }
        } else { // No new update available
            mLibraryResultCallaback.returnUpToDate(versionDownloadable);
        }

    }

    /**
     * Can't get the versionName from Play Store.
     *  
     */
    @Override
    public void multipleApksPublished() {
        mLibraryResultCallaback.returnMultipleApksPublished();
    }

    /**
     * Can't download the store page.
     */
    @Override
    public void networkError() {
        mLibraryResultCallaback.returnNetworkError();
    }

    /**
     * Can't find the store page for this app.
     */
    @Override
    public void appUnpublished() {
        mLibraryResultCallaback.returnAppUnpublished();
    }

    /**
     * The check returns null for new version downloadble
     */
    @Override
    public void storeError() {
        mLibraryResultCallaback.returnStoreError();
    }

    /**
     * versionDownloadable isn't equal to manifest versionName -> New update available.
     * Show the Notice because it's the first time or the number of the checks made is a multiple of the argument of setSuccessfulChecksRequired(int) method. (If you don't call setSuccessfulChecksRequired(int) the default is 5).
     *
     * @param versionDownloadable version downloadable from the Store.
     * 
     */
    @Override
    public void foundUpdateAndShowIt(String versionDownloadable) {
        if (mNotice == UpdateViewType.NOTIFICATION) {
            showNotification();
        }
    }

    /**
     * versionDownloadable isn't equal to manifest versionName -> New update available.
     * Show the Notice because it's the first time or the number of the checks made is a multiple of the argument of setSuccessfulChecksRequired(int) method. (If you don't call setSuccessfulChecksRequired(int) the default is 5).
     *
     * @param versionDownloadable version downloadable from the Store.
     * 
     */
    @Override
    public void foundUpdateAndDontShowIt(String versionDownloadable) {

    }

    /**
     * versionDownloadable is equal to manifest versionName -> No new update available.
     * Don't show the Notice
     *
     * @param versionDonwloadable version downloadable from the Store.
     */
    @Override
    public void returnUpToDate(String versionDonwloadable) {

    }

    @Override
    public void returnMultipleApksPublished() {

    }

    @Override
    public void returnNetworkError() {

    }

    @Override
    public void returnAppUnpublished() {

    }

    @Override
    public void returnStoreError() {

    }

    /**
     * Get if the user has tapped on "No, thanks" button on dialog for this downloable version.
     *
     * @param versionDownloadable version downloadable from the Store.
     * @see com.rampo.updatechecker.notice.Dialog#userHasTappedToNotShowNoticeAgain(android.content.Context, String)
     *//*
    private boolean hasUserTappedToNotShowNoticeAgain(String versionDownloadable) {
        SharedPreferences prefs = mActivity.getSharedPreferences(PREFS_FILENAME, 0);
        String prefKey = DONT_SHOW_AGAIN_PREF_KEY + versionDownloadable;
        return prefs.getBoolean(prefKey, false);
    }*/

    /**
     * Show the Notice only if it's the first time or the number of the checks made is a multiple of the argument of setSuccessfulChecksRequired(int) method. (If you don't call setSuccessfulChecksRequired(int) the default is 5).
     */
    private boolean hasToShowNotice(String versionDownloadable) {
        SharedPreferences prefs = mActivity.getSharedPreferences(PREFS_FILENAME, 0);
        String prefKey = SUCCESSFUL_CHEKS_PREF_KEY + versionDownloadable;
        int mChecksMade = prefs.getInt(prefKey, 0);
        if (mChecksMade % mSuccessfulChecksRequired == 0 || mChecksMade == 0) {
            saveNumberOfChecksForUpdatedVersion(versionDownloadable, mChecksMade);
            return true;
        } else {
            saveNumberOfChecksForUpdatedVersion(versionDownloadable, mChecksMade);
            return false;
        }
    }

    /**
     * Update number of checks for this version downloadable from the Store.
     */
    private void saveNumberOfChecksForUpdatedVersion(String versionDownloadable, int mChecksMade) {
        mChecksMade++;
        SharedPreferences prefs = mActivity.getSharedPreferences(PREFS_FILENAME, 0);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(SUCCESSFUL_CHEKS_PREF_KEY + versionDownloadable, mChecksMade);
        editor.commit();

    }

/*    *//**
     * Show Dialog
     *//*
    public void showDialog(String versionDownloadable) {
        Dialog.show(mActivity, mStore, versionDownloadable, mNoticeIconResId);
    }
*/
    /**
     * Show Notification
     */
    public static void showNotification() {
        UpdateCheckNotification.show(mActivity, mStore, mNoticeIconResId);
    }


}
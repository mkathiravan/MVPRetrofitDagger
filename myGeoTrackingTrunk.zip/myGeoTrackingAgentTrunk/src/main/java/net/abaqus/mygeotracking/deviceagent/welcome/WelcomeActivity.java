package net.abaqus.mygeotracking.deviceagent.welcome;

import android.Manifest;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.ui.TrialAccountSignUp;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.FetchDeviceNumber;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by bm on 1/1/16.
 */

/**
 * Terms of Service activity activated via
 * {@link MDAMainActivity} functionality.
 */
public class WelcomeActivity  extends ReceiverActivity implements WelcomeFragment.WelcomeFragmentContainer{

    private static final String TAG = WelcomeActivity.class.toString();
    private static final int PERMISSIONS_REQUEST_PHONE_STATE = 123;
    WelcomeActivityContent mContentFragment;

    @BindView(R.id.etPhoneNumberWelcome)
    TextInputEditText phoneNumberEdiText;

    @BindView(R.id.etCallingCodeWelcome)
    TextInputEditText etCallingCodeWelcome;
    @BindView(R.id.accept_terms)
    TextView acceptTerms;

    @BindView(R.id.trialSignUp)
    RelativeLayout trialSignUp;

    @BindView(R.id.trail_link)
    TextView trailLink;

    String savePhoneNumber;
    SharedPreferences sp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        ButterKnife.bind(this);

        //lookForPhoneStatePermission();
        checkPermission();

        mContentFragment = getCurrentFragment(this);

//        phoneNumberEdiText = (TextInputEditText) findViewById(R.id.etPhoneNumberWelcome);
//        etCallingCodeWelcome = (TextInputEditText) findViewById(R.id.etCallingCodeWelcome);


        sp = getSharedPreferences("Key", Activity.MODE_PRIVATE);
        savePhoneNumber = sp.getString(MDACons.GET_ACCOUNT_LEVEL_PHONE_NO,"");
        if(!savePhoneNumber.isEmpty())
        {
            trialSignUp.setVisibility(View.VISIBLE);
        }
        else
        {
            trialSignUp.setVisibility(View.GONE);
        }




        // checkPermissionForState();

        // If there's no fragment to use, we're done here.
        if (mContentFragment == null) {
            finish();
        }

        // Wire up the fragment
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.welcome_content, (Fragment) mContentFragment);
        fragmentTransaction.commit();
        DebugLog.debug(TAG, "Inside Create View - WelcomeActivity.");
        setupAnimation();


        acceptTerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.mygeotracking.com/mobile-app-terms";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        trailLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TrialAccountSignUp.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG,"ONRESUME_CALLED ");
        sp = getSharedPreferences("Key", Activity.MODE_PRIVATE);
        savePhoneNumber = sp.getString(MDACons.GET_ACCOUNT_LEVEL_PHONE_NO,"");
        if(!savePhoneNumber.isEmpty())
        {
            phoneNumberEdiText.setText(savePhoneNumber);
            trialSignUp.setVisibility(View.GONE);
        }
        else
        {
            trialSignUp.setVisibility(View.VISIBLE);
        }
        Log.d(TAG,"Account phone number:"+savePhoneNumber);

    }


    private void setupAnimation() {
        /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            ImageView iv = (ImageView) findViewById(R.id.logo);
            AnimatedVectorDrawable logoAnim = (AnimatedVectorDrawable) getDrawable(R.drawable.io_logo_white_anim);
            iv.setImageDrawable(logoAnim);
            logoAnim.start();
        }*/
    }


    private void checkPermission() {
        if (ContextCompat.checkSelfPermission(WelcomeActivity.this,
                Manifest.permission.READ_PHONE_STATE) + ContextCompat
                .checkSelfPermission(WelcomeActivity.this,
                        Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale
                    (WelcomeActivity.this, Manifest.permission.READ_PHONE_STATE) ||
                    ActivityCompat.shouldShowRequestPermissionRationale
                            (WelcomeActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)) {

                Snackbar.make(WelcomeActivity.this.findViewById(android.R.id.content),
                        "Please Grant Permissions",
                        Snackbar.LENGTH_INDEFINITE).setAction("ENABLE",
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    requestPermissions(
                                            new String[]{Manifest.permission.READ_PHONE_STATE, Manifest.permission.ACCESS_FINE_LOCATION},
                                            PERMISSIONS_REQUEST_PHONE_STATE);
                                }
                            }
                        }).show();
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(
                            new String[]{Manifest.permission.READ_PHONE_STATE, Manifest.permission.ACCESS_FINE_LOCATION},
                            PERMISSIONS_REQUEST_PHONE_STATE);
                }
            }
        } else {
            // write your logic code if permission already granted

            Log.d(TAG,"PERMSIS_GRANTED ");
            FetchDeviceNumber fetchDeviceNumber = new FetchDeviceNumber(
                    getApplicationContext());
            String auto_detect_number = fetchDeviceNumber.getPhoneNumber();
            Log.d(TAG,"AUTODETECT "+auto_detect_number);
            String countryCallingCode = fetchDeviceNumber.getCountryCallingCode();
            phoneNumberEdiText.setText(auto_detect_number);
            etCallingCodeWelcome.setText(countryCallingCode);

        }
    }


    public void checkPermissionForState(){
        if(ContextCompat.checkSelfPermission(WelcomeActivity.this,Manifest.permission.CAMERA)
                + ContextCompat.checkSelfPermission(
                WelcomeActivity.this,Manifest.permission.READ_PHONE_STATE)
                + ContextCompat.checkSelfPermission(
                WelcomeActivity.this,Manifest.permission.ACCESS_FINE_LOCATION)
                + ContextCompat.checkSelfPermission(
                WelcomeActivity.this,Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED){

            // Do something, when permissions not granted
            if(ActivityCompat.shouldShowRequestPermissionRationale(
                    WelcomeActivity.this,Manifest.permission.READ_PHONE_STATE)
                    || ActivityCompat.shouldShowRequestPermissionRationale(
                    WelcomeActivity.this,Manifest.permission.ACCESS_FINE_LOCATION)
                    || ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,Manifest.permission.ACCESS_COARSE_LOCATION)){
                // If we should give explanation of requested permissions

                // Show an alert dialog here with request explanation
                AlertDialog.Builder builder = new AlertDialog.Builder(WelcomeActivity.this);
                builder.setMessage("Phone State, GPS Information");
                builder.setTitle("Please grant those permissions");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityCompat.requestPermissions(
                                WelcomeActivity.this,
                                new String[]{
                                        Manifest.permission.READ_PHONE_STATE,
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                },
                                PERMISSIONS_REQUEST_PHONE_STATE
                        );
                    }
                });
                builder.setNeutralButton("Cancel",null);
                AlertDialog dialog = builder.create();
                dialog.show();
            }else{
                // Directly request for required permissions, without explanation
                ActivityCompat.requestPermissions(
                        WelcomeActivity.this,
                        new String[]{
                                Manifest.permission.READ_PHONE_STATE,
                                Manifest.permission.ACCESS_FINE_LOCATION
                        },
                        PERMISSIONS_REQUEST_PHONE_STATE
                );
            }

        }else {
            // Do something, when permissions are already granted
            //Toast.makeText(WelcomeActivity.this,"Permissions already granted",Toast.LENGTH_SHORT).show();

            FetchDeviceNumber fetchDeviceNumber = new FetchDeviceNumber(
                    getApplicationContext());
            String auto_detect_number = fetchDeviceNumber.getPhoneNumber();
            Log.d(TAG,"AUTODETECT "+auto_detect_number);
            String countryCallingCode = fetchDeviceNumber.getCountryCallingCode();
            phoneNumberEdiText.setText(auto_detect_number);
            etCallingCodeWelcome.setText(countryCallingCode);
        }
    }





    private void lookForPhoneStatePermission(){
        // Here, thisActivity is the current activity
        Log.d(TAG,"LOCATIONSTATECALL ");
        if (ContextCompat.checkSelfPermission(WelcomeActivity.this,
                Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(WelcomeActivity.this,
                    Manifest.permission.READ_PHONE_STATE)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(WelcomeActivity.this, R.style.AppCompatAlertDialogStyle);
                builder.setTitle(R.string.title_phone_state_read_permission);
                builder.setMessage(R.string.msg_read_phone_state_permission);
                builder.setPositiveButton(R.string.btn_action_im_sure, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.setNegativeButton(R.string.btn_action_retry, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityCompat.requestPermissions(WelcomeActivity.this,
                                new String[]{Manifest.permission.READ_PHONE_STATE},
                                PERMISSIONS_REQUEST_PHONE_STATE);
                    }
                });
                builder.show();
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(WelcomeActivity.this,
                        new String[]{Manifest.permission.READ_PHONE_STATE},
                        PERMISSIONS_REQUEST_PHONE_STATE);
            }
        }else{
            FetchDeviceNumber fetchDeviceNumber = new FetchDeviceNumber(
                    getApplicationContext());
            String auto_detect_number = fetchDeviceNumber.getPhoneNumber();
            String countryCallingCode = fetchDeviceNumber.getCountryCallingCode();
            phoneNumberEdiText.setText(auto_detect_number);
            etCallingCodeWelcome.setText(countryCallingCode);
        }
    }


    /**
     * Get the current fragment to display.
     *
     * This is the first fragment in the list that WelcomeActivityContent.shouldDisplay().
     *
     * @param context the application context.
     * @return the WelcomeActivityContent to display or null if there's none.
     */
    private static WelcomeActivityContent getCurrentFragment(Context context) {
        List<WelcomeActivityContent> welcomeActivityContents = getWelcomeFragments();

        for (WelcomeActivityContent fragment : welcomeActivityContents) {
            if (fragment.shouldDisplay(context)) {
                return fragment;
            }
        }

        return null;
    }

    /**
     * Whether to display the WelcomeActivity.
     *
     * Decided whether any of the fragments need to be displayed.
     *
     * @param context the application context.
     * @return true if the activity should be displayed.
     */
    public static boolean shouldDisplay(Context context) {
        WelcomeActivityContent fragment = getCurrentFragment(context);
        if (fragment == null) {
            return false;
        }
        return true;
    }


    /**
     * Get all WelcomeFragments for the WelcomeActivity.
     *
     * @return the List of WelcomeFragments.
     */
    private static List<WelcomeActivityContent> getWelcomeFragments() {
        return new ArrayList<WelcomeActivityContent>(Arrays.asList(
                new EULAFragment()
                //new ConductFragment(),
               //new AttendingFragment(),
                //new RegistrationFragment()
        ));
    }

    @Override
    public Button getPositiveButton() {
        return (Button) findViewById(R.id.button_register);
    }

    @Override
    public void setPositiveButtonEnabled(Boolean enabled) {
        try {
            getPositiveButton().setEnabled(enabled);
        } catch (NullPointerException e) {
            DebugLog.debug(TAG, "Positive welcome button doesn't exist to set enabled.");
        }
    }

    @Override
    public CheckBox getTCCheckbox() {
        return (CheckBox) findViewById(R.id.checkBoxEULAAccept);
    }


   /* @Override
    public Button getNegativeButton() {
        return (Button) findViewById(R.id.button_decline);
    }*/

    /*@Override
    public void setNegativeButtonEnabled(Boolean enabled) {
        try {
            getNegativeButton().setEnabled(enabled);
        } catch (NullPointerException e) {
            Log.d(TAG, "Negative welcome button doesn't exist to set enabled.");
        }
    }*/

    /**
     * The definition of a Fragment for a use in the WelcomeActivity.
     */
    interface WelcomeActivityContent {
        /**
         * Whether the fragment should be displayed.
         *
         * @param context the application context.
         * @return true if the WelcomeActivityContent should be displayed.
         */
        public boolean shouldDisplay(Context context);
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSIONS_REQUEST_PHONE_STATE: {
                // If request is cancelled, the result arrays are empty.
                Log.d(TAG,"PERMISSIONGRANDET ");
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    FetchDeviceNumber fetchDeviceNumber = new FetchDeviceNumber(
                            getApplicationContext());
                    String auto_detect_number = fetchDeviceNumber.getPhoneNumber();
                    String countryCallingCode = fetchDeviceNumber.getCountryCallingCode();
                    Log.d(TAG,"DEV_NUMNBER " + auto_detect_number);
                    phoneNumberEdiText.setText(auto_detect_number);
                    etCallingCodeWelcome.setText(countryCallingCode);
                } else {
                    //Snackbar.make(main_view,"Storage permission denied.",Snackbar.LENGTH_LONG).show();
                }
                return;
            }

        }
    }


}

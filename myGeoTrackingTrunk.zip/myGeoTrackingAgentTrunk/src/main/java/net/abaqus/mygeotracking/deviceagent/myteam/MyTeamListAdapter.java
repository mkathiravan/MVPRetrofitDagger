package net.abaqus.mygeotracking.deviceagent.myteam;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.ViewUtils.FlipCheckBox;
import net.abaqus.mygeotracking.deviceagent.listeners.OnFlipCheckedChangeListener;

import java.util.List;

/**
 * Created by bm on 5/6/15.
 */
public class MyTeamListAdapter extends BaseAdapter {

    //OnListItemCheckedListener

    @SuppressWarnings("unused")
    private Context mContext;
    private LayoutInflater mLayoutInflater;
    private List<MyTeamData> mDataSet;

    public MyTeamListAdapter(Context context, List<MyTeamData> dataset) {

        mContext = context;
        mDataSet = dataset;
        mLayoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return mDataSet.size();
    }

    @Override
    public MyTeamData getItem(int position) {
        return mDataSet.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    private int lastPosition = -1;
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final MyTeamData item = getItem(position);
        item.setPosition(position);
        final ViewHolder holder;
        if (convertView == null) {
            convertView = mLayoutInflater.inflate(
                    R.layout.myteam_list_item, parent, false);

            holder = new ViewHolder();
            holder.flipCard = (FlipCheckBox) convertView
                    .findViewById(R.id.flipCard);
            holder.flipCard.setFocusable(false);
            holder.tvCardFrontText = (TextView) convertView.findViewById(R.id.tvCardFrontText);
            holder.title = (TextView) convertView.findViewById(R.id.myteam_device_description);
            holder.subTitle = (TextView) convertView.findViewById(R.id.myteam_device_number);
            holder.lastState = (TextView) convertView.findViewById(R.id.myteam_last_hos_stage_tv);
            holder.imageButton = (ImageButton) convertView.findViewById(R.id.imageButton);
            holder.imageButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //Toast.makeText(mContext, "Clicked Button", Toast.LENGTH_LONG).show();
                    MyTeamListFragment.mCallback.onSingleItemClick((Integer) view.getTag());
                }
            });
            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        String substring = "";

        if(item.getDeviceDescription().length() > 0)
            substring = item.getDeviceDescription().substring(0,1);
        else
            substring = "";
        holder.tvCardFrontText.setText(""+substring);
        holder.title.setText(item.getDeviceDescription());
        holder.subTitle.setText(item.getDeviceNumber());
        holder.lastState.setText(item.getLastHosStage());
        holder.imageButton.setTag(position);
        holder.flipCard.setCheckedInmediate(item.isChecked());
        holder.flipCard
                .setOnFlipCheckedChangeListener(new OnCheckedChangeListener(
                        item));

        //Animation animation = AnimationUtils.loadAnimation(mContext, (position > lastPosition) ? R.anim.up_from_bottom : R.anim.down_from_top);
        //convertView.startAnimation(animation);
        lastPosition = position;
        return convertView;
    }

    public class ViewHolder {

        FlipCheckBox flipCard;
        TextView title;
        TextView subTitle;
        TextView lastState;
        TextView tvCardFrontText;
        ImageButton imageButton;
    }

    public void setDataset(List<MyTeamData> posts) {

        mDataSet = posts;
        notifyDataSetChanged();
    }

    private class OnCheckedChangeListener implements
            OnFlipCheckedChangeListener {

        final MyTeamData item;

        public OnCheckedChangeListener(MyTeamData item) {
            this.item = item;
        }

        @Override
        public void onCheckedChanged(FlipCheckBox flipCardView,
                                     boolean isChecked) {
            item.setChecked(isChecked);
            MyTeamListFragment.mCallback.onItemChecked(item.getPosition());

        }
    }
}
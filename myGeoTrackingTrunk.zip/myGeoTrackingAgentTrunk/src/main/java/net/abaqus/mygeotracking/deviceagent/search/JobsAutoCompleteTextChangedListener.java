package net.abaqus.mygeotracking.deviceagent.search;

import android.text.Editable;
import android.text.TextWatcher;

public class JobsAutoCompleteTextChangedListener implements TextWatcher{

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
	}

	@Override
	public void afterTextChanged(Editable s) {
	}
/*
    public static final String TAG = "JobsAutoCompleteTextChangedListener.java";
    Context context;
    
    public JobsAutoCompleteTextChangedListener(Context context){
        this.context = context;
    }
    
    @Override
    public void afterTextChanged(Editable s) {
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count,
            int after) {
    }

    @Override
    public void onTextChanged(CharSequence userInput, int start, int before, int count) {

        // if you want to see in the logcat what the user types
        Log.e(TAG, "User input: " + userInput);

        HOSUpdateActivity mainActivity = ((HOSUpdateActivity) context);
        
        // query the database based on the user input
        mainActivity.jobs_item = mainActivity.getJobsItemsFromDb(userInput.toString());
        
        // update the adapater
        mainActivity.jobsAdapter.notifyDataSetChanged();
        mainActivity.jobsAdapter = new ArrayAdapter<String>(mainActivity, android.R.layout.simple_dropdown_item_1line, mainActivity.jobs_item);
        
      //  mainActivity.jobsAutoComplete.setAdapter(mainActivity.jobsAdapter);
        
    }*/

}
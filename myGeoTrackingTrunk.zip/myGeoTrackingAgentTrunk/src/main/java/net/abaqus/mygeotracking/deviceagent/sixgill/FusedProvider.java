package net.abaqus.mygeotracking.deviceagent.sixgill;

import android.Manifest;
import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.IBinder;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

public class FusedProvider extends Service {

    private Context mContext;
    double latitude; // Latitude
    double longitude; // Longitude
    float accuracy;  //accuracy
    long time; //timestamp
    // The minimum distance to change Updates in meters
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 1000; // 10 meters

    // The minimum time between updates in milliseconds
    private static final long MIN_TIME_BW_UPDATES = 1000 * 60 * 1; // 1 minute
    Activity activity;
    FusedLocationProviderClient fusedLocationClient;
    Location currentLocation;
    LocationCallback locationCallback;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 2;

    public FusedProvider() {
    }

    public FusedProvider(Context context, Activity activity) {
        this.mContext = context;
        this.activity = activity;
//        addressResultReceiver = new LocationAddressResultReceiver(new Handler());
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(mContext);
        if (ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.

        }else {

            fusedLocationClient.getLastLocation().addOnSuccessListener(activity, new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    Log.wtf("GPS TRAcker", "SUCCESS listener REceived");
                    currentLocation = location;
                    if(currentLocation == null) {
                        Log.wtf("GPS Tracker ", "======>>>> OOPS NULL LOCATION CLIENT HAVE A LOOK");
                    }
                }
            });
        }

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                currentLocation = locationResult.getLocations().get(0);
                if (null != currentLocation) {
                    Log.wtf("GPS TRACKER", "===>>> latitude "+currentLocation.getLatitude());
                    Log.wtf("GPS TRACKER", "===>>> longtitude "+currentLocation.getLongitude());
                    Log.wtf("GPS Tracker ", "GOT current location using fusedlocation client");
                }
            }
        };
        startLocationUpdates();

    }


    /**
     * Function to get latitude
     * */
    public double getLatitude(){
        if(currentLocation != null){
            latitude = currentLocation.getLatitude();
        }

        // return latitude
        return latitude;
    }


    /**
     * Function to get longitude
     * */
    public double getLongitude(){
        if(currentLocation != null){
            longitude = currentLocation.getLongitude();
        }

        // return longitude
        return longitude;
    }

    public float getAccuracy()
    {
        if(currentLocation != null)
        {
            accuracy = currentLocation.getAccuracy();
        }

        return accuracy;
    }

    public long getTime()
    {
        if(currentLocation != null)
        {
            time = currentLocation.getTime();
        }

        return time;
    }


    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

    @SuppressWarnings("MissingPermission")
    private void startLocationUpdates() {
        if (ContextCompat.checkSelfPermission(mContext,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            LocationRequest locationRequest = new LocationRequest();
            locationRequest.setInterval(60000);
            locationRequest.setFastestInterval(60000);
            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

            fusedLocationClient.requestLocationUpdates(locationRequest,
                    locationCallback,
                    null);
        }
    }
}

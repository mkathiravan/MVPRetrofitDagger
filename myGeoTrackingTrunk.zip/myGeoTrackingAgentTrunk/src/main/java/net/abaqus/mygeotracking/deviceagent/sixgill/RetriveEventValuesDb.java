package net.abaqus.mygeotracking.deviceagent.sixgill;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.BatteryManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;
import com.activeandroid.query.Delete;
import com.activeandroid.query.Select;

import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiClient;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiInterface;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkDeviceStatus;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import retrofit2.Call;
import retrofit2.Response;

import static android.content.Context.BATTERY_SERVICE;

public class RetriveEventValuesDb {

    private static final String TAG = RetriveEventValuesDb.class.getSimpleName();
    private List<ProviderInfoTable> providerInfoTableList;
    Context context;


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public RetriveEventValuesDb(Context context) {
        this.context = context;
        read_data_fromDb();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void read_data_fromDb() {

        providerInfoTableList = getInfoData();
        retrivevalues_from_Db(providerInfoTableList);
    }

    public List<ProviderInfoTable> getInfoData() {
        return new Select().from(ProviderInfoTable.class).execute();
    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void retrivevalues_from_Db(List<ProviderInfoTable> providerInfoTableList)
    {

        //Without HaspMap Concept Working Flow

        if(providerInfoTableList.size() > 0)
        {
            ProviderInfoTable providerInfoTable = providerInfoTableList.get(0);

            final ProviderModel provider = new ProviderModel();
            provider.setProvider(providerInfoTable.getProvider());
            provider.setRegionCode(providerInfoTable.getRegionCode());
            provider.setRegionCountry(providerInfoTable.getRegionCountry());
            provider.setStatusCode(providerInfoTable.getStatusCode());
            provider.setStatusMessage(providerInfoTable.getStatusMsg());
            provider.setNationalNumber(providerInfoTable.getNationalNumber());
            provider.setCoOrdinateFormat(providerInfoTable.getCoordinateFormat());
            provider.setCountryCode(providerInfoTable.getCountryCode());
            provider.setDeviceId(providerInfoTable.getDeviceID());
            provider.setLocateTime(providerInfoTable.getLocateTime());

            Log.d(TAG,"TIMEDETAILSOFVBIEW "+providerInfoTable.getLocateTime());
            GeoModel geo = new GeoModel();
            geo.setAccuracy(providerInfoTable.getAccuracy());
            geo.setAltitude(0);
            geo.setDirection("");
            geo.setLatitude(providerInfoTable.getLatitude());
            geo.setLongitude(providerInfoTable.getLongitude());
            provider.setGeo(geo);

            PropertyModel property = new PropertyModel();
            property.setManufacturer(providerInfoTable.getManufacturer());
            property.setModel(providerInfoTable.getModel());
            property.setOs(providerInfoTable.getOs());
            property.setOsVersion(providerInfoTable.getOs_version());
            property.setSensors(providerInfoTable.getSensors());
            property.setSoftwareVersion(providerInfoTable.getSoftware_version());
            property.setType(providerInfoTable.getType());
            provider.setProperty(property);

            DeviceModel device = new DeviceModel();
            BatteryManager bm = (BatteryManager)context.getSystemService(BATTERY_SERVICE);
            int batLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            String methodParam = NetworkDeviceStatus.checkNetworkStatus(context);
            provider.setLocateMethod(methodParam);

            device.setMethod(providerInfoTable.getMethod());
            device.setSpeed(providerInfoTable.getSpeed());
            device.setMovementDetected(providerInfoTable.getMovementDetected());
            device.setBatteryLevel(batLevel);
            device.setBatteryLife(providerInfoTable.getBattery_life());
            device.setCharging(providerInfoTable.isCharging());
            provider.setDevice(device);

            AddressModel address = new AddressModel();
            Geocoder geocoder;
            List<Address> addresses;
            geocoder = new Geocoder(context, Locale.getDefault());


            try {

                String street_address,city,state,country,postalCode,full_address,knownName,locationName,countryCode = null;

                addresses = geocoder.getFromLocation(providerInfoTable.getLatitude(), providerInfoTable.getLongitude(), 1);
                full_address = addresses.get(0).getAddressLine(0);
                Log.wtf(TAG,"ADDRED "+address + "SAMODRE "+addresses);
                street_address = addresses.get(0).getFeatureName() +" " +addresses.get(0).getThoroughfare();
                city = addresses.get(0).getLocality();
                state = addresses.get(0).getAdminArea();
                country = addresses.get(0).getCountryName();

                if(addresses.get(0).getPostalCode() == null || addresses.get(0).getPostalCode().isEmpty())
                {
                    postalCode = "0";
                }
                else
                {
                    postalCode = addresses.get(0).getPostalCode();
                }
                knownName = addresses.get(0).getFeatureName();
                countryCode = addresses.get(0).getCountryCode();
                Double lat = addresses.get(0).getLatitude();
                Double lang = addresses.get(0).getLongitude();

                address.setSetStreetAddress(street_address);
                address.setCity(city);
                address.setState(state);
                address.setPostalCode(postalCode);
                address.setCountry(country);
                address.setAddress(full_address);
                provider.setAddress(address);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }


            if (NetworkConnectionInfo.isOnline(context)) {
                Log.d(TAG,"Internet Available");

                AsyncTask.execute(new Runnable() {
                    @Override
                    public void run() {
                        load_tracking_data(provider);
                    }
                });

            }

        }


    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void load_tracking_data(final  ProviderModel provider)
    {
        Log.d(TAG,"SIXGILLTRACKINGAPICALLED ");
        final String locate_time = provider.getLocateTime();
        final ApiInterface requestInterface = ApiClient.getProductionClient();

        Void result = null;
        Response<Void> execute;
        boolean isRequestSuccess = false;
        Call<Void> call = requestInterface.loadLocationInfo(provider);
        try {
            execute = call.execute();
            isRequestSuccess = execute.isSuccessful();
            result = execute.body();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(isRequestSuccess) {
            new Delete().from(ProviderInfoTable.class).where("locateTime = ?",locate_time).execute();
            if (NetworkConnectionInfo.isOnline(context))
            {
                read_data_fromDb();
            }

        }
    }

}

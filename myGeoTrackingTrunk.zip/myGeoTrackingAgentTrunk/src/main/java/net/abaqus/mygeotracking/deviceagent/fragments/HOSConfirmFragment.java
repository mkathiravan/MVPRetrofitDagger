package net.abaqus.mygeotracking.deviceagent.fragments;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.activeandroid.query.Select;
import com.afollestad.materialdialogs.MaterialDialog;
import com.drew.imaging.ImageMetadataReader;
import com.drew.metadata.Metadata;
import com.drew.metadata.exif.ExifSubIFDDirectory;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kbeanie.multipicker.api.CameraImagePicker;
import com.kbeanie.multipicker.api.ImagePicker;
import com.kbeanie.multipicker.api.Picker;
import com.kbeanie.multipicker.api.callbacks.ImagePickerCallback;
import com.kbeanie.multipicker.api.entity.ChosenImage;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsAttachmentSource;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsCons;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsEvent;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsKey;
import net.abaqus.mygeotracking.deviceagent.forms.FormExpandableListActivity;
import net.abaqus.mygeotracking.deviceagent.forms.FormsRefreshEvent;
import net.abaqus.mygeotracking.deviceagent.forms.FormsTable;
import net.abaqus.mygeotracking.deviceagent.notes.Attachments;
import net.abaqus.mygeotracking.deviceagent.notes.FormAttachment;
import net.abaqus.mygeotracking.deviceagent.notes.ImageAttachment;
import net.abaqus.mygeotracking.deviceagent.notes.ImageCompressUtil;
import net.abaqus.mygeotracking.deviceagent.qrcode.QRScannerActivity;
import net.abaqus.mygeotracking.deviceagent.ui.FormSubmitActivity;
import net.abaqus.mygeotracking.deviceagent.ui.SignatureActivity;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import io.codetail.animation.SupportAnimator;
import io.codetail.animation.ViewAnimationUtils;


public class HOSConfirmFragment extends Fragment {

    //Activity result codes
    final int QR_INTENT_REQUEST_CODE = 0;
    final int GALLERY_INTENT_REQUEST_CODE = 2;
    final int CAMERA_INTENT_REQUEST_CODE = 3;
    final int SIGNATURE_INTENT_REQUEST_CODE = 4;
    final int FORM_INTENT_REQUEST_CODE = 5;

    private static final int MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE = 201;
    private static final int MY_PERMISSIONS_REQUEST_CAMERA = 202;
    private static final int MY_PERMISSIONS_REQUEST_ACCESS_QRCAMERA = 203;
    private ImagePicker imagePicker;
    private CameraImagePicker cameraImagePicker;
    private String cameraPickerPath;

    private boolean IS_IT_FROM_CAMERA = false;

    List<FormsTable> formsTableArrayList = new ArrayList<>();

    private ArrayList<Attachments> attachmentsArrayList;

    private EditText compose_msg;
    private LinearLayout
            attachment_gallery_item,
            attachment_camera_item,
            attachment_signature_item,
            attachment_qr_item,
            attachment_form_item,
            main_view;

    private ImageView attachment_gallery_item_image,
            attachment_camera_item_image,
            attachment_signature_item_image;


    private ViewGroup mTagsContainer;
    private RelativeLayout sendButtonLayout;
    private LinearLayout mRevealView;
    private boolean hidden = true;


    private ViewGroup mPreviewContainer;
    private LinearLayout mPreview;

    private ContentValues values;
    private Uri imageUri;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        EventBus.getDefault().register(this);
        return inflater.inflate(R.layout.fragment_hos_confirm_notes, container, false);
    }


    public Intent getResultValues() {
        Intent i = getActivity().getIntent();
        String scanMessage = "", formResult = "", formUID = "";
       // Log.d("ATULST","ATULST"+attachmentsArrayList.size());
        for (int position = 0; position < attachmentsArrayList.size(); position++) {
            Attachments attachments = attachmentsArrayList.get(position);
            if (attachments.getAttachment_type() == Attachments.Attachment_Type.SCAN) {
                scanMessage = scanMessage + attachments.getText_value() + "|";
                //attachmentsArrayList.remove(position);
            }
        }
        List<Integer> removableIndexes = new ArrayList<>();

        for (int position = 0; position < attachmentsArrayList.size(); position++) {
            Attachments attachments = attachmentsArrayList.get(position);
            if (attachments.getAttachment_type() == Attachments.Attachment_Type.FORM) {
                FormAttachment formAttachment = attachments.getFormAttachment();
                formResult = formResult + formAttachment.getPostableData() + "|";
                formUID = formUID + formAttachment.getFdUID() + "|";
                removableIndexes.add(position);
            }
        }
       /* for (int position = 0; position < attachmentsArrayList.size(); position++) {
            for (int rPosition = 0; rPosition < removableIndexes.size(); rPosition++) {
                //if(removableIndexes.get(rPosition) == position)
                //attachmentsArrayList.remove(position);
            }
        }*/

        ArrayList<ImageAttachment> parcellingAttachments = new ArrayList<ImageAttachment>();
        //Log.d("IOATTASIZE","IOATTASIZE"+attachmentsArrayList.size());
        for (int position = 0; position < attachmentsArrayList.size(); position++) {
            Attachments attachments = attachmentsArrayList.get(position);
            if(attachments.getAttachment_type() == Attachments.Attachment_Type.IMAGE || attachments.getAttachment_type() == Attachments.Attachment_Type.SIGNATURE) {
                ImageAttachment imageAttachment = attachments.getImageAttachment();

                parcellingAttachments.add(imageAttachment);

                new PushAttachmentTODBTask(imageAttachment, getActivity().getBaseContext()).execute();
            }
        }

        //Log.d("PARCELATTSIZE","PARCELATTSIZE"+parcellingAttachments.size());

        i.putParcelableArrayListExtra("attach", parcellingAttachments);

        //i.putParcelableArrayListExtra("attach", parcellingAttachments);

        i.putExtra("message", compose_msg.getText().toString());
        i.putExtra("scan", scanMessage);
        i.putExtra("form", formResult);
        i.putExtra("fdUID", formUID);
        return i;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        attachmentsArrayList = new ArrayList<>();
        formsTableArrayList = getFormsData();
        init();
    }


    private void init() {
        initViews();
    }

    public static List<FormsTable> getFormsData() {
        return new Select()
                .from(FormsTable.class)
                .execute();
    }

    private void initViews() {
        mRevealView = (LinearLayout) getView().findViewById(R.id.reveal_items);
        mRevealView.setVisibility(View.GONE);
        AttachmentClickListener attachmentClickListener = new AttachmentClickListener();
        compose_msg = (EditText) getView().findViewById(R.id.detail_content);
        ImageView attachment_button = (ImageView) getView().findViewById(R.id.btn_qr_code);

        attachment_gallery_item = (LinearLayout) getView().findViewById(R.id.attachment_gallery_item);
        attachment_camera_item = (LinearLayout) getView().findViewById(R.id.attachment_camera_item);
        attachment_signature_item = (LinearLayout) getView().findViewById(R.id.attachment_signature_item);
        attachment_qr_item = (LinearLayout) getView().findViewById(R.id.attachment_qr_item);
        attachment_form_item = (LinearLayout) getView().findViewById(R.id.attachment_form_item);
        //attachment_customer_item = (LinearLayout) getView().findViewById(R.id.attachment_customers_item);

        attachment_gallery_item_image = (ImageView) getView().findViewById(R.id.attachment_gallery_item_image);
        attachment_camera_item_image = (ImageView) getView().findViewById(R.id.attachment_camera_item_image);
        attachment_signature_item_image = (ImageView) getView().findViewById(R.id.attachment_signature_item_image);

        //attachment_customer_item.setVisibility(View.GONE);

        boolean formsAvailable = formsTableArrayList.size() > 0;
        if(formsAvailable)
            attachment_form_item.setVisibility(View.VISIBLE);
        else
            attachment_form_item.setVisibility(View.GONE);

        main_view = (LinearLayout) getView().findViewById(R.id.detail_root);
        main_view.setAlpha(1);
        main_view.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mRevealView.getVisibility() == View.VISIBLE) {
                    main_view.setAlpha(0.7f);
                    mRevealView.setVisibility(View.VISIBLE);
                    revealAnimationForAttachment();
                }
            }
        });

        compose_msg.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mRevealView.getVisibility() == View.VISIBLE) {
                    main_view.setAlpha(0.7f);
                    mRevealView.setVisibility(View.VISIBLE);
                    revealAnimationForAttachment();
                }
            }
        });
        attachment_gallery_item.setOnClickListener(attachmentClickListener);
        attachment_camera_item.setOnClickListener(attachmentClickListener);
        attachment_signature_item.setOnClickListener(attachmentClickListener);
        attachment_qr_item.setOnClickListener(attachmentClickListener);
        attachment_form_item.setOnClickListener(attachmentClickListener);


        sendButtonLayout = (RelativeLayout) getView().findViewById(R.id.btn_send_input_layout);
        sendButtonLayout.setVisibility(View.INVISIBLE);


        mPreview = (LinearLayout) getView().findViewById(R.id.session_tags);
        mPreviewContainer = (ViewGroup) getView().findViewById(R.id.session_tags_container);
        mPreviewContainer.setVisibility(View.GONE);

        attachment_button.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
        /*Intent intent = new Intent(getActivity(), QRScannerActivity.class);
            intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
            startActivityForResult(intent, 0);*/
                main_view.setAlpha(0.7f);
                mRevealView.setVisibility(View.VISIBLE);
                revealAnimationForAttachment();
            }
        });


    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        renderAttachments();
        main_view.setAlpha(0.7f);
        mRevealView.setVisibility(View.VISIBLE);
        if(resultCode != QRScannerActivity.RESULT_PERMISSION_DENIED)
        revealAnimationForAttachment();
        if (requestCode == QR_INTENT_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {

                String contents = intent.getStringExtra("SCAN_RESULT");
                // Handle successful scan
                Attachments attachments = new Attachments();
                attachments.setAttachment_type(Attachments.Attachment_Type.SCAN);
                attachments.setText_value(contents);
                attachments.setAttachmentID(attachmentsArrayList.size());
                final NestedScrollView chipViewText = (NestedScrollView) getView().inflate(getActivity(), R.layout.include_text_preview, null);
                final TextView attachmentText = (TextView) chipViewText.findViewById(R.id.tvAttachmentContent);
                attachmentText.setText(contents);
                attachmentText.setTag(attachmentsArrayList.size());
                attachmentsArrayList.add(attachments);
                ImageView attachmentClose = (ImageView) chipViewText.findViewById(R.id.ivAttacheTextClose);
                attachmentClose.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mPreview.removeView(chipViewText);
                        removeScanAttachmentFromList((Integer) attachmentText.getTag());
                        if (mPreview.getChildCount() <= 0)
                            closeAttachments();
                    }
                });
                mPreviewContainer.setVisibility(View.VISIBLE);
                mPreview.addView(chipViewText);

            } else if (resultCode == Activity.RESULT_CANCELED) {
                // Handle cancel
                Log.i("TAG", "Scan unsuccessful");
            }
        }else if(requestCode == Picker.PICK_IMAGE_DEVICE && resultCode == Activity.RESULT_OK) {
            if(imagePicker == null) {
                imagePicker = new ImagePicker(this);
                imagePicker.setImagePickerCallback(new ImagePickingCallback());
            }
            Snackbar.make(getView(),"Attaching...Please wait.",Snackbar.LENGTH_SHORT).show();
            imagePicker.submit(intent);
        } else if (requestCode == GALLERY_INTENT_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            super.onActivityResult(requestCode, resultCode, intent);
        } else if(requestCode == Picker.PICK_IMAGE_CAMERA && resultCode == Activity.RESULT_OK) {
            if(cameraImagePicker == null) {
                cameraImagePicker = new CameraImagePicker(this);
                cameraImagePicker.setImagePickerCallback(new ImagePickingCallback());
                cameraImagePicker.reinitialize(cameraPickerPath);
            }
            Snackbar.make(getView(),"Attaching...Please wait.",Snackbar.LENGTH_SHORT).show();
            cameraImagePicker.submit(intent);
        }else if (requestCode == CAMERA_INTENT_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            super.onActivityResult(requestCode, resultCode, intent);
        }else if (requestCode == SIGNATURE_INTENT_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            final RelativeLayout chipView = (RelativeLayout) getView().inflate(getActivity(), R.layout.include_image_preview, null);
            final ImageView attachmentImage = (ImageView) chipView.findViewById(R.id.ivAttachment);
            attachmentImage.setTag(attachmentsArrayList.size());
            ImageView attachmentClose = (ImageView) chipView.findViewById(R.id.ivAttachImageClose);
            attachmentClose.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {

                    mPreview.removeView(chipView);
                    removeScanAttachmentFromList((Integer) attachmentImage.getTag());
                    attachment_signature_item.setEnabled(true);
                    attachment_signature_item_image.setImageResource(R.drawable.ic_attachment_signature);

                    if (mPreview.getChildCount() <= 0)
                        closeAttachments();
                }
            });

            Bitmap bitmap;
            try {
                Bundle extras = intent.getExtras();
                String imagePath = extras.get("signature_path").toString();
                String fileName = extras.get("file_name").toString();
                Attachments attachments = new Attachments();
                attachments.setAttachment_type(Attachments.Attachment_Type.SIGNATURE);
                attachments.setImageAttachment(loadImageFromStorage(imagePath, fileName, attachmentImage));
                attachments.setAttachmentID(attachmentsArrayList.size());
                attachmentsArrayList.add(attachments);
            } catch (Exception e) {
                e.printStackTrace();
            }
            mPreviewContainer.setVisibility(View.VISIBLE);
            mPreview.addView(chipView);
            super.onActivityResult(requestCode, resultCode, intent);
        } else if (requestCode == FORM_INTENT_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            String contents = intent.getStringExtra("form_data");
            String fdUID = intent.getStringExtra("fdUID");
            String formId = intent.getStringExtra("formId");
            // Handle successful scan
            final NestedScrollView chipViewText = (NestedScrollView) getView().inflate(getActivity(), R.layout.include_text_preview, null);
            final TextView attachmentText = (TextView) chipViewText.findViewById(R.id.tvAttachmentContent);
            String formName = "";
            for(FormsTable formsTable : formsTableArrayList) {
                if(formId.equals(formsTable.formId)) {
                    formName = formsTable.formName;
                    break;
                }
            }
            attachmentText.setText(formName);
            attachmentText.setTag(attachmentsArrayList.size());

            Attachments attachments = new Attachments();
            attachments.setAttachment_type(Attachments.Attachment_Type.FORM);
            FormAttachment formAttachment = new FormAttachment(contents, fdUID);
            attachments.setFormAttachment(formAttachment);
            attachments.setAttachmentID(attachmentsArrayList.size());
            attachmentsArrayList.add(attachments);

            ImageView attachmentClose = (ImageView) chipViewText.findViewById(R.id.ivAttacheTextClose);
            attachmentClose.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    mPreview.removeView(chipViewText);
                    removeScanAttachmentFromList((Integer) attachmentText.getTag());
                    //attachment_form_item.setEnabled(true);
                    //attachment_form_item_image.setImageResource(R.drawable.ic_action_form);


                    if (mPreview.getChildCount() <= 0)
                        closeAttachments();
                }
            });


            //attachment_form_item.setEnabled(false);
            //attachment_form_item_image.setImageResource(R.drawable.ic_action_form_disabled);

            mPreviewContainer.setVisibility(View.VISIBLE);
            mPreview.addView(chipViewText);
            super.onActivityResult(requestCode, resultCode, intent);


        }
        if (mPreview.getChildCount() <= 0)
            closeAttachments();
    }


 private ImageAttachment loadImageFromStorage(String path, String fileName, ImageView imageView) {
        ImageAttachment imageAttachment = new ImageAttachment();
        try {
            File f = new File(path, fileName);
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            imageView.setImageBitmap(b);
            attachment_signature_item.setEnabled(false);
            attachment_signature_item_image.setImageResource(R.drawable.ic_attachment_signature_disabled);
            //ImageAttachment(String uniqueID, String size, String type, String md5, String path, String name)
            String dateString = "";
            try {
                dateString = CurrentDateAndTime.getDateTimeWaterMark(new SimpleDateFormat(
                        "EEE MMM dd yyyy HH:mm:ss zZ", Locale.getDefault()));
            } catch (Exception e) {
            }

            imageAttachment = new ImageAttachment(UUID.randomUUID().toString(), b.getByteCount() + "", "IMAGE", "", path, fileName, dateString);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return imageAttachment;
    }

    public boolean isClosable() {
        if(compose_msg.getText().toString().isEmpty() && mPreview.getChildCount() <= 0)
            return true;
        else
            return false;
    }



    public void revealAnimationForAttachment() {
        int cx = (mRevealView.getLeft() + mRevealView.getRight());
//                int cy = (mRevealView.getTop() + mRevealView.getBottom())/2;
        int cy = mRevealView.getTop();

        int radius = Math.max(mRevealView.getWidth(), mRevealView.getHeight());

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {


            SupportAnimator animator =
                    ViewAnimationUtils.createCircularReveal(mRevealView, cx, cy, 0, radius);
            animator.setInterpolator(new AccelerateDecelerateInterpolator());
            animator.setDuration(800);

            SupportAnimator animator_reverse = animator.reverse();

            if (hidden) {
                mRevealView.setVisibility(View.VISIBLE);
                animator.start();
                hidden = false;
            } else {
                animator_reverse.addListener(new SupportAnimator.AnimatorListener() {
                    @Override
                    public void onAnimationStart() {

                    }

                    @Override
                    public void onAnimationEnd() {
                        main_view.setAlpha(1);
                        mRevealView.setVisibility(View.GONE);
                        hidden = true;

                    }

                    @Override
                    public void onAnimationCancel() {

                    }

                    @Override
                    public void onAnimationRepeat() {

                    }
                });
                animator_reverse.start();

            }
        } else {
            if (hidden) {
//                Animator anim = android.view.ViewAnimationUtils.createCircularReveal(mRevealView, cx, cy, 0, radius);
//                mRevealView.setVisibility(View.VISIBLE);
//                anim.start();
                hidden = false;

            } else {
                Animator anim = android.view.ViewAnimationUtils.createCircularReveal(mRevealView, cx, cy, radius, 0);
                anim.addListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        main_view.setAlpha(1);
                        mRevealView.setVisibility(View.GONE);
                        hidden = true;
                    }
                });
                anim.start();

            }
        }
    }


    class AttachmentClickListener implements OnClickListener {

        @Override
        public void onClick(View view) {

            switch (view.getId()) {

                case R.id.attachment_gallery_item:
                    launchGalleryImageCaptureIntent();
                    break;

                case R.id.attachment_camera_item:
                    checkForCameraPermission();
                    break;

                case R.id.attachment_signature_item:
                    launchSigantureIntent();
                    break;

                case R.id.attachment_qr_item:
                    checkQRScanCameraPermission();
                    break;
                case R.id.attachment_form_item:

                    FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(getActivity());
                    Bundle bundle = new Bundle();
                    bundle.putString(AnalyticsKey.EVENT_STATE, AnalyticsCons.ITEM_CLICKED);
                    bundle.putString(AnalyticsKey.EVENT_SOURCE, AnalyticsAttachmentSource.SOURCE_HOS_SCREEN);
                    mFirebaseAnalytics.logEvent(AnalyticsEvent.FORM_ATTACHMENT_EVENT, bundle);



                    Intent intent = new Intent(getActivity(), FormExpandableListActivity.class);
                    startActivityForResult(intent, FORM_INTENT_REQUEST_CODE);

                //    launchFormActivity();

                    //if (NetworkConnectionInfo.isOnline(getActivity()))
                        //launchFormActivity();
                    //else
                        //Snackbar.make(view, "Internet disabled.", Snackbar.LENGTH_SHORT).show();

                    break;

            }
        }
    }


    private void launchFormActivity() {
        final List<String> formsList = new ArrayList<>();

        for(FormsTable formsTable : formsTableArrayList) {
            formsList.add(formsTable.formName);
        }
        if(formsList.size() == 1) {
            Intent formIntent = new Intent(getActivity(), FormSubmitActivity.class);
            formIntent.putExtra("formId", formsTableArrayList.get(0).formId);
            startActivityForResult(formIntent, FORM_INTENT_REQUEST_CODE);
        }else {
            new MaterialDialog.Builder(getActivity())
                    .items(formsList)
                    .title("Select Form:")
                    .itemsCallback(new MaterialDialog.ListCallback() {
                        @Override
                        public void onSelection(MaterialDialog dialog, View view, int which, CharSequence text) {
                            Intent formIntent = new Intent(getActivity(), FormSubmitActivity.class);
                            formIntent.putExtra("formId", formsTableArrayList.get(which).formId);
                            startActivityForResult(formIntent, FORM_INTENT_REQUEST_CODE);
                        }
                    })
                    .show();
        }
    }

    private void launchGalleryImageCaptureIntent() {
/*
        Intent intent = new Intent();
        intent.setType("image*/
/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, GALLERY_INTENT_REQUEST_CODE);
*/




        if (ContextCompat.checkSelfPermission(getActivity( ),
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Storage Permission Denied");
                builder.setMessage("Without Storage permission the application will not be able to attach image through Camera. Are you sure you want to deny this permission?");
                builder.setPositiveButton("I'M SURE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                builder.setNegativeButton("RE-TRY", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityCompat.requestPermissions(getActivity(),
                                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE);
                    }
                });
                builder.show();
                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {

                // No explanation needed, we can request the permission.


                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE);

                // MY_PERMISSIONS_REQUEST_ACCESS_CAMERA is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
            //Toast.makeText(getActivity(), "Storage Permission denied", Toast.LENGTH_SHORT).show();
        }else{
            imagePicker = new ImagePicker(this);
            IS_IT_FROM_CAMERA = false;
            imagePicker.setImagePickerCallback(new ImagePickingCallback());
            imagePicker.pickImage();
        }

    }
    class ImagePickingCallback implements ImagePickerCallback {
        @Override
        public void onImagesChosen(List<ChosenImage> images) {
            // Display images
            try {
                if (images.size() <= 0) {
                    return;
                }

                ChosenImage chosenImage = images.get(0);

                final RelativeLayout chipView = (RelativeLayout) getView().inflate(getActivity(), R.layout.include_image_preview, null);
                final ImageView attachmentImage = (ImageView) chipView.findViewById(R.id.ivAttachment);
                attachmentImage.setTag(attachmentsArrayList.size());
                final ImageView attachmentClose = (ImageView) chipView.findViewById(R.id.ivAttachImageClose);
                attachmentClose.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mPreview.removeView(chipView);
                        removeScanAttachmentFromList((Integer) attachmentImage.getTag());
                        int imageAttachedCount = 0;
                        for(Attachments attachments : attachmentsArrayList) {
                            if (attachments.getAttachment_type() == Attachments.Attachment_Type.IMAGE) {
                                imageAttachedCount ++;
                            }
                        }
                        if(imageAttachedCount < 3) {
                            attachment_gallery_item.setEnabled(true);
                            attachment_camera_item.setEnabled(true);
                            attachment_gallery_item_image.setImageResource(R.drawable.ic_attachment_picture);
                            attachment_camera_item_image.setImageResource(R.drawable.ic_attachment_camera);
                        }

                        if (mPreview.getChildCount() <= 0)
                            closeAttachments();
                    }
                });

                Bitmap bitmap = null;
                try {

                    bitmap = BitmapFactory.decodeFile(chosenImage.getThumbnailPath());
                    //if(bitmap.getByteCount() < Attachments.MAX_ATTACHMENT_SIZE) {
                    attachmentImage.setImageBitmap(bitmap);
                    //setPic(stream, attachmentImage);

                    int imageAttachedCount = 0;
                    for(Attachments attachments : attachmentsArrayList) {
                        if (attachments.getAttachment_type() == Attachments.Attachment_Type.IMAGE) {
                            imageAttachedCount ++;
                        }
                    }
                    if(imageAttachedCount >= 2) {
                        attachment_gallery_item.setEnabled(false);
                        attachment_camera_item.setEnabled(false);
                        attachment_gallery_item_image.setImageResource(R.drawable.ic_attachment_picture_disabled);
                        attachment_camera_item_image.setImageResource(R.drawable.ic_attachment_camera_disabled);
                    }
                    //}
                } catch (Exception e) {
                    e.printStackTrace();
                }

                Attachments attachments = new Attachments();
                attachments.setAttachment_type(Attachments.Attachment_Type.IMAGE);
                ImageAttachment imageAttachment = new ImageAttachment();
                //if(bitmap != null && bitmap.getByteCount() < Attachments.MAX_ATTACHMENT_SIZE) {
                File jpegFile = new File(chosenImage.getOriginalPath());
                Metadata metadata = ImageMetadataReader.readMetadata(jpegFile);

                /*for (Directory directory : metadata.getDirectories()) {
                    for (Tag tag : directory.getTags()) {
                        System.out.println("TAG VALUES : "+tag);
                    }
                }*/

                Date createdDate = null;
                try {
                    // obtain the Exif directory
                    ExifSubIFDDirectory directory
                            = metadata.getFirstDirectoryOfType(ExifSubIFDDirectory.class);

                    // query the tag's value
                    createdDate = directory.getDate(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL);
                    Log.d("CURENDAT","CURENDAT"+createdDate);
                }catch (Exception e) {e.printStackTrace();}

                String dateString = "";
                if(createdDate == null || IS_IT_FROM_CAMERA) {
                    dateString = CurrentDateAndTime.getDateTimeWaterMark(new SimpleDateFormat(
                            "EEE MMM dd yyyy HH:mm:ss zZ", Locale.getDefault()));
                } else {
                    try {
                        dateString = new SimpleDateFormat(
                                "EEE MMM dd yyyy HH:mm:ss zZ").format(createdDate);
                    } catch (Exception e) {
                    }
                }



                if (bitmap != null)
                    imageAttachment = new ImageAttachment(UUID.randomUUID().toString(), bitmap.getByteCount() + "", "IMAGE", "", "", "", dateString);

                ImageCompressUtil.compressImage(getActivity(), chosenImage.getOriginalPath(), imageAttachment);
                //ShrinkBitmap(intent.getDataString(),100, 100, imageAttachment);
                //saveImageAttachmentinFile(bitmap, imageAttachment);
                attachments.setImageAttachment(imageAttachment);
                attachments.setAttachmentID(attachmentsArrayList.size());

                attachmentsArrayList.add(attachments);

                mPreviewContainer.setVisibility(View.VISIBLE);
                mPreview.addView(chipView);
			/*}else
			{
				Toast.makeText(getActivity(), "File size limit cannot exceed 3 MB", Toast.LENGTH_SHORT).show();
			}*/

            }catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onError(String message) {
            // Do error handling
        }
    }
    private void launchCameraImageCaptureIntent() {
        /*SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
        Date now = new Date();
        String fileName = "image_attachment_" + formatter.format(now) + ".jpg";
		*//*takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, fileName);
		if (takePictureIntent.resolveActivity(getActivity().getPackageManager()) != null) {
			startActivityForResult(takePictureIntent, CAMERA_INTENT_REQUEST_CODE);
		}*//*


        values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, fileName);
        values.put(MediaStore.Images.Media.DESCRIPTION, "Image Attachment");
        imageUri = getActivity().getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE_SECURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivityForResult(intent, CAMERA_INTENT_REQUEST_CODE);
        }*/
        cameraImagePicker = new CameraImagePicker(this);
        IS_IT_FROM_CAMERA = true;
        cameraImagePicker.shouldGenerateMetadata(true);
        cameraImagePicker.shouldGenerateThumbnails(true);
        cameraImagePicker.setImagePickerCallback(new ImagePickingCallback());
        cameraPickerPath = cameraImagePicker.pickImage();
    }

    private void launchSigantureIntent() {
        Intent takePictureIntent = new Intent(getActivity(), SignatureActivity.class);
        if (takePictureIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, SIGNATURE_INTENT_REQUEST_CODE);
        }

    }

    private void launchQRIntent() {
        Intent intent = new Intent(getActivity(), QRScannerActivity.class);
        intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
        startActivityForResult(intent, QR_INTENT_REQUEST_CODE);
    }

    private void renderAttachments() {
        mTagsContainer = (ViewGroup) getView().findViewById(R.id.session_tags_container);
        mTagsContainer.setVisibility(View.VISIBLE);

    }

    private void closeAttachments() {

        mTagsContainer.setVisibility(View.GONE);

    }


    private void removeScanAttachmentFromList(int id) {
        for (int i = 0; i < attachmentsArrayList.size(); i++) {
            Attachments attachments = attachmentsArrayList.get(i);
            if (attachments.getAttachmentID() == id)
                attachmentsArrayList.remove(i);
        }
    }


    private void checkForStoragePermission(){
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Storage Permission Denied");
                builder.setMessage("Without Storage permission the application will not be able to attach image through Camera. Are you sure you want to deny this permission?");
                builder.setPositiveButton("I'M SURE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                builder.setNegativeButton("RE-TRY", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityCompat.requestPermissions(getActivity(),
                                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE);
                    }
                });
                builder.show();
                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE);

                // MY_PERMISSIONS_REQUEST_ACCESS_CAMERA is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
            //Toast.makeText(getActivity(), "Storage Permission denied", Toast.LENGTH_SHORT).show();
        }else{
            launchCameraImageCaptureIntent();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        launchGalleryImageCaptureIntent();
                } else {
                    //Toast.makeText(getActivity(), "Storage Permission denied", Toast.LENGTH_SHORT).show();
                }
                return;
            }
            case MY_PERMISSIONS_REQUEST_CAMERA: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    checkForStoragePermission();
                } else {
                    //Toast.makeText(getActivity(), "Camera Permission denied", Toast.LENGTH_SHORT).show();
                }
                return;
            }
            case MY_PERMISSIONS_REQUEST_ACCESS_QRCAMERA: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    launchQRIntent();
                } else {
                    //Toast.makeText(getActivity(), "Camera Permission denied", Toast.LENGTH_SHORT).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }



    private void checkForCameraPermission(){
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    Manifest.permission.CAMERA)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Camera Permission Denied");
                builder.setMessage("Without Camera permission the application will not be able to capture camera attachments. Are you sure you want to deny this permission?");
                builder.setPositiveButton("I'M SURE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.setNegativeButton("RE-TRY", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityCompat.requestPermissions(getActivity(),
                                new String[]{Manifest.permission.CAMERA},
                                MY_PERMISSIONS_REQUEST_CAMERA);
                    }
                });
                builder.show();
                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.CAMERA},
                        MY_PERMISSIONS_REQUEST_CAMERA);

                // MY_PERMISSIONS_REQUEST_ACCESS_CAMERA is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
            //Toast.makeText(getActivity(), "Camera Permission denied", Toast.LENGTH_SHORT).show();
        }else{
            checkForStoragePermission();
        }
    }



    private void checkQRScanCameraPermission(){
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                    Manifest.permission.CAMERA)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Camera Permission Denied");
                builder.setMessage("Without Camera permission the application will not be able to scan QR Codes. Are you sure you want to deny this permission?");
                builder.setPositiveButton("I'M SURE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                builder.setNegativeButton("RE-TRY", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityCompat.requestPermissions(getActivity(),
                                new String[]{Manifest.permission.CAMERA},
                                MY_PERMISSIONS_REQUEST_ACCESS_QRCAMERA);
                    }
                });
                builder.show();

            } else {

                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.CAMERA},
                        MY_PERMISSIONS_REQUEST_ACCESS_QRCAMERA);
            }
            //Toast.makeText(getActivity(), "Camera Permission denied", Toast.LENGTH_SHORT).show();
        }else{
            launchQRIntent();
        }
    }


//    @Subscribe
//    public void getMessage(Events.FragmentActivityMessage activityFragmentMessage) {
//
//        formsTableArrayList = activityFragmentMessage.getFormArrayList();
//    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // unregister the registered event.
        //GlobalBus.getsBus().unregister(this);
        EventBus.getDefault().unregister(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(FormsRefreshEvent event) {
        formsTableArrayList = getFormsData();
    };

}



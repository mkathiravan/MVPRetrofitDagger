package net.abaqus.mygeotracking.deviceagent.myteam;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.ui.NotesActivity;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import java.util.ArrayList;


/**
 * Created by bm on 2/6/15.
 */
public class MyTeamMapFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener{

    MapView mapView;
    GoogleMap map;
    RelativeLayout frameLayout;
    FloatingActionButton fab;
    public static final String ARG_POSITION = "arg_position";
    private int MAP_POSITION = -1;
    public static OnMenuMAPItemClicked menuMapCallback;
    private ProgressDialog progress;
    TextView tv_deviceDesc, tv_deviceNumber,tv_group_name, tv_address, tv_updateTime, tv_lastHOSState, tv_updateTimeText;
    ArrayList<MyTeamData> myTeamDataArrayList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        setHasOptionsMenu(true);
        progress = new ProgressDialog(getContext());
        progress.setMessage("Refreshing...");
        progress.setCancelable(false);
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);

        View v = inflater.inflate(R.layout.myteam_map_fragment, container, false);
        getBundleToList();
        // Gets the MapView from the XML layout and creates it
        mapView = (MapView) v.findViewById(R.id.mapview);
        initDetailView(v);
        initMap(savedInstanceState);
        return v;
    }

    private void initDetailView(View v) {
        frameLayout = (RelativeLayout) v.findViewById(R.id.flashbarlayout);
        fab = (FloatingActionButton) v.findViewById(R.id.fab);
        tv_deviceDesc = (TextView) v.findViewById(R.id.map_detail_tv_device_desc);
        tv_deviceNumber = (TextView) v.findViewById(R.id.map_detail_device_id);
        tv_group_name = (TextView) v.findViewById(R.id.map_detail_group_name);
        tv_address = (TextView) v.findViewById(R.id.map_detail_address);
        tv_lastHOSState = (TextView) v.findViewById(R.id.map_detail_last_hos_status);
        tv_updateTime = (TextView) v.findViewById(R.id.map_detail_updated_time);
        tv_updateTimeText = (TextView) v.findViewById(R.id.map_update_time_text_top);
        SharedPreferences prefs = getActivity().getSharedPreferences(MDACons.PREFS,0);
        tv_updateTimeText.setText("Last Updated : "+prefs.getString(MDACons.MY_TEAM_UPDATED_TIME,""));
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Snackbar.make(mapView, "FAB Clicked", Snackbar.LENGTH_SHORT).show();
                Intent notes_intent = new Intent(getActivity(), NotesActivity.class);
                notes_intent.putExtra(NotesActivity.TO_DEVICE_STRING_EXTRA, tv_deviceNumber.getText());
                startActivity(notes_intent);
            }
        });
    }

    private void initMap(Bundle savedInstanceState) {

        mapView.onCreate(savedInstanceState);
        // Gets to GoogleMap from the MapView and does initialization stuff
        if(mapView != null)
            mapView.getMapAsync(new OnMapReadyCallback() {
                @Override
                public void onMapReady(GoogleMap googleMap) {
                    map = googleMap;
                    MapsInitializer.initialize(getActivity());
                    // Updates the location and zoom of the MapView
                    if(MAP_POSITION != -1) {
                        map.addMarker(new MarkerOptions()
                                .position(new LatLng(Double.parseDouble(myTeamDataArrayList.get(MAP_POSITION).getLatitude()), Double.parseDouble(myTeamDataArrayList.get(MAP_POSITION).getLongitude()))));
                        map.setOnMarkerClickListener(MyTeamMapFragment.this);


                        tv_deviceDesc.setText(myTeamDataArrayList.get(MAP_POSITION).getDeviceDescription().replace("\n", ""));
                        tv_deviceNumber.setText(myTeamDataArrayList.get(MAP_POSITION).getDeviceNumber().replace("\n", ""));
                        tv_group_name.setText("(" + myTeamDataArrayList.get(MAP_POSITION).getGroupName().replace("\n", "") + ")");
                        tv_address.setText(myTeamDataArrayList.get(MAP_POSITION).getAddressString().replace("\n", ""));
                        tv_lastHOSState.setText("Timeclock status: "+myTeamDataArrayList.get(MAP_POSITION).getLastHosStage().replace("\n", ""));
                        tv_updateTime.setText("Last Updated: "+myTeamDataArrayList.get(MAP_POSITION).getUpdatedTime().replace("\n",""));

                    /*frameLayout.setVisibility(View.VISIBLE);
                    fab.setVisibility(View.VISIBLE);
                    frameLayout.animate()
                            .translationY(0)
                            .alpha(1.0f);
                    fab.setVisibility(View.VISIBLE);*/
                        CameraUpdate cameraUpdate;
                        cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(Double.parseDouble(myTeamDataArrayList.get(MAP_POSITION).getLatitude()), Double.parseDouble(myTeamDataArrayList.get(MAP_POSITION).getLongitude())), 15);
                        map.animateCamera(cameraUpdate);

                    }else{
                        MyTeamData myTeamData;
                        ArrayList<Marker> markers = new ArrayList<>();
                        Marker marker;
                        boolean anythingFound = false;
                        for(int i = 0; i < myTeamDataArrayList.size(); i++){
                            myTeamData = myTeamDataArrayList.get(i);
                            if(myTeamData.isChecked()){
                                marker  = map.addMarker(new MarkerOptions()
                                        .position(new LatLng(Double.parseDouble(myTeamDataArrayList.get(i).getLatitude()), Double.parseDouble(myTeamDataArrayList.get(i).getLongitude()))));
                                markers.add(marker);
                                map.setOnMarkerClickListener(MyTeamMapFragment.this);
                                anythingFound = true;
                            }
                        }

                        if(!anythingFound){
                            for(int i = 0; i < myTeamDataArrayList.size(); i++){
                                marker = map.addMarker(new MarkerOptions()
                                        .position(new LatLng(Double.parseDouble(myTeamDataArrayList.get(i).getLatitude()), Double.parseDouble(myTeamDataArrayList.get(i).getLongitude()))));
                                markers.add(marker);
                                map.setOnMarkerClickListener(MyTeamMapFragment.this);
                            }
                        }

                        LatLngBounds.Builder builder = new LatLngBounds.Builder();
                        for (Marker markerOne : markers) {
                            builder.include(markerOne.getPosition());
                        }
                        LatLngBounds bounds = builder.build();
                        //MapsInitializer.initialize(this.getActivity());
                        // Updates the location and zoom of the MapView
                        CameraUpdate cameraUpdate;
                        cameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds, 10);
                        map.animateCamera(cameraUpdate);
                    }

                /*map.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
                    @Override
                    public void onMapClick(LatLng latLng) {
                        if(frameLayout.getVisibility() != View.GONE || frameLayout.getTranslationY() != 450){
                            frameLayout.animate()
                                    .translationY(450)
                                    .alpha(1.0f);
                            fab.setVisibility(View.GONE);
                        }
                    }
                });*/

                    //mapView.getMapAsync(this);

                }
            });
        else
            getActivity().finish();
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    private void getBundleToList() {
        try{
            // Get the Bundle Object
            Bundle bundleObject = getActivity().getIntent().getExtras();
            if(bundleObject != null) {
                if (bundleObject.getInt(ARG_POSITION) == -1) {
                    myTeamDataArrayList = (ArrayList<MyTeamData>) bundleObject.getSerializable(MyTeamActivity.MY_TEAM_BUNDLE_LIST);
                    MAP_POSITION = -1;
                } else {
                    myTeamDataArrayList = (ArrayList<MyTeamData>) bundleObject.getSerializable(MyTeamActivity.MY_TEAM_BUNDLE_LIST);
                    MAP_POSITION = bundleObject.getInt(ARG_POSITION);
                }
            }
            // Get ArrayList Bundle
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    public int getMyTeamDataArrayListCount() {
        if(myTeamDataArrayList != null)
            return myTeamDataArrayList.size();
        else
            return 0;
    }

    public void clearMyTeamDataArrayList(){if(myTeamDataArrayList != null)myTeamDataArrayList.clear();}
    public void updateMapView(){}
    public void updateMapViewItemChecked(int position){

        if(myTeamDataArrayList.get(position).isChecked())
            myTeamDataArrayList.get(position).setChecked(false);
        else
            myTeamDataArrayList.get(position).setChecked(true);
    }
    public void updateMapView(int position){

        /*if(myTeamDataArrayList == null)
            getBundleToList();*/
        //initMap(null);
        MapsInitializer.initialize(this.getActivity());
        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(new LatLng(12.65487, 78.235656), 10);
        map.animateCamera(cameraUpdate);
    }

    @Override
    public void onResume() {
        mapView.onResume();
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        if(MAP_POSITION != -1) {
            map.addMarker(new MarkerOptions()
                    .position(new LatLng(Double.parseDouble(myTeamDataArrayList.get(MAP_POSITION).getLatitude()), Double.parseDouble(myTeamDataArrayList.get(MAP_POSITION).getLongitude()))));
            map.setOnMarkerClickListener(this);


            tv_deviceDesc.setText(myTeamDataArrayList.get(MAP_POSITION).getDeviceDescription().replace("\n", ""));
            tv_deviceNumber.setText(myTeamDataArrayList.get(MAP_POSITION).getDeviceNumber().replace("\n", ""));
            tv_group_name.setText("(" + myTeamDataArrayList.get(MAP_POSITION).getGroupName().replace("\n", "") + ")");
            tv_address.setText(myTeamDataArrayList.get(MAP_POSITION).getAddressString().replace("\n", ""));
            tv_lastHOSState.setText(myTeamDataArrayList.get(MAP_POSITION).getLastHosStage().replace("\n", ""));
            tv_updateTime.setText(myTeamDataArrayList.get(MAP_POSITION).getUpdatedTime().replace("\n",""));

            frameLayout.setVisibility(View.VISIBLE);
            fab.setVisibility(View.VISIBLE);
            frameLayout.animate()
                    .translationY(0)
                    .alpha(1.0f);
            fab.setVisibility(View.VISIBLE);
        }else{
            MyTeamData myTeamData;
            ArrayList<Marker> markers = new ArrayList<>();
            Marker marker;
            boolean anythingFound = false;
            for(int i = 0; i < myTeamDataArrayList.size(); i++){
                myTeamData = myTeamDataArrayList.get(i);
                if(myTeamData.isChecked()){
                    marker  = map.addMarker(new MarkerOptions()
                            .position(new LatLng(Double.parseDouble(myTeamDataArrayList.get(i).getLatitude()), Double.parseDouble(myTeamDataArrayList.get(i).getLongitude()))));
                    markers.add(marker);
                    map.setOnMarkerClickListener(this);
                    anythingFound = true;
                }
            }

            if(!anythingFound){
                for(int i = 0; i < myTeamDataArrayList.size(); i++){
                    marker = map.addMarker(new MarkerOptions()
                            .position(new LatLng(Double.parseDouble(myTeamDataArrayList.get(i).getLatitude()), Double.parseDouble(myTeamDataArrayList.get(i).getLongitude()))));
                    markers.add(marker);
                    map.setOnMarkerClickListener(this);
                }
            }

            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            for (Marker markerOne : markers) {
                builder.include(markerOne.getPosition());
            }
            LatLngBounds bounds = builder.build();
            MapsInitializer.initialize(this.getActivity());
            // Updates the location and zoom of the MapView
            CameraUpdate cameraUpdate;
            cameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds, 0);
            map.animateCamera(cameraUpdate);
        }
    }


    @Override
    public boolean onMarkerClick(Marker marker) {


        if(frameLayout.getVisibility() == View.GONE || frameLayout.getTranslationY() == 350){

            if(MAP_POSITION == -1){
                MyTeamData myTeamData;
                for (int i = 0; i < myTeamDataArrayList.size(); i++) {
                    myTeamData = myTeamDataArrayList.get(i);
                    if(marker.getPosition().equals(new LatLng(Double.parseDouble(myTeamData.getLatitude()), Double.parseDouble(myTeamData.getLongitude())))){
                        tv_deviceDesc.setText(myTeamData.getDeviceDescription().replace("\n", ""));
                        tv_deviceNumber.setText(myTeamData.getDeviceNumber().replace("\n", ""));
                        tv_group_name.setText("("+myTeamData.getGroupName().replace("\n", "")+")");
                        tv_address.setText(myTeamData.getAddressString().replace("\n", ""));
                        tv_lastHOSState.setText("Timeclock status: "+myTeamData.getLastHosStage().replace("\n", ""));
                        tv_updateTime.setText("Last Updated: "+myTeamData.getUpdatedTime().replace("\n", ""));
                    }
                }
            }
            frameLayout.setVisibility(View.VISIBLE);
            fab.setVisibility(View.VISIBLE);
            frameLayout.animate()
                    .translationY(0)
                    .alpha(1.0f);
            fab.setVisibility(View.VISIBLE);
        }else{
            //frameLayout.setVisibility(View.GONE);
            frameLayout.animate()
                    .translationY(350)
                    .alpha(1.0f);
            fab.setVisibility(View.GONE);
        }
        return  false;
    }



    public interface OnMenuMAPItemClicked{
        public void sendmapnotes();
        public void map_refresh();
        public void myteamList();
    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.myteam_map_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case android.R.id.home:
                if (getFragmentManager().getBackStackEntryCount() != 0) {
                    getFragmentManager().popBackStack();
                }
                return true;

            case R.id.mymap_notes:
                menuMapCallback.sendmapnotes();
                return true;

            case R.id.map_refresh:
                progress.show();
                final Handler handler = new Handler();
                // Create and start a new Thread
                new Thread(new Runnable() {
                    public void run() {
                        try{
                            Thread.sleep(5000);
                        }
                        catch (Exception e) { } // Just catch the InterruptedException

                        // Now we use the Handler to post back to the main thread
                        handler.post(new Runnable() {
                            public void run() {
                                // Set the View's visibility back on the main UI Thread
                                progress.hide();
                            }
                        });
                    }
                }).start();

                return true;

            case R.id.myteam_list:
                menuMapCallback.myteamList();
                return true;

        }
        return super.onOptionsItemSelected(item);
    }



    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        try {
            menuMapCallback = (MyTeamMapFragment.OnMenuMAPItemClicked) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnHeadlineSelectedListener");
        }

    }


}

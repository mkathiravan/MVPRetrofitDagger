package net.abaqus.mygeotracking.deviceagent.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.telephony.TelephonyManager;

/**
 * Created by root on 23/5/17.
 */

public class PhoneUtils {


    private PhoneUtils() {
        throw new UnsupportedOperationException("u can't instantiate me...");
    }

    /**
     *
     * @return
     */
    public static boolean isPhone(Context mContext) {
        TelephonyManager tm = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
        return tm != null && tm.getPhoneType() != TelephonyManager.PHONE_TYPE_NONE;
    }

    /**
     *
     * @return
     */
    @SuppressLint("HardwareIds")
    public static String getIMEI(Context mContext) {
        TelephonyManager tm = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
        return tm != null ? tm.getDeviceId() : null;
    }

    /**
     *
     * @return
     */
    @SuppressLint("HardwareIds")
    public static String getIMSI(Context mContext) {
        TelephonyManager tm = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
        return tm != null ? tm.getSubscriberId() : null;
    }

    /**
     *
     * <ul>
     * <li>{@link TelephonyManager#PHONE_TYPE_NONE } : 0 </li>
     * <li>{@link TelephonyManager#PHONE_TYPE_GSM  } : 1 </li>
     * <li>{@link TelephonyManager#PHONE_TYPE_CDMA } : 2 </li>
     * <li>{@link TelephonyManager#PHONE_TYPE_SIP  } : 3 </li>
     * </ul>
     */
    public static int getPhoneType(Context mContext) {
        TelephonyManager tm = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
        return tm != null ? tm.getPhoneType() : -1;
    }

    /**
     *
     * @return
     */
    public static boolean isSimCardReady(Context mContext) {
        TelephonyManager tm = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
        return tm != null && tm.getSimState() == TelephonyManager.SIM_STATE_READY;
    }

    /**
     *
     * @return
     */
    public static String getSimOperatorName(Context mContext) {
        TelephonyManager tm = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
        return tm != null ? tm.getSimOperatorName() : null;
    }

}

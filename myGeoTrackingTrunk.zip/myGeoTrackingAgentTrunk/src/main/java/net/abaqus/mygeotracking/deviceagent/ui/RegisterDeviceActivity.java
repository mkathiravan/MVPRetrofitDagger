package net.abaqus.mygeotracking.deviceagent.ui;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.crashlytics.android.Crashlytics;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.notification.ShareRegistrationToken;
//import net.abaqus.mygeotracking.deviceagent.sixgill.InitializeWithSixgill;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.SetUpDefaultsAndCommonValues;
import net.abaqus.mygeotracking.deviceagent.welcome.WelcomeActivity;

public class RegisterDeviceActivity extends ReceiverActivity {

	private static final String TAG = RegisterDeviceActivity.class.getSimpleName();

	private Context mContext;

	public static final String PROPERTY_REG_ID_MGT = "registration_id_mgt";
	public static final String PROPERTY_APP_VERSION = "appVersion";
	private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
	String regid;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = RegisterDeviceActivity.this;

		new ConfigureTask().execute();

		if (WelcomeActivity.shouldDisplay(this)) {
			Crashlytics.log("Inside Register Activity. Should Display welcome screen is TRUE");

			Intent intent = new Intent(this, WelcomeActivity.class);
			startActivity(intent);
			finish();
			return;
		}else{
			Crashlytics.log("Inside Register Activity. Moving to main Activity");
			Intent mda_main_view = new Intent(getApplicationContext(),MDAMainActivity.class);
			startActivity(mda_main_view);
			finish();
		}
	}
	class ConfigureTask extends AsyncTask<String, Void, Boolean>
	{

		@Override
		protected Boolean doInBackground(String... strings) {
			doBgProcesses();
			return true;
		}
	}

	private void doBgProcesses() {
		//new InitializeWithZOS(mContext, RegisterDeviceActivity.this);

		//new InitializeWithSixgill(mContext,RegisterDeviceActivity.this);

		new SetUpDefaultsAndCommonValues(mContext);
		/**Check for Google Play Service Availability, it is required for using GCM,Maps V2 and sometimes Location too.*/
		if (checkPlayServices()) {
			regid = getRegistrationId(getApplicationContext());
			Log.i(MDACons.LOG_TAG, "Registration ID retching (check Availablity )= " + regid);
			Crashlytics.log("Registration ID retching (check Availablity )= " + regid);

			if (regid.length() < 1) {
				Log.i(MDACons.LOG_TAG, "No ID So Calling register in bg");
				//registerInBackground();
				new Thread(new Runnable() {
					@Override
					public void run() {
						Crashlytics.log("Sending Registration FCM Token to server");

						ShareRegistrationToken.sendRegistrationToServer(mContext);
					}
				}).start();
			}
		} else {
			runOnUiThread(new Runnable() {
				public void run() {
					Toast.makeText(mContext, "No valid Google Play Services APK found. Please Install it from Play Store.", Toast.LENGTH_SHORT).show();
				}
			});
		}
	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
		finish();
	}

	/**method statements for checking availability of Google Play Services*/
	private boolean checkPlayServices() {
		Log.i(MDACons.LOG_TAG, "Checking GPS availability");
		GoogleApiAvailability googleApiAvailability = GoogleApiAvailability.getInstance();
		int resultCode = googleApiAvailability.isGooglePlayServicesAvailable(this);
		if (resultCode != ConnectionResult.SUCCESS) {
			if (googleApiAvailability.isUserResolvableError(resultCode)) {
				//Cannot create a alert from background thread
				//googleApiAvailability.getErrorDialog(this, resultCode, PLAY_SERVICES_RESOLUTION_REQUEST).show();
			} else {
				Toast.makeText(mContext, "This device does not support", Toast.LENGTH_SHORT).show();
				finish();
			}
			return false;
		}
		return true;
	}

	/**get GCM registration ID For the device from Google Cloud Messaging Server*/
	private String getRegistrationId(Context context) {
		Log.i(MDACons.LOG_TAG, "get regID From Local Storage");
		SharedPreferences mda_prefs = getSharedPreferences(MDACons.PREFS, 0);
		String registrationIdMGT = mda_prefs.getString(PROPERTY_REG_ID_MGT, "");
		if (registrationIdMGT.length() < 1 ) {
			Log.i(MDACons.LOG_TAG, "Registration not found.");
			return "";
		}
		/** Check if app was updated;
		 * if so, it must clear the registration ID since the existing regID is not guaranteed to work with the new app version.*/
		int registeredVersion = mda_prefs.getInt(PROPERTY_APP_VERSION, Integer.MIN_VALUE);
		int currentVersion = getAppVersion(context);
		if (registeredVersion != currentVersion) {
			Log.i(MDACons.LOG_TAG, "App version changed.");
			return "";
		}
		return registrationIdMGT;
	}

	/**Register for GCM Push Messages*/
   /*private void registerInBackground() {
      new AsyncTask<Void, Void, String>() {
         @Override
         protected String doInBackground(Void... params) {
            Log.i(MDACons.LOG_TAG, "registering with GCM in BG");
            String msg = "";
               try {
                  if (gcm == null) {
                     gcm = GoogleCloudMessaging.getInstance(getApplicationContext());
                  }
                  regid = gcm.register(SENDER_ID);
                  msg = "Device registered, registration ID=" + regid;
                  *//** You should send the registration ID to your server over HTTP,
	 so it can use GCM/HTTP or CCS to send messages to your app.*//*
                  sendRegistrationIdToBackend(regid);
                  *//** Persist the regID - no need to register again.*//*
                  storeRegistrationId(getApplicationContext(), regid);
               } catch (IOException ex) {
                  msg = "Error :" + ex.getMessage();
                  Log.i(MDACons.LOG_TAG, "GCM Registraion Error :" + ex.getMessage());
                  *//** If there is an error, don't just keep trying to register.
	 Require the user to click a button again, or perform exponential back-off.*//*
               }
            return msg;
         }
         @Override
         protected void onPostExecute(String msg) {}
      }.execute(null, null, null);
   }*/

	private void storeRegistrationId(Context context, String regIdZOS, String regIdMGT) {
		Log.i(MDACons.LOG_TAG, "store regID in local");
		final SharedPreferences prefs = getGcmPreferences(context);
		int appVersion = getAppVersion(context);
		Log.i(MDACons.LOG_TAG, "Saving regId on app version " + appVersion);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putString(PROPERTY_REG_ID_MGT, regIdMGT);
		editor.putInt(PROPERTY_APP_VERSION, appVersion);
		editor.commit();
	}

	private int getAppVersion(Context context) {
		int versionCode = 0;
		try {
			versionCode = getPackageManager()
					.getPackageInfo(mContext.getPackageName(), 0).versionCode;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return versionCode;
	}

	/**
	 * @return Application's {@code SharedPreferences}.
	 */
	private SharedPreferences getGcmPreferences(Context context) {
		/** store the regID*/
		return getSharedPreferences(MDACons.PREFS, Context.MODE_PRIVATE);
	}


}
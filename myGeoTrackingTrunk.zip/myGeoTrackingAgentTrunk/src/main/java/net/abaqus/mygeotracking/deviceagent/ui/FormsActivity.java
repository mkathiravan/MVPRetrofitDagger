package net.abaqus.mygeotracking.deviceagent.ui;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.TextView;

import com.activeandroid.query.Select;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.forms.FormsTable;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;

import org.apache.http.util.EncodingUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by root on 4/10/16.
 */

public class FormsActivity extends AppCompatActivity {

    List<FormsTable> formsTableArrayList = new ArrayList<>();
    private RecyclerView mRecyclerView;
    private FormsAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private CardView mainCardView;
    private SwipeRefreshLayout swipeContainer;


    public static List<FormsTable> getFormsData() {
        return new Select()
                .from(FormsTable.class)
                .execute();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forms);

        mRecyclerView = (RecyclerView) findViewById(R.id.rvFormsActivity);
        // mRecyclerView.setAlpha(1);
        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        mRecyclerView.setHasFixedSize(true);
        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(this);
        mainCardView = (CardView) findViewById(R.id.mainCardView);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        mAdapter = new FormsAdapter();
        mRecyclerView.setAdapter(mAdapter);
        formsTableArrayList = getFormsData();
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);

        /*swipeContainer = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayoutFroms);
        // Setup refresh listener which triggers new data loading
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeContainer.setRefreshing(false);
            }
        });
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);*/

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public class FormsAdapter extends RecyclerView.Adapter<FormsAdapter.ViewHolder> {

        View mainView;

        // Create new views (invoked by the layout manager)
        @Override
        public FormsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                              int viewType) {
            // create a new view
            mainView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_items_forms, parent, false);
            FormsAdapter.ViewHolder vh = new FormsAdapter.ViewHolder(mainView);
            return vh;
        }

        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(FormsAdapter.ViewHolder holder, int position) {
            // - get element from your dataset at this position
            // - replace the contents of the view with that element

                FormsTable formsTable = formsTableArrayList.get(position);
                holder.formDescription.setText(formsTable.formName);



        }

        // Return the size of your dataset (invoked by the layout manager)
        @Override
        public int getItemCount() {
            return formsTableArrayList.size();
        }

        // Provide a reference to the views for each data item
        // Complex data items may need more than one view per item, and
        // you provide access to all the views for a data item in a view holder
        public class ViewHolder extends RecyclerView.ViewHolder {
            // each data item is just a string in this case
            public TextView formDescription;


            public ViewHolder(View v) {
                super(v);
                formDescription = (TextView) v.findViewById(R.id.tvFormsDescription);

                v.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int position = mRecyclerView.getChildAdapterPosition(view);
                        if(NetworkConnectionInfo.isOnline(FormsActivity.this))
                            launchFormActivity(position);
                        else
                            Snackbar.make(view,"Internet disabled.",Snackbar.LENGTH_SHORT).show();
                    }
                });

            }
        }


    }

    final int FORM_INTENT_REQUEST_CODE = 5;
    private void launchFormActivity(int formItemPositionInList) {
        Intent formIntent = new Intent(FormsActivity.this, FormSubmitActivity.class);
        formIntent.putExtra("formId", formsTableArrayList.get(formItemPositionInList).formId);
        startActivityForResult(formIntent, FORM_INTENT_REQUEST_CODE);
    }


    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        if (requestCode == FORM_INTENT_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            String contents = intent.getStringExtra("form_data");
            String fdUID = intent.getStringExtra("fdUID");

            WebView webview = new WebView(this);
            SharedPreferences sharedPreferences = getSharedPreferences(MDACons.PREFS, 0);

            String url = MDACons.BASE_URL + "/track/htmlform";

            if(contents != null && contents.length() > 0)
                webview.postUrl(url, EncodingUtils.getBytes(contents, "base64"));

            Snackbar.make(mainCardView,"Submitted.",Snackbar.LENGTH_SHORT).show();
        }
    }
}

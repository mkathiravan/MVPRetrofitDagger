package net.abaqus.mygeotracking.deviceagent.forms;

import java.util.List;

/**
 * Created by user on 28-06-2018.
 */

class FormPreFill {

    public List<FormPreFillData> getFormPreFillData() {
        return FormPreFillData;
    }

    public void setFormPreFillData(List<FormPreFillData> formPreFillData) {
        FormPreFillData = formPreFillData;
    }

    List<FormPreFillData> FormPreFillData;

}

package net.abaqus.mygeotracking.deviceagent.ui;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import com.activeandroid.query.Select;
import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.google.firebase.analytics.FirebaseAnalytics;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsAttachmentSource;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsCons;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsEvent;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsKey;
import net.abaqus.mygeotracking.deviceagent.forms.FormFieldsTable;
import net.abaqus.mygeotracking.deviceagent.forms.FormsPrefillTable;
import net.abaqus.mygeotracking.deviceagent.forms.FormsTable;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.SnackbarUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Created by bm on 20/1/16.
 */
public class FormSubmitActivity extends ReceiverActivity{

    private static final String TAG = FormSubmitActivity.class.getSimpleName();

    String formID = "";
    String url = "";
    Context context;
    WebView webview;
    String LocalPathUrl = "";

    private List<FormFieldsTable> formFieldsTable = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;

        webview = new WebView(this);
        setContentView(webview);

        //SharedPreferences sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
        //String url = sh_prefs.getString(MDACons.NOTES_FORM_LINK, "");
        //String token = sh_prefs.getString(MDACons.NOTES_FORM_TOKEN, "");
        //String formID = sh_prefs.getString(MDACons.NOTES_FORM_ID, "");
        if (getIntent().getExtras().get("formId") != null && getIntent().getExtras().get("formId").toString().length() > 0)
            formID = getIntent().getExtras().get("formId").toString();

        if (formID.equals("")) {
            finishTheActivity();
        }
        FormsTable formsTable = new Select()
                .from(FormsTable.class)
                .where("formId = ?", formID)
                .executeSingle();

        FormsPrefillTable formsPrefillTable = new Select()
                .from(FormsPrefillTable.class)
                .where("formId = ?", formID)
                .executeSingle();

        if (formsPrefillTable != null) {
            String prefillKey = formsPrefillTable.PrefillKey;

            formFieldsTable = new Select()
                    .from(FormFieldsTable.class)
                    .where("PreFillkey = ?", prefillKey)
                    .execute();

        }


        if (formsTable.formType.equalsIgnoreCase("Upload")) {
            url = formsTable.formLinkURL;
        } else {
            url = formsTable.formURL + "?formId=" + formsTable.formId + "&" + "token=" + formsTable.formToken;
        }
        Log.e(TAG, "Form Url:" + url);


        webview.getSettings().setBuiltInZoomControls(true);
        webview.getSettings().setDisplayZoomControls(false);
        webview.getSettings().setDefaultTextEncodingName("utf-8");
        webview.getSettings().setJavaScriptEnabled(true);
        webview.setWebChromeClient(new WebChromeClient());
        webview.setCameraDistance(0.5f);
        Map<String, String> httpHeadersMap = new HashMap<String, String>();
        httpHeadersMap.put("Content-Type", "text/html; charset=utf-8");

        if ((isExistLocalFile(formsTable) && LocalPathUrl.length() > 0)) {//DownloadFiles.downloadZipFileRx(formsTable,context);
            webview.addJavascriptInterface(new JavaScriptInterface(this), "HTMLOUT");
            webview.loadUrl(LocalPathUrl, httpHeadersMap);
        } else {
            if (NetworkConnectionInfo.isOnline(this)) {
                webview.addJavascriptInterface(new JavaScriptInterface(this), "HTMLOUT");
                webview.loadUrl(url, httpHeadersMap);
            } else {
                SnackbarUtils.showShort(webview, "Internet disabled.", Color.GRAY, Color.WHITE);
            }
        }

        ActionBar actionBar = getSupportActionBar();
        try {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowHomeEnabled(true);
        } catch (NullPointerException ne) {
        }

        final ProgressDialog pd = ProgressDialog.show(FormSubmitActivity.this, "", "Loading...", true);
        webview.getSettings().setLoadWithOverviewMode(true);

//        webview.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//
//                WebView.HitTestResult hr = ((WebView)v).getHitTestResult();
//                int type = hr.getType();
//
//                if (type == WebView.HitTestResult.EDIT_TEXT_TYPE) {
//                    //Calls When user touch edittext in webview
//                    //Open Keyboard with done button programatically
//
//                    return;
//                }
//                return false;
//            }
//        });

        webview.setWebViewClient(new WebViewClient() {

            String jsInjectCode =
                    "function processClick() {" +

                            "   if (typeof validation == 'function') {" +
                            "           if(validation())" +
                            "           parseForm();" +
                            "   } else {" +
                            "           parseForm();" +
                            "   } " +

                            " } " +

                            "function getSelectValues(select) {" +
                            "   var result = '';" +
                            "   var options = select && select.options;" +
                            "   var opt;" +
                            "   for (var i=0, iLen=options.length; i<iLen; i++) {" +
                            "       opt = options[i];" +
                            "       if (opt.selected) {" +
                            "           result += result.length == 0 ? \"\" : \",\";"+
                            "           result += (opt.value || opt.text);" +
                            "       }" +
                            "   }" +
                            "   return result;" +
                            "}" +


                            "function parseForm() {" +

                            //Reading all the input elements
                            "    var data = '';" +
                            "    var inputs = document.forms[0].getElementsByTagName('input');" +


                            "    for (var i = 0; i < inputs.length; i++) {" +
                            "         var field = inputs[i];" +
                            "         if (field.type != 'submit' && field.type != 'reset' && field.type != 'checkbox' && field.type != 'button') " +
                            "             data += '&' + encodeURIComponent(field.name) + '=' + encodeURIComponent(field.value);" +

                            "         else if (field.type == 'checkbox') { ;" +
                            "              var checkbxID = field.id; " +

                            "              if (field.checked)" +
                            "                   data += '&' + encodeURIComponent(field.name) + '=On';" +
                            "              else " +
                            "                   data += '&' + encodeURIComponent(field.name) + '=Off'; " +
                            "          } else if(field.type == 'radio') {" +
                            "                   if(field.checked) {" +
                            "                       data += '&' + encodeURIComponent(field.name) + '=' + encodeURIComponent(field.value);" +
                            "                   } " +

                            "          }" +

                            "    }" +

                            //Reading all the select elements
                            "    var selects = document.forms[0].getElementsByTagName('select');" +
                            "    for (var i = 0; i < selects.length; i++) {" +
                            "           var selectedElement = selects[i];" +
                            "           if(typeof selectedElement.attributes['multiple'] == 'undefined') {" +
                            "               var op = selectedElement.options[selectedElement.selectedIndex].value;" +
                            "               data += '&' + encodeURIComponent(selectedElement.name) + '=' + encodeURIComponent(op);" +
                            "           } else {" +
                            "               data += '&' + encodeURIComponent(selectedElement.name) + '=' + encodeURIComponent(getSelectValues(selectedElement));" +
                            "           }" +
                            "    }" +

                            //Reading all the textarea elements
                            "    var textarea = document.forms[0].getElementsByTagName('textarea');" +
                            "    for (var i = 0; i < textarea.length; i++) {" +
                            "         var field = textarea[i];" +
                            "         var op = field.value;" +
                            "         data += '&' + encodeURIComponent(field.name) + '=' + encodeURIComponent(op);" +
                            "    }" +

                            //Reading fdUUID & formId to append the values along with data to post
                            "   var fdUUID = document.getElementById('fduid').value;" +
                            "   var formId = document.getElementById('formId').value;" +
                            "   console.log(data);"+
                            "   HTMLOUT.processFormData(data, fdUUID, formId);" +
                            "}" +


                            //Reading all the input elements & checking for type==button to change or add the event listener to the button
                            "   var inputs = document.getElementsByTagName('input');" +
                            "   for (var i = 0; i < inputs.length; i++) {" +
                            "        if (inputs[i].getAttribute('type') == 'button')" +
                            "            inputs[i].addEventListener('click', processClick, false);" +
                            "   }" +


                            "   var forms = document.getElementsByTagName('form');" +
                            "   for (var i = 0; i < forms.length; i++) {"+
                            "       forms[i].setAttribute('action','');"+
                            "   }"+

                            //Prefill the data once after the form is loaded
                            "   HTMLOUT.prefillData();" +
                            "";

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                pd.show();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pd.dismiss();
                view.loadUrl("javascript:(function() { " +
                        jsInjectCode + "})()");


            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(FormSubmitActivity.this, description, Toast.LENGTH_SHORT).show();
            }
        });
    }





    private boolean isExistLocalFile(FormsTable myFormTable) {
        String path = "/data/data/" + context.getPackageName() + "/forms/" + myFormTable.formId + ".html";
        File file = new File(path);
        if (file.exists()) {
            LocalPathUrl = "file:///" + path;
            return true;
        } else {
            return false;
        }
    }

    private void finishTheActivity() {
        setResult(RESULT_CANCELED);
        finish();
    }

    public class JavaScriptInterface {

        JavaScriptInterface(Context c) {
        }

        @JavascriptInterface
        public void prefillData() {
            //added annotation for API > 17 to make it work

            runOnUiThread(new Runnable() {
                @Override
                public void run() {

                    String message = "";
                    try {

                        JSONArray array = new JSONArray();

                        for (FormFieldsTable formFieldsTable : formFieldsTable) {
                            JSONObject item = new JSONObject();
                            item.put("name", formFieldsTable.fieldName);
                            item.put("value", formFieldsTable.fieldValue);
                            array.put(item);
                        }

                        message = array.toString();

                    } catch (JSONException jsonException) {
                        DebugLog.debug(jsonException.getMessage());
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {

                        DebugLog.debug("Javascript Object to pass: " + message);

                        webview.evaluateJavascript("javascript:(function() {fillForm(" + message + ");" +

                                "function fillForm(prefillObject) {" +
                                "    var inputs = document.forms[0].getElementsByTagName('input');" +
                                "    for (var i = 0; i < inputs.length; i++) {" +
                                "         var field = inputs[i];" +
                                "    for (var j = 0; j < prefillObject.length; j++) {" +
                                "      var prefillItem = prefillObject[j];" +
                                "     if(prefillItem.name == field.name) {" +
                                "         field.value = prefillItem.value;" +
                                "    } " +
                                "    } " +
                                " } " +
                                " } " +


                                "})()", null);
                    } else {
                        webview.loadUrl("javascript:(function() {fillForm(" + message + ");" +

                                "function fillForm(prefillObject) {" +
                                "    var inputs = document.forms[0].getElementsByTagName('input');" +
                                "    for (var i = 0; i < inputs.length; i++) {" +
                                "         var field = inputs[i];" +
                                "    for (var j = 0; j < prefillObject.length; j++) {" +
                                "      var prefillItem = prefillObject[j];" +
                                "     if(prefillItem.name == field.name) {" +
                                "         field.value = prefillItem.value;" +
                                "    } " +
                                "    } " +
                                " } " +
                                " } " +


                                "})()");
                    }
                }
            });

        }

        @JavascriptInterface
        public void processFormData(String formData, String fdUUID, String formId) {
            //added annotation for API > 17 to make it work

            FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(FormSubmitActivity.this);
            Bundle bundle = new Bundle();
            bundle.putString(AnalyticsKey.EVENT_STATE, AnalyticsCons.ITEM_SUBMITTED);
            mFirebaseAnalytics.logEvent(AnalyticsEvent.FORM_ATTACHMENT_EVENT, bundle);

            SharedPreferences prefs = getSharedPreferences(MDACons.PREFS, 0);
            String deviceID = prefs.getString(MDACons.DEVICE_NUMBER, "");

            String time = "";
            SimpleDateFormat sdf = null;
            try {
                sdf = new SimpleDateFormat("yyyy/MMM/dd,HH:mm:ss",
                        Locale.getDefault());
                time = CurrentDateAndTime.getDateTime(new SimpleDateFormat(
                        "yyyy/MM/dd'T'HH:mm:ssZ", Locale.getDefault()));
            } catch (Exception e) {
                e.printStackTrace();
            }

            String postdata = formData + "&deviceID=" + deviceID + "&timestamp=" + time;
            Intent i = getIntent();
            i.putExtra("form_data", postdata);
            i.putExtra("fdUID", fdUUID);
            i.putExtra("formId", formId);
            DebugLog.debug(TAG, postdata);
            DebugLog.debug(TAG, fdUUID);
            DebugLog.debug(TAG, deviceID);
            setResult(RESULT_OK, i);
            finish();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.form_activity_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                showWarningOnBackPress();
                break;
            case R.id.form_menu_action_close:
                finishTheActivity();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showWarningOnBackPress() {
        new MaterialDialog.Builder(FormSubmitActivity.this)
                .title(R.string.title_warning_backbtn_press)
                .content(R.string.msg_warning_backbtn_press_form_submission)
                .positiveText(R.string.action_leave)
                .negativeText(R.string.action_stay)
                .autoDismiss(true)
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        finishTheActivity();
                    }
                })
                .show();
    }

    @Override
    public void onBackPressed() {
        showWarningOnBackPress();
    }
}

package net.abaqus.mygeotracking.deviceagent.utils;

import android.content.Context;
import android.net.ConnectivityManager;

public class NetworkDeviceStatus {

    public static String checkNetworkStatus(final Context context) {

        String networkStatus = "";

        // Get connect mangaer
        final ConnectivityManager connMgr = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);

        // check for wifi
        final android.net.NetworkInfo wifi = connMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI);

        // check for mobile data
        final android.net.NetworkInfo mobile = connMgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

//        if( wifi.isAvailable() ) {
//            networkStatus = "wifi";
//        } else if( mobile.isAvailable() ) {
//            networkStatus = "gps";
//        } else {
//            networkStatus = "noNetwork";
//        }


        // To check the connectivity based on the wifi or mobile data

        if (wifi.isConnectedOrConnecting ()) {
            networkStatus = "wifi";
        } else if (mobile.isConnectedOrConnecting ()) {
            networkStatus = "gps";
        } else {
            networkStatus = "noNetwork";
        }



        return networkStatus;

    }
}

/*
package net.abaqus.mygeotracking.deviceagent.notification;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.google.android.gms.iid.InstanceID;

*/
/**
 * Created by Karthikraj Duraisamy on 8/6/16.
 *//*


public class RegistrationIntentService  extends IntentService {

    private static final String TAG = "RegIntentService";
    //private static final String[] TOPICS = {"global"};
    */
/**sender ID's. Zos and myGeoTracking both Sender ID's are added here*//*

    String SENDER_ID = "734770498401,882772620367";
    private Context mContext;
    private SharedPreferences sharedPreferences;
    public RegistrationIntentService() {
        super(TAG);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        mContext = getApplicationContext();
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        try {
            // [START register_for_gcm]
            // Initially this call goes out to the network to retrieve the token, subsequent calls
            // are local.
            // [START get_token]
            InstanceID instanceID = InstanceID.getInstance(this);
            String token = instanceID.getToken(SENDER_ID,
                    GoogleCloudMessaging.INSTANCE_ID_SCOPE, null);
            // [END get_token]
            Log.d(TAG, "GCM Registration Token: " + token);
            ShareRegistrationToken.sendRegistrationToServer(this, token);
            // Subscribe to topic channels
            //subscribeTopics(token);

            // You should store a boolean that indicates whether the generated token has been
            // sent to your server. If the boolean is false, send the token to your server,
            // otherwise your server should have already received the token.
            // [END register_for_gcm]
        } catch (Exception e) {
            Log.d(TAG, "Failed to complete token refresh", e);
            // If an exception happens while fetching the new token or updating our registration data
            // on a third-party server, this ensures that we'll attempt the update at a later time.
            sharedPreferences.edit().putBoolean(NotificationPreferences.SENT_TOKEN_TO_MGT_SERVER, false).apply();
            sharedPreferences.edit().putBoolean(NotificationPreferences.SENT_TOKEN_TO_ZOS_SERVER, false).apply();
        }
        // Notify UI that registration has completed, so the progress indicator can be hidden.
*/
/*
        Intent registrationComplete = new Intent(QuickstartPreferences.REGISTRATION_COMPLETE);
        LocalBroadcastManager.getInstance(this).sendBroadcast(registrationComplete);
*//*

    }



}*/

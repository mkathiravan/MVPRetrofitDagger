package net.abaqus.mygeotracking.deviceagent.utils;

import android.app.ActivityManager;
import android.content.Context;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by root on 23/5/17.
 */

public class ServiceUtils {


    private ServiceUtils() {
        throw new UnsupportedOperationException("u can't instantiate me...");
    }

    /**
     *
     * @return
     */
    public static Set getAllRunningService(Context mContext) {
        ActivityManager activityManager = (ActivityManager) mContext.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> info = activityManager.getRunningServices(0x7FFFFFFF);
        Set<String> names = new HashSet<>();
        if (info == null || info.size() == 0) return null;
        for (ActivityManager.RunningServiceInfo aInfo : info) {
            names.add(aInfo.service.getClassName());
            DebugLog.debug(aInfo.service.getClassName());
        }
        return names;
    }

    /**
     *
     * @param className
     * @return
     */
    public static boolean isServiceRunning(String className, Context mContext) {
        ActivityManager activityManager = (ActivityManager) mContext.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> info = activityManager.getRunningServices(0x7FFFFFFF);
        if (info == null || info.size() == 0) return false;
        for (ActivityManager.RunningServiceInfo aInfo : info) {
            if (className.equals(aInfo.service.getClassName())) return true;
        }
        return false;
    }
}

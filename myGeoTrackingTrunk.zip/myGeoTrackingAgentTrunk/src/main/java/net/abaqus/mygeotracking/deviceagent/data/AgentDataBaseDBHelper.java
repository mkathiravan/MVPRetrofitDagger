package net.abaqus.mygeotracking.deviceagent.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by bm on 20/10/15.
 */
public class AgentDataBaseDBHelper extends SQLiteOpenHelper {



    public AgentDataBaseDBHelper(Context context) {
        super(context, AgentDatabase.DATABASE_NAME, null, AgentDatabase.DATABASE_VERSION);
    }

    // Method is called during creation of the database
    @Override
    public void onCreate(SQLiteDatabase database) {
        AgentEmployeeDetailsTable.onCreate(database);
        HOSLabelsTable.onCreate(database);
        HOSEntryTable.onCreate(database);
        HOSCustomerANDJobTable.onCreate(database);
        MyTeamTable.onCreate(database);
        HOSCustomerANDJobRelationsTable.onCreate(database);
        NotesEntryTable.onCreate(database);
        ImageAttachmentTable.onCreate(database);
        HeartBeatTable.onCreate(database);
        HOSHistoryEntryTable.onCreate(database);
        //FormTable.onCreate(database);
    }

    // Method is called during an upgrade of the database,
    // e.g. if you increase the database version
    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion,
                          int newVersion) {
        AgentEmployeeDetailsTable.onUpgrade(database, oldVersion, newVersion);
        HOSLabelsTable.onUpgrade(database, oldVersion, newVersion);
        HOSEntryTable.onUpgrade(database, oldVersion, newVersion);
        HOSCustomerANDJobTable.onUpgrade(database, oldVersion, newVersion);
        MyTeamTable.onUpgrade(database, oldVersion, newVersion);
        HOSCustomerANDJobRelationsTable.onUpgrade(database, oldVersion, newVersion);
        NotesEntryTable.onUpgrade(database, oldVersion, newVersion);
        ImageAttachmentTable.onUpgrade(database, oldVersion, newVersion);
        HeartBeatTable.onUpgrade(database, oldVersion, newVersion);
        HOSHistoryEntryTable.onUpgrade(database,oldVersion,newVersion);
        //FormTable.onUpgrade(database, oldVersion, newVersion);
    }


}
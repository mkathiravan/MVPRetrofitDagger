package net.abaqus.mygeotracking.deviceagent.RetrofitBuilder;

import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by user on 22-06-2018.
 */

public class ApiClient {

    public static final String BASE_URL = MDACons.BASE_URL;
    public static final String SIXGILL_BASE_URL = MDACons.SIXGILL_BASE_URL;
    //public static final String BASE_PRODUCTION_URL = "https://www.mygeotracking.com";
    //public static final String BASE_URL = "http://10.1.0.157:8080";
    //public static final String BASE_URL = "https://www.mygeotracking.com";

    //public static String BASE_PRODUCTION_URL = "https://prerelease.mygeotracking.com";


    private static Retrofit retrofit = null;
    private static ApiInterface requestInterface;
    private static ApiInterface requestInterface1;

    public static ApiInterface getClient() {

        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient client = new OkHttpClient.Builder().
                readTimeout(40, TimeUnit.SECONDS)
                .connectTimeout(40, TimeUnit.SECONDS)
                .addInterceptor(interceptor).
                        build();

        if(requestInterface==null) {
            Gson gson = new GsonBuilder()
                    .setLenient()
                    .create();
            requestInterface = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build().create(ApiInterface.class);
        }
        return requestInterface;
    }


//    public static ApiInterface getClientRX() {
//        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
//        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
//        OkHttpClient client = new OkHttpClient.Builder().
//                readTimeout(40, TimeUnit.SECONDS)
//                .connectTimeout(40, TimeUnit.SECONDS)
//                .addInterceptor(interceptor).
//                        build();
//
//        if(requestInterface==null) {
//            Gson gson = new GsonBuilder()
//                    .setLenient()
//                    .create();
//            requestInterface = new Retrofit.Builder()
//                    .baseUrl(BASE_URL)
//                    .callbackExecutor(Executors.newSingleThreadExecutor())
//                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
//                    .addConverterFactory(GsonConverterFactory.create(gson))
//                    .build().create(ApiInterface.class);
//        }
//        return requestInterface;
//    }

//
//    public static ApiInterface getProductionClientRx()
//    {
//        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
//        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
//        OkHttpClient client = new OkHttpClient.Builder().
//                readTimeout(40, TimeUnit.SECONDS)
//                .connectTimeout(40, TimeUnit.SECONDS)
//                .addInterceptor(interceptor).build();
//
//        if(requestInterface==null) {
//            Gson gson = new GsonBuilder()
//                    .setLenient()
//                    .create();
//            requestInterface = new Retrofit.Builder()
//                    .baseUrl(BASE_URL)
//                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
//                    .build().create(ApiInterface.class);
//        }
//        return requestInterface;
//    }





    public static ApiInterface getProductionClient()
    {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder().
                readTimeout(40, TimeUnit.SECONDS)
                .connectTimeout(40, TimeUnit.SECONDS)
                .addInterceptor(interceptor).build();

        if(requestInterface==null) {
            Gson gson = new GsonBuilder()
                    .setLenient()
                    .create();
            requestInterface = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(client)
                    .callbackExecutor(Executors.newSingleThreadExecutor())
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build().create(ApiInterface.class);
        }
        return requestInterface;
    }



    public static ApiInterface getCallSixgill()
    {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(interceptor)
                .readTimeout(40, TimeUnit.SECONDS)
                .connectTimeout(40, TimeUnit.SECONDS).build();

        if(requestInterface1==null) {
            Gson gson = new GsonBuilder()
                    .setLenient()
                    .create();
            requestInterface1 = new Retrofit.Builder()
                    .baseUrl(SIXGILL_BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build().create(ApiInterface.class);
        }
        return requestInterface1;
    }

}

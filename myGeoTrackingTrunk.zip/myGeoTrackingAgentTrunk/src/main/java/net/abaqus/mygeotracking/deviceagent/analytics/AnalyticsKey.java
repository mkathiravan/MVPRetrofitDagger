package net.abaqus.mygeotracking.deviceagent.analytics;

public class AnalyticsKey {

    public static final String EVENT_STATE = "EVENT_STATE";
    public static final String EVENT_SOURCE = "EVENT_SOURCE";

}

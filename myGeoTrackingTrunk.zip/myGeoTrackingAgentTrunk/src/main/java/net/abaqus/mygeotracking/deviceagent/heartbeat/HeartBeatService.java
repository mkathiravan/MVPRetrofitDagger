package net.abaqus.mygeotracking.deviceagent.heartbeat;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Debug;

import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;

import net.abaqus.mygeotracking.deviceagent.bgthread.AttachmentPushTask;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;

/**
 * Created by bmandyam on 1/16/18.
 */

public class HeartBeatService extends JobService {

    @Override
    public boolean onStartJob(final JobParameters job) {

        DebugLog.debug("Started job!", "Should be recurring - HeartBeat Service");
//        try {
//            new ConstructHeartBeatTask().execute(job.getExtras().getString("triggerSource"));
//        } catch (NullPointerException e) {
//            DebugLog.debug(e.getLocalizedMessage());
//        }

        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                //ZDAListener.getInstance().initialize(HeartBeatService.this.getApplicationContext(), null, null, null);
                new ConstructHeartBeat(getApplicationContext()).processHBEntries(job.getExtras().getString("triggerSource"));
                if (NetworkConnectionInfo.isOnline(getApplicationContext())) {
                    new HBTask(getApplicationContext()).execute();
                    new AttachmentPushTask(getApplicationContext()).execute();
                }
                else {
                    SharedPreferences sh_prefs = getApplicationContext().getSharedPreferences(MDACons.PREFS, 0);
                    SharedPreferences.Editor sh_prefs_edit = sh_prefs.edit();
                    sh_prefs_edit.putBoolean(MDACons.HB_SENT_STATUS, false);
                    sh_prefs_edit.apply();
                }
            }
        });


        return false;
    }

    @Override
    public boolean onStopJob(JobParameters job) {
        DebugLog.debug("Stopped job!", "Should be recurring - HeartBeat Service");
        return false;
    }


    private class ConstructHeartBeatTask extends AsyncTask<String, Integer, Boolean> {

        protected Boolean doInBackground(String... params) {
            new ConstructHeartBeat(getApplicationContext()).processHBEntries(params[0]);
            return true;
        }

        protected void onPostExecute(Boolean result) {

            if (NetworkConnectionInfo.isOnline(getApplicationContext()))
                new HBTask(getApplicationContext()).execute();
            else {
                SharedPreferences sh_prefs = getApplicationContext().getSharedPreferences(MDACons.PREFS, 0);
                SharedPreferences.Editor sh_prefs_edit = sh_prefs.edit();
                sh_prefs_edit.putBoolean(MDACons.HB_SENT_STATUS, false);
                sh_prefs_edit.apply();
            }
        }
    }
}
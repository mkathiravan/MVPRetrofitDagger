package net.abaqus.mygeotracking.deviceagent.expandableview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.thoughtbot.expandablerecyclerview.ExpandableRecyclerViewAdapter;
import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.forms.FormPrefillListViewModel;

import java.util.List;

/**
 * Created by user on 28-06-2018.
 */

public class GenreAdapter extends ExpandableRecyclerViewAdapter<GenreViewHolder,FormSubViewHolder> implements FormSubViewHolder.DataFromSubViewHolderToAdapter{

    public interface OnFormsClickListener {
        void formClicked(String formId);
    }

    private OnFormsClickListener onFormsClickListener;

    private static final String TAG = GenreAdapter.class.getSimpleName();
    GetFormPrefillId dataFromAdapterToActivity;
    Context mContext;
    public GenreAdapter(Context context, List<? extends ExpandableGroup> groups,GetFormPrefillId dataFromAdapterToActivity, OnFormsClickListener onFormsClickListenerParam) {
        super(groups);
        mContext = context;
        onFormsClickListener = onFormsClickListenerParam;
        this.dataFromAdapterToActivity = dataFromAdapterToActivity;
    }

    @Override
    public GenreViewHolder onCreateGroupViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_forms_parent,parent,false);
        return new GenreViewHolder(view);
    }

    @Override
    public FormSubViewHolder onCreateChildViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_forms_child,parent,false);
        return new FormSubViewHolder(view,this);
    }

    @Override
    public void onBindChildViewHolder(FormSubViewHolder holder, int flatPosition, ExpandableGroup group, int childIndex) {

         FormPrefillListViewModel fromlist = ((Genre)group).getItems().get(childIndex);
         holder.setFormName(fromlist.getForm_prefill_description(), fromlist.getForm_prefill_id());
         dataFromAdapterToActivity.getValue(fromlist.getForm_prefill_id());

    }

    @Override
    public void onBindGroupViewHolder(GenreViewHolder holder, int flatPosition, final ExpandableGroup group) {
        final ImageView imageView = holder.itemView.findViewById(R.id.list_item_form_arrow);
        TextView formCount = holder.itemView.findViewById(R.id.list_item_form_count);
        final TextView formName = holder.itemView.findViewById(R.id.list_item_form_title);
        if(((Genre)group).getItems().size()==0)
        {
            imageView.setVisibility(View.GONE);
            formCount.setVisibility(View.GONE);
            formName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                  // Toast.makeText(mContext,"Header Item Clicked",Toast.LENGTH_SHORT).show();
                    formName.setClickable(false);
                    onFormsClickListener.formClicked(((Genre) group).getFormId());
                    formName.setClickable(true);

                }
            });


        }else {
            imageView.setVisibility(View.VISIBLE);
            formCount.setVisibility(View.VISIBLE);
        }

        holder.setGenreTitle(group);

    }

    @Override
    public void clickData(String form_id) {
        onFormsClickListener.formClicked(form_id);

        //Toast.makeText(mContext,"Child Item Click",Toast.LENGTH_SHORT).show();


    }


    public interface GetFormPrefillId
    {
        public void getValue(String form_id);

    }
}

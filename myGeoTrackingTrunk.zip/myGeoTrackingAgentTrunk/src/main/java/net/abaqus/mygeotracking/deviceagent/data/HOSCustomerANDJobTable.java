package net.abaqus.mygeotracking.deviceagent.data;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

public class HOSCustomerANDJobTable {

	
	
	private static final String TAG = "MGT_Database";
	/*<Customers>
    <Customer>
    <Id><![CDATA[009cb9e9-cac3-46d0-8a14-4867bbba1a88]]></Id>
    <CustomID></CustomID>
    <Name><![CDATA[Russell Chiropractic]]></Name>
    <CustomerID><![CDATA[63]]></CustomerID>
    <Status><![CDATA[true]]></Status>
    </Customer>
    
    <Jobs>
    <Job>
    <Id><![CDATA[01f61c10-0092-4b76-961b-04f3faf6eb79]]></Id>
    <CustomID></CustomID>
    <Name><![CDATA[Plants & Trees]]></Name>
    <JobID><![CDATA[29]]></JobID>
    <Status><![CDATA[true]]></Status>
    </Job>*/
	
    //The columns we'll include in the dictionary table
	public static final String COLUMN_ID = "_id";
    public static final String HOS_CJ_SOURCE_ID = "hos_cj_source_id";
    
    
    
    public static final String HOS_CJ_ID = "hos_cj_id";
    public static final String HOS_CJ_REF_ID = "hos_cj_ref_id";
    public static final String HOS_CJ_NAME = "hos_cj_source_name";
    public static final String HOS_CJ_STATUS = "hos_cj_status";
    public static final String HOS_CJ_SITE_ID = "hos_cj_site_id";
    public static final String HOS_CJ_WHICH = "hos_cj_which";
    public static final String HOS_CJ_TABLE = "mgtagenthoscjtable";
	
	
	
	  

	  // Database creation SQL statement
    
	  private static final String HOS_CJ_TABLE_CREATE = "create table " 
	      + HOS_CJ_TABLE
	      + "(" 
	      + COLUMN_ID + " integer primary key autoincrement, " 
	      + HOS_CJ_SOURCE_ID + " text null, " 
	      + HOS_CJ_REF_ID + " text null," 
	      
	      + HOS_CJ_ID+ " text null,"
	      + HOS_CJ_NAME+ " text null,"
	      + HOS_CJ_SITE_ID+ " text null,"
	      + HOS_CJ_WHICH+ " text not null,"
	      + HOS_CJ_STATUS
	      + " text null" 
	      + ");";

	  public static void onCreate(SQLiteDatabase database) {
		  DebugLog.debug(TAG, "Creating database ");
	    database.execSQL(HOS_CJ_TABLE_CREATE);
	  }

	  public static void onUpgrade(SQLiteDatabase database, int oldVersion,
	      int newVersion) {
	    DebugLog.debug(TAG, "Upgrading database from version "
	        + oldVersion + " to " + newVersion
	        + ", which will destroy all old data");
	    database.execSQL("DROP TABLE IF EXISTS " + HOS_CJ_TABLE);
	    onCreate(database);
	  }
	
}

package net.abaqus.mygeotracking.deviceagent.utils;

import android.net.TrafficStats;
import android.util.Log;

public class DataUsageStats {

	static long mStartRX = 0;
	static long mStartTX = 0;

	static String TAG = "MGT DATA USAGE";

	public static void initializeForDataUsage(String methodName){
		mStartRX = TrafficStats.getTotalRxBytes();
		mStartTX = TrafficStats.getTotalTxBytes();
		//DebugLog.debug(TAG,(TAG, "Total Received Bytes Before "+ methodName+" Call "+Long.toString(mStartRX)+" Bytes");
		//DebugLog.debug(TAG,(TAG, "Total Transmitted Bytes Before "+ methodName+" Call "+Long.toString(mStartTX)+" Bytes");
	}


	public static void getPresentCallUsedData(String methodName){
		long rxBytes = TrafficStats.getTotalRxBytes()- mStartRX;
		DebugLog.debug(TAG, "Received Bytes for "+ methodName+" Call "+Long.toString(rxBytes)+" Bytes");
		long txBytes = TrafficStats.getTotalTxBytes()- mStartTX;
		DebugLog.debug(TAG, "Transmitted Bytes for "+ methodName+" Call "+Long.toString(txBytes)+" Bytes");
	}
}

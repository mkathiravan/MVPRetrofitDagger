package net.abaqus.mygeotracking.deviceagent.home;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;


@Table(name = "NativeLocationTable", id = "_id")
public class NativeLocationTable extends Model {

    @Column(name = "longitude")
    public float longitude;
    @Column(name = "locateTime")
    public String locateTime = "";
    @Column (name = "latitude")
    public float latitude;
    @Column(name = "accuracy")
    public float accuracy;

    public float getAccuracy() {
        return accuracy;
    }

    public void setAccuracy(float accuracy) {
        this.accuracy = accuracy;
    }



    public float getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public float getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    public String getLocateTime() {
        return locateTime;
    }

    public void setLocateTime(String locateTime) {
        this.locateTime = locateTime;
    }






}

package net.abaqus.mygeotracking.deviceagent.welcome;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

/**
 * Created by bm on 1/1/16.
 */

/**
 * A Fragment class for use with {@link WelcomeActivity} to embed content into the activity.
 *
 * Contains utitlies for attaching the fragment to the activity and updating UI elements.
 */
public abstract class WelcomeFragment extends Fragment{

    private static final String TAG = WelcomeFragment.class.toString();
    protected Activity mActivity;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mActivity = activity;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mActivity = null;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);

        // If the acitivty the fragment has been attached to is a WelcomeFragmentContainer
        if (mActivity instanceof WelcomeFragmentContainer) {
            WelcomeFragmentContainer activity = (WelcomeFragmentContainer) mActivity;

            // Attach to the UI elements
            attachToPositiveButton(activity.getPositiveButton());
            attachToTCCheckBox(activity.getTCCheckbox());
            //attachToNegativeButton(activity.getNegativeButton());
        }
        return view;
    }

    /**
     * Attach to the positive action button of the WelcomeFragmentContainer.
     *
     * @param button the ui element to attach to.
     */
    protected void attachToPositiveButton(Button button) {
        // Set the button text
        button.setText(getPositiveText());

        // Set the click listener
        button.setOnClickListener(getPositiveListener());
    }
/**
     * Attach to the positive action button of the WelcomeFragmentContainer.
     *
     * @param checkBox the ui element to attach to.
     */
    protected void attachToTCCheckBox(CheckBox checkBox) {
        // Set the button text
        //button.setText(getPositiveText());

        // Set the click listener
        checkBox.setOnCheckedChangeListener(getTCCheckedListener());
    }

    /**
     * Attach to the negative action button of the WelcomeFragmentContainer.
     *
     * @param button the ui element to attach to.
     */
    protected void attachToNegativeButton(Button button) {
        // Set the button text
        button.setText(getNegativeText());

        // Set the click listener
        button.setOnClickListener(getNegativeListener());
    }


    /**
     * Get a resource string.
     *
     * @param id the id of the string resource.
     * @return the value of the resource or null.
     */
    protected String getResourceString(int id) {
        if(mActivity != null) {
            return mActivity.getResources().getString(id);
        }
        return null;
    }

    /**
     * Get the text for the positive action button.
     *
     * E.g. Accept
     *
     * @return the text for the button.
     */
    protected abstract String getPositiveText();

    /**
     * Get the text for the negative action button.
     *
     * E.g. Decline
     *
     * @return the text for the negative action button.
     */
    protected abstract String getNegativeText();

    /**
     * Get the {@link android.view.View.OnClickListener} for the positive action click event.
     *
     * @return the click listener.
     */
    protected abstract View.OnClickListener getPositiveListener();


    /**
     * Get the {@link android.view.View.OnClickListener} for the positive action click event.
     *
     * @return the click listener.
     */
    protected abstract CompoundButton.OnCheckedChangeListener getTCCheckedListener();

    /**
     * Get the {@link android.view.View.OnClickListener} for the negative action click event.
     *
     * @return the click listener.
     */
    protected abstract View.OnClickListener getNegativeListener();

    /**
     * A convience {@link android.view.View.OnClickListener} for the common use case in the
     * WelcomeActivityContent.
     */
    protected abstract class WelcomeFragmentOnClickListener implements View.OnClickListener {
        /**
         * The action to perform on click, before proceeding to the next activity or exiting the
         * app.
         */
        Activity mActivity;

        /**
         * Construct a listener that will handle the transition to the next activity or exit after
         * completing.
         *
         * @param activity the Activity to interact with.
         */
        public WelcomeFragmentOnClickListener(Activity activity) {
            mActivity = activity;
        }

        /**
         * Proceed to the next activity.
         */
        void doNext() {
            DebugLog.debug(TAG, "Proceeding to Main Activity From Welcome screen fragment register onclick");
            Intent intent = new Intent(mActivity, MDAMainActivity.class);
            startActivity(intent);
            mActivity.finish();
        }

        /**
         * Finish the activity.
         *
         * We're done here.
         */
        void doFinish() {
            mActivity.finish();
        }
    }
 /**
     * A convience {@link android.view.View.OnClickListener} for the common use case in the
     * WelcomeActivityContent.
     */
    protected abstract class WelcomeFragmentOnCheckListener implements CompoundButton.OnCheckedChangeListener {
        /**
         * The action to perform on click, before proceeding to the next activity or exiting the
         * app.
         */
        Activity mActivity;

        /**
         * Construct a listener that will handle the transition to the next activity or exit after
         * completing.
         *
         * @param activity the Activity to interact with.
         */
        public WelcomeFragmentOnCheckListener(Activity activity) {
            mActivity = activity;
        }

        /**
         * Proceed to the next activity.
         */
        void onChecked() {
            DebugLog.debug(TAG, "Proceeding onchecked activity");
        }

        /**
         * Finish the activity.
         *
         * We're done here.
         */
        void onUnChecked() {
            DebugLog.debug(TAG, "onUnchecked");
        }
    }


    /**
     * The Container for the WelcomeActivityContent.
     */
    interface WelcomeFragmentContainer {

        /**
         * Retrieve a posistive action button from the container.
         *
         * @return the positive action button.
         */
        public Button getPositiveButton();

        public CheckBox getTCCheckbox();
        /**
         * Enable the positive action button in the container.
         *
         * @param enabled true to enable it, false to disable it.
         */
        public void setPositiveButtonEnabled(Boolean enabled);

        /**
         * Retrieve a negative action button from the container.
         *
         * @return the negative action button.
         */
        //public Button getNegativeButton();

        /**
         * Enable the negative action button in the container.
         *
         * @param enabled true to enable it, false to disable it.
         */
       // public void setNegativeButtonEnabled(Boolean enabled);
    }
}

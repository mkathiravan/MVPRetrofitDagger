package net.abaqus.mygeotracking.deviceagent.expandableview;

import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.thoughtbot.expandablerecyclerview.viewholders.ChildViewHolder;

import net.abaqus.mygeotracking.deviceagent.R;

/**
 * Created by user on 28-06-2018.
 */

public class FormSubViewHolder extends ChildViewHolder {
    private static final String TAG = FormSubViewHolder.class.getSimpleName();
    private TextView childTextView;
    DataFromSubViewHolderToAdapter dataFromFromViewHolderToActivity;

    public FormSubViewHolder(View itemView,final DataFromSubViewHolderToAdapter dataFromFromViewHolderToActivity) {
        super(itemView);
        childTextView = (TextView)itemView.findViewById(R.id.list_item_prefill_desc);
        this.dataFromFromViewHolderToActivity = dataFromFromViewHolderToActivity;
//        childTextView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Log.d(TAG,"ONCHILDCLICK");
//                dataFromFromViewHolderToActivity.clickData();
//            }
//        });
    }

    public void setFormName(String name, final String form_id)
    {
        childTextView.setText(name);
        childTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG,"ONCHILDCLICK");
                dataFromFromViewHolderToActivity.clickData(form_id);

            }
        });

    }

    public interface DataFromSubViewHolderToAdapter
    {
        public void clickData(String form_id);

    }


}

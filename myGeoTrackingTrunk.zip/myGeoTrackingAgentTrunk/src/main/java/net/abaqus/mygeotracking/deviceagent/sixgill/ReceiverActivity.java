package net.abaqus.mygeotracking.deviceagent.sixgill;


import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.R;

public class ReceiverActivity extends AppCompatActivity {

    public static final String TAG = ReceiverActivity.class.getSimpleName();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        Log.wtf(TAG, "ONCREATEREVEACT ");
        super.onCreate(savedInstanceState);

    }



    @Override
    protected void onResume() {
        super.onResume();
    }



    @Override
    protected void onPause() {
        super.onPause();
    }


    @Override
    protected void onDestroy() {
        Log.wtf(TAG, "RECREAONDESTRY ");
        super.onDestroy();

    }


}

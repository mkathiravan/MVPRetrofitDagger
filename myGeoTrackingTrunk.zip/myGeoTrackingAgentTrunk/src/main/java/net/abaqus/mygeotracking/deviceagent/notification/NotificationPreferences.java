package net.abaqus.mygeotracking.deviceagent.notification;

/**
 * Created by root on 8/6/16.
 */

public class NotificationPreferences {

    public static final String SENT_TOKEN_TO_ZOS_SERVER = "sentTokenToZosServer";
    public static final String SENT_TOKEN_TO_MGT_SERVER = "sentTokenToMGTServer";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";

}
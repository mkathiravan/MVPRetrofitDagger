package net.abaqus.mygeotracking.deviceagent.ui;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.telephony.PhoneNumberUtils;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsCons;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsEvent;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsKey;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HeartBeat;
import net.abaqus.mygeotracking.deviceagent.heartbeat.TriggerSource;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;

import java.util.ArrayList;
import java.util.Locale;
import java.util.UUID;

public class SettingsAcitivty extends ReceiverActivity {

	LinearLayout location_shot_sett_lay, settings_accuracy_layout,
			settings_timeout_layout, identities_layout;
	View settings_accuracy_border, settings_timeout_border;
	TextView settings_accuracy_text, settings_timout_text;
	Button location_shot_setttings_button,
			send_debug_info_button, re_register_button, about_button;
	SharedPreferences sh_prefs;
	SharedPreferences.Editor sh_prefs_edit;
	Animation mAnimation;
	TextView identities_text_phone_number, identities_text_phone_guid;

	myGeoTrackingDevieAgentApplication app_context;

	private static final int SHOW_ACCURACY_DIALOG = 1;
	private static final int SHOW_TIMEOUT_DIALOG = 2;

	public String CONS_INTENT_EXTRA_ID_TYPE = "id_type";
	public String CONS_SUPPORT_MAIL_ID = "support@abaq.us";
	public String CONS_MAIL_SUBJECT = "myGeoTracking Agent Debug Info Generated";
	public String CONS_ENTER_ACCURACY_VALUE = "Enter Accuracy value:";
	public String CONS_ACCURACY_IN_METERS = "Accuracy in meters";
	public String CONS_ENTER_TIMEOUT_VALUE = "Enter Timeout Value: ";
	public String CONS_TIMEOUT_IN_SECONDS = "Timeout in seconds";
	String device_number = "", country_code_phone = "";


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settings_mda_layout);

		sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
		sh_prefs_edit = sh_prefs.edit();

		device_number = sh_prefs.getString(MDACons.DEVICE_NUMBER, "");

		app_context = (myGeoTrackingDevieAgentApplication) getApplicationContext();

		//send_location_checkbox = (CheckBox) findViewById(R.id.location_enable_checkbox);

		location_shot_sett_lay = (LinearLayout) findViewById(R.id.location_shot_settings_layout);

		settings_accuracy_layout = (LinearLayout) findViewById(R.id.settings_accuracy_layout);
		settings_timeout_layout = (LinearLayout) findViewById(R.id.settings_timeout_layout);

		settings_accuracy_border = (View) findViewById(R.id.settings_accuracy_border);
		settings_timeout_border = (View) findViewById(R.id.settings_timout_border);

		settings_accuracy_text = (TextView) findViewById(R.id.settings_accuracy_textview);
		settings_timout_text = (TextView) findViewById(R.id.settings_timout_textview);

		identities_text_phone_guid = (TextView) findViewById(R.id.identities_text_guid);
		identities_text_phone_number = (TextView) findViewById(R.id.identities_text_phone_number);
		String deviceNumber = sh_prefs.getString(MDACons.DEVICE_NUMBER, "NA");
		final String callingCountryCode = sh_prefs.getString(MDACons.DEVICE_NUMBER_COUNTRY_CALLING_CODE, "");

		if(deviceNumber.length() > 10)
			deviceNumber = "+"+deviceNumber;
		else if(deviceNumber.length() == 10 && callingCountryCode.length() > 0 && callingCountryCode.equals("1"))
			deviceNumber = "+" + callingCountryCode + deviceNumber;
		else
			deviceNumber = "+"+deviceNumber;

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			deviceNumber = PhoneNumberUtils.formatNumber(deviceNumber, Locale.getDefault().getCountry());
		} else {
			//Deprecated method
			deviceNumber = PhoneNumberUtils.formatNumber(deviceNumber);
		}

		identities_text_phone_number.setText("Device number: "+ deviceNumber);
		identities_text_phone_guid.setText("GUID: "+sh_prefs.getString(MDACons.DEVICE_GUID, "NA"));
		
		identities_layout = (LinearLayout) findViewById(R.id.identities_layout);
		
		identities_layout.setOnTouchListener(new View.OnTouchListener() {


		@SuppressLint("NewApi")
		@Override
		public boolean onTouch(View arg0, MotionEvent motionEvent) {

			switch (motionEvent.getAction()){
	        case MotionEvent.ACTION_DOWN:
	        if (Build.VERSION.SDK_INT >= 21) {
	      	  identities_layout.animate().setDuration(100).scaleX(1.1f).scaleY(1.1f).translationZ(10);
	        } else {
	      	  identities_layout.animate().setDuration(100).scaleX(1.1f).scaleY(1.1f);
	        }
	        return true;
	        case MotionEvent.ACTION_CANCEL:
	        case MotionEvent.ACTION_UP:
	        if (Build.VERSION.SDK_INT >= 21) {
	      	  identities_layout.animate().setDuration(100).scaleX(1).scaleY(1).translationZ(0);
	        } else {
	      	  identities_layout.animate().setDuration(100).scaleX(1).scaleY(1);
	        }
	        return true;

	        }
		return true;
		}
		});
		
		

		location_shot_setttings_button = (Button) findViewById(R.id.location_shot_settings_button);
		re_register_button = (Button) findViewById(R.id.re_register_button);

		send_debug_info_button = (Button) findViewById(R.id.send_debug_button);

		about_button = (Button) findViewById(R.id.about_button_view);


		mAnimation = AnimationUtils.loadAnimation(this,
				R.anim.dropfromdownanimation);

		about_button.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent settings_intent_two = new Intent(getApplicationContext(),
						AboutActivity.class);
				startActivity(settings_intent_two);

			}
		});


		re_register_button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {


				FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(SettingsAcitivty.this);
				Bundle bundle = new Bundle();
				bundle.putString(AnalyticsKey.EVENT_STATE, AnalyticsCons.ITEM_CLICKED);
				mFirebaseAnalytics.logEvent(AnalyticsEvent.RE_REGISTRATION_EVENT, bundle);

				Intent settings_intent = new Intent(getApplicationContext(),
						SetIdentitiesActivity.class);
				startActivity(settings_intent);
				finish();
			}
		});

		send_debug_info_button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {


				FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(SettingsAcitivty.this);
				Bundle bundle = new Bundle();
				bundle.putString(AnalyticsKey.EVENT_STATE, AnalyticsCons.ITEM_SUBMITTED);
				mFirebaseAnalytics.logEvent(AnalyticsEvent.SEND_DEBUG_INFO_EVENT, bundle);

				Intent emailIntent = new Intent(
						android.content.Intent.ACTION_SEND);
				String aEmailList[] = { CONS_SUPPORT_MAIL_ID };
				emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL,
						aEmailList);
				emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,
						"myGeoTracking Agent Debug Info - Device Generated");

				String phone = "", guid = "";

				String  uniqueID = UUID.randomUUID().toString();
				Log.d("UNIQ ","UNIQ "+uniqueID + "PHJONE "+device_number);

				String versionName = "";
				try {
					versionName = SettingsAcitivty.this.getPackageManager()
							.getPackageInfo(SettingsAcitivty.this.getPackageName(), 0).versionName;
				} catch (NameNotFoundException e) {
					e.printStackTrace();
				}
				
//
//				for (int i = 0; i < ident_list.size(); i++) {
//					Identity item = ident_list.get(i);
//					if (item.getType().equals("tel"))
//						phone = item.getValue();
//					else if (item.getType().equals("gud"))
//						guid = item.getValue();
//
//				}

				Log.d("GUIOSDRED ", "GUIOSDRED "+phone + "COUINRET "+callingCountryCode);

				country_code_phone = "+"+callingCountryCode+device_number;
				emailIntent
						.putExtra(
								android.content.Intent.EXTRA_TEXT,
								"\nDevice Details:\n\nPhone#: "
										+ country_code_phone
										+ "\nGUID: "
										+ uniqueID
										+ "\nApp Version: "
										+ versionName
										+ "\nPlatform: "
										+ "Android"
										+ "\n\n\nDebug information - shared from myGeoTracking Agent Application.");
				emailIntent.setType("plain/text");

				startActivity(Intent.createChooser(emailIntent,
						MDACons.MSG_SEND_YOUR_EMAIL_IN));

				HeartBeat.getInstance().justOneBeat(SettingsAcitivty.this, TriggerSource.DEBUG_INFO_SENT);

			}
		});


		location_shot_setttings_button
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {

						if (settings_accuracy_layout.getVisibility() == View.GONE) {

							settings_accuracy_layout
									.setVisibility(View.VISIBLE);
							settings_timeout_layout.setVisibility(View.VISIBLE);
							settings_accuracy_border
									.setVisibility(View.VISIBLE);
							settings_timeout_border.setVisibility(View.VISIBLE);


							settings_accuracy_text.setText("Accuracy: "
									+ sh_prefs.getInt(
											MDACons.LOCATION_SHOT_ACCURACY, 0)
									+ " Meters.");
							settings_timout_text.setText("Time out: "
									+ sh_prefs.getInt(
											MDACons.LOCATION_SHOT_TIMEOUT, 0)
									+ " Seconds.");
						} else {
							settings_accuracy_layout.setVisibility(View.GONE);
							settings_timeout_layout.setVisibility(View.GONE);
							settings_accuracy_border.setVisibility(View.GONE);
							settings_timeout_border.setVisibility(View.GONE);

						}
					}
				});

		settings_accuracy_layout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				showDialog(SHOW_ACCURACY_DIALOG);
			}
		});

		settings_timeout_layout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				showDialog(SHOW_TIMEOUT_DIALOG);
			}
		});
	}


	private Handler textHandler = new Handler() {
		public void handleMessage(Message msg) {
			if (msg.what == 0002001) {

				settings_accuracy_layout.setVisibility(View.VISIBLE);
				settings_timeout_layout.setVisibility(View.VISIBLE);
				settings_accuracy_border.setVisibility(View.VISIBLE);
				settings_timeout_border.setVisibility(View.VISIBLE);

				settings_accuracy_text.setText("Accuracy: "
						+ sh_prefs.getInt(MDACons.LOCATION_SHOT_ACCURACY, 0)
						+ " Meters.");
				settings_timout_text.setText("Time out: "
						+ sh_prefs.getInt(MDACons.LOCATION_SHOT_TIMEOUT, 0)
						+ " Seconds.");
			}

		}
	};

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case SHOW_ACCURACY_DIALOG: {
			return createAccuracyDialog();
		}

		case SHOW_TIMEOUT_DIALOG: {
			return createTimeoutDialog();
		}
		}

		return super.onCreateDialog(id);
	}

	@Override
	protected void onPrepareDialog(int id, Dialog dialog) {
		switch (id) {

		}
		super.onPrepareDialog(id, dialog);
	}

	public Dialog createAccuracyDialog() {
		Dialog d = new Dialog(this);
		Window w = d.getWindow();
		w.setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
				WindowManager.LayoutParams.FLAG_BLUR_BEHIND);

		d.setTitle(CONS_ENTER_ACCURACY_VALUE);
		d.setContentView(R.layout.set_identity_dialog);
		Button okButton = (Button) d.findViewById(R.id.buttonOk);
		Button cancelButton = (Button) d.findViewById(R.id.buttonCancel);

		final EditText editNewValue = (EditText) d
				.findViewById(R.id.editNewValue);

		editNewValue.setInputType(InputType.TYPE_CLASS_NUMBER);
		editNewValue.setHint(CONS_ACCURACY_IN_METERS);
		okButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String newValue = editNewValue.getText().toString();

				if (newValue.length() >= 1) {

					dismissDialog(SHOW_ACCURACY_DIALOG);

					sh_prefs_edit.putInt(MDACons.LOCATION_SHOT_ACCURACY,
							Integer.parseInt(newValue));
					sh_prefs_edit.commit();

					textHandler.sendMessage(textHandler.obtainMessage(0002001));
				}

			}
		});

		cancelButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dismissDialog(SHOW_ACCURACY_DIALOG);
			}
		});

		return d;
	}

	public Dialog createTimeoutDialog() {
		Dialog d = new Dialog(this);
		Window w = d.getWindow();
		w.setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
				WindowManager.LayoutParams.FLAG_BLUR_BEHIND);

		d.setTitle(CONS_ENTER_TIMEOUT_VALUE);
		d.setContentView(R.layout.set_identity_dialog);
		Button okButton = (Button) d.findViewById(R.id.buttonOk);
		Button cancelButton = (Button) d.findViewById(R.id.buttonCancel);

		final EditText editNewValue = (EditText) d
				.findViewById(R.id.editNewValue);

		editNewValue.setInputType(InputType.TYPE_CLASS_NUMBER);
		editNewValue.setHint(CONS_TIMEOUT_IN_SECONDS);
		okButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String newValue = editNewValue.getText().toString();
				if (newValue.length() >= 1) {
					dismissDialog(SHOW_TIMEOUT_DIALOG);

					sh_prefs_edit.putInt(MDACons.LOCATION_SHOT_TIMEOUT,
							Integer.parseInt(newValue));
					sh_prefs_edit.commit();
					textHandler.sendMessage(textHandler.obtainMessage(0002001));
				}
			}
		});

		cancelButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dismissDialog(SHOW_TIMEOUT_DIALOG);
			}
		});

		return d;
	}

	@Override
	protected void onResume() {
		super.onResume();

	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
			case android.R.id.home:
				finish();
				return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
	}



}
package net.abaqus.mygeotracking.deviceagent.hos;

import net.abaqus.mygeotracking.deviceagent.notes.ImageAttachment;

import java.util.ArrayList;

/**
 * Created by root on 15/11/16.
 */

public class HOSEntry {

    private String deviceId;
    private String hos_value_to_push;
    private String hos_desc_to_push;
    private String hos_sms_command_to_push;
    private String hos_time_to_push;
    private String selectedJobId;
    private String selectedCustomerId;
    private String selectedWorkOrderId;
    private String typedMessageContent;
    private String qrResultText;
    private String deviceGUID;
    private ArrayList<ImageAttachment> attachmentBlock;
    private String formfdUID;


    public String getHos_desc_to_push() {
        return hos_desc_to_push;
    }

    public void setHos_desc_to_push(String hos_desc_to_push) {
        this.hos_desc_to_push = hos_desc_to_push;
    }

    public String getHos_sms_command_to_push() {
        return hos_sms_command_to_push;
    }

    public void setHos_sms_command_to_push(String hos_sms_command_to_push) {
        this.hos_sms_command_to_push = hos_sms_command_to_push;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getHos_value_to_push() {
        return hos_value_to_push;
    }

    public void setHos_value_to_push(String hos_value_to_push) {
        this.hos_value_to_push = hos_value_to_push;
    }

    public String getHos_time_to_push() {
        return hos_time_to_push;
    }

    public void setHos_time_to_push(String hos_time_to_push) {
        this.hos_time_to_push = hos_time_to_push;
    }

    public String getSelectedJobId() {
        return selectedJobId;
    }

    public void setSelectedJobId(String selectedJobId) {
        this.selectedJobId = selectedJobId;
    }

    public String getSelectedCustomerId() {
        return selectedCustomerId;
    }

    public void setSelectedCustomerId(String selectedCustomerId) {
        this.selectedCustomerId = selectedCustomerId;
    }

    public String getTypedMessageContent() {
        return typedMessageContent;
    }

    public void setTypedMessageContent(String typedMessageContent) {
        this.typedMessageContent = typedMessageContent;
    }

    public String getQrResultText() {
        return qrResultText;
    }

    public void setQrResultText(String qrResultText) {
        this.qrResultText = qrResultText;
    }

    public String getDeviceGUID() {
        return deviceGUID;
    }

    public void setDeviceGUID(String deviceGUID) {
        this.deviceGUID = deviceGUID;
    }

    public ArrayList<ImageAttachment> getAttachmentBlock() {
        return attachmentBlock;
    }

    public void setAttachmentBlock(ArrayList<ImageAttachment> attachmentBlock) {
        this.attachmentBlock = attachmentBlock;
    }

    public String getFormfdUID() {
        return formfdUID;
    }

    public void setFormfdUID(String formfdUID) {
        this.formfdUID = formfdUID;
    }

    public String getSelectedWorkOrderId() {
        return selectedWorkOrderId;
    }

    public void setSelectedWorkOrderId(String selectedWorkOrderId) {
        this.selectedWorkOrderId = selectedWorkOrderId;
    }

}

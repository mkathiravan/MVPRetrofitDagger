package net.abaqus.mygeotracking.deviceagent.updatechecker;

/**
 * The storeof the app. Can set it with setStore(Store). Default is Google Play.
 * 
 */
public class Store {
    public static final Store GOOGLE_PLAY = new Store(0);
  //  public static final Store AMAZON = new Store(1);

    int mStore;

    public Store(int store) {
        mStore = store;
    }
}
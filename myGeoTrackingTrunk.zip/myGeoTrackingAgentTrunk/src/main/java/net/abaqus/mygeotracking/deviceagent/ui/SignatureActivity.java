package net.abaqus.mygeotracking.deviceagent.ui;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobTable;
import net.abaqus.mygeotracking.deviceagent.notes.SignatureView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by bm on 21/10/15.
 */
public class SignatureActivity extends Activity {


    private static final String	CANT_SHARE_EMPTY_VIEW	= "Please sign, save and share!!";

    private static final String	CANT_SHARE_UNSAVED_VIEW	= "Please save the changes before share!!";

    private Context mContext 		= null;
    private FrameLayout mainView 		= null;
    private SignatureView signatureView = null;

    Button sign_attach, sign_clear, sign_close;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signature);

        mContext 	= this;
        mainView 	= (FrameLayout) findViewById(R.id.main_view);
        sign_attach = (Button) findViewById(R.id.btn_sign_attach);
        sign_clear = (Button) findViewById(R.id.btn_sign_clear);
        sign_close = (Button) findViewById(R.id.btn_sign_close);
        signatureView = new SignatureView(this, null);
        mainView.addView(signatureView);


        sign_attach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = getIntent();
                if(saveSignature(i, v)) {
                    setResult(RESULT_OK, i);
                    finish();
                }
            }
        });

        sign_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            signatureView.clear();
            }
        });

        sign_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });
    }


    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
    }



    @Override
    protected void onResume() {
        super.onResume();
    }

    private boolean saveSignature(Intent intent, View view) {
        String fileName = "";
        File directory = null;
        if (!SignatureView.IS_STORED) {
            if (!signatureView.getDrawingAvailability()) {

                SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
                Date now = new Date();
                fileName = "signature_" + formatter.format(now) + ".png";

                ContextWrapper cw = new ContextWrapper(getApplicationContext());
                // path to /data/data/yourapp/app_data/imageDir
                directory = cw.getDir("images", Context.MODE_PRIVATE);
                // Create imageDir
                File mypath = new File(directory, fileName);

                FileOutputStream fos = null;
                try {

                    fos = new FileOutputStream(mypath);

                    // Use the compress method on the BitMap object to write image to the OutputStream
                    getBitmap().compress(Bitmap.CompressFormat.PNG, 50, fos);
                    fos.close();
                    intent.putExtra("signature_path", directory.getAbsolutePath());
                    intent.putExtra("file_name", fileName);
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }
                return true;
            } else {
                Toast.makeText(SignatureActivity.this, "No signature found.", Toast.LENGTH_SHORT).show();
                return false;
            }
        }else{
            return false;
        }
    }

    private Bitmap getBitmap() {
        mainView.setDrawingCacheEnabled(true);
        mainView.buildDrawingCache();
        Bitmap bm = mainView.getDrawingCache();
        return bm;
    }






}
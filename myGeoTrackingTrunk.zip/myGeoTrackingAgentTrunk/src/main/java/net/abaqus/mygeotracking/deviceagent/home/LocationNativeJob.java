package net.abaqus.mygeotracking.deviceagent.home;

import android.content.Context;
import android.os.Bundle;

import com.firebase.jobdispatcher.Constraint;
import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.Lifetime;
import com.firebase.jobdispatcher.RetryStrategy;
import com.firebase.jobdispatcher.Trigger;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

public class LocationNativeJob {

    private static final String KEY_TRIGGER_SOURCE = "locationSource";
    private static LocationNativeJob uniqueInstance;

    private LocationNativeJob()
    {
        if(uniqueInstance!= null)
        {
            throw new RuntimeException("Use getInstance() method to get the single instance of this class.");
        }
    }

    public static synchronized LocationNativeJob getInstance()
    {
        if(uniqueInstance == null)
        {
            uniqueInstance = new LocationNativeJob();
        }
        return uniqueInstance;
    }

    public void startTracking(Context applicationContext)
    {
       int interval = 15;
       Bundle bundle = new Bundle();
       FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(applicationContext));
        Job myJob = dispatcher.newJobBuilder()
                .setService(NativeLocationTrackService.class)
                .setTag("location_tracking")
                .setExtras(bundle)
                .setRecurring(true)
                .setLifetime(Lifetime.FOREVER)
                .setTrigger(Trigger.executionWindow(20*60,35*60))
                .setReplaceCurrent(true)
                .setRetryStrategy(RetryStrategy.DEFAULT_EXPONENTIAL)
                .setConstraints(Constraint.DEVICE_IDLE)
                .build();
        dispatcher.schedule(myJob);
    }


}

package net.abaqus.mygeotracking.deviceagent.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import net.abaqus.mygeotracking.deviceagent.R;

/**
 * Created by bm on 3/8/15.
 */
public class MDAMainActivitySample extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_layout);
    }
}

package net.abaqus.mygeotracking.deviceagent.sixgill;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;

import com.sixgill.protobuf.Ingress;

import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.hos.HOSActivity;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkDeviceStatus;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import io.nlopez.smartlocation.OnLocationUpdatedListener;
import io.nlopez.smartlocation.SmartLocation;
import io.nlopez.smartlocation.location.config.LocationParams;

public class InsertEventValues {

    private static final String TAG = InsertEventValues.class.getSimpleName();
    Context context;
    Ingress.Event event;
    ProviderInfoTable providerInfoTable;
    SharedPreferences sh_prefs;
    private SharedPreferences.Editor sh_prefs_edit;
    String device_number = "";
    String localTime = "";

    public InsertEventValues(Context context,Ingress.Event event) {
        this.context = context;
        this.event = event;
        sh_prefs = context.getSharedPreferences(MDACons.PREFS, 0);
        sh_prefs_edit = sh_prefs.edit();
        device_number = sh_prefs.getString(MDACons.DEVICE_NUMBER, "");

    }


    public void insert_data(Ingress.Event event) {

        providerInfoTable = new ProviderInfoTable();
        providerInfoTable.setProvider("sixgill");
        providerInfoTable.setStatusCode(12450);
        providerInfoTable.setStatusMsg("");
        providerInfoTable.setDeviceID(device_number);
        providerInfoTable.setRegionCode("");
        providerInfoTable.setCountryCode("");
        providerInfoTable.setRegionCountry("");
        providerInfoTable.setNationalNumber("");

        String connect_method = NetworkDeviceStatus.checkNetworkStatus(context);
        providerInfoTable.setLocateMethod(connect_method);
        providerInfoTable.setCoordinateFormat("");

        if (event.getProperties() != null) {
            Ingress.Property receivedProperty = event.getProperties();
            providerInfoTable.setManufacturer(receivedProperty.getManufacturer());
            providerInfoTable.setModel(receivedProperty.getModel());
            providerInfoTable.setOs(receivedProperty.getOs());
            providerInfoTable.setOs_version(receivedProperty.getOsVersion());
            if (receivedProperty.getSensorsList().size() > 0) {
                providerInfoTable.setSensors(receivedProperty.getSensorsList().get(receivedProperty.getSensorsList().size() - 1));
            }
            providerInfoTable.setSoftware_version(receivedProperty.getSoftwareVersion());
//                providerInfoTable.setTimestamp(receivedProperty.getTimestamp());
            providerInfoTable.setType(receivedProperty.getType());
        }

        if (event.getPowersList().size() > 0) {
            Ingress.Power receivedPower = event.getPowersList().get(event.getPowersList().size() - 1);
            providerInfoTable.setBatteryLevel(0);
            providerInfoTable.setBattery_life(receivedPower.getBatteryLife());
            providerInfoTable.setCharging(receivedPower.getCharging());
            providerInfoTable.setCharging(receivedPower.getCharging());
//                providerInfoTable.setTimestamp(receivedPower.getTimestamp());
            String methodParam = NetworkDeviceStatus.checkNetworkStatus(context);
            providerInfoTable.setMethod(methodParam);
            providerInfoTable.setSpeed("");
            providerInfoTable.setMovementDetected("");

        }

        locationData(event);
    }


    public void locationData(Ingress.Event mEvent) {
        Log.d(TAG,"LUINSE "+mEvent.getLocationsList() + "OOP" +mEvent.getLocationsList().size());
        if(mEvent.getLocationsList() != null && mEvent.getLocationsList().size() > 0)
        {
            Ingress.Location location = mEvent.getLocations(mEvent.getLocationsList().size() - 1);
            Log.wtf(TAG,"INSERTLATITUDE "+location.getLatitude());

            Log.d(TAG,"LOCATIONTIMESTAMP "+location.getTimestamp());


            providerInfoTable.setAccuracy(location.getAccuracy());
            providerInfoTable.setLatitude(location.getLatitude());
            providerInfoTable.setLongitude(location.getLongitude());

            Date date = new Date(location.getTimestamp());
            Log.d(TAG,"DATAFIMAT "+date + " TOSTRING "+date.toString());




            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US);
            GregorianCalendar gc = new GregorianCalendar();
            String location_time = formatter.format(date.getTime());
            Log.d(TAG,"LOCATINTIME "+location_time);

            sh_prefs_edit.putString(MDACons.SIXGILL_LAST_LOCATION_EVENT_TIME, String.valueOf(location.getTimestamp()));
            sh_prefs_edit.commit();

            providerInfoTable.setLocateTime(location_time);

            providerInfoTable.save();





        }
        else if(mEvent.getLocationsList().isEmpty() && mEvent.getLocationsList().size() == 0)
        {
            Log.d(TAG,"EMPTYLOCATINOBKE ");

            FusedProvider fusedProvider = MDAMainActivity.getInstanceLocation();
            double latitude = fusedProvider.getLatitude();
            double longitude = fusedProvider.getLongitude();
            long time = fusedProvider.getTime();

            providerInfoTable.setAccuracy(fusedProvider.getAccuracy());
            providerInfoTable.setLatitude(Float.valueOf((float) latitude));
            providerInfoTable.setLongitude(Float.valueOf((float) longitude));

            Date date = new Date(time);
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US);
            GregorianCalendar gc = new GregorianCalendar();
            String native_location_time = formatter.format(date.getTime());

            sh_prefs_edit.putString(MDACons.SIXGILL_LAST_LOCATION_EVENT_TIME, String.valueOf(fusedProvider.getTime()));
            sh_prefs_edit.commit();

            providerInfoTable.setLocateTime(native_location_time);
            providerInfoTable.save();



            sh_prefs_edit.putString(MDACons.NATIVE_LAST_LOCATION_EVENT_TIME,native_location_time);
            sh_prefs_edit.commit();

            // \n is for new line
            Log.wtf(TAG, "NATIVEVALIETEIME " + latitude + "OPIOSE " + longitude + "NATICELOCATIME "+native_location_time);

        }




    }
}

package net.abaqus.mygeotracking.deviceagent.listeners;

import net.abaqus.mygeotracking.deviceagent.ViewUtils.FlipCheckBox;

/**
 * Custom Listener
 * @author Francisco Manuel López Jurado
 *
 */
public interface OnFlipCheckedChangeListener {

	public void onCheckedChanged(FlipCheckBox flipCardView, boolean isChecked);
}

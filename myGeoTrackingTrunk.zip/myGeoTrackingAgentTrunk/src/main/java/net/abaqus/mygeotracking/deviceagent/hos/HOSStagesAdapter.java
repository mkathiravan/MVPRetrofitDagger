package net.abaqus.mygeotracking.deviceagent.hos;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.support.design.widget.CoordinatorLayout;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;


/**
 * Created by root on 25/5/17.
 */

// Create the basic adapter extending from RecyclerView.Adapter
// Note that we specify the custom ViewHolder which gives us access to our views
public class HOSStagesAdapter extends RecyclerView.Adapter<HOSStagesAdapter.ViewHolder> {


    private List<HOSStage> hosStageList;
    // Store the context for easy access
    private Context mContext;
    private SharedPreferences sh_prefs;

    private OnItemClickListener listener;





    // Define the listener interface
    public interface OnItemClickListener {
        void onItemClick(View itemView, int position);
    }
    // Define the method that allows the parent activity or fragment to define the listener
    public void setOnItemClickListener(OnItemClickListener listener)
    {
        this.listener = listener;
    }
    public HOSStagesAdapter(List<HOSStage> hosStageListParam, Context mContext) {
        this.hosStageList = hosStageListParam;
        this.mContext = mContext;
        this.sh_prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
    }

    public void updateDataSet(List<HOSStage> hosStageListParam) {
        this.hosStageList = hosStageListParam;
    }

    // Easy access to the context object in the recyclerview
    private Context getContext() {
        return mContext;
    }


    // Usually involves inflating a layout from XML and returning the holder
    @Override
    public HOSStagesAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the custom layout
        View contactView = inflater.inflate(R.layout.list_item_hos_stages, parent, false);

        // Return a new holder instance
        ViewHolder viewHolder = new ViewHolder(contactView);
        return viewHolder;
    }

    // Involves populating data into the item through holder
    @Override
    public void onBindViewHolder(HOSStagesAdapter.ViewHolder viewHolder, int position) {
        // Get the data model based on position
        HOSStage hosStage = hosStageList.get(position);

        // Set item views based on your views and data model
        TextView stageName = viewHolder.stageName;
        TextView stageStatus = viewHolder.stageStatus;
        LinearLayout stageLayout = viewHolder.stageLayout;



        // Following lines are responsible for showing up the HOS stages Buttons
        String hos_Selection = this.sh_prefs.getInt(MDACons.HOS_SELECTION, -1)
                + "";
        String time = "";
        SimpleDateFormat sdf = new java.text.SimpleDateFormat(
                "yyyy/MM/dd,HH:mm:ss", Locale.getDefault());


        if (hosStage.getStageID().equals("7")) {
            //viewHolder.itemView.setVisibility(View.GONE);
            stageLayout.setVisibility(View.GONE);
            stageName.setVisibility(View.GONE);
            stageStatus.setVisibility(View.GONE);
            }
        else {

            stageStatus.setPadding(0,0,0,0);
            stageName.setVisibility(View.VISIBLE);
            stageStatus.setVisibility(View.VISIBLE);
            stageName.setText(hosStage.getStageName());
        }


        if (hos_Selection.equals(hosStage.getStageID())) {
            try {
                SimpleDateFormat formatter = new SimpleDateFormat(
                        "yyyy/MM/dd'T'HH:mm:ssZ",
                        Locale.getDefault());
                Date date = (Date) formatter.parse(sh_prefs
                        .getString(MDACons.HOS_TIME, ""));
                time = sdf.format(date).toString();
            } catch (ParseException e) {

                e.printStackTrace();
            }
            if(hos_Selection.equals("7")) {

            }
            stageStatus.setText(""+time);
            stageLayout.setBackgroundColor(ContextCompat.getColor(mContext, R.color.blue));
            stageName.setTextColor(Color.WHITE);
            stageStatus.setTextColor(Color.WHITE);
        } else {


            stageStatus.setVisibility(View.INVISIBLE);
            stageLayout.setBackgroundColor(Color.WHITE);
            stageName.setTextColor(ContextCompat.getColor(mContext, R.color.text_gray));
            stageStatus.setTextColor(ContextCompat.getColor(mContext, R.color.text_gray));
        }
    }

    // Returns the total count of items in the list
    @Override
    public int getItemCount() {
        return hosStageList.size();
    }


    // Provide a direct reference to each of the views within a data item
    // Used to cache the views within the item layout for fast access
    public class ViewHolder extends RecyclerView.ViewHolder {
        // Your holder should contain a member variable
        // for any view that will be set as you render a row
        TextView stageName;
        TextView stageStatus;
        LinearLayout stageLayout;


        // We also create a constructor that accepts the entire item row
        // and does the view lookups to find each subview
        public ViewHolder(final View itemView) {
            // Stores the itemView in a public final member variable that can be used
            // to access the context from any ViewHolder instance.
            super(itemView);

            stageName = (TextView) itemView.findViewById(R.id.tv_hos_stages_name);
            stageStatus = (TextView) itemView.findViewById(R.id.tv_hos_stages_status);
            stageLayout = (LinearLayout) itemView.findViewById(R.id.hos_stages_layout);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Triggers click upwards to the adapter on click
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(itemView, position);
                        }
                    }
                }
            });
        }
    }

    // Clean all elements of the recycler
    public void clear() {
        hosStageList.clear();
        notifyDataSetChanged();
    }

    // Add a list of items
    public void addAll(List<HOSStage> list) {
        hosStageList.addAll(list);
        notifyDataSetChanged();
    }

}
package net.abaqus.mygeotracking.deviceagent.home;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.BatteryManager;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import com.activeandroid.query.Delete;
import com.activeandroid.query.Select;
import com.crashlytics.android.Crashlytics;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiClient;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiInterface;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkDeviceStatus;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import retrofit2.Call;
import retrofit2.Response;

public class LocationUpdatesService extends Service {

    private static final String PACKAGE_NAME = "net.abaqus.mygeotracking.deviceagent";

    private static final String TAG = LocationUpdatesService.class.getSimpleName();

    private static final String CHANNEL_ID = "channel_01";

    static final String ACTION_BROADCAST = PACKAGE_NAME + ".broadcast";

    static final String EXTRA_LOCATION = PACKAGE_NAME + ".location";
    private static final String EXTRA_STARTED_FROM_NOTIFICATION = PACKAGE_NAME +
            ".started_from_notification";

    private final IBinder mBinder = new LocalBinder();


    private static final long UPDATE_INTERVAL_IN_MILLISECONDS = 300000;


    private static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = UPDATE_INTERVAL_IN_MILLISECONDS / 2;


    private static final int NOTIFICATION_ID = 12345678;


    private boolean mChangingConfiguration = false;

    private NotificationManager mNotificationManager;


    private LocationRequest mLocationRequest;


    static final int MSG_SAY_HELLO = 1;


    private FusedLocationProviderClient mFusedLocationClient;


    private LocationCallback mLocationCallback;

    private Handler mServiceHandler;

    private Location mLocation;

    long cadence_frequncy;

    NativeLocationTable nativeLocationTable;

    private List<NativeLocationTable> nativeLocationTableList;

    String device_number = "";

    private PowerManager.WakeLock mWakeLock;

    public LocationUpdatesService() {
    }

    @Override
    public void onCreate() {

        Log.d(TAG, "SERVICE ONCREATECALLED ");

        SharedPreferences prefs = getSharedPreferences(MDACons.PREFS, 0);
        cadence_frequncy = Long.parseLong(prefs.getString(MDACons.TRACKING_FREQUENCY, ""));
        Log.d(TAG, "GETTING THE FREQUENCY " + cadence_frequncy);

        device_number = prefs.getString(MDACons.DEVICE_NUMBER, "");

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        mLocationCallback = new LocationCallback() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                onNewLocation(locationResult.getLastLocation());
            }
        };

        createLocationRequest();
        getLastLocation();

        HandlerThread handlerThread = new HandlerThread(TAG);
        handlerThread.start();
        mServiceHandler = new Handler(handlerThread.getLooper());
        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        // Android O requires a Notification Channel.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
           // CharSequence name = "Tracking";//getString(R.string.app_name);
            CharSequence name = getString(R.string.app_name);
            // Create the channel for the notification
            NotificationChannel mChannel =
                    new NotificationChannel(CHANNEL_ID, name, NotificationManager.IMPORTANCE_LOW);
            mChannel.setDescription("Important notification. App will not work properly if you change the settings.");
            // Set the Notification Channel for the Notification Manager.
            mChannel.setSound(null,null);
            mChannel.setVibrationPattern(null);
            mChannel.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
            mNotificationManager.createNotificationChannel(mChannel);
        }
    }

    @SuppressLint("InvalidWakeLockTag")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Service onStartCommand Called");
        boolean startedFromNotification = intent.getBooleanExtra(EXTRA_STARTED_FROM_NOTIFICATION,
                false);

        startForeground(NOTIFICATION_ID, getNotification());
        requestLocationUpdates();

        // We got here because the user decided to remove location updates from the notification.
        if (startedFromNotification) {
            removeLocationUpdates();
            stopSelf();
        }

//        PowerManager pm = (PowerManager)getSystemService(Context.POWER_SERVICE);
//        mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MyWakeLock");
//        mWakeLock.acquire();

        // mLocationcall = (NativeLocationCall)this.getApplicationContext();
        // Tells the system to not try to recreate the service after it has been killed.
        return START_NOT_STICKY;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        Log.d(TAG, "SERVICE onConfigurationChanged");
        super.onConfigurationChanged(newConfig);
        mChangingConfiguration = true;
    }

    @Override
    public IBinder onBind(Intent intent) {
        // Called when a client (MainActivity in case of this sample) comes to the foreground
        // and binds with this service. The service should cease to be a foreground service
        // when that happens.
        Log.i(TAG, "in onBind()");
        stopForeground(true);
        mChangingConfiguration = false;
        return mBinder;
    }

    @Override
    public void onRebind(Intent intent) {
        // Called when a client (MainActivity in case of this sample) returns to the foreground
        // and binds once again with this service. The service should cease to be a foreground
        // service when that happens.
        Log.i(TAG, "in onRebind()");
        stopForeground(true);
        mChangingConfiguration = false;
        super.onRebind(intent);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.i(TAG, "Last client unbound from service");

        // Called when the last client (MainActivity in case of this sample) unbinds from this
        // service. If this method is called due to a configuration change in MainActivity, we
        // do nothing. Otherwise, we make this service a foreground service.
        if (!mChangingConfiguration && Utils.requestingLocationUpdates(this)) {
            Log.i(TAG, "Starting foreground service");

            startForeground(NOTIFICATION_ID, getNotification());
        }
        return true; // Ensures onRebind() is called when a client re-binds.
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "SERVICE ONDESTROYCALLED");
        removeLocationUpdates();
        mServiceHandler.removeCallbacksAndMessages(null);
        //mWakeLock.release();
    }

    /**
     * Makes a request for location updates. Note that in this sample we merely log the
     * {@link SecurityException}.
     */
    public void requestLocationUpdates() {
        Log.i(TAG, "Requesting location updates");
        Utils.setRequestingLocationUpdates(this, true);
        // startService(new Intent(getApplicationContext(), LocationUpdatesService.class));
        try {
            mFusedLocationClient.requestLocationUpdates(mLocationRequest,
                    mLocationCallback, Looper.myLooper());
        } catch (SecurityException unlikely) {
            Utils.setRequestingLocationUpdates(this, false);
            Log.e(TAG, "Lost location permission. Could not request updates. " + unlikely);
        }
    }

    /**
     * Removes location updates. Note that in this sample we merely log the
     * {@link SecurityException}.
     */
    public void removeLocationUpdates() {
        Log.i(TAG, "Removing location updates");
        try {
            mFusedLocationClient.removeLocationUpdates(mLocationCallback);
            Utils.setRequestingLocationUpdates(this, false);
            stopSelf();
        } catch (SecurityException unlikely) {
            Utils.setRequestingLocationUpdates(this, true);
            Log.e(TAG, "Lost  location permission. Could not remove updates. " + unlikely);
        }
    }

    /**
     * Returns the {@link NotificationCompat} used as part of the foreground service.
     */
    private Notification getNotification() {
        Intent intent = new Intent(this, LocationUpdatesService.class);

        // Extra to help us figure out if we arrived in onStartCommand via the notification or not.
        intent.putExtra(EXTRA_STARTED_FROM_NOTIFICATION, true);

        // The PendingIntent that leads to a call to onStartCommand() in this service.
        PendingIntent servicePendingIntent = PendingIntent.getService(this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);

        // The PendingIntent to launch activity.
        PendingIntent activityPendingIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, MDAMainActivity.class), 0);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                .setContentTitle("mGT is collecting GPS information")
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_LOW)
                .setSound(null)
                .setVibrate(null)
                .setVisibility(Notification.VISIBILITY_SECRET)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setSmallIcon(R.mipmap.ic_launcher_round)
                .setWhen(System.currentTimeMillis());

        // Set the Channel ID for Android O.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId(CHANNEL_ID); // Channel ID
        }

        return builder.build();
    }

    private void getLastLocation() {
        try {
            mFusedLocationClient.getLastLocation()
                    .addOnCompleteListener(new OnCompleteListener<Location>() {
                        @Override
                        public void onComplete(@NonNull Task<Location> task) {
                            if (task.isSuccessful() && task.getResult() != null) {
                                mLocation = task.getResult();
                            } else {
                                Log.w(TAG, "Failed to get location.");
                            }
                        }
                    });
        } catch (SecurityException unlikely) {
            Log.e(TAG, "Lost location permission." + unlikely);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void onNewLocation(Location location) {
        Log.i(TAG, "New location: " + location);
        Log.d(TAG, "LOCATIONVAL " + location.getLatitude() + "LOMDF " + location.getLatitude());

        //mLocationcall.getLocation(location);

        // Notify anyone listening for broadcasts about the new location.
//        Intent intent = new Intent(ACTION_BROADCAST);
//        intent.putExtra(EXTRA_LOCATION, location);
//        LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);


        store_location(location);


        // Update notification content if running as a foreground service.
        if (serviceIsRunningInForeground(this)) {
            mNotificationManager.notify(NOTIFICATION_ID, getNotification());
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void store_location(Location location) {


        nativeLocationTable = new NativeLocationTable();
        nativeLocationTable.setLatitude((float) location.getLatitude());
        nativeLocationTable.setLongitude((float) location.getLongitude());
        nativeLocationTable.setAccuracy(location.getAccuracy());

        long time = location.getTime();

        Date date = new Date(time);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US);
        GregorianCalendar gc = new GregorianCalendar();
        String native_location_time = formatter.format(date.getTime());
        nativeLocationTable.setLocateTime(native_location_time);
        nativeLocationTable.save();

        if (NetworkConnectionInfo.isOnline(LocationUpdatesService.this)) {

            read_from_table_data();

        }

    }

    public List<NativeLocationTable> getInfoData() {
        return new Select().from(NativeLocationTable.class).execute();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void read_from_table_data() {

        nativeLocationTableList = getInfoData();
        read_values_fromDB(nativeLocationTableList);

    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void read_values_fromDB(List<NativeLocationTable> nativeLocationTableList) {

        if(nativeLocationTableList.size() > 0)
        {

            NativeLocationTable nativeLocationTable = nativeLocationTableList.get(0);


            double latitude = nativeLocationTable.getLatitude();
            double longitude = nativeLocationTable.getLongitude();
            final long primary_id = nativeLocationTable.getId();

            final ProviderModel provider = new ProviderModel();
            provider.setProvider("sixgill");
            provider.setStatusCode(12450);
            provider.setStatusMessage("");
            provider.setDeviceId(device_number);

            provider.setRegionCode("");
            provider.setCountryCode("");
            provider.setRegionCountry("");
            provider.setNationalNumber("");
            provider.setCoOrdinateFormat("");


            provider.setLocateTime(nativeLocationTable.getLocateTime());


            GeoModel geo = new GeoModel();


            geo.setAccuracy(nativeLocationTable.getAccuracy());
            geo.setAltitude(0);
            geo.setDirection("");
            geo.setLatitude(nativeLocationTable.getLatitude());
            geo.setLongitude(nativeLocationTable.getLongitude());
            provider.setGeo(geo);

            PropertyModel property = new PropertyModel();


            property.setManufacturer(Build.MANUFACTURER);
            property.setModel(Build.MODEL);
            property.setOs("Android");
            property.setOsVersion(String.valueOf(Build.VERSION.SDK_INT));
            property.setSensors("activity");
            property.setSoftwareVersion("1.1");
            property.setType("Android");
            provider.setProperty(property);

            DeviceModel device = new DeviceModel();

            BatteryManager bm = (BatteryManager) getSystemService(BATTERY_SERVICE);
            int batLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);

            String methodParam = NetworkDeviceStatus.checkNetworkStatus(this);

            provider.setLocateMethod(methodParam);


            device.setMethod(methodParam);
            device.setSpeed("");
            device.setMovementDetected("");
            device.setBatteryLevel(0);
            device.setBatteryLife(batLevel);
            device.setCharging(false);
            provider.setDevice(device);


            AddressModel address = new AddressModel();
            Geocoder geocoder;
            List<Address> addresses;
            geocoder = new Geocoder(this, Locale.getDefault());

            try {

                Log.d(TAG, "ADDRESSLOIUOSPE " + latitude + "KSER " + longitude);
                String street_address, city, state, country, postalCode, full_address, knownName, locationName, countryCode = null;
                addresses = geocoder.getFromLocation(latitude, longitude, 1);
                full_address = addresses.get(0).getAddressLine(0);
                Log.wtf(TAG, "ADDRED " + address + "SAMODRE " + addresses);
                street_address = addresses.get(0).getFeatureName() + " " + addresses.get(0).getThoroughfare();
                city = addresses.get(0).getLocality();
                state = addresses.get(0).getAdminArea();
                country = addresses.get(0).getCountryName();

                if (addresses.get(0).getPostalCode() == null || addresses.get(0).getPostalCode().isEmpty()) {
                    postalCode = "0";
                } else {
                    postalCode = addresses.get(0).getPostalCode();
                }
                knownName = addresses.get(0).getFeatureName();
                countryCode = addresses.get(0).getCountryCode();
                Double lat = addresses.get(0).getLatitude();
                Double lang = addresses.get(0).getLongitude();

                address.setSetStreetAddress(street_address);
                address.setCity(city);
                address.setState(state);
                address.setPostalCode(postalCode);
                address.setCountry(country);
                address.setAddress(full_address);
                provider.setAddress(address);

            } catch (Exception e) {
                Crashlytics.logException(e);
                Log.wtf(TAG, "SAMException ");
                e.printStackTrace();
            }

            Gson gson = new Gson();
            String jsonString = gson.toJson(provider);
            Log.d(TAG, "TOSENDJSONDATA " + jsonString);


            if (NetworkConnectionInfo.isOnline(LocationUpdatesService.this)) {

                android.os.AsyncTask.execute(new Runnable() {
                    @Override
                    public void run() {
                        api_location_call(provider, primary_id);
                    }
                });

            }



        }



    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void api_location_call(ProviderModel provider, final long primary_key) {

        Log.d(TAG,"NATIVETRACKINGAPICALLED ");
        final String locate_time = provider.getLocateTime();
        final ApiInterface requestInterface = ApiClient.getProductionClient();


        // The following code to call the synchronous request
        Void result = null;
        Response<Void> execute;
        boolean isRequestSuccess = false;
        Call<Void> call = requestInterface.sentLocationInfo(provider);
        try {
            execute = call.execute();
            isRequestSuccess = execute.isSuccessful();
            result = execute.body();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(isRequestSuccess) {
            new Delete().from(NativeLocationTable.class).where("locateTime = ?",locate_time).execute();
            if (NetworkConnectionInfo.isOnline(LocationUpdatesService.this))
            {
                read_from_table_data();

            }

        }


    }


    /**
     * Sets the location request parameters.
     */
    private void createLocationRequest() {
        Log.d(TAG,"LOCATUONREQUESTFREQUCY " + cadence_frequncy);
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(cadence_frequncy);
        mLocationRequest.setFastestInterval(cadence_frequncy);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    /**
     * Class used for the client Binder.  Since this service runs in the same process as its
     * clients, we don't need to deal with IPC.
     */
    public class LocalBinder extends Binder {
        public LocationUpdatesService getService() {
            return LocationUpdatesService.this;
        }
    }

    /**
     * Returns true if this is a foreground service.
     *
     * @param context The {@link Context}.
     */
    public boolean serviceIsRunningInForeground(Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(
                Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(
                Integer.MAX_VALUE)) {
            if (getClass().getName().equals(service.service.getClassName())) {
                if (service.foreground) {
                    return true;
                }
            }
        }
        return false;
    }

}

package net.abaqus.mygeotracking.deviceagent.home;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.androidadvance.topsnackbar.TSnackbar;
import com.google.firebase.iid.FirebaseInstanceId;
import com.kbeanie.multipicker.utils.LogUtils;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.notification.NotificationPreferences;
import net.abaqus.mygeotracking.deviceagent.notification.ShareRegistrationToken;
import net.abaqus.mygeotracking.deviceagent.ui.RegisterDeviceActivity;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

/**
 * Created by root on 14/11/17.
 */

public class MainActivityHelper {

    private static final String TAG = MainActivityHelper.class.getSimpleName();

    private static final int PERMISSIONS_REQUEST_SEND_SMS = 202;
    private static final int PERMISSIONS_REQUEST_TELEPHONY = 203;


    private Context mContext;
    private Activity mActivity;

    public MainActivityHelper(Context mContext, Activity mActivity) {
        this.mContext = mContext;
        this.mActivity = mActivity;
    }


    public void showInternetDisabledWarning() {
        DebugLog.debug("HOSSOSDISABLELOG", "Internet disabled warning called - Normal Internet Disabled");
        final TSnackbar snackbar = TSnackbar.make(mActivity.findViewById(android.R.id.content), mContext.getString(R.string.msg_internet_disabled_please_try_later), TSnackbar.LENGTH_INDEFINITE);
        snackbar.setActionTextColor(Color.parseColor("#00adee"));
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(Color.parseColor("#ececec"));
        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
        textView.setTextColor(Color.parseColor("#535454"));
        textView.setTypeface(null, Typeface.BOLD);
        snackbar.setAction("GOT IT", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                snackbar.dismiss();
            }
        });
        snackbar.show();
    }

    public void sendGCMTOServer(SharedPreferences sh_prefs) {
        /*Register with GCM if device number and registeration ID are empty. Or else share the token with
        servers in case the SENT value says false and devcice number and registration ID available*/

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);
        if (sharedPreferences.getBoolean(NotificationPreferences.SENT_TOKEN_TO_MGT_SERVER, false)) {
            DebugLog.debug(TAG, "FCM Token has been shared with server already - So returning immediately without initiating a call to share");
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                ShareRegistrationToken.sendRegistrationToServer(mContext);
            }
        }).start();

    }



    public void checkSMSPersmission() {
        if (ContextCompat.checkSelfPermission(mActivity,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity,
                    Manifest.permission.SEND_SMS)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(mContext, R.style.AppCompatAlertDialogStyle);
                builder.setTitle(R.string.title_msg_denied_sms_permission);
                builder.setMessage(R.string.msg_denied_send_sms_permission);
                builder.setPositiveButton(R.string.btn_action_im_sure, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.setNegativeButton(R.string.btn_action_retry, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityCompat.requestPermissions(mActivity,
                                new String[]{Manifest.permission.SEND_SMS},
                                PERMISSIONS_REQUEST_SEND_SMS);
                    }
                });
                builder.show();

            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(mActivity,
                        new String[]{Manifest.permission.SEND_SMS},
                        PERMISSIONS_REQUEST_SEND_SMS);
            }
        }
    }

    public void checkTelephonyPersmission() {
        if (ContextCompat.checkSelfPermission(mActivity,
                Manifest.permission.PROCESS_OUTGOING_CALLS)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity,
                    Manifest.permission.PROCESS_OUTGOING_CALLS)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(mActivity, R.style.AppCompatAlertDialogStyle);
                builder.setTitle(R.string.title_msg_denied_telephony_permission);
                builder.setMessage(R.string.msg_denied_telephony_permission);
                builder.setPositiveButton(R.string.btn_action_im_sure, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.setNegativeButton(R.string.btn_action_retry, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityCompat.requestPermissions(mActivity,
                                new String[]{Manifest.permission.PROCESS_OUTGOING_CALLS},
                                PERMISSIONS_REQUEST_TELEPHONY);
                    }
                });
                builder.show();
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(mActivity,
                        new String[]{Manifest.permission.PROCESS_OUTGOING_CALLS},
                        PERMISSIONS_REQUEST_TELEPHONY);
            }
        }
    }

}

package net.abaqus.mygeotracking.deviceagent.bgthread;

import android.app.Notification;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;
import android.widget.Toast;

import com.activeandroid.util.SQLiteUtils;
import com.facebook.network.connectionclass.DeviceBandwidthSampler;
import com.sixgill.sync.sdk.Reach;
import com.sixgill.sync.sdk.ReachCallback;
import com.sixgill.sync.sdk.ReachConfig;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiClient;
import net.abaqus.mygeotracking.deviceagent.RetrofitBuilder.ApiInterface;
import net.abaqus.mygeotracking.deviceagent.data.HOSEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.listeners.TaskCompleteListener;
import net.abaqus.mygeotracking.deviceagent.myteam.MyTeamDataPullTask;
import net.abaqus.mygeotracking.deviceagent.sixgill.RegistrationToken;
import net.abaqus.mygeotracking.deviceagent.sixgill.TokenModel;
import net.abaqus.mygeotracking.deviceagent.utils.ConnectionManager;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;

import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlSerializer;

import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by bm on 4/6/15.
 */
public class RegistrationTaskMGT extends AsyncTask<String, Void, Boolean> {

    private static final String TAG = RegistrationTaskMGT.class.getSimpleName();

    // **FIELDS**//
    private Context mContext;
    private SharedPreferences prefs		= null;
    private SharedPreferences.Editor sh_prefs_edit;
    SAXParserFactory spf		= null;
    SAXParser sp		= null;
    /* Get the XMLReader of the SAXParser we created. */
    XMLReader xr		= null;
    /* Create a new ContentHandler and apply it to the XML-Reader */
    HBXmlHandler			HBHandler	= null;
    public static String	error_message	= "";
    private TaskCompleteListener listener;

    public RegistrationTaskMGT(TaskCompleteListener taskCompleteListener, Context con) {
        this.mContext = con;
        this.listener = taskCompleteListener;
        this.prefs = con.getSharedPreferences(MDACons.PREFS, 0);
//        Reach.enable(mContext);
//        String deviceId = prefs.getString(MDACons.DEVICE_NUMBER, "");
//        doInitializeWithSixgill(deviceId);
        HBHandler = new HBXmlHandler();


    }

    protected void onPreExecute() {
        DeviceBandwidthSampler.getInstance().startSampling();

    }

    protected void onPostExecute(Boolean success) {
        DeviceBandwidthSampler.getInstance().stopSampling();


        if (HBHandler.error_occured) {
            if(listener != null){
                listener.onTaskCompleted(false);
            }
            if (HBHandler.getErrorMSG().contains(
                    "Can not find a account for the Device with")) {
                //Toast.makeText(mContext.getApplicationContext(),
                // HBHandler.getErrorMSG(), Toast.LENGTH_LONG)
                //.show();
            }
            else if (HBHandler.getErrorMSG().contains(
                    "Multiple account for the Device")) {
                //Toast.makeText(mContext.getApplicationContext(),
                //HBHandler.getErrorMSG(), Toast.LENGTH_LONG)
                //.show();
            }
        }
        else {
            if(listener != null){
                listener.onTaskCompleted(true);
            }


            if(prefs.getBoolean(MDACons.MY_TEAM_SHOW_MENU, false))
                new MyTeamDataPullTask(null, mContext).execute();


        }
    }

    protected Boolean doInBackground(String... urls) {

        if(prefs.getString(MDACons.DEVICE_NUMBER, "").isEmpty())
            return false;

        DebugLog.debug("REQUEST", MDACons.SERVER_URL + "agentRegister");
        ConnectionManager cm = new ConnectionManager();
        cm.setupHttpPost(MDACons.SERVER_URL + "agentRegister");
        cm.setHttpHeader("Content-Type", "application/xml");
        XmlSerializer serializer = Xml.newSerializer();
        StringWriter writer = new StringWriter();
        try {
            serializer.setOutput(writer);
            serializer.startDocument("UTF-8", true);
            serializer.startTag(null, "MGTRequest");
            generateXMLReqBlock(serializer);
            serializer.endTag(null, "MGTRequest");
            serializer.endDocument();
        }
        catch (Exception e) {}
        HttpEntity en = null;
        try {
            en = new StringEntity(writer.toString());
        }
        catch (UnsupportedEncodingException e2) {
            e2.printStackTrace();
        }
        try {
            Log.i("REQUEST", EntityUtils.toString(en));
        }
        catch (Exception e1) {
            e1.printStackTrace();
        }
        cm.setHttpPostEntity(en);
        try {
            InputSource m_is = cm.makeRequestGetResponse();
            spf = SAXParserFactory.newInstance();
            sp = spf.newSAXParser();
            xr = sp.getXMLReader();
            xr.setContentHandler(HBHandler);
            xr.parse(m_is);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    private void generateXMLReqBlock(XmlSerializer serializer)
            throws IOException {
        serializer.startTag(null, "AgentRegistration");
        String deviceId = prefs.getString(MDACons.DEVICE_NUMBER, "");
        Reach.enable(mContext);

        serializer.startTag(null, "DeviceId");
        serializer.text(deviceId);
        serializer.endTag(null, "DeviceId");
        serializer.startTag(null,"agentDeviceID");
        String agent_device_id = Reach.deviceId(mContext);
        serializer.text(agent_device_id);
        prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
        sh_prefs_edit = prefs.edit();
        sh_prefs_edit.putString(MDACons.AGENT_DEVICE_ID, agent_device_id);
        sh_prefs_edit.commit();
        serializer.endTag(null,"agentDeviceID");
        serializer.startTag(null,"Provider");
        serializer.text("Sixgill");
        serializer.endTag(null,"Provider");
        String versionName = "";
        try {
            versionName = mContext.getPackageManager().getPackageInfo(mContext.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        String reg_timeFormat = "";
        try {
            DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd'T'HH:mm:ssZ");
            reg_timeFormat = formatter.format(Calendar.getInstance().getTime().getTime());
            sh_prefs_edit = prefs.edit();
            sh_prefs_edit.putString(MDACons.LAST_REGISTER_TIME,reg_timeFormat);
            sh_prefs_edit.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }

        serializer.startTag(null,"RegistrationTime");
        serializer.text(reg_timeFormat);
        serializer.endTag(null,"RegistrationTime");


        try {
            serializer.startTag(null, "AgentVersion");
            serializer.text(versionName);
            serializer.endTag(null, "AgentVersion");
        } catch (Exception e) {
        }
        serializer.endTag(null, "AgentRegistration");
    }

    public class HBXmlHandler extends DefaultHandler {

        private boolean	MGT_RESPONSE_TAG				= false;
        private boolean	COMMENT_TAG					= false;
        private boolean	MESSAGE_TAG				= false;
        private boolean WORK_ORDER_TITLE        = false;
        private boolean	AGENT_REGISTRATION_TAG	= false;
        private boolean	DEVICE_ID_TAG	= false;
        private boolean	OPTIN_STATUS_TAG				= false;
        private boolean	HOS_TAG				= false;
        private boolean	AUTO_HOS_TAG				= false;
        private boolean	MYTEAM_TAG				= false;
        private boolean WORKORDER_TAG           = false;
        private boolean	HB_INTERVAL_TAG				= false;
        private boolean	JOB_SITE_MANDATORY_TAG				= false;
        private boolean	CUSTOMER_MANDATORY_TAG				= false;
        private boolean	NOTES_MANDATORY_TAG				= false;
        public boolean	error_occured				= false;
        public boolean TWILIO_SHORT_CODE          = false;
        public boolean EMERGENCY_COMMAND          = false;
        public boolean PROVIDER_TAG               = false;
        public boolean ACCOUNT_NAME_TAG                =false;


        StringBuilder stringBuilder;


        public String getErrorMSG() {
            return error_message;
        }

        @Override
        public void startDocument() throws SAXException {}

        @Override
        public void endDocument() throws SAXException {}

        public void startElement(String namespaceURI, String localName, String qName, Attributes atts) throws SAXException {

            stringBuilder = new StringBuilder();
            SharedPreferences sh_prefs = mContext.getSharedPreferences(MDACons.PREFS, 0);
            SharedPreferences.Editor sh_prefs_edit = sh_prefs.edit();
            if (localName.equals("MGTResponse")) {
                this.MGT_RESPONSE_TAG = true;
                if (atts.getValue("result").equalsIgnoreCase("error")) {
                    error_occured = true;
                    sh_prefs_edit.putBoolean(MDACons.MGT_REGISTRATION_HAPPENED, false);
                    sh_prefs_edit.commit();
                }
                else {
                    sh_prefs_edit.putBoolean(MDACons.MGT_REGISTRATION_HAPPENED, true);
                    sh_prefs_edit.commit();
                }
            }
            else if (localName.equals("Comment")) {
                this.COMMENT_TAG = true;
            }
            else if (localName
                    .equals("Message")) {
                this.MESSAGE_TAG = true;
            }
            else if (localName
                    .equals("AgentRegistration")) {
                this.AGENT_REGISTRATION_TAG = true;
            }
            else if (localName.equals("deviceId")) {
                this.DEVICE_ID_TAG = true;
            }else if (localName.equals("optinStatus")) {
                this.OPTIN_STATUS_TAG = true;
            }else if (localName.equals("HOS")) {
                this.HOS_TAG = true;
            }else if (localName.equals("autoHos")) {
                this.AUTO_HOS_TAG = true;
            }else if (localName.equals("myTeam")) {
                this.MYTEAM_TAG = true;
            }else if(localName.equals("workOrder")){
                this.WORKORDER_TAG = true;
            }
            else if(localName.equals("workOrderTitle")){
                this.WORK_ORDER_TITLE = true;
            }
            else if (localName.equals("heartBeatInterval")) {
                this.HB_INTERVAL_TAG = true;
            }
            else if (localName.equals("isTaskMandatory")) {
                this.JOB_SITE_MANDATORY_TAG = true;
            }
            else if (localName.equals("isCustomerMandatory")) {
                this.CUSTOMER_MANDATORY_TAG = true;
            }
            else if (localName.equals("isNotesMandatory")) {
                this.NOTES_MANDATORY_TAG = true;
            }
            else if (localName.equals("ShortCode")) {
                this.TWILIO_SHORT_CODE = true;
            }
            else if (localName.equals("EmergencyCommand")) {
                this.EMERGENCY_COMMAND = true;
            }
            else if(localName.equals("ProviderModel"))
            {
                this.PROVIDER_TAG = true;
            }
            else if(localName.equals("Account"))    // for getting account type information from the server
            {
                this.ACCOUNT_NAME_TAG=true;
            }


        } /* startELement */

        @Override
        public void endElement(String namespaceURI, String localName,
                               String qName) throws SAXException {
            if (localName.equals("MGTResponse")) {
                this.MGT_RESPONSE_TAG = false;

                SharedPreferences.Editor prefs_edit = prefs.edit();
                boolean trueOrFalse = true;
                prefs_edit.putBoolean(MDACons.REGISTER_STATUS,true);
                prefs_edit.commit();


            }
            else if (localName.equals("Comment")) {
                this.COMMENT_TAG = false;
            }
            else if (localName
                    .equals("Message")) {
                this.MESSAGE_TAG = false;
            }
            else if (localName
                    .equals("AgentRegistration")) {
                this.AGENT_REGISTRATION_TAG = false;
            }
            else if (localName.equals("deviceId")) {
                this.DEVICE_ID_TAG = false;
            }else if (localName.equals("optinStatus")) {
                this.OPTIN_STATUS_TAG = false;
            }else if (localName.equals("HOS")) {
                SharedPreferences.Editor prefs_edit = prefs.edit();
                prefs_edit.putBoolean(MDACons.HOS_MENU_AVAILABLE, Boolean.valueOf(stringBuilder.toString().trim()));
                if(!Boolean.valueOf(stringBuilder.toString().trim()))
                {
                    mContext.getContentResolver().delete(HOSEntryContentProvider.CONTENT_URI, null ,null);
                }
                prefs_edit.commit();
                this.HOS_TAG = false;
            }else if (localName.equals("autoHos")) {
                this.AUTO_HOS_TAG = false;
            }else if (localName.equals("myTeam")) {
                this.MYTEAM_TAG = false;
                SharedPreferences.Editor prefs_edit = prefs.edit();
                boolean trueOrFalse = false;
                if(stringBuilder.toString().trim().equals("true"))
                    trueOrFalse = true;
                else
                    trueOrFalse = false;
                DebugLog.debug(TAG, trueOrFalse + "");
                prefs_edit.putBoolean(MDACons.MY_TEAM_SHOW_MENU, trueOrFalse);
                prefs_edit.commit();
            }else if (localName.equals("workOrder")) {
                this.WORKORDER_TAG = false;
                SharedPreferences.Editor prefs_edit = prefs.edit();
                boolean trueOrFalse = false;
                if(stringBuilder.toString().trim().equals("true"))
                    trueOrFalse = true;
                else
                    trueOrFalse = false;
                DebugLog.debug(TAG, trueOrFalse + "");
                prefs_edit.putBoolean(MDACons.WORK_ORDER_SHOW_MENU, trueOrFalse);
                prefs_edit.commit();
            }
            else if(localName.equals("workOrderTitle")){
                this.WORK_ORDER_TITLE = false;
                SharedPreferences sharedPreferences = mContext.getSharedPreferences(MDACons.PREFS, 0);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(MDACons.WORK_ORDER_TEXT, stringBuilder.toString());
                editor.commit();

            }
            else if (localName.equals("heartBeatInterval")) {
                this.HB_INTERVAL_TAG = false;
            }else if (localName.equals("isTaskMandatory")) {
                SharedPreferences.Editor prefs_edit = prefs.edit();
                prefs_edit.putBoolean(MDACons.IS_JOB_SITE_MANDATORY, Boolean.valueOf(stringBuilder.toString().trim()));
                prefs_edit.commit();
                this.JOB_SITE_MANDATORY_TAG = false;
            }
            else if (localName.equals("isCustomerMandatory")) {
                SharedPreferences.Editor prefs_edit = prefs.edit();
                prefs_edit.putBoolean(MDACons.IS_CUSTOMER_MANDATORY, Boolean.valueOf(stringBuilder.toString().trim()));
                prefs_edit.commit();
                this.CUSTOMER_MANDATORY_TAG = false;
            }
            else if (localName.equals("isNotesMandatory")) {
                SharedPreferences.Editor prefs_edit = prefs.edit();
                prefs_edit.putBoolean(MDACons.IS_NOTES_MANDATORY, Boolean.valueOf(stringBuilder.toString().trim()));
                prefs_edit.commit();
                this.NOTES_MANDATORY_TAG = false;
            }
            else if (localName.equals("ShortCode")) {
                SharedPreferences sharedPreferences = mContext.getSharedPreferences(MDACons.PREFS, 0);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                String twilioNumber = "";
                if(stringBuilder.toString().trim().length() == 10)
                    twilioNumber = "+1" + stringBuilder.toString().trim();
                else
                    twilioNumber = stringBuilder.toString().trim();
                editor.putString(MDACons.TWILIO_SHORT_CODE, twilioNumber);
                editor.commit();
                this.TWILIO_SHORT_CODE = false;
            }
            else if (localName.equals("EmergencyCommand")) {
                SharedPreferences sharedPreferences = mContext.getSharedPreferences(MDACons.PREFS, 0);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(MDACons.SOS_EMER_COMMAND, stringBuilder.toString());
                editor.commit();
                this.EMERGENCY_COMMAND = false;
            }
            else if(localName.equals("ProviderModel"))
            {
                SharedPreferences sharedPreferences = mContext.getSharedPreferences(MDACons.PREFS, 0);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(MDACons.PROVIDER_NAME, stringBuilder.toString());
                editor.commit();
                Log.d(TAG,"Provider model"+stringBuilder.toString());

                this.PROVIDER_TAG = false;
            }
            //for getting account name info
            else if(localName.equals("Account"))
            {

                String accountData=localName;
                Log.d(TAG,"In the Account"+accountData);

                Log.d(TAG,"Account info"+stringBuilder.toString());
                this.ACCOUNT_NAME_TAG = false;
            }

        }

        @Override
        public void characters(char ch[], int start, int length) {
            if (MGT_RESPONSE_TAG && COMMENT_TAG) {
                if (error_occured) {
                    error_message = new String(ch, start, length);
                }
                else
                    error_message = "";
            }
            else if (MGT_RESPONSE_TAG && AGENT_REGISTRATION_TAG && OPTIN_STATUS_TAG) {}
            else if (MGT_RESPONSE_TAG && AGENT_REGISTRATION_TAG && HOS_TAG) {
                stringBuilder.append(new String(ch, start, length));
            }
            else if (MGT_RESPONSE_TAG && MYTEAM_TAG) {
                stringBuilder.append(new String(ch, start, length));
            }
            else if(MGT_RESPONSE_TAG && WORKORDER_TAG)
            {
                stringBuilder.append(new String(ch, start, length));
            }
            else if(MGT_RESPONSE_TAG && WORK_ORDER_TITLE)
            {
                stringBuilder.append(new String(ch,start,length));
            }
            else if (MGT_RESPONSE_TAG && AGENT_REGISTRATION_TAG && HB_INTERVAL_TAG) {}
            else if (MGT_RESPONSE_TAG && JOB_SITE_MANDATORY_TAG && AGENT_REGISTRATION_TAG) {
                stringBuilder.append(new String(ch, start, length));
            }else if (MGT_RESPONSE_TAG && CUSTOMER_MANDATORY_TAG && AGENT_REGISTRATION_TAG) {
                stringBuilder.append(new String(ch, start, length));
            }else if (MGT_RESPONSE_TAG && NOTES_MANDATORY_TAG && AGENT_REGISTRATION_TAG) {
                stringBuilder.append(new String(ch, start, length));
            }else if (MGT_RESPONSE_TAG && AGENT_REGISTRATION_TAG && TWILIO_SHORT_CODE) {
                stringBuilder.append(new String(ch, start, length));
            }else if (MGT_RESPONSE_TAG && AGENT_REGISTRATION_TAG && EMERGENCY_COMMAND) {
                stringBuilder.append(new String(ch, start, length));
            } else if(MGT_RESPONSE_TAG && ACCOUNT_NAME_TAG)
            {
                Log.d(TAG,"ACC_TYPE " + new String(ch, start, length));
                stringBuilder.append(new String(ch, start, length));
                SharedPreferences sharedPreferences = mContext.getSharedPreferences(MDACons.PREFS, 0);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(MDACons.ACCOUNT_TYPE_NAME,new String(ch, start, length));
                editor.commit();
            }
        }/* characters */
    }
}

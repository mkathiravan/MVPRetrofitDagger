package net.abaqus.mygeotracking.deviceagent.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import com.sixgill.sync.sdk.Reach;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HeartBeat;
import net.abaqus.mygeotracking.deviceagent.heartbeat.TriggerSource;
import net.abaqus.mygeotracking.deviceagent.home.LocationUpdatesService;


public class RestartAgentreceiver extends BroadcastReceiver{

	private static final String TAG = RestartAgentreceiver.class.getSimpleName();
	long trip_start_seconds,trip_end_seconds,system_seconds;

	@Override
	public void onReceive(Context context, Intent intent) {
		SharedPreferences sh_prefs = context.getSharedPreferences(MDACons.PREFS, 0);
		if (intent.getAction().equals(Intent.ACTION_USER_PRESENT)) {
			DebugLog.debug(TAG, "Restarted After USER PRESENT");
			RestartAgentActivity.startAlarmManager(context.getApplicationContext());
		}
		if (intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
			HeartBeat heartBeat = HeartBeat.getInstance();
			heartBeat.justOneBeat(context, TriggerSource.DEVICE_REBOOT_COMPLETED);
			heartBeat.startBeating(context);
			//RestartAgentActivity.startAlarmManager(context.getApplicationContext());
			//Intent intent_alarm = new Intent("net.abaqus.mygeotracking.deviceagent.HB_SERVICE_ACTION");
			//context.startService(intent_alarm);



			//Reboot the device schedule started continue based on the existing tracking schedule
			final boolean schedule_status = sh_prefs.getBoolean(MDACons.SCHUDELE_TRACK_STATUS,false);
			trip_start_seconds = sh_prefs.getLong(MDACons.TRIP_STARTS_SECONDS,-1);
			trip_end_seconds = sh_prefs.getLong(MDACons.TRIP_END_SECONDS,-1);
			system_seconds = System.currentTimeMillis();

			Log.d(TAG,"REBOOT_TIME_SCHEDULE "+ trip_start_seconds + " NOW " + system_seconds + "END_TRIP_SECONDS "+ trip_end_seconds);



			// The following condition to check whether already schedule is started or not & the current date is between the tracking schedule date.

		//	if((schedule_status) || (todayWorkDate.after(tripStartDate) && todayWorkDate.before(tripEndDate)))

			if((schedule_status) || (system_seconds > trip_start_seconds && system_seconds < trip_end_seconds))
			{
				Log.d(TAG,"REBOOT_TRACKING_CALLED ");
				if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
				{
					Intent pushIntent = new Intent(context, LocationUpdatesService.class);
					context.startForegroundService(pushIntent);
				}
				else
				{
					Reach.enable(context);
				}
			}



		}
	}

}

package net.abaqus.mygeotracking.deviceagent.hos;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.support.annotation.NonNull;

import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.telephony.PhoneStateListener;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.work.WorkManager;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.androidadvance.topsnackbar.TSnackbar;
import com.facebook.network.connectionclass.ConnectionClassManager;
import com.facebook.network.connectionclass.ConnectionQuality;

import com.google.firebase.analytics.FirebaseAnalytics;

import com.sixgill.protobuf.Ingress;
import com.sixgill.sync.sdk.Reach;
import com.sixgill.sync.sdk.ReachLocationCallback;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.bgthread.AttachmentPushTask;
import net.abaqus.mygeotracking.deviceagent.bgthread.HOSBackgroundService;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobRelationContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobRelationsTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSEntryTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSLabelsTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSLabelseContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryTable;
import net.abaqus.mygeotracking.deviceagent.enums.InternetState;
import net.abaqus.mygeotracking.deviceagent.enums.PhoneServiceState;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HeartBeat;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HeartBeatMetaData;
import net.abaqus.mygeotracking.deviceagent.heartbeat.TriggerSource;
import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.home.MainActivityHelper;
import net.abaqus.mygeotracking.deviceagent.listeners.InternetChangeListener;
import net.abaqus.mygeotracking.deviceagent.listeners.PhoneStateChangeListener;
import net.abaqus.mygeotracking.deviceagent.notes.Attachments;
import net.abaqus.mygeotracking.deviceagent.notes.ImageAttachment;
import net.abaqus.mygeotracking.deviceagent.notes.Notes;
import net.abaqus.mygeotracking.deviceagent.notes.NotesComposeFragment;
import net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder;
import net.abaqus.mygeotracking.deviceagent.receivers.PhoneStateChangeReceiver;
import net.abaqus.mygeotracking.deviceagent.sixgill.EventResponse;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReachReceiver;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.soshardware.ProcessSMS;
import net.abaqus.mygeotracking.deviceagent.ui.HOSConfirmActivity;
import net.abaqus.mygeotracking.deviceagent.ui.HOSCustomerJobListActivity;
import net.abaqus.mygeotracking.deviceagent.ui.SetIdentitiesActivity;
import net.abaqus.mygeotracking.deviceagent.utils.AccountUtils;
import net.abaqus.mygeotracking.deviceagent.utils.ConnectionSampler;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.DeviceUtils;
import net.abaqus.mygeotracking.deviceagent.utils.FetchLocationForHOS;
import net.abaqus.mygeotracking.deviceagent.utils.FragmentTransactionBaseClass;
import net.abaqus.mygeotracking.deviceagent.utils.HOSEntryConstruction;
import net.abaqus.mygeotracking.deviceagent.utils.HOSPullCalls;
import net.abaqus.mygeotracking.deviceagent.utils.HOSPushTask;
import net.abaqus.mygeotracking.deviceagent.utils.HOSStatesData;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkDeviceStatus;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkUtils;
import net.abaqus.mygeotracking.deviceagent.utils.NotesEntryConstruction;
import net.abaqus.mygeotracking.deviceagent.utils.SnackbarUtils;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;
import net.abaqus.mygeotracking.deviceagent.workorder.WorkOrderActivity;

import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.nlopez.smartlocation.OnLocationUpdatedListener;
import io.nlopez.smartlocation.SmartLocation;
import io.nlopez.smartlocation.location.config.LocationParams;

/**
 * Created by root on 25/5/17.
 */

public class HOSActivity extends ReceiverActivity implements HOSStagesAdapter.OnItemClickListener, ConnectionClassManager.ConnectionClassStateChangeListener, InternetChangeListener, PhoneStateChangeListener{

    private static final String TAG = HOSActivity.class.getSimpleName();

    ArrayList<HOSStage> hosStageArrayList;
    private RecyclerView mRecyclerView;
    private HOSStagesAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private SwipeRefreshLayout swipeContainer;
    private Snackbar statusSnackBar;
    private Location liveLocation;
    private int CLICKED_ITEM = -1;
    final int CUS_TASK_INTENT_REQUEST_CODE = 1;
    final int LOCATION_PERMISSION_REQUEST_CODE = 9001;
    Button hos_customer_clear_button, hos_job_clear_button;
    LinearLayout hos_update_cj_customer_layout, hos_update_cj_job_layout,hos_update_work_order_layout;
    EditText hos_update_cj_customer_text,hos_update_cj_job_text;
    LinearLayout cj_update_selection_view;
    String QR_RESULT_TEXT, TYPED_MESSAGE, FORM_POST_DATA, FORM_FDUID,work_order_pos_id,work_order_number;
    ArrayList<ImageAttachment> ATTACHMENT_BLOCK;
    List<HOSEntry> hosEntryList;
    boolean IS_PUSHING_TO_DB;
    private SharedPreferences sh_prefs;
    private SharedPreferences.Editor edit_prefs;
    private View clickedView;
    private Cursor hosValues;

    private PhoneServiceState CONNECTIVITY_STATUS;
    private InternetState INTERNET_STATUS;
    TelephonyManager telephonyManager;
    @BindView(R.id.fragment_container)
    FrameLayout frag;

    private boolean URICheckinAvailable;
    private boolean URICheckinMatchesAvailable;
    private boolean URICheckinAlreadyOnSameStage;
    private String stageNameForURICheckin;

    private FirebaseAnalytics mFirebaseAnalytics;
    private RelativeLayout rootLayout;

    private FragmentManager mFragmentManager;
    private NotesComposeFragment mDetailFragment = null;
    public final String FRAGMENT_NOTES_TAG = "fragment_notes";
    @BindView(R.id.button_messages_menu)
    ImageView notesView;
    @BindView(R.id.button_sos_menu)
    TextView sosView;
    @BindView(R.id.hos_update_work_order)
    TextView workOrderNumber;
    private Ingress.Location locationModel;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hos_update);
        this.sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
        ButterKnife.bind(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        initializeComposeMsgDependencies();

        telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        telephonyManager.listen(new PhoneStateChangeReceiver(HOSActivity.this, this), PhoneStateListener.LISTEN_SERVICE_STATE | PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
        int SIM_STATE = telephonyManager.getSimState();
        if(SIM_STATE == TelephonyManager.SIM_STATE_UNKNOWN ||
                SIM_STATE == TelephonyManager.SIM_STATE_ABSENT ||
                SIM_STATE == TelephonyManager.SIM_STATE_NETWORK_LOCKED ||
                SIM_STATE == TelephonyManager.SIM_STATE_PIN_REQUIRED ||
                SIM_STATE == TelephonyManager.SIM_STATE_PUK_REQUIRED) {
            CONNECTIVITY_STATUS = PhoneServiceState.STATE_DISCONNECTED;
        } else {
            CONNECTIVITY_STATUS = PhoneServiceState.STATE_UNKNOWN;
        }

        if(NetworkConnectionInfo.isOnline(this)) {
            INTERNET_STATUS = InternetState.STATE_CONNECTED;
        } else {
            INTERNET_STATUS = InternetState.STATE_DISCONNECTED;
        }


        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        mFirebaseAnalytics.setUserId(DeviceUtils.getAndroidID(HOSActivity.this));
        mFirebaseAnalytics.setUserProperty("mgt_track_id", DeviceUtils.getAndroidID(HOSActivity.this));
        mFirebaseAnalytics.setCurrentScreen(this, "HOSActivity", null /* class override */);
        this.edit_prefs = sh_prefs.edit();
        hosEntryList = new ArrayList<>();
        hosStageArrayList = new ArrayList<>();
        swipeContainer = (SwipeRefreshLayout) findViewById(R.id.swipeContainer);
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);

        try {
            if(getIntent().getData() != null) {
                Uri uri = getIntent().getData();
                String stageName = uri.getQueryParameter("s");
                DebugLog.debug(TAG, "URI Parameters : " + uri.getQueryParameter("s"));
                if (stageName != null && stageName.length() > 0) {
                    URICheckinAvailable = true;
                    stageNameForURICheckin = URLDecoder.decode(stageName, "UTF-8");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        
        // Check the device number availability before showing up the HOS View
        if (!this.sh_prefs.getString(MDACons.DEVICE_NUMBER, "").equals("")) {
            if (NetworkConnectionInfo.isOnline(this)) {
                new HOSPushTask(HOSActivity.this).execute();
                new AttachmentPushTask(HOSActivity.this).execute();
            }
        } else {
            SnackbarUtils.showIndefinite(rootLayout, "Please register your device!", Color.WHITE, ContextCompat.getColor(HOSActivity.this, R.color.alert), "REGISTER", Color.WHITE, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent registerIntent = new Intent(HOSActivity.this, SetIdentitiesActivity.class);
                    startActivity(registerIntent);
                }
            });
        }
        mAdapter = new HOSStagesAdapter(hosStageArrayList, this);
        mAdapter.setOnItemClickListener(this);
        // Attach the adapter to the recyclerview to populate items
        mRecyclerView.setAdapter(mAdapter);
        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        swipeContainer.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Your code to refresh the list here.
                // Make sure you call swipeContainer.setRefreshing(false)
                // once the network request has completed successfully.
                // fetchTimelineAsync(0);
                if (NetworkConnectionInfo.isOnline(HOSActivity.this)) {

                    Bundle bundle = new Bundle();
                    bundle.putString("TC_REFRESH_SOURCE", "Swipe");
                    mFirebaseAnalytics.logEvent("TC_REFRESH", bundle);


                    hosStageArrayList.clear();
                    mAdapter.updateDataSet(hosStageArrayList);
                    mAdapter.notifyDataSetChanged();
                    cj_update_selection_view.setVisibility(View.GONE);
                    HOSPullCalls.makeHOSInitializeCalls(HOSActivity.this, pullLabelsHandler);
                    swipeContainer.setRefreshing(true);
                    SnackbarUtils.showShort(rootLayout, "Refreshing. Please wait.", Color.BLACK, ContextCompat.getColor(HOSActivity.this, R.color.yellow));
                } else {
                    SnackbarUtils.showShort(rootLayout, getString(R.string.msg_internet_disabled_please_try_later), Color.WHITE, ContextCompat.getColor(HOSActivity.this, R.color.alert));
                }

            }
        });



        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(R.color.blue,
                R.color.blue_dullish,
                R.color.yellow);
        checkLocationPermission();
        updateUI();

        if(AccountUtils.isSOSAvailable(sh_prefs) && !NetworkUtils.isConnectedFast(HOSActivity.this)) {
            askForSMSPermission();
        }


        HeartBeat heartBeat = HeartBeat.getInstance();
        heartBeat.justOneBeat(this, TriggerSource.APP_LAUNCHED);
        heartBeat.startBeating(this);



    }



    private void initializeComposeMsgDependencies() {
        //DebugLog.debug(TAG, "initializeComposeMsgDependencies Called");

        /*Code block for in app notes implementation*/
        mFragmentManager = getSupportFragmentManager();
        mFragmentManager.addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
            @SuppressLint("NewApi")
            @Override
            public void onBackStackChanged() {
                if (getFragmentManager().getBackStackEntryCount() == 0)
                    if (frag.getVisibility() == View.VISIBLE)
                        frag.setVisibility(View.GONE);
            }
        });
        frag.setVisibility(View.GONE);
        /*Code block for in app notes implementation*/
    }



    private void askForSMSPermission() {
        if (!isSMSPermissionGranted()) {
            MainActivityHelper mainActivityHelper = new MainActivityHelper(HOSActivity.this, HOSActivity.this);
            mainActivityHelper.checkSMSPersmission();
        }
    }

    private boolean isSMSPermissionGranted() {
        return ContextCompat.checkSelfPermission(HOSActivity.this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void showNoNetworkWarning() {
        if(CONNECTIVITY_STATUS == PhoneServiceState.STATE_DISCONNECTED) {
            showNoConnectivityWarning();
        } else {
            final TSnackbar snackbar = TSnackbar.make(findViewById(android.R.id.content), getString(R.string.slow_internet_alert_checkins), TSnackbar.LENGTH_INDEFINITE);
            snackbar.setActionTextColor(Color.parseColor("#00adee"));
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#ececec"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.parseColor("#535454"));
            textView.setTypeface(null, Typeface.BOLD);
            snackbar.setAction("GOT IT", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    snackbar.dismiss();
                }
            });
            snackbar.show();
        }
    }

    private void showSlowNetworkWarning() {
        if (AccountUtils.isSOSAvailable(sh_prefs)) {
            if(CONNECTIVITY_STATUS == PhoneServiceState.STATE_DISCONNECTED) {
                showNoConnectivityWarning();
            } else {
                final TSnackbar snackbar = TSnackbar.make(findViewById(android.R.id.content), getString(R.string.slow_internet_alert_checkins), TSnackbar.LENGTH_INDEFINITE);
                snackbar.setActionTextColor(Color.parseColor("#00adee"));
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#ececec"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.parseColor("#535454"));
                textView.setTypeface(null, Typeface.BOLD);
                snackbar.setAction("GOT IT", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        snackbar.dismiss();
                    }
                });
                snackbar.show();
            }
        }
    }

    private void updateUI() {
        initViews();
        initiallizeScanData();
        ActionBar actionBar = initActionBar();
        setPageTitle(actionBar);
        hosValues = fetchHOSData();
        constructHOSStageArray(hosValues);
        mAdapter.updateDataSet(hosStageArrayList);
        mAdapter.notifyDataSetChanged();
    }


    private void initViews() {
        rootLayout = (RelativeLayout) findViewById(R.id.hos_root_layout);
        cj_update_selection_view = (LinearLayout) findViewById(R.id.cjTopView);
        hos_update_cj_customer_text = (EditText) findViewById(R.id.hos_update_slect_customer);
        hos_update_cj_job_text = (EditText) findViewById(R.id.hos_update_slect_job);
        hos_customer_clear_button = (Button) findViewById(R.id.customer_clear_txt_button);
        hos_job_clear_button = (Button) findViewById(R.id.job_clear_txt_button);
        hos_update_cj_customer_layout = (LinearLayout) findViewById(R.id.hos_update_slect_customer_layout);
        hos_update_cj_job_layout = (LinearLayout) findViewById(R.id.hos_update_slect_job_layout);
        hos_update_work_order_layout = (LinearLayout)findViewById(R.id.hos_update_work_order_layout);




        if (this.sh_prefs.getString(MDACons.HOS_CUSTOMER_SELECTED, "").length() > 0)
            hos_update_cj_customer_text.setText("Customer: " + this.sh_prefs.getString(MDACons.HOS_CUSTOMER_SELECTED, ""));

        if (hos_update_cj_customer_text.getText().length() >= 1)
            hos_update_cj_job_layout.setVisibility(View.VISIBLE);
        else
            hos_update_cj_job_layout.setVisibility(View.GONE);

        if (this.sh_prefs.getString(MDACons.HOS_JOB_SELECTED, "").length() > 0)
            hos_update_cj_job_text.setText("Job: " + this.sh_prefs.getString(MDACons.HOS_JOB_SELECTED, ""));


        if(AccountUtils.isSOSAvailable(sh_prefs))
        {
            notesView.setVisibility(View.GONE);
            sosView.setVisibility(View.VISIBLE);
            sosView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sosAlertDialogView();
                }
            });
        }
        else {
            notesView.setVisibility(View.VISIBLE);
            notesView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    openNotesComposer();

                }
            });
        }




        SharedPreferences sharedPreferences = getSharedPreferences(MDACons.PREFS, 0);
       work_order_pos_id = sharedPreferences.getString(MDACons.WORK_ORDER_POS_ID, "");
       work_order_number = sharedPreferences.getString(MDACons.WORK_ORDER_NUMBER,"");
        Log.d(TAG,"WORKIRDENUM "+work_order_number);
        if(!work_order_pos_id.isEmpty())
        {
            hos_update_work_order_layout.setVisibility(View.VISIBLE);
            workOrderNumber.setText("Work Order No : "+work_order_number);
        }


        hos_customer_clear_button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                hos_update_cj_customer_text.setText("");
                SharedPreferences.Editor prefs_edit = sh_prefs.edit();
                prefs_edit.putString(MDACons.HOS_CUSTOMER_SELECTED, "");
                prefs_edit.commit();
                hos_update_cj_job_layout.setVisibility(View.GONE);

            }
        });

        hos_job_clear_button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                hos_update_cj_job_text.setText("");
                SharedPreferences.Editor prefs_edit = sh_prefs.edit();
                prefs_edit.putString(MDACons.HOS_JOB_SELECTED, "");
                prefs_edit.commit();
            }
        });

        hos_update_cj_customer_layout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent hos_cj_listing_intent = new Intent(HOSActivity.this,
                        HOSCustomerJobListActivity.class);
                hos_cj_listing_intent.putExtra("which", "customer");
                startActivityForResult(hos_cj_listing_intent, CUS_TASK_INTENT_REQUEST_CODE);
            }
        });

        hos_update_cj_customer_text.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent hos_cj_listing_intent = new Intent(HOSActivity.this,
                        HOSCustomerJobListActivity.class);
                hos_cj_listing_intent.putExtra("which", "customer");
                startActivityForResult(hos_cj_listing_intent, CUS_TASK_INTENT_REQUEST_CODE);
            }
        });

        hos_update_cj_customer_text.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int inType = hos_update_cj_customer_text.getInputType(); // backup the input type
                hos_update_cj_customer_text.setInputType(InputType.TYPE_NULL); // disable
                // soft
                // input
                hos_update_cj_customer_text.onTouchEvent(event); // call native
                // handler
                hos_update_cj_customer_text.setInputType(inType); // restore
                // input
                // type

                return true; // consume touch even
            }
        });
        hos_update_cj_job_text.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int inType = hos_update_cj_job_text.getInputType(); // backup
                // the input
                // type
                hos_update_cj_job_text.setInputType(InputType.TYPE_NULL); // disable
                // soft
                // input
                hos_update_cj_job_text.onTouchEvent(event); // call native
                // handler
                hos_update_cj_job_text.setInputType(inType); // restore input
                // type

                return true; // consume touch even
            }
        });

        hos_update_cj_job_text.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent hos_cj_listing_intent = new Intent(HOSActivity.this,
                        HOSCustomerJobListActivity.class);
                hos_cj_listing_intent.putExtra("which", "job");
                hos_cj_listing_intent.putExtra("customer", getSelectedCustomerName());
                startActivityForResult(hos_cj_listing_intent, CUS_TASK_INTENT_REQUEST_CODE);
            }
        });

        hos_update_cj_job_layout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent hos_cj_listing_intent = new Intent(HOSActivity.this,
                        HOSCustomerJobListActivity.class);
                hos_cj_listing_intent.putExtra("which", "job");
                startActivityForResult(hos_cj_listing_intent, CUS_TASK_INTENT_REQUEST_CODE);
            }
        });

        Cursor jobcus = fetchCustomerAndJobID();


        if (!customerAvailability()) {
            //put something here
            if (jobcus.getCount() > 0)
                hos_update_cj_job_layout.setVisibility(View.VISIBLE);
            hos_update_cj_customer_layout.setVisibility(View.GONE);
        }



        String[] relationsTableResult = getRelationsData();
        int argcount = relationsTableResult.length; // number of IN arguments

        if (jobcus.getCount() > 0) {
            cj_update_selection_view.setVisibility(View.VISIBLE);
        }


        if (argcount > 0)
            if (sh_prefs.getBoolean(MDACons.IS_JOB_SITE_MANDATORY, false) && relationsTableResult[0].equals("all") && jobcus.getCount() > 0) {
                hos_update_cj_job_layout.setVisibility(View.VISIBLE);
            }

        jobcus.close();


        if (!jobAvailability())
            hos_update_cj_job_layout.setVisibility(View.GONE);
    }



    @SuppressLint("NewApi")
    public void openNotesComposer() {
        //DebugLog.debug(TAG, "openNotesComposer Called. ");

        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        FragmentTransactionBaseClass.animateTransition(transaction, FragmentTransactionBaseClass.TRANSITION_VERTICAL);
        mDetailFragment = new NotesComposeFragment();
        Bundle b = new Bundle();
        mDetailFragment.setArguments(b);
        if (mFragmentManager.findFragmentByTag(FRAGMENT_NOTES_TAG) == null) {
            transaction.replace(R.id.fragment_container, mDetailFragment,
                    FRAGMENT_NOTES_TAG)
                    .commitAllowingStateLoss();
        } else {
            transaction.replace(R.id.fragment_container, mDetailFragment,
                    FRAGMENT_NOTES_TAG).commitAllowingStateLoss();
        }
        FrameLayout frag = (FrameLayout) findViewById(R.id.fragment_container);
        frag.setVisibility(View.VISIBLE);
        invalidateOptionsMenuItems();
    }


    private void closeComposeView() {
        //DebugLog.debug(TAG, "closeComposeView Called. ");

        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction trans = manager.beginTransaction();
        trans.remove(mDetailFragment);
        trans.commit();
        manager.popBackStack();
        FrameLayout frag = (FrameLayout) findViewById(R.id.fragment_container);
        frag.setVisibility(View.GONE);
        mDetailFragment = null;
        invalidateOptionsMenuItems();
    }


    @SuppressLint("NewApi")
    private void invalidateOptionsMenuItems() {
        invalidateOptionsMenu();
    }




    private String[] getRelationsData() {

        int i = 0;
        String[] projection = {
                HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID, HOSCustomerANDJobRelationsTable.HOS_CJ_REL_CUS_ID};
        Cursor cursor = this.getContentResolver().query(Uri.parse(HOSCustomerANDJobRelationContentProvider.CONTENT_URI.toString()), projection, null, null,
                null);
        String[] resultString = new String[cursor.getCount()];
        if (cursor != null) {
            while (cursor.moveToNext()) {
                try {
                    DebugLog.debug(TAG, cursor.getString(cursor
                            .getColumnIndexOrThrow(HOSCustomerANDJobRelationsTable.HOS_CJ_REL_CUS_ID)));

                    DebugLog.debug(TAG, cursor.getString(cursor
                            .getColumnIndexOrThrow(HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID)));
                    resultString[i] = cursor.getString(cursor
                            .getColumnIndexOrThrow(HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID));
                    i++;
                } catch (Exception e) {
                }
            }

        }
        cursor.close();
        return resultString;
    }


    private Cursor fetchCustomerAndJobID() {
        String[] projection =
                {HOSCustomerANDJobTable.HOS_CJ_ID,
                        HOSCustomerANDJobTable.HOS_CJ_REF_ID,
                        HOSCustomerANDJobTable.HOS_CJ_SOURCE_ID,
                        HOSCustomerANDJobTable.HOS_CJ_NAME,
                        HOSCustomerANDJobTable.HOS_CJ_STATUS,
                        HOSCustomerANDJobTable.HOS_CJ_WHICH};
        Cursor cursor = getContentResolver().query(
                Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI
                        .toString()), projection, null, null, null);
        return cursor;
    }


    private void constructHOSStageArray(Cursor mCursor) {
        if (mCursor != null) {
            hosStageArrayList.clear();

            String hos_Selection = this.sh_prefs.getInt(MDACons.HOS_SELECTION, -1)
                    + "";
            String stageName = "", stageID = "", smsCommand = "";
            HOSStage sosHOSStage = new HOSStage();
            HOSStage uriCheckinStage = new HOSStage();
            for (int i = 0; i < mCursor.getCount(); i++) {
                mCursor.moveToPosition(i);
                stageID = mCursor.getString(mCursor
                        .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL_VALUE));
                stageName = mCursor.getString(mCursor
                        .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL));
                smsCommand = mCursor.getString(mCursor
                        .getColumnIndexOrThrow(HOSLabelsTable.HOS_SMS_COMMAND));
                if(stageName.isEmpty()) {
                    continue;
                }
                if (hos_Selection.equals(stageID)) {
                    if (URICheckinAvailable && stageNameForURICheckin.equalsIgnoreCase(stageName)) {
                        URICheckinAlreadyOnSameStage = true;
                    }
                }

                HOSStage hosStage = new HOSStage(stageID, stageName, smsCommand);
                if(hosStage.getStageID().equals("7")) {
                    sosHOSStage = hosStage;
                } else {
                    hosStageArrayList.add(hosStage);
                }
                if(URICheckinAvailable && stageNameForURICheckin.equalsIgnoreCase(hosStage.getStageName())) {
                    URICheckinMatchesAvailable = true;
                    uriCheckinStage = hosStage;
                }
            }
            // Just added and condition because if there is SOS condition in the object we should not add in the arrayList
            if(sosHOSStage.getStageID().length() > 0 && !sosHOSStage.getStageID().equals("7"))
                hosStageArrayList.add(sosHOSStage);


            if(!URICheckinMatchesAvailable) {
                URICheckinMatchesAvailable = false;
                URICheckinAvailable = false;
                URICheckinAlreadyOnSameStage = false;
            } else {
                itemClicked(hosStageArrayList.indexOf(uriCheckinStage));
            }
        }
    }

    @Override
    public void onItemClick(View itemView, int position) {
        String hos_Selection = this.sh_prefs.getInt(MDACons.HOS_SELECTION, -1)
                + "";
        String hos_Selection_stage_name = this.sh_prefs.getString(MDACons.HOS_SELECTION_NAME, "");
        Bundle bundle = new Bundle();
        bundle.putString("TC_CLICKED_STAGE", hosStageArrayList.get(position).getStageName());
        bundle.putString("TC_PREVIOUS_STAGE", hos_Selection_stage_name);
        bundle.putString("TC_EVENT_SOURCE", "Manual Click");
        mFirebaseAnalytics.logEvent("TC_EVENT", bundle);

        if (!hos_Selection.equals(hosStageArrayList.get(position).getStageID())) {
            itemClicked(position);
        } else {
            SnackbarUtils.showLong(rootLayout, "Oops! You are already in '" + hosStageArrayList.get(position).getStageName() + "' stage.", Color.WHITE, ContextCompat.getColor(HOSActivity.this, R.color.alert));
        }



//        if(hosStageArrayList.get(position).getStageID().equals("7")) {
//            new MaterialDialog.Builder(HOSActivity.this)
//                    .title("Send SOS")
//                    .content("Please Confirm.")
//                    .positiveText("Yes")
//                    .negativeText("Cancel")
//                    .autoDismiss(true)
//                    .onPositive(new MaterialDialog.SingleButtonCallback() {
//                        @Override
//                        public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
//                            SharedPreferences sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
//                            String hos_Selection_stage_name = sh_prefs.getString(MDACons.HOS_SELECTION_NAME, "");
//                            Bundle bundle = new Bundle();
//                            bundle.putString("TC_CLICKED_STAGE", "SOS");
//                            bundle.putString("TC_PREVIOUS_STAGE", hos_Selection_stage_name);
//                            bundle.putString("TC_EVENT_SOURCE", "Manual Click");
//                            mFirebaseAnalytics.logEvent("TC_EVENT", bundle);
//
//                            if (!NetworkConnectionInfo.isOnline(HOSActivity.this)) {
//                                processSOSAsSMS();
//                            } else {
//                                if(AccountUtils.isSOSAvailable(sh_prefs) && ConnectionClassManager.getInstance().getCurrentBandwidthQuality() == ConnectionQuality.POOR) {
//                                    processSOSAsSMS();
//                                } else {
//                                    new HOSBackgroundService().processHOS(HOSActivity.this, "Safety Alert Triggered", "7");
//                                }
//                            }
//                            try {
//                                runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//                                        updateUI();
//                                    }
//                                });
//                            }catch (Exception e) {e.printStackTrace();}
//                            SnackbarUtils.showLong(mRecyclerView, "Safety Alert Triggered.", Color.BLACK, ContextCompat.getColor(HOSActivity.this, R.color.yellow));
//                        }
//                    })
//                    .show();
//
//        }
//        else {
//            if (!hos_Selection.equals(hosStageArrayList.get(position).getStageID())) {
//                itemClicked(position);
//            } else {
//                SnackbarUtils.showLong(mRecyclerView, "Oops! You are already in '" + hosStageArrayList.get(position).getStageName() + "' stage.", Color.WHITE, ContextCompat.getColor(HOSActivity.this, R.color.alert));
//            }
//        }
    }

    private void processSOSAsSMS() {
        SharedPreferences sharedPreferences = getSharedPreferences(MDACons.PREFS, 0);
        String toPhoneNumber = sharedPreferences.getString(MDACons.TWILIO_SHORT_CODE, "+18032327769");
        String sosCommand = sharedPreferences.getString(MDACons.SOS_EMER_COMMAND, "SOS");
        SharedPreferences.Editor edit_prefs = sharedPreferences.edit();
        edit_prefs.putInt(MDACons.HOS_SELECTION,
                Integer.parseInt("7"));
        edit_prefs.putString(MDACons.HOS_SELECTION_NAME,
                "Safety Alert Triggered");
        edit_prefs.commit();

        new ProcessSMS().sendNow(HOSActivity.this, toPhoneNumber, sosCommand, "7", "");
    }


    private void itemClicked(final int position) {
        CLICKED_ITEM = position;
        if (mandatoryConditionsPassed() || URICheckinAvailable) {
            if (URICheckinAvailable) {
                String hos_Selection_stage_name = this.sh_prefs.getString(MDACons.HOS_SELECTION_NAME, "");
                Bundle bundle = new Bundle();
                bundle.putString("TC_CLICKED_STAGE", hosStageArrayList.get(position).getStageName());
                bundle.putString("TC_PREVIOUS_STAGE", hos_Selection_stage_name);
                bundle.putString("TC_EVENT_SOURCE", "URI");
                mFirebaseAnalytics.logEvent("TC_EVENT", bundle);

                URICheckinAvailable = false;
                if(URICheckinAlreadyOnSameStage) {
                    URICheckinAlreadyOnSameStage = false;
                    SnackbarUtils.showLong(rootLayout, "Oops! You are already in '"+stageNameForURICheckin+"' stage.", Color.WHITE, ContextCompat.getColor(HOSActivity.this, R.color.alert));
                } else {
                    new MaterialDialog.Builder(HOSActivity.this)
                            .title("TimeClock")
                            .content("Change myGeoTracking status to '" + stageNameForURICheckin + "' ?")
                            .positiveText("Confirm")
                            .negativeText("Cancel")
                            .autoDismiss(true)
                            .onPositive(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    startHOSConfirmActivity(position);
                                }
                            })
                            .show();
                }
            } else {
                startHOSConfirmActivity(position);
            }
        }
    }

    @SuppressLint("HandlerLeak")
    private Handler pullLabelsHandler = new Handler() {
        public void handleMessage(
                Message msg) {
            System.out.println("Check the what = " + msg.what );
            if (msg.what == 101108) {
                swipeContainer.setRefreshing(false);
                updateUI();
                //updateUIView(); Just notify any list changes to adapter
            } else if (msg.what == 101109) {
                if(statusSnackBar.isShownOrQueued())
                    statusSnackBar.dismiss();
                SnackbarUtils.showShort(rootLayout, "Status Updated!", Color.WHITE, ContextCompat.getColor(HOSActivity.this, R.color.blue));
            }else{
                System.out.println("Check the waht = " + msg.what );
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        if (hosValues == null)
            hosValues = fetchHOSData();

        liveLocation = null;

        /*LiveData<Location> liveData = new LocationLiveData(HOSActivity.this);
        liveData.observe(HOSActivity.this, new Observer<Location>() {
            @Override
            public void onChanged(@Nullable Location updatedLocation) {
                liveLocation = updatedLocation;
            }
        });*/

        ConnectionQuality connectionQuality = ConnectionClassManager.getInstance().getCurrentBandwidthQuality();

        if(connectionQuality == ConnectionQuality.POOR) {
            Log.i("CONNECTION_SAMPLING_HOS", "POOR");
            //showSlowNetworkWarning();
        } else if(connectionQuality == ConnectionQuality.MODERATE) {
            //return false;
            if(AccountUtils.isSOSAvailable(sh_prefs))
                SnackbarUtils.dismiss();
            Log.i("CONNECTION_SAMPLING_HOS", "MODERATE");
        } else if(connectionQuality == ConnectionQuality.UNKNOWN) {
            //return false;
            if(AccountUtils.isSOSAvailable(sh_prefs))
                SnackbarUtils.dismiss();
            Log.i("CONNECTION_SAMPLING_HOS", "UNKNOWN");
        } else if(connectionQuality == ConnectionQuality.EXCELLENT) {
            //return false;
            if(AccountUtils.isSOSAvailable(sh_prefs))
                SnackbarUtils.dismiss();
            Log.i("CONNECTION_SAMPLING_HOS", "EXCELLENT");
        } else if(connectionQuality == ConnectionQuality.GOOD) {
            //return false;
            if(AccountUtils.isSOSAvailable(sh_prefs))
                SnackbarUtils.dismiss();
            Log.i("CONNECTION_SAMPLING_HOS", "GOOD");
        } else {
            //return true;
            Log.i("CONNECTION_SAMPLING_HOS", "SOMETHING ELSE");
        }
        Log.i("CONNECTION_SAMPLING_HOS", "Download kbps : "+ConnectionClassManager.getInstance().getDownloadKBitsPerSecond());


        if(AccountUtils.isSOSAvailable(sh_prefs) && NetworkConnectionInfo.isOnline(HOSActivity.this)) {
            ConnectionSampler.doSmapling(HOSActivity.this);
        }

//        if(AccountUtils.isSOSAvailable(sh_prefs))
        if(AccountUtils.isSOSAvailable(sh_prefs) && !NetworkUtils.isConnectedFast(HOSActivity.this))
        {
            Handler mHandler = new Handler();
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (NetworkConnectionInfo.isOnline(HOSActivity.this)) {
                        if ( !NetworkUtils.isConnectedFast(HOSActivity.this))
                        {
                            showSlowNetworkWarning();
                        }
                    }
                    else {
                        showNoNetworkWarning();
                    }
                }
            }, 3000);
        }else {
            if (!NetworkConnectionInfo.isOnline(HOSActivity.this)) {
                showInternetDisabled();
            }
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
        Cursor entryCursor = null;
        try {
            entryCursor = new HOSStatesData(HOSActivity.this).getHOSEntries();
        } catch (Exception e) {
        }

        if (entryCursor.getCount() > 0) {
            edit_prefs.putBoolean(MDACons.HOS_QUEUE_AVAILABLE, true);
        } else {
            edit_prefs.putBoolean(MDACons.HOS_QUEUE_AVAILABLE, false);
        }
        /*if(hosValues != null)
			hosValues.close();*/
        edit_prefs.commit();
        entryCursor.close();
    }

    @NonNull
    private ActionBar initActionBar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        return actionBar;
    }

    private void setPageTitle(ActionBar actionBar) {
        if (this.sh_prefs.getString(MDACons.HOS_GROUP_ID, "").equals("Mobile"))
            actionBar.setTitle("Time Clock");
        else
            actionBar.setTitle("Hours-Of-Service");
    }



    private void initiallizeScanData() {
        QR_RESULT_TEXT = "";
        ATTACHMENT_BLOCK = new ArrayList<ImageAttachment>();
        TYPED_MESSAGE = "";
    }

    private void checkLocationPermission() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        LOCATION_PERMISSION_REQUEST_CODE);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.timeclocking_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
//            case android.R.id.home:
//                finish();
//                return true;
            case R.id.action_hos_history:
                Intent intent = new Intent(HOSActivity.this, HOSHistoryActivity.class);
                startActivity(intent);
                return true;

            case R.id.action_close:
                closeComposeView();
                return true;

            case R.id.action_timeclocking_refresh:
                if (NetworkConnectionInfo.isOnline(HOSActivity.this)) {
                    if(swipeContainer.isRefreshing()) {
                        SnackbarUtils.showShort(rootLayout, "Refreshing. Please wait.", Color.WHITE, ContextCompat.getColor(HOSActivity.this, R.color.blue));
                    } else {

                        //While refreshing to clear the edittext value of customer and task
                        hos_update_cj_customer_text.getText().clear();
                        hos_update_cj_job_text.getText().clear();


                        Bundle bundle = new Bundle();
                        bundle.putString("TC_REFRESH_SOURCE", "Refresh Button");
                        mFirebaseAnalytics.logEvent("TC_REFRESH", bundle);

                        hosStageArrayList.clear();
                        mAdapter.updateDataSet(hosStageArrayList);
                        mAdapter.notifyDataSetChanged();
                        cj_update_selection_view.setVisibility(View.GONE);
                        swipeContainer.setRefreshing(true);
                        HOSPullCalls.makeHOSInitializeCalls(HOSActivity.this, pullLabelsHandler);
                        SnackbarUtils.showShort(rootLayout, "Refreshing. Please wait.", Color.BLACK, ContextCompat.getColor(HOSActivity.this, R.color.yellow));
                    }
                } else {
                    SnackbarUtils.showShort(rootLayout, getString(R.string.msg_internet_disabled_please_try_later), Color.WHITE, ContextCompat.getColor(HOSActivity.this, R.color.alert));
                }
                break;


        }
        return super.onOptionsItemSelected(item);
    }


    private Cursor fetchHOSData() {
        String[] projection =
                {HOSLabelsTable.HOS_LABEL, HOSLabelsTable.HOS_LABEL_VALUE, HOSLabelsTable.HOS_SMS_COMMAND};
        Cursor cursor = getContentResolver().query(
                Uri.parse(HOSLabelseContentProvider.CONTENT_URI.toString()),
                projection, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                try {
                    Log.d("mgtagentempdbfirst",
                            cursor.getString(cursor
                                    .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL)));
                    Log.d("mgtagentempdbfirst",
                            cursor.getString(cursor
                                    .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL_VALUE)));
                } catch (NullPointerException e) {
                    e.printStackTrace();
                }
            }
        }
        return cursor;
    }

    @Override
    protected void onDestroy() {
        SharedPreferences.Editor prefs_edit = sh_prefs.edit();
        prefs_edit.putString(MDACons.HOS_JOB_SELECTED, "");
        prefs_edit.putString(MDACons.HOS_CUSTOMER_SELECTED, "");
        prefs_edit.putString(MDACons.HOS_JOB_SELECTED_ID, "");
        prefs_edit.putString(MDACons.HOS_CUSTOMER_SELECTED_ID, "");
        prefs_edit.commit();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {

        if (mDetailFragment != null) {
            if(mDetailFragment.isClosable()) {
                closeComposeView();
            } else {
                showWarningOnBackPress();
            }
        } else {
            super.onBackPressed();
            hosValues.close();
        }
    }



    private void showWarningOnBackPress() {
        //DebugLog.debug(TAG, "showWarningOnBackPress Called. ");

        new MaterialDialog.Builder(HOSActivity.this)
                .title(R.string.title_warning_backbtn_press)
                .content(R.string.msg_warning_backbtn_press_notes_compose)
                .positiveText(R.string.action_discard)
                .negativeText(R.string.action_stay)
                .autoDismiss(true)
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        closeComposeView();
                    }
                })
                .show();
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (mDetailFragment != null) {
            menu.findItem(R.id.action_close).setVisible(true);
            menu.findItem(R.id.action_hos_history).setVisible(false);
            menu.findItem(R.id.action_timeclocking_refresh).setVisible(false);
            return true;
        } else {
            return super.onPrepareOptionsMenu(menu);
        }
    }



    private void startHOSConfirmActivity(int position) {

        //The if loop is added because of deep link checking with -1 position
        if(position >= 0) {
            String s = hosStageArrayList.get(position).getStageName();
            Intent hosConfirmIntent = new Intent(HOSActivity.this, HOSConfirmActivity.class);
            hosConfirmIntent.putExtra("stage", s);
            hosConfirmIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivityForResult(hosConfirmIntent, 100);

        }

    }

    private boolean mandatoryConditionsPassed() {
        if (hos_update_cj_customer_layout.getVisibility() == View.VISIBLE && customerAvailability() && sh_prefs.getBoolean(MDACons.IS_CUSTOMER_MANDATORY, false) && hos_update_cj_customer_text.getText().length() <= 0) {
            hos_update_cj_customer_text.setHint("Please select customer");
            hos_update_cj_customer_text.setHintTextColor(Color.RED);
            hos_update_cj_customer_text.setTypeface(null, Typeface.ITALIC);
            return false;
        }
        if (hos_update_cj_job_layout.getVisibility() == View.VISIBLE && jobAvailability() && sh_prefs.getBoolean(MDACons.IS_JOB_SITE_MANDATORY, false) && hos_update_cj_job_text.getText().length() <= 0) {
            hos_update_cj_job_text.setHint("Please select task");
            hos_update_cj_job_text.setHintTextColor(Color.RED);
            hos_update_cj_job_text.setTypeface(null, Typeface.ITALIC);
            return false;
        }
        return true;
    }


    private boolean customerAvailability() {
        String[] projection =
                {HOSCustomerANDJobTable.HOS_CJ_ID,
                        HOSCustomerANDJobTable.HOS_CJ_WHICH};
        Cursor cursor = this.getContentResolver().query(Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI.toString()), projection, HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ?", new String[]{"Customer"},
                HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.close();
                return true;
            } else {
                cursor.close();
                return false;
            }
        } else
            return false;
    }

    private boolean jobAvailability() {
        String[] projection =
                {HOSCustomerANDJobTable.HOS_CJ_ID,
                        HOSCustomerANDJobTable.HOS_CJ_WHICH};
        Cursor cursor = this.getContentResolver().query(Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI.toString()), projection, HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ?", new String[]{"Job"},
                HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.close();
                return true;
            } else {
                cursor.close();
                return false;
            }
        } else
            return false;
    }



    private void getSlectedJobName() {
        if (hos_update_cj_job_text.getText().toString().replace("Job: ", "")
                .length() >= 1) {
            String[] projection_job =
                    {HOSCustomerANDJobTable.HOS_CJ_ID};
            Cursor job_cursor = getContentResolver().query(
                    Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI
                            .toString()),
                    projection_job,
                    HOSCustomerANDJobTable.HOS_CJ_NAME + " LIKE ?" + " AND " + HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ? ",
                    new String[]
                            {hos_update_cj_job_text.getText().toString()
                                    .replace("Job: ", ""), "Job"}, null);
            if (job_cursor != null) {

                while (job_cursor.moveToNext()) {
                    this.edit_prefs
                            .putString(MDACons.HOS_JOB_SELECTED_ID,
                                    job_cursor.getString(job_cursor
                                            .getColumnIndexOrThrow(HOSCustomerANDJobTable.HOS_CJ_ID)));
                }
            }

            if (job_cursor.getCount() == 0) {
                this.edit_prefs.putString(MDACons.HOS_JOB_SELECTED_NEW,
                        hos_update_cj_job_text.getText().toString()
                                .replace("Job: ", ""));
            }
            job_cursor.close();
        }
        this.edit_prefs.commit();
    }

    private String getSelectedCustomerName() {
        String returnString = "";
        if (hos_update_cj_customer_text.getText().toString()
                .replace("Customer: ", "").length() >= 1) {
            String[] projection =
                    {HOSCustomerANDJobTable.HOS_CJ_ID};
            Cursor customer_cursor = getContentResolver().query(
                    Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI
                            .toString()),
                    projection,
                    HOSCustomerANDJobTable.HOS_CJ_NAME + " LIKE ?" + " AND " + HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ? ",
                    new String[]
                            {hos_update_cj_customer_text.getText()
                                    .toString()
                                    .replace("Customer: ", ""), "Customer"}, null);

            if (customer_cursor != null) {

                while (customer_cursor.moveToNext()) {
                    returnString = customer_cursor
                            .getString(customer_cursor
                                    .getColumnIndexOrThrow(HOSCustomerANDJobTable.HOS_CJ_ID));
                    this.edit_prefs
                            .putString(MDACons.HOS_CUSTOMER_SELECTED_ID,
                                    returnString);

                }
            }
            if (customer_cursor.getCount() == 0) {
                this.edit_prefs.putString(MDACons.HOS_CUSTOMER_SELECTED_NEW,
                        hos_update_cj_customer_text.getText().toString()
                                .replace("Customer: ", ""));
            }
            customer_cursor.close();
        }




        this.edit_prefs.commit();
        return returnString;
    }


    private void pushHOSEntrytoDB() {
        // save data into database
        for(HOSEntry hosEntry : hosEntryList) {
            if(NetworkConnectionInfo.isOnline(HOSActivity.this) ||
                    hosEntry.getAttachmentBlock().size() > 0 ||
                    hosEntry.getFormfdUID().length() > 0 ||
                    hosEntry.getQrResultText().length() > 0 ||
                    hosEntry.getSelectedCustomerId().length() > 0 ||
                    hosEntry.getSelectedJobId().length() > 0 ||
                    hosEntry.getTypedMessageContent().length() > 0 ||
                    hosEntry.getHos_sms_command_to_push().trim().length() <= 0) {


                insertHOSEntryInDB(hosEntry);

            } else {
                SharedPreferences sharedPreferences = getSharedPreferences(MDACons.PREFS, 0);
                String toPhoneNumber = sharedPreferences.getString(MDACons.TWILIO_SHORT_CODE, "+18032327769");
                String stageSMSCommand = hosEntry.getHos_sms_command_to_push();
                String stageDesc = hosEntry.getHos_desc_to_push();
                if(isSMSPermissionGranted()) {
                    new ProcessSMS().sendNow(HOSActivity.this, toPhoneNumber, stageSMSCommand, hosEntry.getHos_value_to_push(), stageDesc);
                } else {
                    insertHOSEntryInDB(hosEntry);
                }
            }
        }
        hosEntryList.clear();
        IS_PUSHING_TO_DB = false;
    }

    private void insertHOSEntryInDB(HOSEntry hosEntry) {
        Log.d("INSERTINTODB","INSERTINTODB");
        ContentValues initialValues = new ContentValues();
        initialValues.put(HOSEntryTable.HOS_ENTRY_XML,
                HOSEntryConstruction.constructHOSEntryBlock(HOSActivity.this.getApplicationContext(), hosEntry.getDeviceId(),
                        hosEntry.getHos_value_to_push(), hosEntry.getHos_time_to_push(),
                        FetchLocationForHOS.getCurrentLatitude(), FetchLocationForHOS.getCurrentLongitude(), FetchLocationForHOS.getAccuracy(), FetchLocationForHOS.getDeviceMethod(), FetchLocationForHOS.getTimestampToSend(),
                        hosEntry.getSelectedJobId(), hosEntry.getSelectedWorkOrderId(),hosEntry.getSelectedCustomerId(), hosEntry.getTypedMessageContent(),
                        hosEntry.getQrResultText(), "", hosEntry.getDeviceGUID(), hosEntry.getAttachmentBlock(), hosEntry.getFormfdUID()));
        initialValues.put(HOSEntryTable.HOS_ENTRY_FORM_POST_DATA, FORM_POST_DATA);
        initialValues.put(HOSEntryTable.HOS_ENTRY_NO_OF_TRIES, 0);
        this.getContentResolver().insert(HOSEntryContentProvider.CONTENT_URI,
                initialValues);
    }

    public void getLocation(Context ctx, String token, int accuracy,
                            int timeout) {

        Log.d(TAG,"LOCATIONCALL ");

        if (ContextCompat.checkSelfPermission(HOSActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            processAfterLocationSuccess("0.0", "", 1.0, 1.0, Calendar.getInstance().getTime().getTime());
            return;
        }
        else
        {
            Log.d(TAG,"GETELSEPAR ");
            int locationMode = 0;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT){
                try {
                    locationMode = Settings.Secure.getInt(ctx.getContentResolver(),Settings.Secure.LOCATION_MODE);
                } catch (Settings.SettingNotFoundException e) {
                    e.printStackTrace();
                }

                if(locationMode == Settings.Secure.LOCATION_MODE_OFF) {
                    processAfterLocationSuccess("0.0", "", 1.0, 1.0, Calendar.getInstance().getTime().getTime());
                    return;
                }


            }

//
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
//            {
//                reach_call_location();
//            }
//            else
//            {
//                native_call_location();
//            }

            if(Build.VERSION.SDK_INT >= 26)
            {
                native_call_location();
            }
            else
            {
                reach_call_location();
            }



        }



    }

    private void native_call_location()
    {
        SmartLocation.with(HOSActivity.this).location()
                        .oneFix()
                        .config(LocationParams.LAZY)
                        .start(new OnLocationUpdatedListener() {
                            @Override
                            public void onLocationUpdated(Location location) {
                                String accuracyParam = location.getAccuracy() + "";
                                String methodParam = NetworkDeviceStatus.checkNetworkStatus(HOSActivity.this);
                                Double latitudeParam = location.getLatitude();
                                Double longitudeParam = location.getLongitude();
                                long timestampParam = location.getTime();
                                Log.d(TAG,"LICATSCESDER");
                                processAfterLocationSuccess(accuracyParam, methodParam, latitudeParam, longitudeParam, timestampParam);

                            }
                        });
    }


    private void reach_call_location()
    {
        Reach.getLocation(getApplicationContext(), new ReachLocationCallback(){
            @Override
            public void onLocationSuccess(Ingress.Location location) {

                String accuracyParam = location.getAccuracy() + "";
                String methodParam = NetworkDeviceStatus.checkNetworkStatus(HOSActivity.this);
                Float latitudeParam = location.getLatitude();
                Float longitudeParam = location.getLongitude();
                long timestampParam = location.getTimestamp();
                processAfterLocationSuccess(accuracyParam, methodParam, Double.valueOf(latitudeParam), Double.valueOf(longitudeParam), timestampParam);


            }
            @Override
            public void onLocationFailure(Ingress.Error error) {
                Log.d(TAG,"Location failure");
            }
        });




    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        if (requestCode == CUS_TASK_INTENT_REQUEST_CODE) {
            String resulted_selection = data.getStringExtra("selected_which");
            if (!resulted_selection.equals("null") && resulted_selection != null)
                if (data.getStringExtra("which").equals("customer")) {
                    hos_update_cj_customer_text.setText("Customer: "
                            + resulted_selection);

                    this.edit_prefs.putString(MDACons.HOS_CUSTOMER_SELECTED,
                            resulted_selection);
                    if (jobAvailability())
                        hos_update_cj_job_layout.setVisibility(View.VISIBLE);
                    hos_update_cj_job_text.setText("");
                    SharedPreferences.Editor prefs_edit = sh_prefs.edit();
                    prefs_edit.putString(MDACons.HOS_JOB_SELECTED, "");
                    prefs_edit.commit();
                    hos_update_cj_customer_text.setHintTextColor(Color.GRAY);
                    hos_update_cj_customer_text.setTypeface(null, Typeface.NORMAL);
                } else if (data.getStringExtra("which").equals("job")) {
                    hos_update_cj_job_text.setText("Job: " + resulted_selection);
                    hos_update_cj_job_text.setHintTextColor(Color.GRAY);
                    hos_update_cj_job_text.setTypeface(null, Typeface.NORMAL);
                    this.edit_prefs.putString(MDACons.HOS_JOB_SELECTED,
                            resulted_selection);
                }
            this.edit_prefs.commit();
        } else if (requestCode == 100 && resultCode == RESULT_OK) {
            ATTACHMENT_BLOCK = data.getParcelableArrayListExtra("attach");
            QR_RESULT_TEXT = data.getStringExtra("scan").toString();
            TYPED_MESSAGE = data.getStringExtra("message").toString();
            FORM_POST_DATA = data.getStringExtra("form").toString();
            FORM_FDUID = data.getStringExtra("fdUID").toString();

            Bundle bundle = new Bundle();
            bundle.putString("TC_CONFIRMATION", "Submitted");
            bundle.putString("TC_IMAGES", ATTACHMENT_BLOCK.size()+" Attachments");
            if(QR_RESULT_TEXT.length() > 0)
                bundle.putString("TC_SCAN_AVAILABLITY", "true");
            else
                bundle.putString("TC_SCAN_AVAILABLITY", "false");
            if(TYPED_MESSAGE.length() > 0)
                bundle.putString("TC_NOTES_AVAILABLITY", "true");
            else
                bundle.putString("TC_NOTES_AVAILABLITY", "false");
            if(FORM_POST_DATA.length() > 0)
                bundle.putString("TC_FORM_AVAILABLITY", "true");
            else
                bundle.putString("TC_FORM_AVAILABLITY", "false");
            mFirebaseAnalytics.logEvent("TC_EVENT", bundle);

            HOSOkButtonClicked(CLICKED_ITEM);
        } else if (requestCode == 100 && resultCode == RESULT_CANCELED) {
            URICheckinAlreadyOnSameStage = false;
            URICheckinAvailable = false;
            //updateUIView();
            updateUI();
            Bundle bundle = new Bundle();
            bundle.putString("TC_CONFIRMATION", "Cancelled");
            mFirebaseAnalytics.logEvent("TC_EVENT", bundle);

        }
        super.onActivityResult(requestCode, resultCode, data);
    }





    private void HOSOkButtonClicked(int position) {
        String time = "";
        SimpleDateFormat sdf = null;
        try {
            sdf = new SimpleDateFormat("yyyy/MMM/dd,HH:mm:ss",
                    Locale.getDefault());
            time = CurrentDateAndTime.getDateTime(new SimpleDateFormat(
                    "yyyy/MM/dd'T'HH:mm:ssZ", Locale.getDefault()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        // DebugLog.debug(TAG,("getTag", Integer.parseInt(v.getTag().toString()) + "");
        // DebugLog.debug(TAG,("getTag", v.getTag() + "");

        edit_prefs.putInt(MDACons.HOS_SELECTION,
                Integer.parseInt(hosStageArrayList.get(position).getStageID()));
        String s = hosStageArrayList.get(position).getStageName();
        edit_prefs.putString(MDACons.HOS_SELECTION_NAME,
                s);
        String smsCommand = hosStageArrayList.get(position).getSMSCommand();
        edit_prefs.putString(MDACons.HOS_SELECTION_SMS_COMMAND,
                smsCommand);

        edit_prefs.putString(MDACons.HOS_TIME, time);
        edit_prefs.putString(MDACons.HOS_CUSTOMER_SELECTED_ID, "");
        edit_prefs.putString(MDACons.HOS_JOB_SELECTED_ID, "");
        edit_prefs.putString(MDACons.HOS_WORK_SELECTED_ID, "");
        edit_prefs.putString(MDACons.HOS_CUSTOMER_SELECTED_NEW, "");
        edit_prefs.putString(MDACons.HOS_JOB_SELECTED_NEW, "");
        edit_prefs.commit();
        getSelectedCustomerName();
        getSlectedJobName();
        /*
         * DebugLog.debug(TAG,("CUSTOMERANDJOB",
         * this.prefs.getString(MDACons.HOS_CUSTOMER_SELECTED, ""));
         * DebugLog.debug(TAG,("CUSTOMERANDJOB", this.prefs.getString(MDACons.HOS_JOB_SELECTED,
         * ""));
         */
        mAdapter.notifyDataSetChanged();

        try {
            SimpleDateFormat formatter = new SimpleDateFormat(
                    "yyyy/MM/dd'T'HH:mm:ssZ", Locale.getDefault());
            Date date = (Date) formatter.parse(sh_prefs.getString(
                    MDACons.HOS_TIME, ""));
            time = sdf.format(date).toString();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        time = null;

        statusSnackBar = Snackbar.make(rootLayout, "Updating... Please wait.", Snackbar.LENGTH_LONG);
        View snackView = statusSnackBar.getView();
        snackView.setBackgroundColor(ContextCompat.getColor(HOSActivity.this, R.color.yellow));

        SpannableString spannableString = new SpannableString("Updating... Please wait.");
        ForegroundColorSpan colorSpan = new ForegroundColorSpan(Color.BLACK);
        spannableString.setSpan(colorSpan, 0, spannableString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        statusSnackBar.setText(spannableString);

        statusSnackBar.show();

        //SnackbarUtils.showIndefinite(rootLayout, "Updating... Please wait.", Color.BLACK, ContextCompat.getColor(HOSActivity.this, R.color.yellow));
        HOSEntry hosEntry = new HOSEntry();
        hosEntry.setDeviceId(this.sh_prefs.getString(MDACons.DEVICE_NUMBER, ""));
        hosEntry.setHos_value_to_push(""
                + sh_prefs.getInt(MDACons.HOS_SELECTION, -1));
        hosEntry.setHos_desc_to_push(""
                + sh_prefs.getString(MDACons.HOS_SELECTION_NAME, ""));
        hosEntry.setHos_sms_command_to_push(""
                + sh_prefs.getString(MDACons.HOS_SELECTION_SMS_COMMAND, ""));
        hosEntry.setHos_time_to_push("" + sh_prefs.getString(MDACons.HOS_TIME, ""));
        hosEntry.setSelectedJobId(this.sh_prefs.getString(MDACons.HOS_JOB_SELECTED_ID, ""));
        hosEntry.setSelectedCustomerId(this.sh_prefs.getString(MDACons.HOS_CUSTOMER_SELECTED_ID, ""));
        hosEntry.setTypedMessageContent(TYPED_MESSAGE);
        hosEntry.setQrResultText(QR_RESULT_TEXT);
        hosEntry.setSelectedWorkOrderId(work_order_pos_id);
        hosEntry.setDeviceGUID(this.sh_prefs.getString(MDACons.DEVICE_GUID, ""));
        hosEntry.setAttachmentBlock(ATTACHMENT_BLOCK);
        hosEntry.setFormfdUID(FORM_FDUID);

        hosEntryList.add(hosEntry);

        //if(AccountUtils.isSOSAvailable(sh_prefs) && ConnectionClassManager.getInstance().getCurrentBandwidthQuality() == ConnectionQuality.POOR)
       // if(AccountUtils.isSOSAvailable(sh_prefs) && !NetworkUtils.isConnectedFast(HOSActivity.this) && isSMSPermissionGranted())
        if((AccountUtils.isSOSAvailable(sh_prefs) && !NetworkUtils.isConnectedFast(HOSActivity.this)) || (AccountUtils.isSOSAvailable(sh_prefs) && ConnectionClassManager.getInstance().getCurrentBandwidthQuality() == ConnectionQuality.POOR))
        {
            SnackbarUtils.dismiss();
            SharedPreferences sharedPreferences = getSharedPreferences(MDACons.PREFS, 0);
            String toPhoneNumber = sharedPreferences.getString(MDACons.TWILIO_SHORT_CODE, "+18032327769");
            String stageSMSCommand = hosEntry.getHos_sms_command_to_push();
            String stageDesc = hosEntry.getHos_desc_to_push();
            new ProcessSMS().sendNow(HOSActivity.this, toPhoneNumber, stageSMSCommand, hosEntry.getHos_value_to_push(), stageDesc);

            ContentValues initialValues = new ContentValues();
            initialValues.put(NotesEntryTable.NOTES_ENTRY_NO_OF_TRIES,
                    0);

            initialValues.put(NotesEntryTable.NOTES_ENTRY_FORM_POST_DATA,
                    FORM_POST_DATA);

            Notes notes = new Notes();
            String messageBodyText = hosEntry.getTypedMessageContent();
            String taskString = "", qrString = "", formString = "", fdUID = "", customerString = "";
            //taskString = hosEntry.getSelectedJobId();
            //notes.setTask_description(taskString);
            //customerString = hosEntry.getSelectedCustomerId();
            //notes.setjobsite_description(customerString);
            qrString = hosEntry.getQrResultText();
            notes.setMessageBody(messageBodyText);
            notes.setQr_result(qrString);
            notes.setForm_result(FORM_POST_DATA);
            notes.setForm_fdUID(hosEntry.getFormfdUID());
            ArrayList<Attachments> attachmentsArrayList = new ArrayList<>();

            for(ImageAttachment imageAttachment : hosEntry.getAttachmentBlock()) {
                Attachments attachments = new Attachments();
                if(imageAttachment.getType().equals(Attachments.Attachment_Type.IMAGE))
                    attachments.setAttachment_type(Attachments.Attachment_Type.IMAGE);
                else if (imageAttachment.getType().equals(Attachments.Attachment_Type.SIGNATURE))
                    attachments.setAttachment_type(Attachments.Attachment_Type.SIGNATURE);

                attachments.setImageAttachment(imageAttachment);
                attachments.setAttachmentID(attachmentsArrayList.size());
                attachmentsArrayList.add(attachments);
            }

            initialValues.put(NotesEntryTable.NOTES_ENTRY_XML,
                    NotesEntryConstruction.constructNotesEntryBlock(HOSActivity.this, notes, attachmentsArrayList));
            getContentResolver().insert(NotesEntryContentProvider.CONTENT_URI,
                    initialValues);

        } else {
            Log.d("LIVELOCATION","LIVELOCATION "+liveLocation);
            if(liveLocation != null) {
                Log.d("TAG",
                        "Got ZDA location - " + liveLocation.getLatitude() + ","
                                + liveLocation.getLongitude() + " "
                                + liveLocation.getAccuracy() + "m");

                FetchLocationForHOS.setAccuracy(liveLocation.getAccuracy() + "");
                String methodParam = NetworkDeviceStatus.checkNetworkStatus(HOSActivity.this);

                FetchLocationForHOS.setDeviceMethod(methodParam);
                FetchLocationForHOS.setCurrentLatitude(liveLocation.getLatitude()
                );
                FetchLocationForHOS.setCurrentLongitude(liveLocation.getLongitude()
                );

                String timeFormatted = "";
                try {
                    DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd'T'HH:mm:ssZ");
                    timeFormatted = formatter.format(liveLocation.getTime());
                } catch (Exception e) {
                    e.printStackTrace();
                }

                FetchLocationForHOS.setTimestampToSend(timeFormatted);
                pushHOSEntrytoDB();

                if (NetworkConnectionInfo.isOnline(HOSActivity.this))
                    new HOSPushTask(HOSActivity.this).execute();

            } else {
                AsyncTask.execute(new Runnable() {
                    @Override
                    public void run() {
                        getLocation(HOSActivity.this.getApplicationContext(),
                                myGeoTrackingDevieAgentApplication.AUTH_TOKEN, 1000, 20);
                    }
                });

            }
        }
    }


    private void sosAlertDialogView() {

        new MaterialDialog.Builder(HOSActivity.this)
                .title("Send SOS")
                .content("Please Confirm.")
                .positiveText("Yes")
                .negativeText("Cancel")
                .autoDismiss(true)
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        SharedPreferences sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
                        String hos_Selection_stage_name = sh_prefs.getString(MDACons.HOS_SELECTION_NAME, "");
                        Bundle bundle = new Bundle();
                        bundle.putString("TC_CLICKED_STAGE", "SOS");
                        bundle.putString("TC_PREVIOUS_STAGE", hos_Selection_stage_name);
                        bundle.putString("TC_EVENT_SOURCE", "Manual Click");
                        mFirebaseAnalytics.logEvent("TC_EVENT", bundle);

                        //IF No Internet at all - then process as SMS immediately
                        //IF Internet available - then check for connection quality
                        //IF Connection quality is POOR - then process as SMS
                        //IF Connection quality is GOOD and FAST - then process ausual with API Request
                        if(!NetworkConnectionInfo.isOnline(HOSActivity.this) && isSMSPermissionGranted()) {
                            processSOSAsSMS();
                        } else {
                            if(AccountUtils.isSOSAvailable(sh_prefs) && !NetworkUtils.isConnectedFast(HOSActivity.this) && isSMSPermissionGranted()) {
                                processSOSAsSMS();
                            } else {
                                new HOSBackgroundService().processHOS(HOSActivity.this, "Safety Alert Triggered", "7");
                                if(!isSMSPermissionGranted())
                                    askForSMSPermission();
                            }
                        }
                        try {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    updateUI();
                                }
                            });
                        }catch (Exception e) {e.printStackTrace();}
                        SnackbarUtils.showLong(rootLayout, "Safety Alert Triggered.", Color.BLACK, ContextCompat.getColor(HOSActivity.this, R.color.yellow));
                    }
                })
                .show();
    }


    private void processAfterLocationSuccess(String accuracyParam, String methodParam, Double latitudeParam, Double longitudeParam, long timestampParam) {

        Log.d(TAG,"UPDATELOCATIONCALLED ");

        if (pullLabelsHandler != null) {
            pullLabelsHandler.sendMessage(pullLabelsHandler
                    .obtainMessage(101109));
        }

        FetchLocationForHOS.setAccuracy(accuracyParam);
        FetchLocationForHOS.setDeviceMethod(methodParam);
        FetchLocationForHOS.setCurrentLatitude(latitudeParam
        );
        FetchLocationForHOS.setCurrentLongitude(longitudeParam
        );
        String timeFormatted = "";
        try {
            DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd'T'HH:mm:ssZ");
            timeFormatted = formatter.format(timestampParam);
        } catch (Exception e) {
            e.printStackTrace();
        }

        FetchLocationForHOS.setTimestampToSend(timeFormatted);

        pushHOSEntrytoDB();

        if (NetworkConnectionInfo.isOnline(HOSActivity.this))
            new HOSPushTask(HOSActivity.this).execute();
    }


    @Override
    public void onBandwidthStateChange(ConnectionQuality bandwidthState) {
        if(bandwidthState == ConnectionQuality.POOR && !NetworkUtils.isConnectedFast(HOSActivity.this)) {
            showSlowNetworkWarning();
            Log.i("CONNECTION_SAMPLING", "POOR");
        } else if(bandwidthState == ConnectionQuality.MODERATE) {
            //return false;
            if(AccountUtils.isSOSAvailable(sh_prefs))
                SnackbarUtils.dismiss();
            Log.i("CONNECTION_SAMPLING", "MODERATE");
        } else if(bandwidthState == ConnectionQuality.UNKNOWN) {
            //return false;
            if(AccountUtils.isSOSAvailable(sh_prefs))
                SnackbarUtils.dismiss();
            Log.i("CONNECTION_SAMPLING", "UNKNOWN");
        } else if(bandwidthState == ConnectionQuality.EXCELLENT) {
            //return false;
            if(AccountUtils.isSOSAvailable(sh_prefs))
                SnackbarUtils.dismiss();
            Log.i("CONNECTION_SAMPLING", "EXCELLENT");
        } else if(bandwidthState == ConnectionQuality.GOOD) {
            //return false;
            if(AccountUtils.isSOSAvailable(sh_prefs))
                SnackbarUtils.dismiss();
            Log.i("CONNECTION_SAMPLING", "GOOD");
        } else {
            //return true;
            Log.i("CONNECTION_SAMPLING", "SOMETHING ELSE");
        }
    }



    private void showNoConnectivityWarning() {

        if(AccountUtils.isSOSAvailable(sh_prefs)) {
            if(NetworkConnectionInfo.isOnline(HOSActivity.this)) {
                if(ConnectionClassManager.getInstance().getCurrentBandwidthQuality() != ConnectionQuality.POOR) {
                    //displayNoConnectivityAlert();
                }
            } else {
                displayNoConnectivityAlert();
            }
        }
    }

    private void displayNoConnectivityAlert() {
        final TSnackbar snackbar = TSnackbar.make(findViewById(android.R.id.content), getString(R.string.txtwarning_no_connectivty_reachable), TSnackbar.LENGTH_INDEFINITE);
        snackbar.setActionTextColor(Color.parseColor("#00adee"));
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(Color.parseColor("#ececec"));
        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
        textView.setTextColor(Color.parseColor("#535454"));
        textView.setTypeface(null, Typeface.BOLD);
        snackbar.setAction("GOT IT", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                snackbar.dismiss();
            }
        });
        snackbar.show();
    }


    private void showInternetDisabled() {
        final TSnackbar snackbar = TSnackbar.make(findViewById(android.R.id.content), getString(R.string.msg_internet_disabled_please_try_later), TSnackbar.LENGTH_INDEFINITE);
        snackbar.setActionTextColor(Color.parseColor("#00adee"));
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(Color.parseColor("#ececec"));
        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
        textView.setTextColor(Color.parseColor("#535454"));
        textView.setTypeface(null, Typeface.BOLD);
        snackbar.setAction("GOT IT", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                snackbar.dismiss();
            }
        });
        snackbar.show();
    }

    @Override
    public void onInternetChanged() {
        if(NetworkConnectionInfo.isOnline(HOSActivity.this)) {
            INTERNET_STATUS = InternetState.STATE_CONNECTED;
        } else {
            //determineButtonDisableCondition
            INTERNET_STATUS = InternetState.STATE_DISCONNECTED;

            if(!AccountUtils.isSOSAvailable(sh_prefs)) {
                final TSnackbar snackbar = TSnackbar.make(findViewById(android.R.id.content), getString(R.string.msg_internet_disabled_please_try_later), TSnackbar.LENGTH_INDEFINITE);
                snackbar.setActionTextColor(Color.parseColor("#00adee"));
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#ececec"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.parseColor("#535454"));
                textView.setTypeface(null, Typeface.BOLD);
                snackbar.setAction("GOT IT", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        snackbar.dismiss();
                    }
                });
                snackbar.show();
            } else if(CONNECTIVITY_STATUS == PhoneServiceState.STATE_DISCONNECTED) {
                finish();
            }

        }
    }

    @Override
    public void onNetworkConnected() {
        //determineButtonDisableCondition
        int SIM_STATE = telephonyManager.getSimState();
        if( SIM_STATE == TelephonyManager.SIM_STATE_UNKNOWN ||
                SIM_STATE == TelephonyManager.SIM_STATE_ABSENT ||
                SIM_STATE == TelephonyManager.SIM_STATE_NETWORK_LOCKED ||
                SIM_STATE == TelephonyManager.SIM_STATE_PIN_REQUIRED ||
                SIM_STATE == TelephonyManager.SIM_STATE_PUK_REQUIRED) {
            CONNECTIVITY_STATUS = PhoneServiceState.STATE_DISCONNECTED;
            if(INTERNET_STATUS == InternetState.STATE_DISCONNECTED) {
                if(AccountUtils.isSOSAvailable(sh_prefs)) {
                    finish();
                }
            }
        } else {
            CONNECTIVITY_STATUS = PhoneServiceState.STATE_CONNECTED;
        }
    }

    @Override
    public void onNetworkDisconnected() {
        //determineButtonDisableCondition
        CONNECTIVITY_STATUS = PhoneServiceState.STATE_DISCONNECTED;
        if(INTERNET_STATUS == InternetState.STATE_DISCONNECTED) {
            if(AccountUtils.isSOSAvailable(sh_prefs)) {
                finish();
            }
        }
    }




}
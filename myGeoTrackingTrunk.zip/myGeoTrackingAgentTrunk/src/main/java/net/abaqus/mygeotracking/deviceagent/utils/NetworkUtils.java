package net.abaqus.mygeotracking.deviceagent.utils;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.support.annotation.RequiresPermission;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.facebook.network.connectionclass.ConnectionClassManager;
import com.facebook.network.connectionclass.ConnectionQuality;
import com.kbeanie.multipicker.utils.LogUtils;

import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Created by root on 23/5/17.
 */

public class NetworkUtils {


    private NetworkUtils() {
        throw new UnsupportedOperationException("u can't instantiate me...");
    }

    public enum NetworkType {
        NETWORK_WIFI,
        NETWORK_4G,
        NETWORK_3G,
        NETWORK_2G,
        NETWORK_UNKNOWN,
        NETWORK_NO
    }

    /**
     *
     * @param mContext
     */
    public static void openWirelessSettings(Context mContext) {
        if (android.os.Build.VERSION.SDK_INT > 10) {
            mContext.startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } else {
            mContext.startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }
    }

    /**
     *
     * @return
     */
    private static NetworkInfo getActiveNetworkInfo(Context mContext) {
        return ((ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
    }

    /**
     *
     * @return
     */
    public static boolean isConnected(Context mContext) {
        NetworkInfo info = getActiveNetworkInfo(mContext);
        return info != null && info.isConnected();
    }

    /**
     *
     * @return
     */
    public static boolean isAvailableByPing() {
        ShellUtils.CommandResult result = ShellUtils.execCmd("ping -c 1 -w 1 162.144.222.124", false);
        boolean ret = result.result == 0;
        if (result.errorMsg != null) {
            DebugLog.debug("isAvailableByPing Error: " + result.errorMsg);
        }
        if (result.successMsg != null) {
            DebugLog.debug("isAvailableByPing Success: " + result.successMsg);
        }
        return ret;
    }

    /**
     *
     * @return
     */
    public static boolean getConnectionQuality() {
        ConnectionQuality cq = ConnectionClassManager.getInstance().getCurrentBandwidthQuality();

        if(cq == ConnectionQuality.POOR) {
            return false;
        } else if(cq == ConnectionQuality.MODERATE) {
            return false;
        } else if(cq == ConnectionQuality.UNKNOWN) {
            return false;
        } else {
            return true;
        }
    }


    /**
     *
     * @return
     */
    public static boolean isSlowNetwork() {
        if(!isAvailableByPing()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     *
     * @return
     */
    public static boolean getDataEnabled(Context mContext) {
        try {
            TelephonyManager tm = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
            Method getMobileDataEnabledMethod = tm.getClass().getDeclaredMethod("getDataEnabled");
            if (null != getMobileDataEnabledMethod) {
                return (boolean) getMobileDataEnabledMethod.invoke(tm);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     *
     * @param enabled
     */
    public static void setDataEnabled(boolean enabled, Context mContext) {
        try {
            TelephonyManager tm = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
            Method setMobileDataEnabledMethod = tm.getClass().getDeclaredMethod("setDataEnabled", boolean.class);
            if (null != setMobileDataEnabledMethod) {
                setMobileDataEnabledMethod.invoke(tm, enabled);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @return
     */
    public static boolean is4G(Context mContext) {
        NetworkInfo info = getActiveNetworkInfo(mContext);
        return info != null && info.isAvailable() && info.getSubtype() == TelephonyManager.NETWORK_TYPE_LTE;
    }

    /**
     *
     * @return
     */
    public static boolean getWifiEnabled(Context mContext) {
        @SuppressLint("WifiManagerLeak")
        WifiManager wifiManager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
        return wifiManager.isWifiEnabled();
    }

    /**
     *
     * @param enabled
     */
    public static void setWifiEnabled(boolean enabled, Context mContext) {
        @SuppressLint("WifiManagerLeak")
        WifiManager wifiManager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
        if (enabled) {
            if (!wifiManager.isWifiEnabled()) {
                wifiManager.setWifiEnabled(true);
            }
        } else {
            if (wifiManager.isWifiEnabled()) {
                wifiManager.setWifiEnabled(false);
            }
        }
    }

    /**
     *
     * @return
     */
    public static boolean isWifiConnected(Context mContext) {
        ConnectivityManager cm = (ConnectivityManager) mContext
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm != null && cm.getActiveNetworkInfo() != null
                && cm.getActiveNetworkInfo().getType() == ConnectivityManager.TYPE_WIFI;
    }

    /**
     *
     * @return
     */
    public static boolean isWifiAvailable(Context mContext) {
        return getWifiEnabled(mContext) && isAvailableByPing();
    }

    /**
     *
     * @return
     */
    public static String getNetworkOperatorName(Context mContext) {
        TelephonyManager tm = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
        return tm != null ? tm.getNetworkOperatorName() : null;
    }

    private static final int NETWORK_TYPE_GSM      = 16;
    private static final int NETWORK_TYPE_TD_SCDMA = 17;
    private static final int NETWORK_TYPE_IWLAN    = 18;

    /**
     *
     * <ul>
     * <li>{@link NetworkUtils.NetworkType#NETWORK_WIFI   } </li>
     * <li>{@link NetworkUtils.NetworkType#NETWORK_4G     } </li>
     * <li>{@link NetworkUtils.NetworkType#NETWORK_3G     } </li>
     * <li>{@link NetworkUtils.NetworkType#NETWORK_2G     } </li>
     * <li>{@link NetworkUtils.NetworkType#NETWORK_UNKNOWN} </li>
     * <li>{@link NetworkUtils.NetworkType#NETWORK_NO     } </li>
     * </ul>
     */
    public static NetworkType getNetworkType(Context mContext) {
        NetworkType netType = NetworkType.NETWORK_NO;
        NetworkInfo info = getActiveNetworkInfo(mContext);
        if (info != null && info.isAvailable()) {

            if (info.getType() == ConnectivityManager.TYPE_WIFI) {
                netType = NetworkType.NETWORK_WIFI;
            } else if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
                switch (info.getSubtype()) {

                    case NETWORK_TYPE_GSM:
                    case TelephonyManager.NETWORK_TYPE_GPRS:
                    case TelephonyManager.NETWORK_TYPE_CDMA:
                    case TelephonyManager.NETWORK_TYPE_EDGE:
                    case TelephonyManager.NETWORK_TYPE_1xRTT:
                    case TelephonyManager.NETWORK_TYPE_IDEN:
                        netType = NetworkType.NETWORK_2G;
                        break;

                    case NETWORK_TYPE_TD_SCDMA:
                    case TelephonyManager.NETWORK_TYPE_EVDO_A:
                    case TelephonyManager.NETWORK_TYPE_UMTS:
                    case TelephonyManager.NETWORK_TYPE_EVDO_0:
                    case TelephonyManager.NETWORK_TYPE_HSDPA:
                    case TelephonyManager.NETWORK_TYPE_HSUPA:
                    case TelephonyManager.NETWORK_TYPE_HSPA:
                    case TelephonyManager.NETWORK_TYPE_EVDO_B:
                    case TelephonyManager.NETWORK_TYPE_EHRPD:
                    case TelephonyManager.NETWORK_TYPE_HSPAP:
                        netType = NetworkType.NETWORK_3G;
                        break;

                    case NETWORK_TYPE_IWLAN:
                    case TelephonyManager.NETWORK_TYPE_LTE:
                        netType = NetworkType.NETWORK_4G;
                        break;
                    default:

                        String subtypeName = info.getSubtypeName();
                        if (subtypeName.equalsIgnoreCase("TD-SCDMA")
                                || subtypeName.equalsIgnoreCase("WCDMA")
                                || subtypeName.equalsIgnoreCase("CDMA2000")) {
                            netType = NetworkType.NETWORK_3G;
                        } else {
                            netType = NetworkType.NETWORK_UNKNOWN;
                        }
                        break;
                }
            } else {
                netType = NetworkType.NETWORK_UNKNOWN;
            }
        }
        return netType;
    }

    /**
     *
     * @param useIPv4
     * @return
     */
    public static String getIPAddress(boolean useIPv4) {
        try {
            for (Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces(); nis.hasMoreElements(); ) {
                NetworkInterface ni = nis.nextElement();
                // 防止小米手机返回10.0.2.15
                if (!ni.isUp()) continue;
                for (Enumeration<InetAddress> addresses = ni.getInetAddresses(); addresses.hasMoreElements(); ) {
                    InetAddress inetAddress = addresses.nextElement();
                    if (!inetAddress.isLoopbackAddress()) {
                        String hostAddress = inetAddress.getHostAddress();
                        boolean isIPv4 = hostAddress.indexOf(':') < 0;
                        if (useIPv4) {
                            if (isIPv4) return hostAddress;
                        } else {
                            if (!isIPv4) {
                                int index = hostAddress.indexOf('%');
                                return index < 0 ? hostAddress.toUpperCase() : hostAddress.substring(0, index).toUpperCase();
                            }
                        }
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     *
     * @param domain
     * @return
     */
    public static String getDomainAddress(final String domain) {
        try {
            ExecutorService exec = Executors.newCachedThreadPool();
            Future<String> fs = exec.submit(new Callable<String>() {
                @Override
                public String call() throws Exception {
                    InetAddress inetAddress;
                    try {
                        inetAddress = InetAddress.getByName(domain);
                        return inetAddress.getHostAddress();
                    } catch (UnknownHostException e) {
                        e.printStackTrace();
                    }
                    return null;
                }
            });
            return fs.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return null;
    }



    /**
          * Check if the connection is fast
          *
          * @param type    the type
          * @param subType the sub type
          * @return boolean boolean
          */
    public static boolean isConnectionFast(int type, int subType) {
                if (type == ConnectivityManager.TYPE_WIFI) {
                        return true;
                    } else if (type == ConnectivityManager.TYPE_MOBILE) {
                        switch (subType) {
                                case TelephonyManager.NETWORK_TYPE_1xRTT:
                                        return false; // ~ 50-100 kbps
                                case TelephonyManager.NETWORK_TYPE_CDMA:
                                        return false; // ~ 14-64 kbps
                                case TelephonyManager.NETWORK_TYPE_EDGE:
                                        return false; // ~ 50-100 kbps
                                case TelephonyManager.NETWORK_TYPE_EVDO_0:
                                        return true; // ~ 400-1000 kbps
                                case TelephonyManager.NETWORK_TYPE_EVDO_A:
                                        return true; // ~ 600-1400 kbps
                                case TelephonyManager.NETWORK_TYPE_GPRS:
                                        return false; // ~ 100 kbps
                                case TelephonyManager.NETWORK_TYPE_HSDPA:
                                        return true; // ~ 2-14 Mbps
                                case TelephonyManager.NETWORK_TYPE_HSPA:
                                        return true; // ~ 700-1700 kbps
                                case TelephonyManager.NETWORK_TYPE_HSUPA:
                                        return true; // ~ 1-23 Mbps
                                case TelephonyManager.NETWORK_TYPE_UMTS:
                                        return true; // ~ 400-7000 kbps
                                /*
                 * Above API level 7, make sure to set android:targetSdkVersion
                 * to appropriate level to use these
                 */
                                        case TelephonyManager.NETWORK_TYPE_EHRPD: // API level 11
                                        return true; // ~ 1-2 Mbps
                                case TelephonyManager.NETWORK_TYPE_EVDO_B: // API level 9
                                        return true; // ~ 5 Mbps
                                case TelephonyManager.NETWORK_TYPE_HSPAP: // API level 13
                                        return true; // ~ 10-20 Mbps
                                case TelephonyManager.NETWORK_TYPE_IDEN: // API level 8
                                        return false; // ~25 kbps
                                case TelephonyManager.NETWORK_TYPE_LTE: // API level 11
                                       return true; // ~ 10+ Mbps
                               // Unknown
                                       case TelephonyManager.NETWORK_TYPE_UNKNOWN:
                                   default:
                                       return false;
                           }
                   } else {
                       return false;
                  }
           }



/**
      * Check if there is fast connectivity
      *
      * @param context the context
      * @return boolean boolean
      */
    @RequiresPermission(Manifest.permission.ACCESS_NETWORK_STATE)
    public static boolean isConnectedFast(Context context) {
                NetworkInfo info = getNetworkInfo(context);
                return (info != null && info.isConnected() && isConnectionFast(info.getType(),
                        info.getSubtype()));
            }


            /**
      * Get the network info
      *
      * @param context the context
      * @return network info
      */
            @RequiresPermission(Manifest.permission.ACCESS_NETWORK_STATE)
    public static NetworkInfo getNetworkInfo(Context context) {
                ConnectivityManager cm =
                        (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                return cm.getActiveNetworkInfo();
            }

        }
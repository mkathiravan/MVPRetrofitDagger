package net.abaqus.mygeotracking.deviceagent.updatechecker;

/**
 * Returns the result of ASyncCheck to UpdateChecker.
 *
 */
public interface StoreCheckTaskResult {
    /**
     * If the library found a version available on the Store, and it's different from the installed one, notify it to the user.
     *
     * @param versionDownloadable String to compare to the version installed of the app.
     */
    public void versionDownloadableFound(String versionDownloadable);

    /**
     * Can't get the versionName from the Store.
     */
    public void multipleApksPublished();

    /**
     * Can't download the store page.
     */
    public void networkError();

    /**
     * Can't find the store page for this app.
     */
    public void appUnpublished();

    /**
     * The check returns null for new version downloadble
     */
    public void storeError();

}
package net.abaqus.mygeotracking.deviceagent.soshardware;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.util.Log;

/**
 * Created by root on 12/12/16.
 */

public class PowerButtonTriggerService extends Service {
    private PowerButtonTriggerReceiver powerButtonTriggerReceiver;
    @Override
    public void onCreate() {
        super.onCreate();
        Log.e(">>>>>>", "HardwareTriggerService CREATED.");
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        powerButtonTriggerReceiver = new PowerButtonTriggerReceiver();
        registerReceiver(powerButtonTriggerReceiver, filter);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e(">>>>>>", "HardwareTriggerService DESTROYED.");
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        unregisterReceiver(powerButtonTriggerReceiver);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

package net.abaqus.mygeotracking.deviceagent.utils;

import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.util.Base64;
import android.util.Log;
import android.util.Xml;

import net.abaqus.mygeotracking.deviceagent.notes.ImageAttachment;

import org.xmlpull.v1.XmlSerializer;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by bm on 14/9/15.
 */
public class HOSEntryConstruction {

    private static final String TAG = HOSEntryConstruction.class.getSimpleName();


    public static String constructHOSEntryBlock(Context mContext, String deviceNumber, String hosState, String time, Double latitude,
                                                Double longitude, String accuracy, String deviceMethod, String timeStampofLocation,
                                                String jobID, String workID,String customerID, String messageBody, String qrResult,
                                                String barcodeResult, String uuid, ArrayList<ImageAttachment> attachmentBlock, String formUID){

        XmlSerializer serializer;
        StringWriter writer;
            serializer = Xml.newSerializer();
            writer = new StringWriter();
            try{
                serializer.setOutput(writer);
                serializer.startDocument("UTF-8", true);
                serializer.startTag(null, "MGTRequest");

                serializer.startTag(null, "Device");

                serializer.startTag(null, "DeviceID");
                serializer.text(deviceNumber);
                serializer.endTag(null, "DeviceID");

                serializer.startTag(null, "HOSState");
                serializer.text(hosState);
                serializer.endTag(null, "HOSState");

                serializer.startTag(null, "Time");
                serializer.text(time);
                serializer.endTag(null, "Time");

                serializer.startTag(null, "Latitude");
                if(latitude == 1.0)
                    serializer.text("1");
                else
                    serializer.text(String.valueOf(latitude));
                serializer.endTag(null, "Latitude");
                serializer.startTag(null, "Longitude");
                if(longitude == 1.0)
                    serializer.text("1");
                else
                    serializer.text(String.valueOf(longitude));
                serializer.endTag(null, "Longitude");

                serializer.startTag(null, "Accuracy");
                serializer.text(accuracy);
                serializer.endTag(null, "Accuracy");

                serializer.startTag(null, "DeviceMethod");
                serializer.text(deviceMethod);
                serializer.endTag(null, "DeviceMethod");

                serializer.startTag(null, "LocationTimeStamp");
                serializer.text(timeStampofLocation);
                serializer.endTag(null, "LocationTimeStamp");

                    List<Address> addressArray = null;
                    try{
                        Geocoder geocoding = new Geocoder(mContext);
                        addressArray = geocoding.getFromLocation(
                                latitude,
                                longitude, 2);
                    }catch(Exception e){
                        e.printStackTrace();
                    }

                    if(addressArray != null && addressArray.size() > 0)
                    try {
                    if (addressArray.get(0).getAddressLine(0) != null) {
                        serializer.startTag(null, "AddressModel");
                        String addressLine = "";
                        for(int i = 0; i < addressArray.get(0).getMaxAddressLineIndex()+1; i++) {
                            if(addressLine.length() > 0)
                                addressLine = addressLine +", "+ addressArray.get(0).getAddressLine(i);
                            else
                                addressLine = addressLine + addressArray.get(0).getAddressLine(i);
                        }
                        serializer.text(addressLine);
                        serializer.endTag(null,"AddressModel");
                    }
                    if (addressArray.get(0).getLocality() != null) {
                        serializer.startTag(null, "City");
                        serializer.text(addressArray.get(0).getLocality());
                        serializer.endTag(null,"City");
                    }
                    if (addressArray.get(0).getFeatureName() != null) {
                        serializer.startTag(null, "Street");
                        serializer.text(addressArray.get(0).getFeatureName());
                        serializer.endTag(null,"Street");
                    }
                    if (addressArray.get(0).getAdminArea() != null) {
                        serializer.startTag(null, "State");
                        serializer.text(addressArray.get(0).getAdminArea());
                        serializer.endTag(null,"State");
                    }
                    if (addressArray.get(0).getCountryName() != null) {
                        serializer.startTag(null, "Country");
                        serializer.text(addressArray.get(0).getCountryName());
                        serializer.endTag(null,"Country");
                    }
                    if (addressArray.get(0).getPostalCode() != null){
                        serializer.startTag(null, "Zip");
                        serializer.text(addressArray.get(0).getPostalCode());
                        serializer.endTag(null,"Zip");
                    }
                } catch (Exception e) {
                        e.printStackTrace();
                }



                serializer.startTag(null, "JobID");
                serializer.text(jobID);
                serializer.endTag(null, "JobID");

                serializer.startTag(null, "WorkOrderID");
                serializer.text(workID);
                serializer.endTag(null, "WorkOrderID");

                serializer.startTag(null, "CustomerID");
                serializer.text(customerID);
                serializer.endTag(null, "CustomerID");

                if(messageBody.trim().length() > 0){
                    serializer.startTag(null, "Message");
                    serializer.text(messageBody);
                    serializer.endTag(null,"Message");
                }

                List<String> fdUIDList = Arrays.asList(formUID.split("\\|"));
                if(formUID != null && formUID.length() > 0) {
                    for (String tempfdUID : fdUIDList) {
                        serializer.startTag(null, "fdUID");
                        serializer.text(tempfdUID);
                        serializer.endTag(null, "fdUID");
                    }
                }


                List<String> items = Arrays.asList(qrResult.trim().split("\\|"));
                if(qrResult.trim().length() >= 1) {
                    serializer.startTag(null, "Tags");
                    for (String temp : items) {
                        serializer.startTag(null, "QR");
                        serializer.text(temp);
                        serializer.endTag(null, "QR");
                    }
                    serializer.endTag(null, "Tags");
                }

                if(attachmentBlock != null && attachmentBlock.size() > 0) {
                    serializer.startTag(null, "Attachments");
                    for (ImageAttachment imageAttachment : attachmentBlock) {
                        serializer.startTag(null, "Attachment");

                        serializer.startTag(null, "Id");
                        serializer.text(imageAttachment.getUniqueID());
                        serializer.endTag(null, "Id");

                        serializer.startTag(null, "Name");
                        serializer.text(imageAttachment.getName());
                        serializer.endTag(null, "Name");

                        serializer.startTag(null, "Size");
                        serializer.text(imageAttachment.getSize());
                        serializer.endTag(null, "Size");

                        serializer.startTag(null, "Type");
                        serializer.text(imageAttachment.getType());
                        serializer.endTag(null, "Type");

                        serializer.endTag(null, "Attachment");
                    }

                    serializer.endTag(null, "Attachments");
                }

                serializer.startTag(null, "UUID");
                serializer.text(uuid);
                serializer.endTag(null,"UUID");

                String versionName = "";
                String bundleid = "";
                try {
                    bundleid = mContext.getPackageManager()
                            .getPackageInfo(mContext.getPackageName(), 0).packageName;
                    versionName =mContext.getPackageManager()
                            .getPackageInfo(mContext.getPackageName(), 0).versionName;
                } catch (PackageManager.NameNotFoundException e) {
                    e.printStackTrace();
                }

                serializer.startTag(null, "AgentVersion");
                serializer.text(versionName);
                serializer.endTag(null,"AgentVersion");

                serializer.startTag(null, "BundleID");
                serializer.text(bundleid);
                serializer.endTag(null,"BundleID");

                serializer.startTag(null, "Platform");
                serializer.text("Android");
                serializer.endTag(null,"Platform");

                serializer.endTag(null,"Device");
                serializer.endTag(null,"MGTRequest");
                serializer.endDocument();
            }catch (Exception e) {
                DebugLog.debug(TAG, "REQUEST" + e.toString());
            }

               return writer.toString();


    }
}

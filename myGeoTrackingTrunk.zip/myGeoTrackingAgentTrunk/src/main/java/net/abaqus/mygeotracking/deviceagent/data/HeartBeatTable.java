package net.abaqus.mygeotracking.deviceagent.data;

import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

/**
 * Created by bm on 6/1/16.
 */
public class HeartBeatTable {



    private static final String TAG = "HEARTBEAT_ENTRY_TABLE";


    //The columns we'll include in the dictionary table
    public static final String COLUMN_ID = "_id";
    public static final String HEARTBEAT_ENTRY_XML = "heartbeat_entry_xml";
    public static final String HEARTBEAT_ENTRY_NO_OF_TRIES = "heartbeat_entry_no_of_tries";
    public static final String HEARTBEAT_ENTRY_TABLE = "heartbeatentrytable";

    // Database creation SQL statement
    private static final String HEARTBEAT_ENTRY_TABLE_CREATE = "create table "
            + HEARTBEAT_ENTRY_TABLE
            + "("
            + COLUMN_ID + " integer primary key autoincrement, "
            + HEARTBEAT_ENTRY_XML + " text null,"
            + HEARTBEAT_ENTRY_NO_OF_TRIES + " int not null,"
            + " text null"
            + ");";

    public static void onCreate(SQLiteDatabase database) {
        DebugLog.debug(TAG, "Creating database ");
        database.execSQL(HEARTBEAT_ENTRY_TABLE_CREATE);
    }

    public static void onUpgrade(SQLiteDatabase database, int oldVersion,
                                 int newVersion) {
        DebugLog.debug(TAG, "Upgrading database from version "
                + oldVersion + " to " + newVersion
                + ", which will destroy all old data");
        database.execSQL("DROP TABLE IF EXISTS " + HEARTBEAT_ENTRY_TABLE);
        onCreate(database);

    }

}

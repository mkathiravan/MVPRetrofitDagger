package net.abaqus.mygeotracking.deviceagent.updatechecker;

/**
 * Type of UpdateView used to alert, either Dialog or Notification.
 * Can set it with setUpdateViewType(UpdateViewType). 
 * Default is Notification. Presently No Dialog support added.
 * 
 */
public class UpdateViewType {
    public static final UpdateViewType NOTIFICATION = new UpdateViewType(0);
    //public static final UpdateViewType DIALOG = new UpdateViewType(1);

    int mViewType;

    public UpdateViewType(int type) {
        mViewType = type;
    }
}
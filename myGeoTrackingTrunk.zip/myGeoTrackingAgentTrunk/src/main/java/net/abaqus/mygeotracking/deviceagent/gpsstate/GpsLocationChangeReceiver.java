package net.abaqus.mygeotracking.deviceagent.gpsstate;

import net.abaqus.mygeotracking.deviceagent.bgthread.HeartBeatMonitorService;
import net.abaqus.mygeotracking.deviceagent.heartbeat.HeartBeat;
import net.abaqus.mygeotracking.deviceagent.heartbeat.TriggerSource;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.util.Log;


//TODO: Need to test and confirm in OREO. Whether we are able to get the broadcast properly or not

public class GpsLocationChangeReceiver extends BroadcastReceiver {
    private static String LOG_TAG = "Gps Listener MGT";
    private static int lastAction = 0;
    private int ENABLED = 1;
    private int DISABLED = 2;

    @Override
    public void onReceive(Context context, Intent intent) {
        LocationManager mlocManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);


        if (intent.getAction().matches("android.location.PROVIDERS_CHANGED")) {

            if (mlocManager.isProviderEnabled(LocationManager.GPS_PROVIDER) && lastAction == DISABLED || lastAction == 0) {
                lastAction = ENABLED;
                DebugLog.debug("GPS Provider Enabled");
            } else if (!mlocManager.isProviderEnabled(LocationManager.GPS_PROVIDER) && lastAction == ENABLED || lastAction == 0) {
                lastAction = DISABLED;
                DebugLog.debug("GPS Provider Disabled");
            }
            HeartBeat.getInstance().justOneBeat(context, TriggerSource.LOCATION_SETTINGS_CHANGED);
        }
    }


}
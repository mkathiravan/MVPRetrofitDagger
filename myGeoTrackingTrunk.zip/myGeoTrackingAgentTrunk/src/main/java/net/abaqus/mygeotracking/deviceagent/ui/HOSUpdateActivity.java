package net.abaqus.mygeotracking.deviceagent.ui;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.google.firebase.analytics.FirebaseAnalytics;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobRelationContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobRelationsTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSEntryTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSLabelsTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSLabelseContentProvider;
import net.abaqus.mygeotracking.deviceagent.hos.HOSEntry;
import net.abaqus.mygeotracking.deviceagent.notes.ImageAttachment;
import net.abaqus.mygeotracking.deviceagent.soshardware.ProcessSMS;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.FetchLocationForHOS;
import net.abaqus.mygeotracking.deviceagent.utils.HOSEntryConstruction;
import net.abaqus.mygeotracking.deviceagent.utils.HOSPullCalls;
import net.abaqus.mygeotracking.deviceagent.utils.HOSPushTask;
import net.abaqus.mygeotracking.deviceagent.utils.HOSStatesData;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;

import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HOSUpdateActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = HOSUpdateActivity.class.getSimpleName();
    final int CUS_TASK_INTENT_REQUEST_CODE = 1;
    ProgressDialog m_ProgressDialog;
    ScrollView scrollView_MainContent;
    LinearLayout linearLayout;
    Button hos_stages_name_button,
            hos_customer_clear_button, hos_job_clear_button;
    LinearLayout hos_stages_layout,
            hos_update_cj_customer_layout, hos_update_cj_job_layout;
    TextView hos_stages_status_text;
    EditText hos_update_cj_customer_text,
            hos_update_cj_job_text;
    View cj_update_selection_view;
    TextView hos_update_text;
    String QR_RESULT_TEXT, TYPED_MESSAGE, FORM_POST_DATA, FORM_FDUID,work_order_pos_id;
    ArrayList<ImageAttachment> ATTACHMENT_BLOCK;
    List<HOSEntry> hosEntryList;
    boolean IS_PUSHING_TO_DB;
    private Cursor hosValues;
    private SharedPreferences sh_prefs;
    private SharedPreferences.Editor edit_prefs;
    private View clickedView;

    private boolean URICheckinAvailable;
    private boolean URICheckinMatchesAvailable;
    private boolean URICheckinAlreadyOnSameStage;
    private String stageNameForURICheckin;

    private FirebaseAnalytics mFirebaseAnalytics;

    @SuppressLint("HandlerLeak")
    private Handler pullLabelsHandler = new Handler() {
        public void handleMessage(
                Message msg) {
            if (msg.what == 101108) {
                updateUIView();
            } else if (msg.what == 101109) {
                hos_update_text
                        .setVisibility(View.GONE);
                hos_update_cj_job_text.setText("");
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        if (hosValues == null)
            hosValues = fetchHOSData();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Cursor entryCursor = null;
        try {
            entryCursor = new HOSStatesData(HOSUpdateActivity.this).getHOSEntries();
        } catch (Exception e) {
        }

        if (entryCursor.getCount() > 0) {
            edit_prefs.putBoolean(MDACons.HOS_QUEUE_AVAILABLE, true);
        } else {
            edit_prefs.putBoolean(MDACons.HOS_QUEUE_AVAILABLE, false);
        }
        /*if(hosValues != null)
			hosValues.close();*/
        edit_prefs.commit();
        entryCursor.close();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        //setContentView(R.layout.hos_update);
        this.sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        mFirebaseAnalytics.setUserProperty("mgt_track_id", sh_prefs.getString(MDACons.DEVICE_GUID, ""));
        mFirebaseAnalytics.setCurrentScreen(this, "HOSActivity", null /* class override */);
        this.edit_prefs = sh_prefs.edit();
        hosEntryList = new ArrayList<HOSEntry>();
        assignScanValuesInitially();
        ActionBar actionBar = initActionBar();
        setPageTitle(actionBar);

        SharedPreferences sharedPreferences = getSharedPreferences(MDACons.PREFS, 0);
        work_order_pos_id = sharedPreferences.getString(MDACons.WORK_ORDER_POS_ID, "");

        try {
            Uri uri = getIntent().getData();
            String stageName = uri.getQueryParameter("s");
            DebugLog.debug(TAG, "URI Parameters : " + uri.getQueryParameter("s"));
            if(stageName != null && stageName.length() > 0) {
                URICheckinAvailable = true;
                stageNameForURICheckin = URLDecoder.decode(stageName, "UTF-8");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Check the device number availability before showing up the HOS View
        showHOSButtons();
        checkLocationPermission();
    }

    private void showHOSButtons() {
        if (!this.sh_prefs.getString(MDACons.DEVICE_NUMBER, "").equals("")) {
            scrollView_MainContent = new ScrollView(this);
            ScrollView.LayoutParams scrollLayoutParams = new ScrollView.LayoutParams(
                    LayoutParams.MATCH_PARENT,
                    LayoutParams.MATCH_PARENT);
            scrollLayoutParams.setMargins(0, 5, 0, 5);
            scrollView_MainContent.setLayoutParams(scrollLayoutParams);
            linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            scrollView_MainContent.addView(linearLayout);
            updateUIView();
            if (NetworkConnectionInfo.isOnline(this))
                new HOSPushTask(HOSUpdateActivity.this).execute();
        } else {
            finish();
            Toast.makeText(getApplicationContext(),
                    "Please register your device in settings",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void setPageTitle(ActionBar actionBar) {
        if (this.sh_prefs.getString(MDACons.HOS_GROUP_ID, "").equals("Mobile"))
            actionBar.setTitle("Time Clock");
        else
            actionBar.setTitle("Hours-Of-Service");
    }

    @NonNull
    private ActionBar initActionBar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        return actionBar;
    }

    private void assignScanValuesInitially() {
        QR_RESULT_TEXT = "";
        ATTACHMENT_BLOCK = new ArrayList<ImageAttachment>();
        TYPED_MESSAGE = "";
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.timeclocking_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            case R.id.action_timeclocking_refresh:
                if (NetworkConnectionInfo.isOnline(HOSUpdateActivity.this)) {
                    if (hos_update_text.getVisibility() != View.VISIBLE) {
                        HOSPullCalls.makeHOSInitializeCalls(HOSUpdateActivity.this, pullLabelsHandler);
                        Toast.makeText(HOSUpdateActivity.this, "Refreshing. Please wait.", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(HOSUpdateActivity.this, "Internet disconnected", Toast.LENGTH_SHORT).show();
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    private void updateUIView() {

        this.setContentView(R.layout.hos_update);
        hosValues = fetchHOSData();
        linearLayout.removeAllViews();
        m_ProgressDialog = new ProgressDialog(HOSUpdateActivity.this);
        m_ProgressDialog.setCancelable(true);

        // Updating text, while doing hos updates. this will be hidden and shown
        // when needed
        hos_update_text = new TextView(new ContextThemeWrapper(this, R.style.hosPageTitle));
        hos_update_text.setText("Updating...Please wait...");
        hos_update_text.setVisibility(View.GONE);
        linearLayout.addView(hos_update_text);

        // Setting up the view for Customer and Job selection
        LayoutInflater inflater = getLayoutInflater();
        cj_update_selection_view = inflater.inflate(R.layout.hos_update_cj_selection_view, linearLayout, false);
        linearLayout.addView(cj_update_selection_view);

        cj_update_selection_view.setVisibility(View.GONE);
        hos_update_cj_customer_text = (EditText) cj_update_selection_view.findViewById(R.id.hos_update_slect_customer);
        hos_update_cj_job_text = (EditText) cj_update_selection_view.findViewById(R.id.hos_update_slect_job);
        hos_customer_clear_button = (Button) cj_update_selection_view.findViewById(R.id.customer_clear_txt_button);
        hos_job_clear_button = (Button) cj_update_selection_view.findViewById(R.id.job_clear_txt_button);
        hos_update_cj_customer_layout = (LinearLayout) cj_update_selection_view.findViewById(R.id.hos_update_slect_customer_layout);
        hos_update_cj_job_layout = (LinearLayout) cj_update_selection_view.findViewById(R.id.hos_update_slect_job_layout);

        if (this.sh_prefs.getString(MDACons.HOS_CUSTOMER_SELECTED, "").length() > 0)
            hos_update_cj_customer_text.setText("Customer: " + this.sh_prefs.getString(MDACons.HOS_CUSTOMER_SELECTED, ""));

        if (hos_update_cj_customer_text.getText().length() >= 1)
            hos_update_cj_job_layout.setVisibility(View.VISIBLE);
        else
            hos_update_cj_job_layout.setVisibility(View.GONE);

        if (this.sh_prefs.getString(MDACons.HOS_JOB_SELECTED, "").length() > 0)
            hos_update_cj_job_text.setText("Job: " + this.sh_prefs.getString(MDACons.HOS_JOB_SELECTED, ""));

        hos_customer_clear_button.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                hos_update_cj_customer_text.setText("");
                SharedPreferences.Editor prefs_edit = sh_prefs.edit();
                prefs_edit.putString(MDACons.HOS_CUSTOMER_SELECTED, "");
                prefs_edit.commit();
                hos_update_cj_job_layout.setVisibility(View.GONE);

            }
        });

        hos_job_clear_button.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                hos_update_cj_job_text.setText("");
                SharedPreferences.Editor prefs_edit = sh_prefs.edit();
                prefs_edit.putString(MDACons.HOS_JOB_SELECTED, "");
                prefs_edit.commit();
            }
        });

        hos_update_cj_customer_layout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent hos_cj_listing_intent = new Intent(HOSUpdateActivity.this,
                        HOSCustomerJobListActivity.class);
                hos_cj_listing_intent.putExtra("which", "customer");
                startActivityForResult(hos_cj_listing_intent, CUS_TASK_INTENT_REQUEST_CODE);
            }
        });

        hos_update_cj_customer_text.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent hos_cj_listing_intent = new Intent(HOSUpdateActivity.this,
                        HOSCustomerJobListActivity.class);
                hos_cj_listing_intent.putExtra("which", "customer");
                startActivityForResult(hos_cj_listing_intent, CUS_TASK_INTENT_REQUEST_CODE);
            }
        });

        hos_update_cj_customer_text.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int inType = hos_update_cj_customer_text.getInputType(); // backup the input type
                hos_update_cj_customer_text.setInputType(InputType.TYPE_NULL); // disable
                // soft
                // input
                hos_update_cj_customer_text.onTouchEvent(event); // call native
                // handler
                hos_update_cj_customer_text.setInputType(inType); // restore
                // input
                // type

                return true; // consume touch even
            }
        });
        hos_update_cj_job_text.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int inType = hos_update_cj_job_text.getInputType(); // backup
                // the input
                // type
                hos_update_cj_job_text.setInputType(InputType.TYPE_NULL); // disable
                // soft
                // input
                hos_update_cj_job_text.onTouchEvent(event); // call native
                // handler
                hos_update_cj_job_text.setInputType(inType); // restore input
                // type

                return true; // consume touch even
            }
        });

        hos_update_cj_job_text.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent hos_cj_listing_intent = new Intent(HOSUpdateActivity.this,
                        HOSCustomerJobListActivity.class);
                hos_cj_listing_intent.putExtra("which", "job");
                hos_cj_listing_intent.putExtra("customer", getSelectedCustomerName());
                startActivityForResult(hos_cj_listing_intent, CUS_TASK_INTENT_REQUEST_CODE);
            }
        });

        hos_update_cj_job_layout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent hos_cj_listing_intent = new Intent(HOSUpdateActivity.this,
                        HOSCustomerJobListActivity.class);
                hos_cj_listing_intent.putExtra("which", "job");
                startActivityForResult(hos_cj_listing_intent, CUS_TASK_INTENT_REQUEST_CODE);
            }
        });


        Cursor jobcus = fetchCustomerAndJobID();


        if (!customerAvailability()) {
            //put something here
            if (jobcus.getCount() > 0)
                hos_update_cj_job_layout.setVisibility(View.VISIBLE);
            hos_update_cj_customer_layout.setVisibility(View.GONE);
        }


        // Following lines are responsible for showing up the HOS stages Buttons
        String hos_Selection = this.sh_prefs.getInt(MDACons.HOS_SELECTION, -1)
                + "";
        String time = "";
        SimpleDateFormat sdf = new java.text.SimpleDateFormat(
                "yyyy/MM/dd,HH:mm:ss", Locale.getDefault());
        clearAllToggle();
        if (hosValues != null) {

            for (int i = 0; i < hosValues.getCount(); i++) {
                hosValues.moveToPosition(i);
                try {

                } catch (NullPointerException e) {

                }

                hos_stages_name_button = new Button(this);
                hos_stages_name_button.setText("DynamicBtn");
                hos_stages_layout = new LinearLayout(this);

                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                hos_stages_layout.setOrientation(LinearLayout.VERTICAL);
                // hos_stages_layout.setBackgroundResource(R.drawable.btn_white_matte);
                hos_stages_layout.setBackgroundColor(Color.WHITE);
                layoutParams.setMargins(0, 0, 0, 0);
                hos_stages_layout.setGravity(Gravity.CENTER);
                hos_stages_layout.setPadding(0, 15, 0, 15);
                hos_stages_layout.setLayoutParams(layoutParams);

                hos_stages_status_text = new TextView(
                        new ContextThemeWrapper(this,
                                R.style.hosStatusTextView));
                hos_stages_status_text.setText("DynamicText");

                LayoutParams buttonLayoutParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                hos_stages_name_button.setTextColor(Color.BLACK);
                hos_stages_name_button.setGravity(Gravity.CENTER_VERTICAL);
                buttonLayoutParams.setMargins(3, 3, 3, 3);
                hos_stages_name_button.setTextSize(30.0f);
                hos_stages_name_button
                        .setBackgroundResource(android.R.color.transparent);

                hos_stages_name_button.setLayoutParams(buttonLayoutParams);

                DebugLog.debug(TAG, hos_Selection);
                if (hos_Selection
                        .equals(hosValues.getString(hosValues
                                .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL_VALUE)))) {
                    if(URICheckinAvailable && stageNameForURICheckin.equalsIgnoreCase(hosValues.getString(hosValues
                            .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL)))) {
                        URICheckinAlreadyOnSameStage = true;
                    }
                    hos_stages_status_text.setVisibility(View.VISIBLE);
                    try {
                        SimpleDateFormat formatter = new SimpleDateFormat(
                                "yyyy/MM/dd'T'HH:mm:ssZ",
                                Locale.getDefault());
                        Date date = (Date) formatter.parse(sh_prefs
                                .getString(MDACons.HOS_TIME, ""));
                        time = sdf.format(date).toString();
                    } catch (ParseException e) {

                        e.printStackTrace();
                    }
                    hos_stages_status_text.setText("" + time);
                    // hos_stages_layout.setBackgroundResource(R.drawable.btn_blue_matte);
                    hos_stages_layout.setBackgroundColor(Color
                            .parseColor("#00BFFF"));
                    hos_stages_name_button.setTextColor(Color.WHITE);
                    hos_stages_name_button.setEnabled(false);

                } else {
                    buttonLayoutParams = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT);
                    hos_stages_name_button.setTextColor(Color.BLACK);
                    hos_stages_name_button.setGravity(Gravity.CENTER);
                    hos_stages_layout.setGravity(Gravity.CENTER);
                    buttonLayoutParams.setMargins(3, 3, 3, 3);
                    hos_stages_name_button.setTextSize(30.0f);
                    hos_stages_name_button
                            .setBackgroundResource(android.R.color.transparent);

                    hos_stages_name_button
                            .setLayoutParams(buttonLayoutParams);
                    hos_stages_name_button.setEnabled(true);
                }

                hos_stages_name_button
                        .setTag(hosValues.getString(hosValues
                                .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL_VALUE)));
                hos_stages_name_button.setOnClickListener(this);

                hos_stages_name_button
                        .setText(hosValues.getString(hosValues
                                .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL)));

                hos_stages_layout.addView(hos_stages_name_button);
                hos_stages_layout.addView(hos_stages_status_text);

                View seperator_view = new View(this);
                LayoutParams seperator_layout_params = new LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 1);
                seperator_view.setLayoutParams(seperator_layout_params);
                seperator_view.setBackgroundColor(Color.LTGRAY);

                linearLayout.addView(seperator_view);
                linearLayout.addView(hos_stages_layout);
                if(URICheckinAvailable && stageNameForURICheckin.equalsIgnoreCase(hosValues.getString(hosValues
                        .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL)))) {
                    URICheckinMatchesAvailable = true;
                    hos_stages_name_button.performClick();
                    //return;
                }
            }
            if(!URICheckinMatchesAvailable) {
                URICheckinMatchesAvailable = false;
                URICheckinAvailable = false;
                URICheckinAlreadyOnSameStage = false;
            }
        }
        String[] relationsTableResult = getRelationsData();
        int argcount = relationsTableResult.length; // number of IN arguments

        if (jobcus.getCount() > 0) {
            cj_update_selection_view.setVisibility(View.VISIBLE);
        }


        if (argcount > 0)
            if (sh_prefs.getBoolean(MDACons.IS_JOB_SITE_MANDATORY, false) && relationsTableResult[0].equals("all") && jobcus.getCount() > 0) {
                hos_update_cj_job_layout.setVisibility(View.VISIBLE);
            }

        jobcus.close();


        if (!jobAvailability())
            hos_update_cj_job_layout.setVisibility(View.GONE);

        Animation mAnimation = AnimationUtils.loadAnimation(this,
                R.anim.bottom_to_top_animation);
        linearLayout.startAnimation(mAnimation);
        scrollView_MainContent.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        this.setContentView(scrollView_MainContent);
    }


    private String[] getRelationsData() {

        int i = 0;
        String[] projection = {
                HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID, HOSCustomerANDJobRelationsTable.HOS_CJ_REL_CUS_ID};
        Cursor cursor = this.getContentResolver().query(Uri.parse(HOSCustomerANDJobRelationContentProvider.CONTENT_URI.toString()), projection, null, null,
                null);
        String[] resultString = new String[cursor.getCount()];
        if (cursor != null) {
            while (cursor.moveToNext()) {
                try {
                    DebugLog.debug(TAG, cursor.getString(cursor
                            .getColumnIndexOrThrow(HOSCustomerANDJobRelationsTable.HOS_CJ_REL_CUS_ID)));

                    DebugLog.debug(TAG, cursor.getString(cursor
                            .getColumnIndexOrThrow(HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID)));
                    resultString[i] = cursor.getString(cursor
                            .getColumnIndexOrThrow(HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID));
                    i++;
                } catch (Exception e) {
                }
            }

        }
        cursor.close();
        return resultString;
    }


    private Cursor fetchCustomerAndJobID() {

        String[] projection =
                {HOSCustomerANDJobTable.HOS_CJ_ID,
                        HOSCustomerANDJobTable.HOS_CJ_REF_ID,
                        HOSCustomerANDJobTable.HOS_CJ_SOURCE_ID,
                        HOSCustomerANDJobTable.HOS_CJ_NAME,
                        HOSCustomerANDJobTable.HOS_CJ_STATUS,
                        HOSCustomerANDJobTable.HOS_CJ_WHICH};
        Cursor cursor = getContentResolver().query(
                Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI
                        .toString()), projection, null, null, null);
        if (cursor != null) {

            while (cursor.moveToNext()) {

                try {

                } catch (NullPointerException e) {

                }
            }

            // always close the cursor

        }
        return cursor;

    }

    private boolean customerAvailability() {

        String[] projection =
                {HOSCustomerANDJobTable.HOS_CJ_ID,
                        HOSCustomerANDJobTable.HOS_CJ_WHICH};
        Cursor cursor = this.getContentResolver().query(Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI.toString()), projection, HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ?", new String[]{"Customer"},
                HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.close();
                return true;
            } else {
                cursor.close();
                return false;
            }
        } else
            return false;

    }

    private boolean jobAvailability() {

        String[] projection =
                {HOSCustomerANDJobTable.HOS_CJ_ID,
                        HOSCustomerANDJobTable.HOS_CJ_WHICH};
        Cursor cursor = this.getContentResolver().query(Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI.toString()), projection, HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ?", new String[]{"Job"},
                HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");
        if (cursor != null) {
            if (cursor.getCount() > 0) {
                cursor.close();
                return true;
            } else {
                cursor.close();
                return false;
            }
        } else
            return false;

    }


    private Cursor fetchHOSData() {

        String[] projection =
                {HOSLabelsTable.HOS_LABEL, HOSLabelsTable.HOS_LABEL_VALUE, HOSLabelsTable.HOS_SMS_COMMAND};
        Cursor cursor = getContentResolver().query(
                Uri.parse(HOSLabelseContentProvider.CONTENT_URI.toString()),
                projection, null, null, null);
        if (cursor != null) {

            while (cursor.moveToNext()) {

                try {
                    DebugLog.debug(TAG,
                            cursor.getString(cursor
                                    .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL)));

                    DebugLog.debug(TAG,
                            cursor.getString(cursor
                                    .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL_VALUE)));
                } catch (NullPointerException e) {
                    // DebugLog.debug(TAG,("mgtagentempdb",e.toString());
                }
            }


        }
        return cursor;

    }

    public void clearAllToggle() {
    }

    @Override
    protected void onDestroy() {
        SharedPreferences.Editor prefs_edit = sh_prefs.edit();
        prefs_edit.putString(MDACons.HOS_JOB_SELECTED, "");
        prefs_edit.putString(MDACons.HOS_CUSTOMER_SELECTED, "");
        prefs_edit.putString(MDACons.HOS_JOB_SELECTED_ID, "");
        prefs_edit.putString(MDACons.HOS_CUSTOMER_SELECTED_ID, "");
        prefs_edit.commit();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
        hosValues.close();
    }

    @Override
    public void onClick(final View v) {
        //Dialog dialog = null;
        if (mandatoryConditionsPassed() || URICheckinAvailable) {
            if (URICheckinAvailable) {
                URICheckinAvailable = false;
                if(URICheckinAlreadyOnSameStage) {
                    URICheckinAlreadyOnSameStage = false;
                    new MaterialDialog.Builder(HOSUpdateActivity.this)
                            .title("TimeClock")
                            .content("Can't Change from '" + stageNameForURICheckin + "' to '" + stageNameForURICheckin + "' ?")
                            .negativeText("Ok")
                            .show();
                } else {
                    new MaterialDialog.Builder(HOSUpdateActivity.this)
                            .title("TimeClock")
                            .content("Change myGeoTracking status to '" + stageNameForURICheckin + "' ?")
                            .positiveText("Confirm")
                            .negativeText("Cancel")
                            .autoDismiss(true)
                            .onPositive(new MaterialDialog.SingleButtonCallback() {
                                @Override
                                public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                    startHOSConfirmActivity(v);
                                }
                            })
                            .show();
                }
            } else {
                startHOSConfirmActivity(v);
            }
        }
    }

    private void startHOSConfirmActivity(View v) {
        int positionToMove = 0;

        if (hosValues != null) {

            for (int i = 0; i < hosValues.getCount(); i++) {
                hosValues.moveToPosition(i);
                String coloumn = hosValues.getString(hosValues
                        .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL_VALUE));
                if (coloumn.equals(v.getTag().toString())) {
                    positionToMove = i;
                }
            }
        }
        hosValues.moveToPosition(positionToMove);
        String s = hosValues.getString(hosValues
                .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL));

        Intent hosConfirmIntent = new Intent(HOSUpdateActivity.this, HOSConfirmActivity.class);
        hosConfirmIntent.putExtra("stage", s);
        clickedView = v;

        startActivityForResult(hosConfirmIntent, 100);
    }


    private void HOSOkButtonClicked(View v) {



            String time = "";
            SimpleDateFormat sdf = null;

            try {
                sdf = new SimpleDateFormat("yyyy/MMM/dd,HH:mm:ss",
                        Locale.getDefault());
                time = CurrentDateAndTime.getDateTime(new SimpleDateFormat(
                        "yyyy/MM/dd'T'HH:mm:ssZ", Locale.getDefault()));
            } catch (Exception e) {
                e.printStackTrace();
            }
            // DebugLog.debug(TAG,("getTag", Integer.parseInt(v.getTag().toString()) + "");
            // DebugLog.debug(TAG,("getTag", v.getTag() + "");

            edit_prefs.putInt(MDACons.HOS_SELECTION,
                    Integer.parseInt(v.getTag().toString()));
            String s = hosValues.getString(hosValues
                    .getColumnIndexOrThrow(HOSLabelsTable.HOS_LABEL));
            edit_prefs.putString(MDACons.HOS_SELECTION_NAME,
                    s);
            String smsCommand = hosValues.getString(hosValues
                .getColumnIndexOrThrow(HOSLabelsTable.HOS_SMS_COMMAND));
            edit_prefs.putString(MDACons.HOS_SELECTION_SMS_COMMAND,
                    smsCommand);

            edit_prefs.putString(MDACons.HOS_TIME, time);
            edit_prefs.putString(MDACons.HOS_CUSTOMER_SELECTED_ID, "");
            edit_prefs.putString(MDACons.HOS_JOB_SELECTED_ID, "");
            edit_prefs.putString(MDACons.HOS_CUSTOMER_SELECTED_NEW, "");
            edit_prefs.putString(MDACons.HOS_JOB_SELECTED_NEW, "");
            edit_prefs.commit();
            getSelectedCustomerName();
            getSlectedJobName();

           	/*
           	 * DebugLog.debug(TAG,("CUSTOMERANDJOB",
           	 * this.prefs.getString(MDACons.HOS_CUSTOMER_SELECTED, ""));
           	 * DebugLog.debug(TAG,("CUSTOMERANDJOB", this.prefs.getString(MDACons.HOS_JOB_SELECTED,
           	 * ""));
           	 */
            updateUIView();

            try {
                SimpleDateFormat formatter = new SimpleDateFormat(
                        "yyyy/MM/dd'T'HH:mm:ssZ", Locale.getDefault());
                Date date = (Date) formatter.parse(sh_prefs.getString(
                        MDACons.HOS_TIME, ""));
                time = sdf.format(date).toString();
            } catch (ParseException e) {
                e.printStackTrace();
            }

            time = null;
            hos_update_text.setVisibility(View.VISIBLE);
            HOSEntry hosEntry = new HOSEntry();
            hosEntry.setDeviceId(this.sh_prefs.getString(MDACons.DEVICE_NUMBER, ""));
            hosEntry.setHos_value_to_push(""
                    + sh_prefs.getInt(MDACons.HOS_SELECTION, -1));
            hosEntry.setHos_desc_to_push(""
                    + sh_prefs.getString(MDACons.HOS_SELECTION_NAME, ""));
            hosEntry.setHos_sms_command_to_push(""
                    + sh_prefs.getString(MDACons.HOS_SELECTION_SMS_COMMAND, ""));
            hosEntry.setHos_time_to_push("" + sh_prefs.getString(MDACons.HOS_TIME, ""));
            hosEntry.setSelectedJobId(this.sh_prefs.getString(MDACons.HOS_JOB_SELECTED_ID, ""));
            hosEntry.setSelectedCustomerId(this.sh_prefs.getString(MDACons.HOS_CUSTOMER_SELECTED_ID, ""));
            hosEntry.setSelectedWorkOrderId(work_order_pos_id);
            hosEntry.setTypedMessageContent(TYPED_MESSAGE);
            hosEntry.setQrResultText(QR_RESULT_TEXT);
            hosEntry.setDeviceGUID(this.sh_prefs.getString(MDACons.DEVICE_GUID, ""));
            hosEntry.setAttachmentBlock(ATTACHMENT_BLOCK);
            hosEntry.setFormfdUID(FORM_FDUID);

            hosEntryList.add(hosEntry);
            getLocation(HOSUpdateActivity.this.getApplicationContext(),
                    myGeoTrackingDevieAgentApplication.AUTH_TOKEN, 500, 40);


    }

    private boolean mandatoryConditionsPassed() {


        if (hos_update_cj_customer_layout.getVisibility() == View.VISIBLE && customerAvailability() && sh_prefs.getBoolean(MDACons.IS_CUSTOMER_MANDATORY, false) && hos_update_cj_customer_text.getText().length() <= 0) {
            hos_update_cj_customer_text.setHint("Please select customer");
            hos_update_cj_customer_text.setHintTextColor(Color.RED);
            hos_update_cj_customer_text.setTypeface(null, Typeface.ITALIC);
            return false;
        }
        if (hos_update_cj_job_layout.getVisibility() == View.VISIBLE && jobAvailability() && sh_prefs.getBoolean(MDACons.IS_JOB_SITE_MANDATORY, false) && hos_update_cj_job_text.getText().length() <= 0) {
            hos_update_cj_job_text.setHint("Please select task");
            hos_update_cj_job_text.setHintTextColor(Color.RED);
            hos_update_cj_job_text.setTypeface(null, Typeface.ITALIC);
            return false;
        }

        return true;
    }


    private void getSlectedJobName() {
        if (hos_update_cj_job_text.getText().toString().replace("Job: ", "")
                .length() >= 1) {
            String[] projection_job =
                    {HOSCustomerANDJobTable.HOS_CJ_ID};
            Cursor job_cursor = getContentResolver().query(
                    Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI
                            .toString()),
                    projection_job,
                    HOSCustomerANDJobTable.HOS_CJ_NAME + " LIKE ?" + " AND " + HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ? ",
                    new String[]
                            {hos_update_cj_job_text.getText().toString()
                                    .replace("Job: ", ""), "Job"}, null);
            if (job_cursor != null) {

                while (job_cursor.moveToNext()) {
                    this.edit_prefs
                            .putString(MDACons.HOS_JOB_SELECTED_ID,
                                    job_cursor.getString(job_cursor
                                            .getColumnIndexOrThrow(HOSCustomerANDJobTable.HOS_CJ_ID)));

                }

            }

            if (job_cursor.getCount() == 0) {

                this.edit_prefs.putString(MDACons.HOS_JOB_SELECTED_NEW,
                        hos_update_cj_job_text.getText().toString()
                                .replace("Job: ", ""));

            }
            job_cursor.close();
        }

        this.edit_prefs.commit();
    }

    private String getSelectedCustomerName() {
        String returnString = "";
        if (hos_update_cj_customer_text.getText().toString()
                .replace("Customer: ", "").length() >= 1) {
            String[] projection =
                    {HOSCustomerANDJobTable.HOS_CJ_ID};
            Cursor customer_cursor = getContentResolver().query(
                    Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI
                            .toString()),
                    projection,
                    HOSCustomerANDJobTable.HOS_CJ_NAME + " LIKE ?" + " AND " + HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ? ",
                    new String[]
                            {hos_update_cj_customer_text.getText()
                                    .toString()
                                    .replace("Customer: ", ""), "Customer"}, null);
            if (customer_cursor != null) {

                while (customer_cursor.moveToNext()) {
                    returnString = customer_cursor
                            .getString(customer_cursor
                                    .getColumnIndexOrThrow(HOSCustomerANDJobTable.HOS_CJ_ID));
                    this.edit_prefs
                            .putString(MDACons.HOS_CUSTOMER_SELECTED_ID,
                                    returnString);

                }

            }

            if (customer_cursor.getCount() == 0) {

                this.edit_prefs.putString(MDACons.HOS_CUSTOMER_SELECTED_NEW,
                        hos_update_cj_customer_text.getText().toString()
                                .replace("Customer: ", ""));

            }
            customer_cursor.close();
        }
        this.edit_prefs.commit();

        return returnString;
    }

    private void pushHOSEntrytoDB() {

        // save data into database
        for(HOSEntry hosEntry : hosEntryList) {
            if(NetworkConnectionInfo.isOnline(HOSUpdateActivity.this) ||
                    hosEntry.getAttachmentBlock().size() > 0 ||
                    hosEntry.getFormfdUID().length() > 0 ||
                    hosEntry.getQrResultText().length() > 0 ||
                    hosEntry.getSelectedCustomerId().length() > 0 ||
                    hosEntry.getSelectedCustomerId().length() > 0 ||
                    hosEntry.getTypedMessageContent().length() > 0 ||
                    hosEntry.getHos_sms_command_to_push().trim().length() <= 0) {
                ContentValues initialValues = new ContentValues();
                initialValues.put(HOSEntryTable.HOS_ENTRY_XML,
                        HOSEntryConstruction.constructHOSEntryBlock(HOSUpdateActivity.this.getApplicationContext(), hosEntry.getDeviceId(),
                                hosEntry.getHos_value_to_push(), hosEntry.getHos_time_to_push(),
                                FetchLocationForHOS.getCurrentLatitude(), FetchLocationForHOS.getCurrentLongitude(), FetchLocationForHOS.getAccuracy(), FetchLocationForHOS.getDeviceMethod(),FetchLocationForHOS.getTimestampToSend(),
                                hosEntry.getSelectedJobId(), hosEntry.getSelectedWorkOrderId(),hosEntry.getSelectedCustomerId(), hosEntry.getTypedMessageContent(),
                                hosEntry.getQrResultText(), "", hosEntry.getDeviceGUID(), hosEntry.getAttachmentBlock(), hosEntry.getFormfdUID()));
                initialValues.put(HOSEntryTable.HOS_ENTRY_FORM_POST_DATA, FORM_POST_DATA);

                initialValues.put(HOSEntryTable.HOS_ENTRY_NO_OF_TRIES, 0);
                this.getContentResolver().insert(HOSEntryContentProvider.CONTENT_URI,
                        initialValues);
            } else {
                SharedPreferences sharedPreferences = getSharedPreferences(MDACons.PREFS, 0);
                String toPhoneNumber = sharedPreferences.getString(MDACons.TWILIO_SHORT_CODE, "+18032327769");
                String stageSMSCommand = hosEntry.getHos_sms_command_to_push();
                String stageDesc = hosEntry.getHos_desc_to_push();

                new ProcessSMS().sendNow(HOSUpdateActivity.this, toPhoneNumber, stageSMSCommand, hosEntry.getHos_value_to_push(), stageDesc);
            }
        }
        hosEntryList.clear();
        IS_PUSHING_TO_DB = false;
    }

    public void getLocation(Context ctx, String token, int accuracy,
                            int timeout) {
        Log.e("TAG", "on Get Location");
        try {
//            zdaService = ZDAClassFactory.getEventService(ctx);
//
//            zdaService.requestLocationShot(token, accuracy, timeout,
//                    new HOSLocationEventHandler());
        } catch (Exception e) {
            Log.e("TAG",
                    "Exception requesting location shot - "
                            + e.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        if (requestCode == CUS_TASK_INTENT_REQUEST_CODE) {
            String resulted_selection = data.getStringExtra("selected_which");
            if (!resulted_selection.equals("null") && resulted_selection != null)
                if (data.getStringExtra("which").equals("customer")) {
                    hos_update_cj_customer_text.setText("Customer: "
                            + resulted_selection);

                    this.edit_prefs.putString(MDACons.HOS_CUSTOMER_SELECTED,
                            resulted_selection);
                    if (jobAvailability())
                        hos_update_cj_job_layout.setVisibility(View.VISIBLE);
                    hos_update_cj_job_text.setText("");
                    SharedPreferences.Editor prefs_edit = sh_prefs.edit();
                    prefs_edit.putString(MDACons.HOS_JOB_SELECTED, "");
                    prefs_edit.commit();
                    hos_update_cj_customer_text.setHintTextColor(Color.GRAY);
                    hos_update_cj_customer_text.setTypeface(null, Typeface.NORMAL);
                } else if (data.getStringExtra("which").equals("job")) {
                    hos_update_cj_job_text.setText("Job: " + resulted_selection);
                    hos_update_cj_job_text.setHintTextColor(Color.GRAY);
                    hos_update_cj_job_text.setTypeface(null, Typeface.NORMAL);
                    this.edit_prefs.putString(MDACons.HOS_JOB_SELECTED,
                            resulted_selection);
                }
            this.edit_prefs.commit();
        } else if (requestCode == 100 && resultCode == RESULT_OK) {
            ATTACHMENT_BLOCK = data.getParcelableArrayListExtra("attach");
            QR_RESULT_TEXT = data.getStringExtra("scan").toString();
            TYPED_MESSAGE = data.getStringExtra("message").toString();
            FORM_POST_DATA = data.getStringExtra("form").toString();
            FORM_FDUID = data.getStringExtra("fdUID").toString();
            HOSOkButtonClicked(clickedView);
        } else if (requestCode == 100 && resultCode == RESULT_CANCELED) {
            URICheckinAlreadyOnSameStage = false;
            URICheckinAvailable = false;
            updateUIView();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void checkLocationPermission() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        1);
            }
        }
    }


}

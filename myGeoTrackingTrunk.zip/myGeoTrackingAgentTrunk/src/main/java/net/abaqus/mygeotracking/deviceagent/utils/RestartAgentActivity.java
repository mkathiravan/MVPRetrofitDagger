package net.abaqus.mygeotracking.deviceagent.utils;

import java.util.Calendar;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

public class RestartAgentActivity extends Activity{

    private static final String TAG = RestartAgentActivity.class.getSimpleName();


    public static AlarmManager mAlarmManager;
    public static PendingIntent mPintent;
    public static Intent mIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        DebugLog.debug(TAG, "Restart Activity oncreate");
        Context context = getApplicationContext();
        
        
        RestartAgentActivity.startAlarmManager(context);
    }

    public static void startAlarmManager(Context context){
    	
    	/*Intent intent = new Intent(context, RestartAgnetService.class);
        PendingIntent pi = PendingIntent.getService(context, 0, intent, 0);
        AlarmManager almmgr = (AlarmManager) context.getSystemService(ALARM_SERVICE);
        Calendar cldr = Calendar.getInstance();
        int min1 = cldr.get(Calendar.MINUTE);
        cldr.setTimeInMillis(System.currentTimeMillis());
        cldr.add(Calendar.SECOND, 3);
        almmgr.set(AlarmManager.RTC_WAKEUP, cldr.getTimeInMillis(), pi);*/
    	
    	SharedPreferences sh_prefs = context.getSharedPreferences(MDACons.PREFS, 0);
		
//
//    	if (sh_prefs.getBoolean(MDACons.AUTO_RELAUNCH_ENABLED_STATUS, true)){
//    		DebugLog.debug(TAG, "Restart Alarm Started");
//            RestartAgentActivity.mIntent = new Intent(context, myGeoTrackingAgentService.class);
//            mAlarmManager = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
//            mPintent = PendingIntent.getService(context, 0, RestartAgentActivity.mIntent, 0);
//            Calendar cal = Calendar.getInstance();
//            mAlarmManager.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), 70*10000, mPintent);
//		 }
    }
}
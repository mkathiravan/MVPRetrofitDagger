package net.abaqus.mygeotracking.deviceagent.enums;

/**
 * Created by root on 15/11/17.
 */

public enum InternetState {
    STATE_UNKNOWN,
    STATE_CONNECTED,
    STATE_DISCONNECTED
}

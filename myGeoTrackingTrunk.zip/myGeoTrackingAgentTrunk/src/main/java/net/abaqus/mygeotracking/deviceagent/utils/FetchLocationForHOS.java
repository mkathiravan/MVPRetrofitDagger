package net.abaqus.mygeotracking.deviceagent.utils;

import android.util.Log;

public class FetchLocationForHOS{

	private static final String TAG = FetchLocationForHOS.class.getSimpleName();
	//protected LocationManager locationManager;
	//protected LocationListener locationListener;
	//protected Context context;
	//TextView txtLat;
	//String lat;
	//String provider;
	
	static  Double latToSend=1.0;

	static Double lonToSend=1.0;

	static String deviceMethodToSend="";
	
	static String accuracyToSend="";
	 
	static String timestampToSend="";

	//protected boolean gps_enabled,network_enabled;
	//private static LocationClient mLocationClient;
	
	//private static Location mCurrentLocation;
	
	//private static String latitude, logitude;
	
	public static Double getCurrentLatitude()
	{
		
		return latToSend;
	}
	
	public static Double getCurrentLongitude()
	{
		return lonToSend;
	}
	
	public static String getAccuracy()
	{
		DebugLog.debug(TAG, accuracyToSend );
		return accuracyToSend;
		
	}
	
	public static String getDeviceMethod()
	{
		return deviceMethodToSend;
		
	}
	
	public static void setCurrentLatitude(Double value)
	{
		
		latToSend = value;
	}
	
	public static void setCurrentLongitude(Double value)
	{
		lonToSend = value;
	}
	
	public static void setAccuracy(String value)
	{
		accuracyToSend = value;
	}
	
	
	public static void setDeviceMethod(String value)
	{
		deviceMethodToSend = value;
	}

	public static String getTimestampToSend() {
		return timestampToSend;
	}

	public static void setTimestampToSend(String timestampToSend) {
		FetchLocationForHOS.timestampToSend = timestampToSend;
	}
}

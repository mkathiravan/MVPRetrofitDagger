package net.abaqus.mygeotracking.deviceagent.exception;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build;

public class AgentExceptionHandler implements
        java.lang.Thread.UncaughtExceptionHandler {
    private final Context myContext;
    private final String LINE_SEPARATOR = "\n";

    public AgentExceptionHandler(Context context) {
        myContext = context;
    }

    public void uncaughtException(Thread thread, Throwable exception) {
        StringWriter stackTrace = new StringWriter();
        exception.printStackTrace(new PrintWriter(stackTrace));
        StringBuilder errorReport = new StringBuilder();
        errorReport.append("************ CAUSE OF ERROR ************\n\n");
        errorReport.append(stackTrace.toString());

        errorReport.append("\n************ DEVICE INFORMATION ***********\n");
        errorReport.append("Brand: ");
        errorReport.append(Build.BRAND);
        errorReport.append(LINE_SEPARATOR);
        errorReport.append("Device: ");
        errorReport.append(Build.DEVICE);
        errorReport.append(LINE_SEPARATOR);
        errorReport.append("Model: ");
        errorReport.append(Build.MODEL);
        errorReport.append(LINE_SEPARATOR);
        errorReport.append("Id: ");
        errorReport.append(Build.ID);
        errorReport.append(LINE_SEPARATOR);
        errorReport.append("Product: ");
        errorReport.append(Build.PRODUCT);
        errorReport.append(LINE_SEPARATOR);
        errorReport.append("\n************ FIRMWARE ************\n");
        errorReport.append("SDK: ");
        errorReport.append(Build.VERSION.SDK);
        errorReport.append(LINE_SEPARATOR);
        errorReport.append("Release: ");
        errorReport.append(Build.VERSION.RELEASE);
        errorReport.append(LINE_SEPARATOR);
        errorReport.append("Incremental: ");
        errorReport.append(Build.VERSION.INCREMENTAL);
        errorReport.append(LINE_SEPARATOR);
        errorReport.append("\n************ APPLICATION DEVICE INFORMATION ************\n");
        SharedPreferences sh_prefs = myContext.getSharedPreferences(MDACons.PREFS, 0);
        
        errorReport.append("Device ID: ");
        errorReport.append(sh_prefs.getString(MDACons.DEVICE_NUMBER, ""));
        errorReport.append(LINE_SEPARATOR);

        errorReport.append("UUID: ");
        errorReport.append(sh_prefs.getString(MDACons.DEVICE_GUID, ""));
        errorReport.append(LINE_SEPARATOR);
        
        String versionName = "";
	String bundleid = "";
	try {
	bundleid = myContext.getPackageManager()
	.getPackageInfo(myContext.getPackageName(), 0).packageName;
	versionName =myContext.getPackageManager()
	.getPackageInfo(myContext.getPackageName(), 0).versionName;
	} catch (NameNotFoundException e) {
		e.printStackTrace();
	}
	
        errorReport.append("BUNDLE ID: ");
        errorReport.append(bundleid);
        errorReport.append(LINE_SEPARATOR);
        
        errorReport.append("APP VERSION: ");
        errorReport.append(versionName);
        errorReport.append(LINE_SEPARATOR);
        
        errorReport.append("PLATFORM: ");
        errorReport.append("Android");
        errorReport.append(LINE_SEPARATOR);
             
	new SendExceptionLogToServerTask(myContext).execute(errorReport.toString());
	final ScheduledExecutorService worker = 
		  Executors.newSingleThreadScheduledExecutor();
	Runnable task = new Runnable() {
	    public void run() {
		PendingIntent myActivity = PendingIntent.getActivity(myContext.getApplicationContext(),
	                192837, new Intent(myContext.getApplicationContext(), MDAMainActivity.class),
	                PendingIntent.FLAG_ONE_SHOT);

	            AlarmManager alarmManager;
	            alarmManager = (AlarmManager) myContext.getSystemService(Context.ALARM_SERVICE);
	            alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, 
	                10000, myActivity );
	           System.exit(2);
	    }
	};worker.schedule(task, 5, TimeUnit.SECONDS);
	
		
           
        
    }

    
   
    
}
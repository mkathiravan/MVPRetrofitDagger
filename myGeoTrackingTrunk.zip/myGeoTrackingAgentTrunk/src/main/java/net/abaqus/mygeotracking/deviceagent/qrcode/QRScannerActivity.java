package net.abaqus.mygeotracking.deviceagent.qrcode;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

public class QRScannerActivity extends Activity implements ZXingScannerView.ResultHandler {


	private static final String TAG = QRScannerActivity.class.getSimpleName();
	    private ZXingScannerView mScannerView;
	    private static final List<BarcodeFormat> FORMATS = new ArrayList<BarcodeFormat>();
		private static final int MY_PERMISSIONS_REQUEST_ACCESS_CAMERA = 1;
		public static final int RESULT_PERMISSION_DENIED = 101;

	    static {
	        FORMATS.add(BarcodeFormat.QR_CODE);
			FORMATS.add(BarcodeFormat.UPC_E);
			FORMATS.add(BarcodeFormat.AZTEC);
			FORMATS.add(BarcodeFormat.CODABAR);
			FORMATS.add(BarcodeFormat.CODE_128);
			FORMATS.add(BarcodeFormat.CODE_39);
			FORMATS.add(BarcodeFormat.CODE_93);
			FORMATS.add(BarcodeFormat.DATA_MATRIX);
			FORMATS.add(BarcodeFormat.EAN_13);
			FORMATS.add(BarcodeFormat.EAN_8);
			FORMATS.add(BarcodeFormat.ITF);
			FORMATS.add(BarcodeFormat.MAXICODE);
			FORMATS.add(BarcodeFormat.PDF_417);
			FORMATS.add(BarcodeFormat.RSS_14);
			FORMATS.add(BarcodeFormat.RSS_EXPANDED);
			FORMATS.add(BarcodeFormat.UPC_A);
			FORMATS.add(BarcodeFormat.UPC_EAN_EXTENSION);
		}


	    @Override
	    public void onCreate(Bundle state) {
	        super.onCreate(state);
	        mScannerView = new ZXingScannerView(this);
	        mScannerView.setFormats(FORMATS); // Programmatically initialize the scanner view
	        setContentView(mScannerView);                // Set the scanner view as the content view
	    }

	    @Override
	    public void onResume() {
	        super.onResume();
	        mScannerView.setResultHandler(this); // Register ourselves as a handler for scan results.
	        mScannerView.startCamera();          // Start camera on resume

	    }

	    @Override
	    public void onPause() {
	        super.onPause();
	        mScannerView.stopCamera();           // Stop camera on pause
	    }

	    @Override
	    public void handleResult(Result rawResult) {
	        // Do something with the result here
	        DebugLog.debug(TAG, rawResult.getText()); // Prints 	scan results
	        DebugLog.debug(TAG, rawResult.getBarcodeFormat().toString()); // Prints the scan format (qrcode, pdf417 etc.)
	        Intent resultIntent = new Intent();
	        resultIntent.putExtra("SCAN_RESULT", rawResult.getText());
	        resultIntent.putExtra("SCAN_RESULT_TIME", rawResult.getTimestamp());
	        resultIntent.putExtra("SCAN_RESULT_FORMAT", rawResult.getBarcodeFormat());    
	        
	     setResult(Activity.RESULT_OK, resultIntent);
	     finish();
	    }


	}
package net.abaqus.mygeotracking.deviceagent.data;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.search.MyObject;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by bm on 20/10/15.
 */
public class HOSCusJobSearchProvider {

    private static final String TAG = HOSCusJobSearchProvider.class.getSimpleName();

    // database
    private AgentDataBaseDBHelper database;

    public HOSCusJobSearchProvider(Context c)
    {
        database = new AgentDataBaseDBHelper(c);
    }

    public void close()
    {
        if(database != null)
        database.close();
    }

    public List<MyObject> readCustomer(String searchTerm) {

        List<MyObject> recordsList = new ArrayList<MyObject>();

        DebugLog.debug(TAG, searchTerm.contains("'") + "");
        DebugLog.debug(TAG, searchTerm.contains("\'")+"");


        // select query
        if (searchTerm.contains("'"));{

            searchTerm = searchTerm.replace("'","\\'");
        }

        DebugLog.debug(TAG, searchTerm);

        String sql = "";
        Cursor cursor;
        SQLiteDatabase db = database.getWritableDatabase();
        if (searchTerm.length() == 0){
            sql += "SELECT * FROM " + HOSCustomerANDJobTable.HOS_CJ_TABLE;
            sql += " WHERE " + HOSCustomerANDJobTable.HOS_CJ_WHICH +" LIKE ? ";
            // sql += "AND "+HOSCustomerANDJobTable.HOS_CJ_NAME + " LIKE ? ";
            sql += " ORDER BY " + HOSCustomerANDJobTable.COLUMN_ID + " DESC";
            sql += " LIMIT 0,5";
            cursor = db.rawQuery(sql, new String[] {"Customer"/*, "%" + searchTerm + "%"*/});

        }else{
            sql += "SELECT * FROM " + HOSCustomerANDJobTable.HOS_CJ_TABLE;
            sql += " WHERE " + HOSCustomerANDJobTable.HOS_CJ_WHICH +" LIKE ? ";
            sql += "AND "+HOSCustomerANDJobTable.HOS_CJ_NAME + " LIKE ? ";
            sql += " ORDER BY " + HOSCustomerANDJobTable.COLUMN_ID + " DESC";
            sql += " LIMIT 0,5";
            cursor = db.rawQuery(sql, new String[] {"Customer", "%" + searchTerm + "%"});

        }




        // execute the query

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {

                // int productId = Integer.parseInt(cursor.getString(cursor.getColumnIndex(fieldProductId)));
                String objectName = cursor.getString(cursor.getColumnIndex(HOSCustomerANDJobTable.HOS_CJ_NAME));
                MyObject myObject = new MyObject(objectName);

                // add to list
                recordsList.add(myObject);

            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        // return the list of records
        return recordsList;
    }

    public List<MyObject> readJobs(String searchTerm) {

        List<MyObject> recordsList = new ArrayList<MyObject>();
        DebugLog.debug(TAG, searchTerm.contains("'")+"");
        DebugLog.debug(TAG, searchTerm.contains("\'")+"");


        // select query
        if (searchTerm.contains("'"));{

            searchTerm = searchTerm.replace("'","\\'");
        }

        DebugLog.debug(TAG, searchTerm);

        String sql = "";
        SQLiteDatabase db = database.getWritableDatabase();
        Cursor cursor;

        if (searchTerm.length() == 0){
            sql += "SELECT * FROM " + HOSCustomerANDJobTable.HOS_CJ_TABLE;
            sql += " WHERE " + HOSCustomerANDJobTable.HOS_CJ_WHICH +" LIKE ? ";
            //sql += "AND "+HOSCustomerANDJobTable.HOS_CJ_NAME + " LIKE ? ";
            sql += " ORDER BY " + HOSCustomerANDJobTable.COLUMN_ID + " DESC";
            sql += " LIMIT 0,5";
            cursor = db.rawQuery(sql, new String[] {"Job"/*, "%" + searchTerm + "%"*/});
        }else{
            sql += "SELECT * FROM " + HOSCustomerANDJobTable.HOS_CJ_TABLE;
            sql += " WHERE " + HOSCustomerANDJobTable.HOS_CJ_WHICH +" LIKE ? ";
            sql += "AND "+HOSCustomerANDJobTable.HOS_CJ_NAME + " LIKE ? ";
            sql += " ORDER BY " + HOSCustomerANDJobTable.COLUMN_ID + " DESC";
            sql += " LIMIT 0,5";
            cursor = db.rawQuery(sql, new String[] {"Job", "%" + searchTerm + "%"});
        }

        // execute the query


        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {

                // int productId = Integer.parseInt(cursor.getString(cursor.getColumnIndex(fieldProductId)));
                String objectName = cursor.getString(cursor.getColumnIndex(HOSCustomerANDJobTable.HOS_CJ_NAME));
                MyObject myObject = new MyObject(objectName);

                // add to list
                recordsList.add(myObject);

            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        // return the list of records
        return recordsList;
    }



    public Cursor fetchCountriesByName(String inputText, String which) throws SQLException {
        Log.w("TAG", inputText);
        SQLiteDatabase mDb = database.getWritableDatabase();
        Cursor mCursor = null;
        if (inputText == null  ||  inputText.length () == 0)  {
            mCursor = mDb.query(HOSCustomerANDJobTable.HOS_CJ_TABLE, new String[] {
                            HOSCustomerANDJobTable.COLUMN_ID,HOSCustomerANDJobTable.HOS_CJ_NAME,HOSCustomerANDJobTable.HOS_CJ_SITE_ID, HOSCustomerANDJobTable.HOS_CJ_WHICH},
                    HOSCustomerANDJobTable.HOS_CJ_WHICH+" LIKE ?", new String[]{which}, null, null, HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");

        }
        else {
            mCursor = mDb.query(true, HOSCustomerANDJobTable.HOS_CJ_TABLE, new String[] {HOSCustomerANDJobTable.COLUMN_ID,HOSCustomerANDJobTable.HOS_CJ_SITE_ID,HOSCustomerANDJobTable.HOS_CJ_NAME,HOSCustomerANDJobTable.HOS_CJ_WHICH},
                    HOSCustomerANDJobTable.HOS_CJ_NAME + " like '%" + inputText + "%'" +" AND "+ HOSCustomerANDJobTable.HOS_CJ_WHICH+" LIKE '%"+which+"%'", null,
                    null, null, null, null);
        }
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }
}

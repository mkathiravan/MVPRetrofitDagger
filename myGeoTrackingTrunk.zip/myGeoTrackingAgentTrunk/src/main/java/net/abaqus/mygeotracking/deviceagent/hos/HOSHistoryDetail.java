package net.abaqus.mygeotracking.deviceagent.hos;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by user on 22-06-2018.
 */

public class HOSHistoryDetail {

    public HOSHistoryDetail(String stageTime, String stageId, String stageDesc, String serviceHour, String textNotesParam, String addressParam) {
        StageTime = stageTime;
        StageId = stageId;
        StageDesc = stageDesc;
        ServiceHour = serviceHour;
        textNotes = textNotesParam;
        address = addressParam;
    }

    public HOSHistoryDetail() {
    }

    public String getStageTime() {
        return StageTime;
    }

    public void setStageTime(String stageTime) {
        StageTime = stageTime;
    }

    public String getStageId() {
        return StageId;
    }

    public void setStageId(String stageId) {
        StageId = stageId;
    }

    public String getStageDesc() {
        return StageDesc;
    }

    public void setStageDesc(String stageDesc) {
        StageDesc = stageDesc;
    }

    public String getServiceHour() {
        return ServiceHour;
    }

    public void setServiceHour(String serviceHour) {
        ServiceHour = serviceHour;
    }

    @SerializedName("StageTime")
    String StageTime = "";
    @SerializedName("StageId")
    String StageId = "";
    @SerializedName("StageDesc")
    String StageDesc = "";
    @SerializedName("ServiceHour")
    String ServiceHour = "00:00";
    @SerializedName("textNotes")
    String textNotes = "";
    @SerializedName("address")
    String address = "";

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }



    public String getTextNotes() {
        return textNotes;
    }

    public void setTextNotes(String textNotesParam) {
        textNotes = textNotesParam;
    }


    public List<ScanNotes> getScanNotes() {
        return scanNotes;
    }

    public void setScanNotes(List<ScanNotes> scanNotes) {
        this.scanNotes = scanNotes;
    }

    @SerializedName("scanNotes")
    List<ScanNotes> scanNotes;


}

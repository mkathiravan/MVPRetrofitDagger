package net.abaqus.mygeotracking.deviceagent.hos;

import com.google.gson.annotations.SerializedName;

public class Total {

    @SerializedName("weeklyDistance")
    String weeklyDistance;

    @SerializedName("weeklyHrs")
    String weeklyHrs;

    @SerializedName("dailyDistance")
    String dailyDistance;

    @SerializedName("dailyHrs")
    String dailyHrs;

    public String getWeeklyDistance() {
        return weeklyDistance;
    }

    public void setWeeklyDistance(String weeklyDistance) {
        this.weeklyDistance = weeklyDistance;
    }

    public String getWeeklyHrs() {
        return weeklyHrs;
    }

    public void setWeeklyHrs(String weeklyHrs) {
        this.weeklyHrs = weeklyHrs;
    }

    public String getDailyDistance() {
        return dailyDistance;
    }

    public void setDailyDistance(String dailyDistance) {
        this.dailyDistance = dailyDistance;
    }

    public String getDailyHrs() {
        return dailyHrs;
    }

    public void setDailyHrs(String dailyHrs) {
        this.dailyHrs = dailyHrs;
    }


}

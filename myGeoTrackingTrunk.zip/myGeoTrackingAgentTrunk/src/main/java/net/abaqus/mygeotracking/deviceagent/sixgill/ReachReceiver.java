package net.abaqus.mygeotracking.deviceagent.sixgill;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Base64;
import android.util.Log;
import com.sixgill.protobuf.Ingress;
import com.sixgill.sync.sdk.Reach;

import java.util.List;


public class ReachReceiver

{

    private static final String TAG = ReachReceiver.class.getSimpleName();
    LocalBroadcastManager lBroadReceiver;
    Context context;
    EventResponse eventResponse;
    LocationCall locationCall;
    private static ReachReceiver mReachReceiver;

    public static ReachReceiver getInstance(Context context){
        if(mReachReceiver == null){
            mReachReceiver = new ReachReceiver(context);
        }
        return mReachReceiver;
    }
    private ReachReceiver(Context context)
    {
        this.context = context;

    }

    public void registerReachReceiver()
    {

        lBroadReceiver = LocalBroadcastManager.getInstance(context);
        locationCall=(LocationCall)context.getApplicationContext();
        lBroadReceiver.registerReceiver(mReceiver, new IntentFilter(Reach.EVENT_BROADCAST));
        Log.d(TAG,"CONTXT "+context + "LBRODAD "+lBroadReceiver) ;
    }

    public void unregisterReachReceiver()
    {
        lBroadReceiver.unregisterReceiver(mReceiver);
    }

    ExamRece mReceiver=new ExamRece();

    class ExamRece extends BroadcastReceiver
    {
        ExamRece()
        {
            Log.wtf(TAG,"EXAMRACECONSTRE B");
        }
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        public void onReceive(Context context, Intent intent) {

            Log.d(TAG,"ONRECEIVECALLED "+context + "INTEM "+intent);

            Bundle bundle = intent.getExtras();
            Log.d(TAG,"BNDKEVALD "+bundle);
            if(bundle != null)
            {
                String encodedEvent = bundle.getString(Reach.EVENT_DATA);
                Log.d(TAG,"ENCODEDEVNT "+encodedEvent);
                if (encodedEvent != null) {
                    byte[] b = Base64.decode(encodedEvent, Base64.DEFAULT);
                    Ingress.Event event = Ingress.Event.parseFrom(b);
                    event.getErrorCount();
                    List<Ingress.Error> errors = event.getErrorList();
                    Log.d(TAG,"ERRORCNSTSZE "+errors.size() + " WRRCNT "+event.getErrorCount());
                    if(errors.size() > 0)
                    {
                        int error_code = errors.get(0).getErrorCode();
                        switch(error_code)
                        {
                            case 1:
                                Log.d(TAG,"Activity Permission Missing");
                                break;
                            case 4:
                                Log.d(TAG,"Location permission is not enabled");
                                break;
                            case 6:
                                Log.d(TAG,"Wifi permission is not enabled");
                                break;
                            case 7:
                                Log.d(TAG,"Beacon permission is not enabled");
                                break;
                            default:
                                break;

                        }
                    }


                    eventResponse = EventResponse.getInstance(context.getApplicationContext());
                    eventResponse.eventDataResponse(event);

                    if(event.getLocationsList().size() > 0)
                    {
                        Ingress.Location location = event.getLocations(event.getLocationsList().size() - 1);
                        locationCall.getLocationValue(location);
                    }
                    Log.d(TAG, "SIXGILLEVENDATA " + event);
                    Log.d(TAG, "SIXGILLBYTEARRA " + b);


                    }




                }
            }
        }
    }



package net.abaqus.mygeotracking.deviceagent.myteam;

import android.media.Image;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.SearchView.OnQueryTextListener;
import android.support.v4.view.MenuItemCompat;
import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.data.MyTeamSearchProvider;

import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.support.v7.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by root on 6/1/17.
 */

public class MyTeamRedesignActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private ListViewAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private List<MyTeamData> myTeamList;
    private Toolbar toolbar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myteam_redesign);
        myTeamList = new ArrayList<>();
        getMyTeamData();

/*
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
*/

        mRecyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        mAdapter = new ListViewAdapter();
        mRecyclerView.setAdapter(mAdapter);
    }


    private void getMyTeamData() {
        MyTeamSearchProvider myTeamDBHelper = new MyTeamSearchProvider(this);
        myTeamList = myTeamDBHelper.readMyTeamData("");
        myTeamDBHelper.close();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.myteam_menu_redesign, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        searchView.setOnQueryTextListener(new OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // perform query here

                // workaround to avoid issues with some emulators and keyboard devices firing twice if a keyboard enter is used
                // see https://code.google.com/p/android/issues/detail?id=24599
                searchView.clearFocus();

                return true;
            }
            int QUERY_LENGTH = 0;
            @Override
            public boolean onQueryTextChange(String query) {
                if(query.length() <= QUERY_LENGTH)
                {
                    myTeamList.clear();
                    getMyTeamData();
                    mAdapter.notifyDataSetChanged();
                }
                final List<MyTeamData> filteredModelList = filter(myTeamList, query);
                mAdapter.animateTo(filteredModelList);
                mRecyclerView.scrollToPosition(0);

                QUERY_LENGTH = query.length();

                if(QUERY_LENGTH <= 0)
                    mAdapter.notifyDataSetChanged();
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }


    private List<MyTeamData> filter(List<MyTeamData> models, String query) {
        query = query.toLowerCase();

        final List<MyTeamData> filteredModelList = new ArrayList<>();
        for (MyTeamData model : models) {
            final String text = model.getDeviceDescription();
            if (text.contains(query)) {
                filteredModelList.add(model);
            }
        }
        return filteredModelList;
    }

    public class ListViewAdapter extends RecyclerView.Adapter<ListViewAdapter.ViewHolder> {


        public void animateTo(List<MyTeamData> models) {
            applyAndAnimateRemovals(models);
            applyAndAnimateAdditions(models);
            applyAndAnimateMovedItems(models);
        }

        private void applyAndAnimateRemovals(List<MyTeamData> newModels) {
            for (int i = myTeamList.size() - 1; i >= 0; i--) {
                final MyTeamData model = myTeamList.get(i);
                if (!newModels.contains(model)) {
                    removeItem(i);
                }
            }
        }

        private void applyAndAnimateAdditions(List<MyTeamData> newModels) {
            for (int i = 0, count = newModels.size(); i < count; i++) {
                final MyTeamData model = newModels.get(i);
                if (!myTeamList.contains(model)) {
                    addItem(i, model);
                }
            }
        }

        private void applyAndAnimateMovedItems(List<MyTeamData> newModels) {
            for (int toPosition = newModels.size() - 1; toPosition >= 0; toPosition--) {
                final MyTeamData model = newModels.get(toPosition);
                final int fromPosition = myTeamList.indexOf(model);
                if (fromPosition >= 0 && fromPosition != toPosition) {
                    moveItem(fromPosition, toPosition);
                }
            }
        }

        public MyTeamData removeItem(int position) {
            final MyTeamData model = myTeamList.remove(position);
            notifyItemRemoved(position);
            return model;
        }

        public void addItem(int position, MyTeamData model) {
            myTeamList.add(position, model);
            notifyItemInserted(position);
        }

        public void moveItem(int fromPosition, int toPosition) {
            final MyTeamData model = myTeamList.remove(fromPosition);
            myTeamList.add(toPosition, model);
            notifyItemMoved(fromPosition, toPosition);
        }


        public class ViewHolder extends RecyclerView.ViewHolder {
            // each data item is just a string in this case
            private TextView tvDescription;
            private TextView tvDeviceNumber;
            private TextView tvTimeClockStatus;
            private TextView tvAddressLine;
            private TextView tvUpdatedTime;

            private ImageView ivMessageAction;
            private ImageView ivViewOnMapAction;
            private ImageView ivSelectedIndicator;

            private ViewHolder(View itemView) {
                super(itemView);
                tvDescription = (TextView) itemView.findViewById(R.id.tvDescription);
                tvDeviceNumber = (TextView) itemView.findViewById(R.id.tvDeviceNumber);
                tvTimeClockStatus = (TextView) itemView.findViewById(R.id.tvTimeClockStatus);
                tvAddressLine = (TextView) itemView.findViewById(R.id.tvAddressLine);
                tvUpdatedTime = (TextView) itemView.findViewById(R.id.tvUpdatedTime);

                ivMessageAction = (ImageView) itemView.findViewById(R.id.ivMessageAction);
                ivViewOnMapAction = (ImageView) itemView.findViewById(R.id.ivViewOnMapAction);
                ivSelectedIndicator = (ImageView) itemView.findViewById(R.id.ivSelectedIndicator);
            }
        }


        // Create new views (invoked by the layout manager)
        @Override
        public ListViewAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                             int viewType) {
            // create a new view
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.myteam_list_item_redesign, parent, false);
            ViewHolder vh = new ViewHolder(v);
            return vh;
        }

        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            // - get element from your dataset at this position
            // - replace the contents of the view with that element
            holder.tvDescription.setText(myTeamList.get(position).getDeviceDescription());
            holder.tvDeviceNumber.setText(myTeamList.get(position).getDeviceNumber());
            holder.tvAddressLine.setText(myTeamList.get(position).getAddressString());
            holder.tvUpdatedTime.setText(myTeamList.get(position).getUpdatedTime());
            holder.tvTimeClockStatus.setText(myTeamList.get(position).getLastHosStage());

            if (myTeamList.get(position).getLastHosStage().trim().length() <= 0) {
                holder.tvTimeClockStatus.setText("");
                holder.tvTimeClockStatus.setVisibility(View.GONE);
            } else {
                holder.tvTimeClockStatus.setVisibility(View.VISIBLE);
            }
        }

        // Return the size of your dataset (invoked by the layout manager)
        @Override
        public int getItemCount() {
            return myTeamList.size();
        }
    }
}

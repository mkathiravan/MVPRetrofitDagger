package net.abaqus.mygeotracking.deviceagent.ui;


import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.Toast;
import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.welcome.WelcomeActivity;

import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;


// implemented by ASHISH.

public class TrialAccountSignUp extends AppCompatActivity {

    private static final String TAG = TrialAccountSignUp.class.getSimpleName();

    @BindView(R.id.webview)
    WebView myWebView;
    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    String getPhoneNumber;
    SharedPreferences sp;
    String UserPhoneNumber;
    SharedPreferences.Editor edtitorEditor;
    long delayInMillis = 1500;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trial_account_sign_up);
        ButterKnife.bind(this);


        //progressBar=findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);


       // myWebView = (WebView) findViewById(R.id.webview);
        myWebView.setWebChromeClient(new YourWebChromeClient());
        myWebView.getSettings().setJavaScriptEnabled(true);
//   WebSettings webSettings = myWebView.getSettings();





//        Timer timer = new Timer();
//        timer.schedule(new TimerTask() {
//            @Override
//            public void run() {
//                progressBar.setVisibility(View.GONE);
//            }
//        }, delayInMillis);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                progressBar.setVisibility(View.GONE);
            }
        },delayInMillis);


        myWebView.loadUrl("https://www.mygeotracking.com/mobile-app-signup");

        sp = getSharedPreferences("Key", Activity.MODE_PRIVATE);
        edtitorEditor = sp.edit();


    }



    final class YourWebChromeClient extends WebChromeClient {
        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
            Log.d(TAG,"RECEIVEDTITLE "+title);
        }

        @Override
        public boolean onJsAlert(WebView view, String url, final String message, JsResult result) {


           Log.d(TAG, "RESPONSE_MESSAGE "+message);


           if(!message.contains("PhoneNumber") && !message.contains("Register your Device"))
           {
               Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
           }


            //Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();

           if(message.contains("PhoneNumber"))
           {
               new Handler().postDelayed(new Runnable() {
                   @Override
                   public void run() {
                       getPhoneNumber=message.toString();
                       String[] part = getPhoneNumber.split("(?<=\\D)(?=\\d)");
                       System.out.println("Check text"+part[1]);
                       UserPhoneNumber= part[1];
                       edtitorEditor.putString(MDACons.GET_ACCOUNT_LEVEL_PHONE_NO,UserPhoneNumber);
                       edtitorEditor.commit();

                       Intent intent = new Intent(TrialAccountSignUp.this, WelcomeActivity.class);
                       startActivity(intent);

                   }
               },5000);


           }

            result.confirm();
            return true;
        }
    }


}

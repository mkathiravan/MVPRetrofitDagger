package net.abaqus.mygeotracking.deviceagent.utils;

import android.content.Context;
import android.telephony.TelephonyManager;

import net.abaqus.mygeotracking.deviceagent.R;

public class FetchDeviceNumber {
	
	
	private Context mContext;
	public FetchDeviceNumber(Context mContext) {
		this.mContext = mContext;
	}
	
	public String getPhoneNumber() {
		String userId;
		String country_code_removed = "";
		TelephonyManager telephonyMgr = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
			try {
				userId = telephonyMgr.getLine1Number();
				country_code_removed = userId;
				/*if(userId.contains("+") || userId.startsWith("1")){
					if(userId.startsWith("1") && userId.length() >= 10)
					{
						country_code_removed = userId.replaceFirst("1", "");
					}else if(userId.startsWith("+") && userId.length() >= 10)
					{
						country_code_removed = userId.replaceFirst("+", "");
					}
					else
					{
						country_code_removed = userId.replace("+1", "");
					}
				}*/
				country_code_removed = country_code_removed.replace("+", "");
				if(country_code_removed.length() > 10)
					country_code_removed = country_code_removed.substring(country_code_removed.length() - 10);
			} catch (Exception e) {
				e.printStackTrace();
			}
        return country_code_removed;
	}


	public String getCountryCallingCode() {
		String CountryID="";
		String CountryZipCode="";
		TelephonyManager manager = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
		//getNetworkCountryIso
		CountryID = manager.getSimCountryIso().toUpperCase();
		String[] rl = mContext.getResources().getStringArray(R.array.CountryCodes);
		for(int i=0;i<rl.length;i++){
			String[] g=rl[i].split(",");
			if(g[1].trim().equals(CountryID.trim())){
				CountryZipCode=g[0];
				break;
			}
		}
		return CountryZipCode;
	}
}
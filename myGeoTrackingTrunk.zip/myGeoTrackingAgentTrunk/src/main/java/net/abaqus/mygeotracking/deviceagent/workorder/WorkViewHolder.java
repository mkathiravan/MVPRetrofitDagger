package net.abaqus.mygeotracking.deviceagent.workorder;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.thoughtbot.expandablerecyclerview.listeners.OnGroupClickListener;
import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;
import com.thoughtbot.expandablerecyclerview.viewholders.GroupViewHolder;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static android.view.animation.Animation.RELATIVE_TO_SELF;

public class WorkViewHolder extends GroupViewHolder {

    private TextView genreName,jobsiteName,startTimeValue;
    private ImageView arrow;



    public WorkViewHolder(View itemView) {
        super(itemView);
        genreName = (TextView)itemView.findViewById(R.id.work_order_number);
        arrow = (ImageView)itemView.findViewById(R.id.list_item_form_arrow);
        jobsiteName = (TextView)itemView.findViewById(R.id.job_site_value);
        startTimeValue = (TextView)itemView.findViewById(R.id.startTimeValue);

    }

    public void setGenreTitle(ExpandableGroup genre, final Context context, final int position)
    {

        if(genre instanceof Genre)
        {

            genreName.setText(((Genre) genre).getWorkOrderNumber());



            //Prepare and display stage actual time
            Date startDate = new Date(((Genre) genre).getStartTime());
            DateFormat df = new SimpleDateFormat("yyyy/MM/dd, hh:mm:ss");


            //Prepare and display sinceTime
            SimpleDateFormat inFormat = new SimpleDateFormat("hh:mm a");
            SimpleDateFormat onFormat = new SimpleDateFormat("MMM d, yyyy", Locale.ENGLISH);
            String sinceTime = inFormat.format(startDate);
            String onDate = onFormat.format(startDate);
            String startDayAndTime = sinceTime + " on " + onDate;

            startTimeValue.setText(startDayAndTime);
            jobsiteName.setText(((Genre) genre).getJobSite());

            }
    }


    public void setWorkOrderStatus(String name)
    {
        jobsiteName.setText(name);
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
    }

    @Override
    public void setOnGroupClickListener(OnGroupClickListener listener) {
        super.setOnGroupClickListener(listener);
    }

    @Override
    public void expand() {
        animateExpand();
    }

    @Override
    public void collapse() {
        animateCollapse();
    }

    private void animateExpand() {
        RotateAnimation rotate =
                new RotateAnimation(360, 180, RELATIVE_TO_SELF, 0.5f, RELATIVE_TO_SELF, 0.5f);
        rotate.setDuration(300);
        rotate.setFillAfter(true);
        arrow.setAnimation(rotate);
    }

    private void animateCollapse() {
        RotateAnimation rotate =
                new RotateAnimation(180, 360, RELATIVE_TO_SELF, 0.5f, RELATIVE_TO_SELF, 0.5f);
        rotate.setDuration(300);
        rotate.setFillAfter(true);
        arrow.setAnimation(rotate);
    }
}

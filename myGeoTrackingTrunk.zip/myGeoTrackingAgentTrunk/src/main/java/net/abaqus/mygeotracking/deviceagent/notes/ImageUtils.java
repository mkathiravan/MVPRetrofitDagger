package net.abaqus.mygeotracking.deviceagent.notes;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Typeface;

import net.abaqus.mygeotracking.deviceagent.R;

/**
 * Created by Badari Mandyam on 31/8/16.
 */
public class ImageUtils {

    public static Bitmap waterMarkIt(Context mContext, Bitmap src, String watermark, Point location, int color, int alpha, int size, boolean underline) {
        int w = src.getWidth();
        int h = src.getHeight();
        Bitmap result = Bitmap.createBitmap(w, h, src.getConfig());

        Canvas canvas = new Canvas(result);
        canvas.drawBitmap(src, 0, 0, null);

        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        //paint.setAlpha(alpha);
        paint.setTextSize(size);
        paint.setFakeBoldText(true);
        paint.setAntiAlias(true);
        paint.setUnderlineText(underline);
        canvas.drawText(watermark, location.x, location.y, paint);
        paint.setColor(Color.LTGRAY);
        paint.setAlpha(50);
        canvas.drawRect(0, src.getHeight()-55, src.getWidth(), src.getHeight()-30,paint);
        return result;
    }

    public static Bitmap waterMarkItLite(Context mContext, Bitmap src, String watermark, Point location, int color, int alpha, int size, boolean underline) {
        int w = src.getWidth();
        int h = src.getHeight();
        Bitmap result = Bitmap.createBitmap(w, h, src.getConfig());

        Canvas canvas = new Canvas(result);
        canvas.drawBitmap(src, 0, 0, null);

        Paint paint = new Paint();
        paint.setColor(color);
        paint.setAlpha(alpha);
        paint.setTextSize(size);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setFakeBoldText(true);
        paint.setAntiAlias(true);
        paint.setUnderlineText(underline);
        canvas.drawText(watermark, location.x, location.y, paint);
        return result;
    }
}

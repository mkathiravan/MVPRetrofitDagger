
package net.abaqus.mygeotracking.deviceagent.notes;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;
import android.location.Address;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AlertDialog;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.activeandroid.query.Select;
import com.afollestad.materialdialogs.MaterialDialog;
import com.drew.imaging.ImageMetadataReader;
import com.drew.metadata.Metadata;
import com.drew.metadata.exif.ExifSubIFDDirectory;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.kbeanie.multipicker.api.CameraImagePicker;
import com.kbeanie.multipicker.api.ImagePicker;
import com.kbeanie.multipicker.api.Picker;
import com.kbeanie.multipicker.api.callbacks.ImagePickerCallback;
import com.kbeanie.multipicker.api.entity.ChosenImage;
import com.sixgill.protobuf.Ingress;
import com.sixgill.sync.sdk.Reach;
import com.sixgill.sync.sdk.ReachLocationCallback;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsAttachmentSource;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsCons;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsEvent;
import net.abaqus.mygeotracking.deviceagent.analytics.AnalyticsKey;
import net.abaqus.mygeotracking.deviceagent.bgthread.AttachmentPushTask;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobRelationContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobRelationsTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobTable;
import net.abaqus.mygeotracking.deviceagent.data.ImageAttachmentContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.ImageAttachmentTable;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryTable;
import net.abaqus.mygeotracking.deviceagent.forms.*;
import net.abaqus.mygeotracking.deviceagent.fragments.PushAttachmentTODBTask;
import net.abaqus.mygeotracking.deviceagent.home.MDAMainActivity;
import net.abaqus.mygeotracking.deviceagent.hos.HOSActivity;
import net.abaqus.mygeotracking.deviceagent.hos.HOSHistoryActivity;
import net.abaqus.mygeotracking.deviceagent.qrcode.QRScannerActivity;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReachReceiver;
import net.abaqus.mygeotracking.deviceagent.ui.FormSubmitActivity;
import net.abaqus.mygeotracking.deviceagent.ui.FormsActivity;
import net.abaqus.mygeotracking.deviceagent.ui.HOSCustomerJobListActivity;
import net.abaqus.mygeotracking.deviceagent.ui.NotesActivity;
import net.abaqus.mygeotracking.deviceagent.ui.SignatureActivity;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.LocationPUSHTask;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkDeviceStatus;
import net.abaqus.mygeotracking.deviceagent.utils.NotesEntryConstruction;
import net.abaqus.mygeotracking.deviceagent.utils.SnackbarUtils;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import io.codetail.animation.SupportAnimator;
import io.codetail.animation.ViewAnimationUtils;
import io.nlopez.smartlocation.OnLocationUpdatedListener;
import io.nlopez.smartlocation.OnReverseGeocodingListener;
import io.nlopez.smartlocation.SmartLocation;



public class NotesComposeFragment extends Fragment {

    private final String TAG = NotesComposeFragment.class.getSimpleName();
    final int QR_INTENT_REQUEST_CODE = 0;
    final int TASKS_INTENT_REQUEST_CODE = 1;
    final int GALLERY_INTENT_REQUEST_CODE = 2;
    final int CAMERA_INTENT_REQUEST_CODE = 3;
    final int SIGNATURE_INTENT_REQUEST_CODE = 4;
    final int FORM_INTENT_REQUEST_CODE = 5;
    final int CUSTOMERS_INTENT_REQUEST_CODE = 6;
    private static final int MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE = 201;
    private static final int MY_PERMISSIONS_REQUEST_CAMERA = 202;
    private static final int MY_PERMISSIONS_REQUEST_ACCESS_QRCAMERA = 203;
    private ImagePicker imagePicker;
    private CameraImagePicker cameraImagePicker;
    private String cameraPickerPath;
    private boolean IS_IT_FROM_CAMERA = false;
    ArrayList<Attachments> attachmentsArrayList;

    List<FormsTable> formsTableArrayList;
    AttachmentClickListener attachmentClickListener;

    EditText compose_msg, to_edittext;
    ImageView send_image_btn,
            to_group_btn,
            to_device_btn,
            qr_code_image_btn;

    Fragment fragmentThis = null;
    LinearLayout toAddressCardLayout,
            attachment_gallery_item,
            attachment_camera_item,
            attachment_signature_item,
            attachment_qr_item,
            attachment_tasks_item,
            attachment_customers_item,
            attachment_form_item,
            main_view,
            attachment_first_item_layout,
            attachment_second_item_layout;

    ImageView attachment_gallery_item_image,
            attachment_camera_item_image,
            attachment_signature_item_image,
            attachment_qr_item_image,
            attachment_tasks_item_image,
            attachment_customers_item_image,
            attachment_form_item_image;


    ContentValues values;
    Uri imageUri;

    LinearLayout mPreviewLayout;
    private ViewGroup mTagsContainer;
    LayoutInflater layoutInflater;

    boolean ATTACHMENTS_AVAILABLE = false;

    boolean URI_QR_SCAN = false;


    LinearLayout mRevealView;
    boolean hidden = true;


    private ViewGroup mPreviewContainer;
    private LinearLayout mPreview;
    private boolean URICheckinAvailable;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //GlobalBus.getsBus().register(this);
        EventBus.getDefault().register(this);
        return inflater.inflate(R.layout.fragment_notes, container, false);
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        layoutInflater = LayoutInflater.from(getActivity());
        attachmentsArrayList = new ArrayList<>();
        formsTableArrayList = getFormsData();
        init();
        fragmentThis = this;
        if (savedInstanceState != null) {
            if (savedInstanceState.containsKey("picker_path")) {
                cameraPickerPath = savedInstanceState.getString("picker_path");
            }
        }



        try {


            if(MDAMainActivity.isUrlPath)
            {
                if(getActivity().getIntent().getData() != null) {
                    Uri uri = getActivity().getIntent().getData();
                    String notesName = uri.getQueryParameter("s");
                    DebugLog.debug(TAG, "URI Parameters : " + uri.getQueryParameter("s"));
                    Log.d(TAG, "QURPARAN "+notesName);

                    URICheckinAvailable = true;

                    if(notesName.equalsIgnoreCase("sign"))
                    {
                        URI_QR_SCAN = true;
                        launchSigantureIntent();
                    }

                    if(notesName.equalsIgnoreCase("scan"))
                    {
                        URI_QR_SCAN = true;

//                        Intent intent = new Intent(getActivity(), QRScannerActivity.class);
//                        intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
//                        startActivityForResult(intent, QR_INTENT_REQUEST_CODE);

                        checkQRScanCameraPermission();

                    }

                }



            }


        } catch (Exception e) {
            e.printStackTrace();
        }



//        try {
//            Intent appLinkIntent = getActivity().getIntent();
//            String appLinkAction = appLinkIntent.getAction();
//            Uri appLinkData = appLinkIntent.getData();
//            String urlName = appLinkData.getPath();
//            Log.d("NOTESCOMSER","NOTESCOMSER "+urlName);
//            Log.d("APLNKACTION","APLNKACTION "+appLinkAction + "APLNKDAT "+appLinkData);
//
//            if(urlName.equals("/agent/notes/scan"))
//            {
//                Log.wtf("CLICKQR","CLICKQR");
//
////                main_view.setAlpha(0.7f);
//                //      mRevealView.setVisibility(View.GONE);
//                // checkQRScanCameraPermission();
//                //      revealAnimationForAttachment();
//
//                //launchQRIntent();
//                URI_QR_SCAN = true;
//
//                Intent intent = new Intent(getActivity(), QRScannerActivity.class);
//                intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
//                startActivityForResult(intent, QR_INTENT_REQUEST_CODE);
//
//            }
//
//            if(urlName.equals("/agent/notes/sign"))
//            {
//                URI_QR_SCAN = true;
//                launchSigantureIntent();
//            }
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }


    }


    private void init() {
        initViews();

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
//        {
//            reach_call_location();
//        }
//        else
//        {
//            native_call_location();
//        }

        if(Build.VERSION.SDK_INT >= 26)
        {
            native_call_location();
        }
        else
        {
            reach_call_location();
        }



//        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.N_MR1) {
//            SmartLocation.with(getContext()).location()
//                    .oneFix()
//                    .start(new OnLocationUpdatedListener() {
//                        @Override
//                        public void onLocationUpdated(Location location) {
//
//                            CurrentDateAndTime.setLatLonValues(
//                                    location.getLatitude(),
//                                    location.getLongitude());
//                            CurrentDateAndTime.setDeviceMethod("NATIVE");
//                            CurrentDateAndTime.setAccuracyValue(location.getAccuracy() + "");
//                        }
//                    });
//        }
//
//
//        try {
//            ZDAListener listener = ZDAListener.getInstance();
//            listener.sendLocationShot(1000, 60);
//        } catch (Exception e) {
//            Log.e("TAG",
//                    "Exception requesting location shot - "
//                            + e.getMessage());
//        }

//        AsyncTask.execute(new Runnable() {
//            @Override
//            public void run() {
//                reach_call_location();
//            }
//        });


    }



    private void reach_call_location()
    {
        Reach.getLocation(getActivity(), new ReachLocationCallback() {
            @Override
            public void onLocationSuccess(Ingress.Location location) {

                CurrentDateAndTime.setLatLonValues(
                        Double.valueOf(location.getLatitude()),
                        Double.valueOf(location.getLongitude()));
                //String methodParam = NetworkDeviceStatus.checkNetworkStatus(getActivity());
                String methodParam = NetworkDeviceStatus.checkNetworkStatus(getActivity());
                CurrentDateAndTime.setDeviceMethod(methodParam);
                CurrentDateAndTime.setAccuracyValue(location.getAccuracy() + "");

            }

            @Override
            public void onLocationFailure(Ingress.Error error) {

            }
        });
    }


    private void native_call_location()
    {
        SmartLocation.with(getContext()).location()
                .oneFix()
                .start(new OnLocationUpdatedListener() {
                    @Override
                    public void onLocationUpdated(Location location) {

                        CurrentDateAndTime.setLatLonValues(
                                location.getLatitude(),
                                location.getLongitude());
                        String methodParam = NetworkDeviceStatus.checkNetworkStatus(getActivity());
                        CurrentDateAndTime.setDeviceMethod(methodParam);
                        CurrentDateAndTime.setAccuracyValue(location.getAccuracy() + "");
                    }
                });
    }

    public static List<FormsTable> getFormsData() {
        return new Select()
                .from(FormsTable.class)
                .execute();
    }

    private boolean customerFoundOrAll() {
        boolean resultBoolean = false;
        String[] projection = {
                HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID, HOSCustomerANDJobRelationsTable.HOS_CJ_REL_CUS_ID};
        Cursor cursor = getActivity().getContentResolver().query(Uri.parse(HOSCustomerANDJobRelationContentProvider.CONTENT_URI.toString()), projection, null, null,
                null);

        if (cursor != null) {
            if (cursor.getCount() == 0) {
                String[] cus_projection = {HOSCustomerANDJobTable.HOS_CJ_ID};
                Cursor customer_cursor = getActivity().getContentResolver().query(
                        Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI
                                .toString()),
                        cus_projection,
                        HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ?",
                        new String[]
                                {"Job"}, null);
                if (customer_cursor != null & customer_cursor.getCount() >= 1) {
                    resultBoolean = true;
                }
                customer_cursor.close();
            } else {
                cursor.moveToFirst();
                try {
                    if (cursor.getString(cursor
                            .getColumnIndexOrThrow(HOSCustomerANDJobRelationsTable.HOS_CJ_REL_TASK_ID)).equalsIgnoreCase("all"))
                        resultBoolean = true;
                    else
                        resultBoolean = false;
                } catch (Exception e) {
                }
            }
        }
        cursor.close();
        return resultBoolean;
    }


    private void initViews() {
        mRevealView = (LinearLayout) getView().findViewById(R.id.reveal_items);

        attachment_first_item_layout = (LinearLayout) getView().findViewById(R.id.attachment_first_item_layout);

        attachment_second_item_layout = (LinearLayout)getView().findViewById(R.id.attachment_second_item_layout);

        mRevealView.setVisibility(View.GONE);

        attachmentClickListener = new AttachmentClickListener();

        compose_msg = (EditText) getView().findViewById(R.id.detail_content);
        to_edittext = (EditText) getView().findViewById(R.id.to_edit_box);
        qr_code_image_btn = (ImageView) getView().findViewById(R.id.btn_qr_code);

		/*text_mode_image_btn= (ImageView) getView().findViewById(R.id.btn_text_input);
        attachment_mode_image_btn = (ImageView) getView().findViewById(R.id.btn_attachment_input);
		signature_mode_image_btn = (ImageView) getView().findViewById(R.id.btn_sign_input);*/
        send_image_btn = (ImageView) getView().findViewById(R.id.btn_send_input);
        send_image_btn.setEnabled(true);
        to_group_btn = (ImageView) getView().findViewById(R.id.btn_to_group);
        to_device_btn = (ImageView) getView().findViewById(R.id.btn_to_device);
        to_device_btn.setEnabled(false);

        attachment_gallery_item = (LinearLayout) getView().findViewById(R.id.attachment_gallery_item);
        attachment_camera_item = (LinearLayout) getView().findViewById(R.id.attachment_camera_item);
        attachment_signature_item = (LinearLayout) getView().findViewById(R.id.attachment_signature_item);
        attachment_qr_item = (LinearLayout) getView().findViewById(R.id.attachment_qr_item);
        attachment_form_item = (LinearLayout) getView().findViewById(R.id.attachment_form_item);
        attachment_tasks_item = (LinearLayout) getView().findViewById(R.id.attachment_tasks_item);
        attachment_customers_item = (LinearLayout) getView().findViewById(R.id.attachment_customers_item);


        attachment_gallery_item_image = (ImageView) getView().findViewById(R.id.attachment_gallery_item_image);
        attachment_camera_item_image = (ImageView) getView().findViewById(R.id.attachment_camera_item_image);
        attachment_signature_item_image = (ImageView) getView().findViewById(R.id.attachment_signature_item_image);
        attachment_qr_item_image = (ImageView) getView().findViewById(R.id.attachment_qr_item_image);
        attachment_form_item_image = (ImageView) getView().findViewById(R.id.attachment_form_item_image);
        attachment_tasks_item_image = (ImageView) getView().findViewById(R.id.attachment_tasks_item_image);
        attachment_customers_item_image = (ImageView) getView().findViewById(R.id.attachment_customers_item_image);

        boolean formAvailable = formsTableArrayList.size() > 0;
        if (formAvailable)
            attachment_form_item.setVisibility(View.VISIBLE);
        else
            attachment_form_item.setVisibility(View.GONE);

        main_view = (LinearLayout) getView().findViewById(R.id.detail_root);
        main_view.setAlpha(1);
        main_view.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mRevealView.getVisibility() == View.VISIBLE) {
                    main_view.setAlpha(0.7f);
                    mRevealView.setVisibility(View.VISIBLE);
                    revealAnimationForAttachment();
                }
            }
        });

        compose_msg.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mRevealView.getVisibility() == View.VISIBLE) {
                    main_view.setAlpha(0.7f);
                    mRevealView.setVisibility(View.VISIBLE);
                    revealAnimationForAttachment();
                }
            }
        });
        attachment_gallery_item.setOnClickListener(attachmentClickListener);
        attachment_camera_item.setOnClickListener(attachmentClickListener);
        attachment_signature_item.setOnClickListener(attachmentClickListener);
        attachment_qr_item.setOnClickListener(attachmentClickListener);
        attachment_form_item.setOnClickListener(attachmentClickListener);
        attachment_tasks_item.setOnClickListener(attachmentClickListener);
        attachment_customers_item.setOnClickListener(attachmentClickListener);

        SharedPreferences sh_prefs = getActivity().getSharedPreferences(MDACons.PREFS, 0);

        if (jobAvailable())
            attachment_tasks_item.setVisibility(View.VISIBLE);
        else
            attachment_tasks_item.setVisibility(View.GONE);


        if (!sh_prefs.getBoolean(MDACons.HOS_MENU_AVAILABLE, false)) {
            if (!sh_prefs.getBoolean(MDACons.HOS_SHOW_MENU, true)) {
                if (customersAvailable())
                    attachment_customers_item.setVisibility(View.VISIBLE);
                else
                    attachment_customers_item.setVisibility(View.GONE);
            }
        }


        toAddressCardLayout = (LinearLayout) getView().findViewById(R.id.to_card);
        toAddressCardLayout.setVisibility(View.VISIBLE);

        mPreview = (LinearLayout) getView().findViewById(R.id.session_tags);
        mPreviewContainer = (ViewGroup) getView().findViewById(R.id.session_tags_container);
        mPreviewContainer.setVisibility(View.GONE);
        //tryRenderPreview();


        if (getActivity().getIntent().getStringExtra(NotesActivity.TO_DEVICE_STRING_EXTRA) != null && getActivity().getIntent().getStringExtra(NotesActivity.TO_DEVICE_STRING_EXTRA).length() > 0)
            to_edittext.setText(getActivity().getIntent().getStringExtra(NotesActivity.TO_DEVICE_STRING_EXTRA));


        send_image_btn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                sendMessage(v);

            }
        });

        qr_code_image_btn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
		/*Intent intent = new Intent(getActivity(), QRScannerActivity.class);
            intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
            startActivityForResult(intent, 0);*/
                main_view.setAlpha(0.7f);
                mRevealView.setVisibility(View.VISIBLE);

                revealAnimationForAttachment();


            }
        });


        to_device_btn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                togroupBtnClick();
            }
        });


        to_group_btn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                togroupBtnClick();
            }
        });


    }

    public boolean isClosable() {
        if(submitProcessed) return true;
        if (compose_msg.getText().toString().isEmpty() && mPreview.getChildCount() <= 0)
            return true;
        else
            return false;
    }

    private void makeTasksPullListCall() {
        Intent hos_cj_listing_intent = new Intent(getActivity(),
                HOSCustomerJobListActivity.class);
        hos_cj_listing_intent.putExtra("which", "job");
        hos_cj_listing_intent.putExtra("customer", "");
        startActivityForResult(hos_cj_listing_intent, TASKS_INTENT_REQUEST_CODE);
    }

    private void makeCustomersPullListCall() {
        Intent hos_cj_listing_intent = new Intent(getActivity(),
                HOSCustomerJobListActivity.class);
        hos_cj_listing_intent.putExtra("which", "customer");
        startActivityForResult(hos_cj_listing_intent, CUSTOMERS_INTENT_REQUEST_CODE);
    }

    private boolean jobAvailable() {
        Cursor mCursor = getActivity().getContentResolver().query(Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI.toString()), null, HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ?", new String[]{"Job"},
                HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");

        if (mCursor != null && mCursor.getCount() > 0) {
            mCursor.close();
            return true;
        } else {
            mCursor.close();
            return false;
        }
    }

    private boolean customersAvailable() {
        Cursor mCursor = getActivity().getContentResolver().query(Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI.toString()), null, HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ?", new String[]{"Customer"},
                HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");
        if (mCursor != null && mCursor.getCount() > 0) {
            mCursor.close();
            return true;
        } else {
            mCursor.close();
            return false;
        }

    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        Log.wtf("REQCODE ","REQCODE "+requestCode);
        super.onActivityResult(requestCode, resultCode, intent);
        renderAttachments();
        main_view.setAlpha(0.7f);
        mRevealView.setVisibility(View.VISIBLE);
        revealAnimationForAttachment();
        if (requestCode == QR_INTENT_REQUEST_CODE) {
            Log.wtf("QRINTNET ","QRINTNET ");
            if (resultCode == Activity.RESULT_OK) {
                Log.wtf("RESULTOK ","RESULTOK ");

                String contents = intent.getStringExtra("SCAN_RESULT");
                // Handle successful scan
                Attachments attachments = new Attachments();
                attachments.setAttachment_type(Attachments.Attachment_Type.SCAN);
                attachments.setText_value(contents);
                attachments.setAttachmentID(attachmentsArrayList.size());

                final NestedScrollView chipViewText = (NestedScrollView) getView().inflate(getActivity(), R.layout.include_text_preview, null);
                final TextView attachmentText = (TextView) chipViewText.findViewById(R.id.tvAttachmentContent);
                attachmentText.setText(contents);
                attachmentText.setTag(attachmentsArrayList.size());
                attachmentsArrayList.add(attachments);
                ImageView attachmentClose = (ImageView) chipViewText.findViewById(R.id.ivAttacheTextClose);
                attachmentClose.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mPreview.removeView(chipViewText);
                        removeScanAttachmentFromList((Integer) attachmentText.getTag());
                        if (mPreview.getChildCount() <= 0)
                            closeAttachments();
                    }
                });
                mPreviewContainer.setVisibility(View.VISIBLE);
                mPreview.addView(chipViewText);

            } else if (resultCode == Activity.RESULT_CANCELED) {
                // Handle cancel
                Log.i("TAG", "Scan unsuccessful");
            }

        } else if (requestCode == TASKS_INTENT_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {

                String resulted_selection = intent.getStringExtra("selected_which");
                if (!resulted_selection.equals("null") && resulted_selection != null)
                    if (intent.getStringExtra("which").equals("job")) {

                        //hos_update_cj_job_text.setText("Job : " + resulted_selection);


                        if (resulted_selection.length() >= 1) {

                            Attachments attachments = new Attachments();
                            attachments.setAttachment_type(Attachments.Attachment_Type.TASK);
                            attachments.setText_value(resulted_selection);
                            attachments.setAttachmentID(attachmentsArrayList.size());

                            boolean avail = false;
                            for (Attachments attachments1 : attachmentsArrayList) {
                                if (attachments1.getAttachment_type() == Attachments.Attachment_Type.TASK && attachments1.getText_value().equals(resulted_selection)) {
                                    avail = true;
                                }
                            }
                            if (!avail) {


                                final NestedScrollView chipViewText = (NestedScrollView) getView().inflate(getActivity(), R.layout.include_text_preview, null);
                                final TextView attachmentText = (TextView) chipViewText.findViewById(R.id.tvAttachmentContent);
                                attachmentText.setText(resulted_selection);
                                attachmentText.setTag(attachmentsArrayList.size());
                                attachmentsArrayList.add(attachments);

                                ImageView attachmentClose = (ImageView) chipViewText.findViewById(R.id.ivAttacheTextClose);
                                attachmentClose.setOnClickListener(new OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        mPreview.removeView(chipViewText);
                                        removeScanAttachmentFromList((Integer) attachmentText.getTag());
                                        if (mPreview.getChildCount() <= 0)
                                            closeAttachments();
                                    }
                                });
                                mPreviewContainer.setVisibility(View.VISIBLE);
                                mPreview.addView(chipViewText);
                            }
                        }

                    }

            }
        } else if (requestCode == Picker.PICK_IMAGE_DEVICE && resultCode == Activity.RESULT_OK) {
            if (imagePicker == null) {
                imagePicker = new ImagePicker(this);
                imagePicker.setImagePickerCallback(new ImagePickingCallback());
            }
            Snackbar.make(fragmentThis.getView(), "Attaching...Please wait.", Snackbar.LENGTH_SHORT).show();
            imagePicker.submit(intent);
        } else if (requestCode == GALLERY_INTENT_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            super.onActivityResult(requestCode, resultCode, intent);
        } else if (requestCode == Picker.PICK_IMAGE_CAMERA && resultCode == Activity.RESULT_OK) {
            if (cameraImagePicker == null) {
                cameraImagePicker = new CameraImagePicker(this);
                cameraImagePicker.setImagePickerCallback(new ImagePickingCallback());
                cameraImagePicker.reinitialize(cameraPickerPath);
            }
            Snackbar.make(fragmentThis.getView(), "Attaching...Please wait.", Snackbar.LENGTH_SHORT).show();
            cameraImagePicker.submit(intent);
        } else if (requestCode == CAMERA_INTENT_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            super.onActivityResult(requestCode, resultCode, intent);
        } else if (requestCode == SIGNATURE_INTENT_REQUEST_CODE && resultCode == Activity.RESULT_OK) {

            final RelativeLayout chipView = (RelativeLayout) getView().inflate(getActivity(), R.layout.include_image_preview, null);
            final ImageView attachmentImage = (ImageView) chipView.findViewById(R.id.ivAttachment);
            ImageView attachmentClose = (ImageView) chipView.findViewById(R.id.ivAttachImageClose);
            attachmentImage.setTag(attachmentsArrayList.size());
            attachmentClose.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    mPreview.removeView(chipView);
                    removeScanAttachmentFromList((Integer) attachmentImage.getTag());
                    if (mPreview.getChildCount() <= 0)
                        closeAttachments();
                    attachment_signature_item.setEnabled(true);
                    attachment_signature_item_image.setImageResource(R.drawable.ic_attachment_signature);
                    if (mPreview.getChildCount() <= 0)
                        closeAttachments();
                }
            });

            Bitmap bitmap;
            try {

                Bundle extras = intent.getExtras();
                String imagePath = extras.get("signature_path").toString();
                String fileName = extras.get("file_name").toString();
                Attachments attachments = new Attachments();
                attachments.setAttachment_type(Attachments.Attachment_Type.SIGNATURE);
                attachments.setImageAttachment(loadImageFromStorage(imagePath, fileName, attachmentImage));
                attachments.setAttachmentID(attachmentsArrayList.size());
                attachmentsArrayList.add(attachments);


            } catch (Exception e) {
                e.printStackTrace();

            }
            mPreviewContainer.setVisibility(View.VISIBLE);
            mPreview.addView(chipView);
            super.onActivityResult(requestCode, resultCode, intent);


        } else if (requestCode == FORM_INTENT_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            String contents = intent.getStringExtra("form_data");
            String fdUID = intent.getStringExtra("fdUID");
            String formId = intent.getStringExtra("formId");
            Log.d("FORMID ","FORMID "+formId);
            // Handle successful scan
            // formsTableArrayList = getFormsData();
            final NestedScrollView chipViewText = (NestedScrollView) getView().inflate(getActivity(), R.layout.include_text_preview, null);
            final TextView attachmentText = (TextView) chipViewText.findViewById(R.id.tvAttachmentContent);
            String formName = "";
            for (FormsTable formsTable : formsTableArrayList) {
                if (formId.equals(formsTable.formId)) {
                    formName = formsTable.formName;
                    Log.d("FORMNAME ","FORMNAME "+formName);
                    break;
                }
            }
            Log.d("OURSIERNAME ","OURSIERNAME "+formName);


            attachmentText.setText(formName);
            attachmentText.setTag(attachmentsArrayList.size());

            Attachments attachments = new Attachments();
            attachments.setAttachment_type(Attachments.Attachment_Type.FORM);
            FormAttachment formAttachment = new FormAttachment(contents, fdUID);
            attachments.setFormAttachment(formAttachment);
            attachments.setAttachmentID(attachmentsArrayList.size());
            attachmentsArrayList.add(attachments);


            ImageView attachmentClose = (ImageView) chipViewText.findViewById(R.id.ivAttacheTextClose);
            attachmentClose.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    mPreview.removeView(chipViewText);
                    removeScanAttachmentFromList((Integer) attachmentText.getTag());
                    if (mPreview.getChildCount() <= 0)
                        closeAttachments();
                    //attachment_form_item.setEnabled(true);
                    attachment_form_item_image.setImageResource(R.drawable.ic_action_form);
                    if (mPreview.getChildCount() <= 0)
                        closeAttachments();

                }
            });

            //attachment_form_item.setEnabled(false);
            //attachment_form_item_image.setImageResource(R.drawable.ic_action_form_disabled);

            mPreviewContainer.setVisibility(View.VISIBLE);
            mPreview.addView(chipViewText);
            super.onActivityResult(requestCode, resultCode, intent);


        } else if (requestCode == CUSTOMERS_INTENT_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                String resulted_selection = intent.getStringExtra("selected_which");
                if (!resulted_selection.equals("null") && resulted_selection != null)
                    if (intent.getStringExtra("which").equals("customer")) {

                        if (resulted_selection.length() >= 1) {

                            Attachments attachments = new Attachments();
                            attachments.setAttachment_type(Attachments.Attachment_Type.CUSTOMER);
                            attachments.setText_value(resulted_selection);
                            attachments.setAttachmentID(attachmentsArrayList.size());
                            boolean avail = false;
                            for (Attachments attachments1 : attachmentsArrayList) {
                                if (attachments1.getAttachment_type() == Attachments.Attachment_Type.CUSTOMER && attachments1.getText_value().equals(resulted_selection)) {
                                    avail = true;
                                }
                            }
                            if (!avail) {
                                final NestedScrollView chipViewText = (NestedScrollView) getView().inflate(getActivity(), R.layout.include_text_preview, null);
                                final TextView attachmentText = (TextView) chipViewText.findViewById(R.id.tvAttachmentContent);
                                attachmentText.setText(resulted_selection);
                                attachmentText.setTag(attachmentsArrayList.size());
                                attachmentsArrayList.add(attachments);
                                ImageView attachmentClose = (ImageView) chipViewText.findViewById(R.id.ivAttacheTextClose);
                                attachmentClose.setOnClickListener(new OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        mPreview.removeView(chipViewText);
                                        removeScanAttachmentFromList((Integer) attachmentText.getTag());
                                        if (mPreview.getChildCount() <= 0)
                                            closeAttachments();
                                    }
                                });
                                mPreviewContainer.setVisibility(View.VISIBLE);
                                mPreview.addView(chipViewText);
                            }
                        }
                    }
            }

            if (mPreview.getChildCount() <= 0)
                closeAttachments();
        }
    }

    public static Bitmap decodeSampledBitmapFromResource(InputStream inputStream,
                                                         int reqWidth, int reqHeight) {

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeStream(inputStream, new Rect(50, 50, 50, 50), options);
    }

    public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight
                    && (halfWidth / inSampleSize) > reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }

    private void saveImageAttachmentinFile(Bitmap bitmap, ImageAttachment imageAttachment) {
        String fileName = "";
        File directory = null;


        SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
        Date now = new Date();
        fileName = "image_attachment_" + formatter.format(now) + ".jpg";

        ContextWrapper cw = new ContextWrapper(getActivity().getApplicationContext());
        // path to /data/data/yourapp/app_data/imageDir
        directory = cw.getDir("images", Context.MODE_PRIVATE);
        // Create imageDir
        File mypath = new File(directory, fileName);

        FileOutputStream fos = null;
        try {

            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, fos);
            fos.close();

            imageAttachment.setPath(directory.getAbsolutePath());
            imageAttachment.setName(fileName);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    Bitmap ShrinkBitmap(String file, int width, int height, ImageAttachment imageAttachment) {

        BitmapFactory.Options bmpFactoryOptions = new BitmapFactory.Options();
        bmpFactoryOptions.inJustDecodeBounds = true;
        Bitmap bitmap = BitmapFactory.decodeFile(file, bmpFactoryOptions);

        int heightRatio = (int) Math.ceil(bmpFactoryOptions.outHeight / (float) height);
        int widthRatio = (int) Math.ceil(bmpFactoryOptions.outWidth / (float) width);

        if (heightRatio > 1 || widthRatio > 1) {
            if (heightRatio > widthRatio) {
                bmpFactoryOptions.inSampleSize = heightRatio;
            } else {
                bmpFactoryOptions.inSampleSize = widthRatio;
            }
        }

        bmpFactoryOptions.inJustDecodeBounds = false;
        bitmap = BitmapFactory.decodeFile(file, bmpFactoryOptions);

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        byte[] imageInByte = stream.toByteArray();
        //this gives the size of the compressed image in kb
        long lengthbmp = imageInByte.length / 1024;

        String fileName = "";
        File directory = null;


        SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
        Date now = new Date();
        fileName = "image_attachment_" + formatter.format(now) + ".jpg";

        ContextWrapper cw = new ContextWrapper(getActivity().getApplicationContext());
        // path to /data/data/yourapp/app_data/imageDir
        directory = cw.getDir("images", Context.MODE_PRIVATE);
        // Create imageDir
        File mypath = new File(directory, fileName);
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(mypath);

//          write the compressed bitmap at the destination specified by filename.
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            imageAttachment.setPath(directory.getAbsolutePath());
            imageAttachment.setName(fileName);
            imageAttachment.setSize(bitmap.getByteCount() + "");
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

        return bitmap;
    }

    private ImageAttachment loadImageFromStorage(String path, String fileName, ImageView imageView) {
        ImageAttachment imageAttachment = new ImageAttachment();
        try {
            File f = new File(path, fileName);
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            imageView.setImageBitmap(b);
            attachment_signature_item.setEnabled(false);
            attachment_signature_item_image.setImageResource(R.drawable.ic_attachment_signature_disabled);

            String dateString = "";
            try {
                dateString = CurrentDateAndTime.getDateTimeWaterMark(new SimpleDateFormat(
                        "EEE MMM dd yyyy HH:mm:ss zZ", Locale.getDefault()));
            } catch (Exception e) {
            }

            //ImageAttachment(String uniqueID, String size, String type, String md5, String path, String name)
            imageAttachment = new ImageAttachment(UUID.randomUUID().toString(), b.getByteCount() + "", "IMAGE", "", path, fileName, dateString);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return imageAttachment;
    }


    protected void togroupBtnClick() {
        if (to_group_btn.isEnabled()) {
            to_device_btn.setEnabled(true);
            to_group_btn.setEnabled(false);
            to_edittext.setInputType(InputType.TYPE_CLASS_TEXT);
        } else {
            to_device_btn.setEnabled(false);
            to_group_btn.setEnabled(true);
            to_edittext.setInputType(InputType.TYPE_CLASS_NUMBER);
        }
    }


    protected void toDeviceBtnClick() {
        if (to_device_btn.isEnabled()) {
            to_device_btn.setEnabled(false);
            to_group_btn.setEnabled(true);
            to_edittext.setInputType(InputType.TYPE_CLASS_NUMBER);
        } else {
            to_device_btn.setEnabled(true);
            to_group_btn.setEnabled(false);
            to_edittext.setInputType(InputType.TYPE_CLASS_TEXT);
        }
    }

    boolean submitProcessed;

    protected void sendMessage(View view) {
        SharedPreferences sh_prefs = getActivity().getSharedPreferences(MDACons.PREFS, 0);
        submitProcessed = false;
        if (verifyInputs()) {
            submitProcessed = true;
            Notes notes = new Notes();
            String messageBodyText = compose_msg.getText().toString();
            String taskString = "", qrString = "", formString = "", fdUID = "", customerString = "";
            for (int i = 0; i < attachmentsArrayList.size(); i++) {
                Attachments attachments = attachmentsArrayList.get(i);
                if (attachments.getAttachment_type() == Attachments.Attachment_Type.TASK) {
                    taskString = taskString + attachments.getText_value() + "|";
                }
            }
            notes.setTask_description(taskString);

            if (attachment_tasks_item.getVisibility() == View.VISIBLE && sh_prefs.getBoolean(MDACons.IS_JOB_SITE_MANDATORY, false) && taskString.length() <= 0) {
                SnackbarUtils.showLong(main_view, "Please attach task to proceed!", Color.WHITE, ContextCompat.getColor(getActivity(), R.color.alert));
                return;
            }

            for (int i = 0; i < attachmentsArrayList.size(); i++) {
                Attachments attachments = attachmentsArrayList.get(i);
                if (attachments.getAttachment_type() == Attachments.Attachment_Type.CUSTOMER) {
                    customerString = customerString + attachments.getText_value() + "|";
                }
            }

            notes.setjobsite_description(customerString);

            for (int i = 0; i < attachmentsArrayList.size(); i++) {
                Attachments attachments = attachmentsArrayList.get(i);
                if (attachments.getAttachment_type() == Attachments.Attachment_Type.SCAN) {
                    qrString = qrString + attachments.getText_value() + "|";
                }
            }

            notes.setQr_result(qrString);

            for (int i = 0; i < attachmentsArrayList.size(); i++) {
                Attachments attachments = attachmentsArrayList.get(i);
                if (attachments.getAttachment_type() == Attachments.Attachment_Type.FORM) {
                    FormAttachment formAttachment = attachments.getFormAttachment();
                    formString = formString + formAttachment.getPostableData() + "|";
                    fdUID = fdUID + formAttachment.getFdUID() + "|";
                    //i = attachmentsArrayList.size();
                }
            }
            notes.setForm_result(formString);
            notes.setForm_fdUID(fdUID);


            for (int i = 0; i < attachmentsArrayList.size(); i++) {
                Attachments attachments = attachmentsArrayList.get(i);
                if (attachments.getAttachment_type() == Attachments.Attachment_Type.TASK || attachments.getAttachment_type() == Attachments.Attachment_Type.SCAN || attachments.getAttachment_type() == Attachments.Attachment_Type.CUSTOMER) {
                    attachmentsArrayList.remove(attachments);
                }
            }


            for (int i = 0; i < attachmentsArrayList.size(); i++) {
                Attachments attachments = attachmentsArrayList.get(i);
                if (attachments.getAttachment_type() == Attachments.Attachment_Type.IMAGE || attachments.getAttachment_type() == Attachments.Attachment_Type.SIGNATURE) {
                    //pushAttachmentDataToDB(attachments.getImageAttachment());
                    new PushAttachmentTODBTask(attachments.getImageAttachment(), getActivity().getBaseContext()).execute();
                }
            }


            notes.setMessageBody(messageBodyText);
            if (to_edittext.getText().toString().length() > 1)
                notes.setDeviceLsit(to_edittext.getText().toString());
            pushNotesEntrytoDB(notes);

            if (NetworkConnectionInfo.isOnline(getActivity())) {
                send_image_btn.setEnabled(false);
                new UploadNotesTask(getActivity()).execute();
                new AttachmentPushTask(getActivity()).execute();
                SnackbarUtils.showShort(main_view, "Success!", Color.WHITE, ContextCompat.getColor(getActivity(), R.color.blue));

                InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(
                        Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(compose_msg.getWindowToken(), 0);
            } else
                SnackbarUtils.showLong(main_view, "Internet connection problem! Your message will be sent later.", Color.WHITE, ContextCompat.getColor(getActivity(), R.color.alert));

            getActivity().onBackPressed();


        } else
            SnackbarUtils.showShort(main_view, "Message is blank!", Color.WHITE, ContextCompat.getColor(getActivity(), R.color.alert));

    }

    private void pushNotesEntrytoDB(Notes notes) {


        SharedPreferences sh_prefs = getActivity().getSharedPreferences(MDACons.PREFS, 0);
        // save data into database
        ContentValues initialValues = new ContentValues();
        initialValues.put(NotesEntryTable.NOTES_ENTRY_NO_OF_TRIES,
                0);
        String formString = "";
        for (int i = 0; i < attachmentsArrayList.size(); i++) {
            Attachments attachments = attachmentsArrayList.get(i);
            if (attachments.getAttachment_type() == Attachments.Attachment_Type.FORM) {
                FormAttachment formAttachment = attachments.getFormAttachment();
                formString = formString + formAttachment.getPostableData() + "|";
                //i = attachmentsArrayList.size();
            }
        }

        initialValues.put(NotesEntryTable.NOTES_ENTRY_FORM_POST_DATA,
                formString);
        initialValues.put(NotesEntryTable.NOTES_ENTRY_XML,
                NotesEntryConstruction.constructNotesEntryBlock(getActivity(), notes, attachmentsArrayList));
        getActivity().getContentResolver().insert(NotesEntryContentProvider.CONTENT_URI,
                initialValues);
    }


    private void pushAttachmentDataToDB(ImageAttachment imageAttachment) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_TYPE,
                imageAttachment.getType());
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_SIZE,
                imageAttachment.getSize());
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_ID,
                imageAttachment.getUniqueID());
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_ENTRY_NO_OF_TRIES,
                0);
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_PATH, imageAttachment.getPath());
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_NAME, imageAttachment.getName());
        initialValues.put(ImageAttachmentTable.IMAGE_ATTACHMENT_MD5, imageAttachment.getMd5());

        getActivity().getContentResolver().insert(ImageAttachmentContentProvider.CONTENT_URI,
                initialValues);
    }

    @SuppressLint("NewApi")
    private boolean verifyInputs() {

        if (compose_msg.getText().toString().isEmpty() && mPreview.getChildCount() <= 0)
            return false;
        else
            return true;
    }


    public void revealAnimationForAttachment() {
        final int cx = (mRevealView.getLeft() + mRevealView.getRight());
//                int cy = (mRevealView.getTop() + mRevealView.getBottom())/2;
        final int cy = mRevealView.getTop();

        final int radius = Math.max(mRevealView.getWidth(), mRevealView.getHeight());

        Log.wtf("callreveal","callreveal ");

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {

            Log.wtf("GETINSIDE","GETINSIDE ");


            SupportAnimator animator =
                    ViewAnimationUtils.createCircularReveal(mRevealView, cx, cy, 0, radius);
            animator.setInterpolator(new AccelerateDecelerateInterpolator());
            animator.setDuration(800);

            SupportAnimator animator_reverse = animator.reverse();

            if (hidden) {
                mRevealView.setVisibility(View.VISIBLE);
                animator.start();
                hidden = false;
            } else {
                animator_reverse.addListener(new SupportAnimator.AnimatorListener() {
                    @Override
                    public void onAnimationStart() {

                    }

                    @Override
                    public void onAnimationEnd() {
                        main_view.setAlpha(1);
                        mRevealView.setVisibility(View.GONE);
                        hidden = true;

                    }

                    @Override
                    public void onAnimationCancel() {

                    }

                    @Override
                    public void onAnimationRepeat() {

                    }
                });
                animator_reverse.start();

            }
        } else {
            Log.wtf("ELSEPARTESE","ELSEPARTESE ");
            if (hidden) {
                Log.wtf("HISDDDREN","HISDDDREN "+URI_QR_SCAN);


//                String value= getActivity().getIntent().getStringExtra("URI_SCAN");

                if(URI_QR_SCAN)
                {
                    //  attachment_first_item_layout.setVisibility(View.GONE);
                    // attachment_second_item_layout.setVisibility(View.GONE);
                    Log.d(TAG,"URISCAMN ");
                    main_view.setAlpha(1);
                    mRevealView.setVisibility(View.GONE);
                    hidden = true;

                    qr_code_image_btn.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mRevealView.setVisibility(View.VISIBLE);
                        }
                    });

                }
                else
                {
                    Log.d(TAG,"URIELSERPARE ");
                    Animator anim = android.view.ViewAnimationUtils.createCircularReveal(mRevealView, cx, cy, 0, radius);
                    mRevealView.setVisibility(View.VISIBLE);
                    anim.start();
                    hidden = false;
                }



//                main_view.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
//                    @Override
//                    public void onLayoutChange(View view, int i, int i1, int i2, int i3, int i4, int i5, int i6, int i7) {
//                        view.removeOnLayoutChangeListener(this);
//
//                        //Add circular revel animation on activity start
//                        main_view.post(new Runnable() {
//                            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
//                            @Override
//                            public void run() {
//                                //Your Animation Code
//
//                                Animator anim = android.view.ViewAnimationUtils.createCircularReveal(mRevealView, cx, cy, 0, radius);
//                                mRevealView.setVisibility(View.VISIBLE);
//                                anim.start();
//                                hidden = false;
//                            }
//                        });
//
//                    }
//                });

            } else {
                Log.wtf("ELSEHIDDEN","ELSEHIDDEN ");
                Animator anim = android.view.ViewAnimationUtils.createCircularReveal(mRevealView, cx, cy, radius, 0);
                anim.addListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        main_view.setAlpha(1);
                        mRevealView.setVisibility(View.GONE);
                        hidden = true;
                    }
                });
                anim.start();

            }
        }
    }


    class AttachmentClickListener implements OnClickListener {

        @Override
        public void onClick(View view) {

            switch (view.getId()) {

                case R.id.attachment_gallery_item:
                    launchGalleryImageCaptureIntent();
                    break;

                case R.id.attachment_camera_item:
                    //launchCameraImageCaptureIntent();
                    checkForCameraPermission();
                    break;

                case R.id.attachment_signature_item:
                    launchSigantureIntent();
                    break;

                case R.id.attachment_tasks_item:
                    makeTasksPullListCall();
                    break;

                case R.id.attachment_customers_item:
                    makeCustomersPullListCall();
                    break;

                case R.id.attachment_qr_item:
                    checkQRScanCameraPermission();

                    break;
                case R.id.attachment_form_item:

                    // launchFormActivity();
                    //TODO: Luanch the expandable list view from here. Comment the above method call.
                    //TODO: Inside the Expandable list activity, make API call to get forms list and display

                    FirebaseAnalytics mFirebaseAnalytics = FirebaseAnalytics.getInstance(getActivity().getBaseContext());
                    Bundle bundle = new Bundle();
                    bundle.putString(AnalyticsKey.EVENT_STATE, AnalyticsCons.ITEM_CLICKED);
                    bundle.putString(AnalyticsKey.EVENT_SOURCE, AnalyticsAttachmentSource.SOURCE_NOTES_SCREEN);
                    mFirebaseAnalytics.logEvent(AnalyticsEvent.FORM_ATTACHMENT_EVENT, bundle);


                    // To Use for Expandable List to show the forms and subforms List
                    Intent intent = new Intent(getActivity(), FormExpandableListActivity.class);
                    startActivityForResult(intent, FORM_INTENT_REQUEST_CODE);
                    //return true;

                    break;
            }
        }
    }

    private void loadOfflineFilesFromInternalMemory() {

        formsTableArrayList = getFormsData();
        for (FormsTable myFormTable : formsTableArrayList) {

            String path = "/data/data/" + getContext().getPackageName() + "/" + myFormTable.formId + ".html";

            //String path=getString(R.string.ApplicationFormPath);

            File file = new File(path);
            if (file.exists()) {
                // Toast File is exists
                Toast.makeText(getActivity().getApplicationContext(), myFormTable.formId + " this file exist ,..", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity().getApplicationContext(), "  file Not exist ,..", Toast.LENGTH_SHORT).show();
            }
        }


    }

    private void launchFormActivity() {


        final List<String> formsList = new ArrayList<>();

        for (FormsTable formsTable : formsTableArrayList) {
            formsList.add(formsTable.formName);
        }
        if (formsList.size() == 1) {
            Intent formIntent = new Intent(getActivity(), FormSubmitActivity.class);
            formIntent.putExtra("formId", formsTableArrayList.get(0).formId);
            startActivityForResult(formIntent, FORM_INTENT_REQUEST_CODE);
        } else {
            new MaterialDialog.Builder(getActivity())
                    .items(formsList)
                    .title("Select Form:")
                    .itemsCallback(new MaterialDialog.ListCallback() {
                        @Override
                        public void onSelection(MaterialDialog dialog, View view, int which, CharSequence text) {
                            Intent formIntent = new Intent(getActivity(), FormSubmitActivity.class);
                            formIntent.putExtra("formId", formsTableArrayList.get(which).formId);
                            startActivityForResult(formIntent, FORM_INTENT_REQUEST_CODE);
                        }
                    })
                    .show();
        }
    }


    private void launchGalleryImageCaptureIntent() {
		/*Intent intent = new Intent();
		intent.setType("image*//*");
		intent.setAction(Intent.ACTION_GET_CONTENT);
		intent.addCategory(Intent.CATEGORY_OPENABLE);
		startActivityForResult(intent, GALLERY_INTENT_REQUEST_CODE);*/


        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (shouldShowRequestPermissionRationale(
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Storage Permission Denied");
                builder.setMessage("Without Storage permission the application will not be able to attach image through Camera. Are you sure you want to deny this permission?");
                builder.setPositiveButton("I'M SURE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                builder.setNegativeButton("RE-TRY", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        requestPermissions(
                                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE);
                    }
                });
                builder.show();
                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {

                // No explanation needed, we can request the permission.


                requestPermissions(
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE);

                // MY_PERMISSIONS_REQUEST_ACCESS_CAMERA is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
            //Toast.makeText(getActivity(), "Storage Permission denied", Toast.LENGTH_SHORT).show();
        } else {
            imagePicker = new ImagePicker(this);
            IS_IT_FROM_CAMERA = false;
            imagePicker.setImagePickerCallback(new ImagePickingCallback());
            imagePicker.shouldGenerateMetadata(true);
            imagePicker.pickImage();
        }


    }


    class ImagePickingCallback implements ImagePickerCallback {
        @Override
        public void onImagesChosen(List<ChosenImage> images) {
            // Display images
            try {
                if (images.size() <= 0) {
                    return;
                }

                ChosenImage chosenImage = images.get(0);

                final RelativeLayout chipView = (RelativeLayout) getView().inflate(getActivity(), R.layout.include_image_preview, null);
                final ImageView attachmentImage = (ImageView) chipView.findViewById(R.id.ivAttachment);
                attachmentImage.setTag(attachmentsArrayList.size());
                final ImageView attachmentClose = (ImageView) chipView.findViewById(R.id.ivAttachImageClose);
                attachmentClose.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mPreview.removeView(chipView);
                        removeScanAttachmentFromList((Integer) attachmentImage.getTag());
                        if (mPreview.getChildCount() <= 0)
                            closeAttachments();
                        int imageAttachedCount = 0;
                        for (Attachments attachments : attachmentsArrayList) {
                            if (attachments.getAttachment_type() == Attachments.Attachment_Type.IMAGE) {
                                imageAttachedCount++;
                            }
                        }
                        if (imageAttachedCount < 3) {
                            attachment_gallery_item.setEnabled(true);
                            attachment_camera_item.setEnabled(true);
                            attachment_gallery_item_image.setImageResource(R.drawable.ic_attachment_picture);
                            attachment_camera_item_image.setImageResource(R.drawable.ic_attachment_camera);
                        }
                        if (mPreview.getChildCount() <= 0)
                            closeAttachments();
                    }
                });


                Bitmap bitmap = null;
                try {

                    bitmap = BitmapFactory.decodeFile(chosenImage.getThumbnailPath());
                    //if(bitmap.getByteCount() < Attachments.MAX_ATTACHMENT_SIZE) {
                    attachmentImage.setImageBitmap(bitmap);
                    //setPic(stream, attachmentImage);

                    int imageAttachedCount = 0;
                    for (Attachments attachments : attachmentsArrayList) {
                        if (attachments.getAttachment_type() == Attachments.Attachment_Type.IMAGE) {
                            imageAttachedCount++;
                        }
                    }
                    if (imageAttachedCount >= 2) {
                        attachment_gallery_item.setEnabled(false);
                        attachment_camera_item.setEnabled(false);
                        attachment_gallery_item_image.setImageResource(R.drawable.ic_attachment_picture_disabled);
                        attachment_camera_item_image.setImageResource(R.drawable.ic_attachment_camera_disabled);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                File jpegFile = new File(chosenImage.getOriginalPath());
                Metadata metadata = ImageMetadataReader.readMetadata(jpegFile);

				/*for (Directory directory : metadata.getDirectories()) {
					for (Tag tag : directory.getTags()) {
						System.out.println("TAG VALUES : "+tag);
					}
				}*/

                Date createdDate = null;
                try {
                    // obtain the Exif directory
                    ExifSubIFDDirectory directory
                            = metadata.getFirstDirectoryOfType(ExifSubIFDDirectory.class);

                    // query the tag's value
                    createdDate
                            = directory.getDate(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL);
                } catch (Exception e) {
                    e.printStackTrace();
                }


                String dateString = "";
                if (createdDate == null || IS_IT_FROM_CAMERA) {
                    dateString = CurrentDateAndTime.getDateTimeWaterMark(new SimpleDateFormat(
                            "EEE MMM dd yyyy HH:mm:ss zZ", Locale.getDefault()));
                } else {
                    try {
                        dateString = new SimpleDateFormat(
                                "EEE MMM dd yyyy HH:mm:ss zZ").format(createdDate);
                    } catch (Exception e) {
                    }
                }


                Attachments attachments = new Attachments();
                attachments.setAttachment_type(Attachments.Attachment_Type.IMAGE);
                ImageAttachment imageAttachment = new ImageAttachment();
                //if(bitmap != null && bitmap.getByteCount() < Attachments.MAX_ATTACHMENT_SIZE) {
                if (bitmap != null)
                    imageAttachment = new ImageAttachment(UUID.randomUUID().toString(), bitmap.getByteCount() + "", "IMAGE", "", "", "", dateString);

                ImageCompressUtil.compressImage(getActivity(), chosenImage.getOriginalPath(), imageAttachment);
                //ShrinkBitmap(intent.getDataString(),100, 100, imageAttachment);
                //saveImageAttachmentinFile(bitmap, imageAttachment);
                attachments.setImageAttachment(imageAttachment);
                attachments.setAttachmentID(attachmentsArrayList.size());

                attachmentsArrayList.add(attachments);

                mPreviewContainer.setVisibility(View.VISIBLE);
                mPreview.addView(chipView);
			/*}else
			{
				Toast.makeText(getActivity(), "File size limit cannot exceed 3 MB", Toast.LENGTH_SHORT).show();
			}*/

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onError(String message) {
            // Do error handling
        }
    }


    private void launchCameraImageCaptureIntent() {
        //Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		/*SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
		Date now = new Date();
		String fileName = "image_attachment_"+formatter.format(now)+".jpg";
		values = new ContentValues();
		values.put(MediaStore.Images.Media.TITLE, fileName);
		values.put(MediaStore.Images.Media.DESCRIPTION, "Image Attachment");
		imageUri = getActivity().getContentResolver().insert(
				MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE_SECURE);
		intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
		if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
			startActivityForResult(intent, CAMERA_INTENT_REQUEST_CODE);
		}*/
        cameraImagePicker = new CameraImagePicker(this);
        cameraImagePicker.shouldGenerateMetadata(true);
        cameraImagePicker.shouldGenerateThumbnails(true);
        IS_IT_FROM_CAMERA = true;
        cameraImagePicker.setImagePickerCallback(new ImagePickingCallback());
        cameraPickerPath = cameraImagePicker.pickImage();
    }

    private void launchSigantureIntent() {
        Intent takePictureIntent = new Intent(getActivity(), SignatureActivity.class);
        if (takePictureIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, SIGNATURE_INTENT_REQUEST_CODE);
        }

    }

    private void launchQRIntent() {
        Intent intent = new Intent(getActivity(), QRScannerActivity.class);
        intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
        startActivityForResult(intent, QR_INTENT_REQUEST_CODE);
    }

    private void renderAttachments() {
        mPreviewLayout = (LinearLayout) getView().findViewById(R.id.session_tags);
        mTagsContainer = (ViewGroup) getView().findViewById(R.id.session_tags_container);
        mTagsContainer.setVisibility(View.VISIBLE);

    }

    private void closeAttachments() {

        mTagsContainer.setVisibility(View.GONE);

    }


    private void removeScanAttachmentFromList(int id) {
        for (int i = 0; i < attachmentsArrayList.size(); i++) {
            Attachments attachments = attachmentsArrayList.get(i);
            if (attachments.getAttachmentID() == id)
                attachmentsArrayList.remove(i);
        }
    }


    public String getRealPathFromURI(Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getActivity().managedQuery(contentUri, proj, null, null, null);
        int column_index = cursor
                .getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    private void checkForStoragePermission() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (shouldShowRequestPermissionRationale(
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Storage Permission Denied");
                builder.setMessage("Without Storage permission the application will not be able to attach image through Camera. Are you sure you want to deny this permission?");
                builder.setPositiveButton("I'M SURE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                builder.setNegativeButton("RE-TRY", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityCompat.requestPermissions(getActivity(),
                                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE);
                    }
                });
                builder.show();
                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {

                // No explanation needed, we can request the permission.


                requestPermissions(
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE);

                // MY_PERMISSIONS_REQUEST_ACCESS_CAMERA is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
            //Toast.makeText(getActivity(), "Storage Permission denied", Toast.LENGTH_SHORT).show();
        } else {
            launchCameraImageCaptureIntent();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    launchGalleryImageCaptureIntent();
                } else {
                    //Snackbar.make(main_view,"Storage permission denied.",Snackbar.LENGTH_LONG).show();
                }
                return;
            }

            case MY_PERMISSIONS_REQUEST_CAMERA: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    checkForStoragePermission();
                } else {
                    //Snackbar.make(main_view,"Camera permission denied.",Snackbar.LENGTH_LONG).show();
                }
                return;
            }

            case MY_PERMISSIONS_REQUEST_ACCESS_QRCAMERA: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    launchQRIntent();
                } else {
                    //Snackbar.make(main_view,"Camera permission denied.",Snackbar.LENGTH_LONG).show();
                }

                return;
            }


            // other 'case' lines to check for other
            // permissions this app might request
        }
    }


    private void checkForCameraPermission() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (shouldShowRequestPermissionRationale(
                    Manifest.permission.CAMERA)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Camera Permission Denied");
                builder.setMessage("Without Camera permission the application will not be able to capture camera attachments. Are you sure you want to deny this permission?");
                builder.setPositiveButton("I'M SURE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.setNegativeButton("RE-TRY", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        requestPermissions(
                                new String[]{Manifest.permission.CAMERA},
                                MY_PERMISSIONS_REQUEST_CAMERA);
                    }
                });
                builder.show();
                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.\

            } else {

                // No explanation needed, we can request the permission.

				/*ActivityCompat.requestPermissions(getActivity(),
						new String[]{Manifest.permission.CAMERA},
						MY_PERMISSIONS_REQUEST_CAMERA);*/

                String[] permissos = {"android.permission.CAMERA"};
                requestPermissions(permissos, MY_PERMISSIONS_REQUEST_CAMERA);


                // MY_PERMISSIONS_REQUEST_ACCESS_CAMERA is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
            //Toast.makeText(getActivity(), "Camera Permission denied", Toast.LENGTH_SHORT).show();
        } else {
            checkForStoragePermission();
        }
    }


    private void checkQRScanCameraPermission() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            if (shouldShowRequestPermissionRationale(
                    Manifest.permission.CAMERA)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Camera Permission Denied");
                builder.setMessage("Without Camera permission the application will not be able to scan QR Codes. Are you sure you want to deny this permission?");
                builder.setPositiveButton("I'M SURE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });
                builder.setNegativeButton("RE-TRY", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        requestPermissions(
                                new String[]{Manifest.permission.CAMERA},
                                MY_PERMISSIONS_REQUEST_ACCESS_QRCAMERA);
                    }
                });
                builder.show();
            } else {
                requestPermissions(
                        new String[]{Manifest.permission.CAMERA},
                        MY_PERMISSIONS_REQUEST_ACCESS_QRCAMERA);
            }
        } else {
            launchQRIntent();
        }
    }


    @Override
    public void onSaveInstanceState(Bundle outState) {
        // You have to save path in case your activity is killed.
        // In such a scenario, you will need to re-initialize the CameraImagePicker
        outState.putString("picker_path", cameraPickerPath);
        super.onSaveInstanceState(outState);
    }


//    @Subscribe
//    public void getMessage(Events.FragmentActivityMessage activityFragmentMessage) {
//
//        formsTableArrayList = activityFragmentMessage.getFormArrayList();
//    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // unregister the registered event.
        //GlobalBus.getsBus().unregister(this);
        EventBus.getDefault().unregister(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(FormsRefreshEvent event) {
        formsTableArrayList = getFormsData();
    };

}


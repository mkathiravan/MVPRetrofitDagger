package net.abaqus.mygeotracking.deviceagent.forms;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import com.activeandroid.query.Select;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.expandableview.Genre;
import net.abaqus.mygeotracking.deviceagent.expandableview.GenreAdapter;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.ui.FormSubmitActivity;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.SnackbarUtils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by user on 28-06-2018.
 */

public class FormExpandableListActivity extends ReceiverActivity implements GenreAdapter.GetFormPrefillId, GenreAdapter.OnFormsClickListener, FormsAPIPullJob.FormsPullListener {
    private static final String TAG = FormExpandableListActivity.class.getSimpleName();
    public static final int RESULT_REQUEST_CODE = 20017;
    @BindView(R.id.form_recycler_view)
    RecyclerView mrecyclerView;
    @BindView(R.id.errorViewLayout)
    LinearLayout errorViewLayout;
    private RecyclerView.LayoutManager mLayoutManager;
    private SharedPreferences sh_prefs;
    String device_number = "";
    List<FormListViewModel> formList = new ArrayList<>();
    public GenreAdapter adapter;
    private List<FormsTable> formsTableArrayList;
    private List<FormsPrefillTable> formsPrefillDataArrayList;
    private ProgressDialog progress;
    @BindView(R.id.form_root_layout)
    LinearLayout rootLayout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.expand_form_list);
        ButterKnife.bind(this);

        progress = new ProgressDialog(this);
        progress.setTitle("Please Wait!!");
        progress.setMessage("Wait!!");
        progress.setCancelable(false);
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);


        this.sh_prefs = getSharedPreferences(MDACons.PREFS, 0);
        device_number = sh_prefs.getString(MDACons.DEVICE_NUMBER, "");
        mrecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mrecyclerView.setLayoutManager(mLayoutManager);

        offline_data();




        ActionBar actionBar = initActionBar();
        setPageTitle(actionBar);

    }

    private void offline_data() {
        if (!this.sh_prefs.getString(MDACons.DEVICE_NUMBER, "").equals("")) {
            if (getFormsData().size() <= 0 && NetworkConnectionInfo.isOnline(this)) {
                progress.show();
                new FormsAPIPullJob().load_form_data(FormExpandableListActivity.this, this);
            } else {
                setFormPrefillData();
            }
        }

    }

    @NonNull
    private ActionBar initActionBar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        return actionBar;
    }


    private void setPageTitle(ActionBar actionBar) {
        actionBar.setTitle("Forms");
    }


    private List<FormsTable> getFormsData() {
        return new Select().from(FormsTable.class).execute();
    }

    private List<FormsPrefillTable> getFormPreFillData() {
        return new Select().from(FormsPrefillTable.class).execute();
    }



    private void setFormPrefillData() {
        formsTableArrayList = getFormsData();
        formsPrefillDataArrayList = getFormPreFillData();
        formList.clear();
        for (int index = 0; index < formsTableArrayList.size(); index++) {
            FormListViewModel formListViewModel = new FormListViewModel();
            formListViewModel.setForm_id(formsTableArrayList.get(index).getFormId());
            formListViewModel.setForm_name(formsTableArrayList.get(index).getFormName());
            FormPrefillListViewModel formPrefillListViewModel = new FormPrefillListViewModel();
            List<FormPrefillListViewModel> formPrefillListViewModelList = new ArrayList<>();
            for(int subindex = 0 ; subindex < formsPrefillDataArrayList.size(); subindex++)
            {
                if(formsTableArrayList.get(index).getFormId().equals(formsPrefillDataArrayList.get(subindex).getFormId()))
                {
                    formPrefillListViewModel.setForm_prefill_id(formsPrefillDataArrayList.get(subindex).getFormId());
                    formPrefillListViewModel.setForm_prefill_description(formsPrefillDataArrayList.get(subindex).getFormPrefillDescription());
                    formPrefillListViewModelList.add(formPrefillListViewModel);

                }
            }

            formListViewModel.setFormPrefillListViewModelList(formPrefillListViewModelList);
            formList.add(formListViewModel);
//            Log.d(TAG,"FORMLSTZIE "+formList.size() + "SEDR "+formList.get(index).getFormPrefillListViewModelList());
        }

        setAdapter();


    }

    private void setAdapter() {
        List<Genre> genres = getGenres();
        adapter = new GenreAdapter(FormExpandableListActivity.this, genres,this, this);
        mrecyclerView.setAdapter(adapter);

        }


    private void showErrorView() {
        errorViewLayout.setVisibility(View.VISIBLE);
        mrecyclerView.setVisibility(View.GONE);
    }

    public List<Genre> getGenres() {
        List<Genre> genreList = new ArrayList<>();
        for (int index = 0; index < formList.size(); index++) {
          //  int form_id = Integer.parseInt(formList.get(index).getForm_id());
            //Genre genre = new Genre(formList.get(index).getForm_name(), index, formList.get(index).getFormPrefillListViewModelList());
            Genre genre = new Genre(formList.get(index).getForm_name(), formList.get(index).getForm_id(), formList.get(index).getFormPrefillListViewModelList());

            genreList.add(genre);
        }
        return genreList;
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.timeclocking_menu, menu);
        MenuItem menuHistoryItem = menu.findItem(R.id.action_hos_history);
        menuHistoryItem.setVisible(false);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_timeclocking_refresh:
                if (!NetworkConnectionInfo.isOnline(FormExpandableListActivity.this)) {
                    SnackbarUtils.showShort(rootLayout, getString(R.string.msg_internet_disabled_please_try_later), Color.WHITE, ContextCompat.getColor(FormExpandableListActivity.this, R.color.alert));
                    break;
                }
                else
                {
                    progress.show();
                    new FormsAPIPullJob().load_form_data(FormExpandableListActivity.this, this);
                    //load_form_data();
                }

        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void getValue(String form_id) {

    }


    @Override
    public void formClicked(String formId) {
        Intent formIntent = new Intent(FormExpandableListActivity.this, FormSubmitActivity.class);
        formIntent.putExtra("formId", formId);
        startActivityForResult(formIntent, RESULT_REQUEST_CODE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if(requestCode == RESULT_REQUEST_CODE) {
            if(resultCode == RESULT_OK) {
                setResult(RESULT_OK, data);
                finish();
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }


    //Forms API Pull completion listener - method implementation

    @Override
    public void formPullCompleted(boolean formPullStatus, String errorMessage) {
        progress.hide();
        if(formPullStatus) {
            setFormPrefillData();
        } else {
            showErrorView();
        }
    }





}

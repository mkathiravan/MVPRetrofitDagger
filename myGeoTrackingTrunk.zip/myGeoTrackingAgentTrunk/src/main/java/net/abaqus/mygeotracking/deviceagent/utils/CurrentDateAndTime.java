package net.abaqus.mygeotracking.deviceagent.utils;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.util.Log;


public class CurrentDateAndTime {

	private static Double latitude;
	private static Double longitude;
	private static String accuracy;
	private static String deviceLocationMethod;
	private static String address = "";

	public static long getTime() {
		return time;
	}

	public static void setTime(long time) {
		CurrentDateAndTime.time = time;
	}

	private static long time;

	public static void setLatLonValues(Double lat, Double lon){
		latitude = lat;
		longitude = lon;
	}
	public static void setAccuracyValue(String acc){
		accuracy = acc;

	}

	public static void setDeviceMethod(String method){
		deviceLocationMethod = method;
	}
	public static void setAddress(String addressParam){
		address = addressParam;
	}
	public static String getDeviceMethod(){
		return deviceLocationMethod;
	}

	public static String getAccuracy(){
		return accuracy;
	}
	public static String getAddress(){
		return address;
	}

	public static Double getLatValue(){
		return latitude;
	}
	public static Double getLonValue(){
		return longitude;
	}

	public static String getAddressValue(Context con){
		Geocoder geocoder = new Geocoder(con, Locale.getDefault());
		List<Address> addresses = null ;
		try {
			addresses = geocoder.getFromLocation(latitude, longitude, 1);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return addresses.toString();
	}

	/**
	 * Gets current data and time from the device settings.
	 * @param sdf Dateformat for the return string value
	 * @return returns a String with the specified format
	 */

	public static String getCurrentTime(SimpleDateFormat sdf){
		Calendar c = null;
		try {
			c = Calendar.getInstance();
		}catch(Exception e){}
		return sdf.format(c.getTime()).toString();
	}

	public static String getDateTime(SimpleDateFormat sdf){
		DateFormat sdf1 = null;
		Calendar c = null;
		try {
			sdf1 = new SimpleDateFormat("yyyy/MM/dd'T'HH:mm:ssZ");

			c = Calendar.getInstance();
		}catch(Exception e){}
		return sdf1.format(c.getTime()).toString();
	}

	public static String getDate(SimpleDateFormat sdf)
	{
		DateFormat sdf1 = null;
		Calendar c = null;
		try {
			sdf1 = new SimpleDateFormat("yyyy/MM/dd");

			c = Calendar.getInstance();
		}catch(Exception e){}
		return sdf1.format(c.getTime()).toString();
	}


	public static String getDateTimeWaterMark(SimpleDateFormat sdf){
		DateFormat sdf1 = null;
		Calendar c = null;
		try {
			sdf1 = new SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss zZ", Locale.getDefault());

			c = Calendar.getInstance();
		}catch(Exception e){}
		return sdf1.format(c.getTime()).toString();
	}



}

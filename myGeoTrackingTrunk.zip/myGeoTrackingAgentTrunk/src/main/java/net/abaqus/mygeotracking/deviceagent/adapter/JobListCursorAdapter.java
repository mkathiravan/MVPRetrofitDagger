package net.abaqus.mygeotracking.deviceagent.adapter;

import net.abaqus.mygeotracking.deviceagent.MGTScheduleStatus;
import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobTable;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

import android.content.Context;
import android.database.Cursor;
import android.support.v4.widget.CursorAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class JobListCursorAdapter extends CursorAdapter{

	private static final String TAG = JobListCursorAdapter.class.getSimpleName();

	private LayoutInflater mInflater;
	
	public JobListCursorAdapter(Context context, Cursor c, int flags) {
	super(context, c, flags);
	mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	DebugLog.debug(TAG, "JobListCursorAdapter() ");
	}

	@Override
	public void bindView(View view, Context context, Cursor cursor) {
		TextView nameText = (TextView) view.findViewById(R.id.text1);
		nameText.setText(cursor.getString(cursor.getColumnIndex(HOSCustomerANDJobTable.HOS_CJ_NAME)));
		DebugLog.debug(TAG, "Applied Job name: "+nameText.getText());
	}

	@Override
	public View newView(Context context, Cursor cursor, ViewGroup parent) {
		DebugLog.debug(TAG, "JobListCursorAdapter() newView()");
		return mInflater.inflate(R.layout.hos_cj_listview_content_single_textview, parent, false);
	}
}
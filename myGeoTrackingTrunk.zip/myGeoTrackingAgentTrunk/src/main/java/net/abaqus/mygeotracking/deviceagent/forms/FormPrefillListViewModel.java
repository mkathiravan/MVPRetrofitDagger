package net.abaqus.mygeotracking.deviceagent.forms;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by user on 13-07-2018.
 */

public class FormPrefillListViewModel implements Parcelable{

    String form_prefill_id;

    protected FormPrefillListViewModel(Parcel in) {
        form_prefill_id = in.readString();
        form_prefill_description = in.readString();
    }

    public FormPrefillListViewModel() {
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(form_prefill_id);
        dest.writeString(form_prefill_description);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<FormPrefillListViewModel> CREATOR = new Creator<FormPrefillListViewModel>() {
        @Override
        public FormPrefillListViewModel createFromParcel(Parcel in) {
            return new FormPrefillListViewModel(in);
        }

        @Override
        public FormPrefillListViewModel[] newArray(int size) {
            return new FormPrefillListViewModel[size];
        }
    };

    public String getForm_prefill_id() {
        return form_prefill_id;
    }

    public void setForm_prefill_id(String form_prefill_id) {
        this.form_prefill_id = form_prefill_id;
    }

    public String getForm_prefill_description() {
        return form_prefill_description;
    }

    public void setForm_prefill_description(String form_prefill_description) {
        this.form_prefill_description = form_prefill_description;
    }

    String form_prefill_description;


}

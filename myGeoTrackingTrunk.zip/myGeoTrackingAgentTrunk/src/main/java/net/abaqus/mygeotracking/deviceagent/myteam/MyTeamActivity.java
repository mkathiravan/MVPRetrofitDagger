package net.abaqus.mygeotracking.deviceagent.myteam;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDelegate;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.RelativeLayout;
import android.widget.Toast;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.data.MyTeamSearchProvider;
import net.abaqus.mygeotracking.deviceagent.listeners.TaskCompleteListener;
import net.abaqus.mygeotracking.deviceagent.sixgill.ReceiverActivity;
import net.abaqus.mygeotracking.deviceagent.ui.NotesActivity;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

import java.util.ArrayList;

/**
 * Created by bm on 2/6/15.
 */
public class MyTeamActivity extends AppCompatActivity implements TaskCompleteListener, MyTeamListFragment.OnListSelectionListener,MyTeamListFragment.OnMenuItemClicked,MyTeamMapFragment.OnMenuMAPItemClicked{

    private static final String TAG = MyTeamActivity.class.getSimpleName();

    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    public boolean SINGLE_ITEM_CLICKED = false;
    public static final String MY_TEAM_BUNDLE_LIST = "myteambundlelist";
    MyTeamListFragment myTeamListFragment;
    MyTeamMapFragment myTeamMapFragment;
    ArrayList<MyTeamData> myTeamDataList;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.myteam_main_layout);

        progressDialog = new ProgressDialog(this);

        new MyTeamDataPullTask(this, this).execute();

        getMyTeamData();

        if(myTeamDataList.size() <= 0)
            refreshList();

        // Check that the activity is using the layout version with
        // the fragment_container FrameLayout
        if (findViewById(R.id.fragment_container) != null) {

            // However, if we're being restored from a previous state,
            // then we don't need to do anything and should return or else
            // we could end up with overlapping fragments.
            if (savedInstanceState != null) {
                return;
            }


            initListView();

        }

        // Create a new Fragment to be placed in the activity layout


        DebugLog.debug(TAG, "Call happened in Oncreate");
    }

    private void initListView() {

        Log.d(TAG,"INITLSTIVE ");

        myTeamListFragment = new MyTeamListFragment();
        // In case this activity was started with special instructions from an
        // Intent, pass the Intent's extras to the fragment as arguments

        myTeamListFragment.setArguments(constructIntentToPassList().getExtras());
        // Add the fragment to the 'fragment_container' FrameLayout
        getSupportFragmentManager().beginTransaction()
                .add(R.id.fragment_container, myTeamListFragment).addToBackStack(null).commitAllowingStateLoss();
        invalidateOptionsMenu();
    }

    private void getMyTeamData() {
        MyTeamSearchProvider myTeamDBHelper = new MyTeamSearchProvider(this);
        myTeamDataList = myTeamDBHelper.readMyTeamData("");
        myTeamDBHelper.close();
    }

    private Intent constructIntentToPassList() {
        Intent passIntent = getIntent();
        // Create a Bundle and Put Bundle in to it
        Bundle bundleObject = new Bundle();
        bundleObject.putSerializable(MY_TEAM_BUNDLE_LIST, myTeamDataList);
        bundleObject.putInt(MyTeamMapFragment.ARG_POSITION, -1);
        // Put Bundle in to Intent and call start Activity
        passIntent.putExtras(bundleObject);
        return passIntent;
    }

    @Override
    public void onTaskCompleted(boolean success) {

        getMyTeamData();
        if(progressDialog.isShowing())
            progressDialog.dismiss();

        if(myTeamListFragment != null)
        {
            if(myTeamListFragment.isVisible()) {
                getSupportFragmentManager().beginTransaction().remove(myTeamListFragment).commitAllowingStateLoss();
                initListView();

            }
        }

        else if(myTeamMapFragment != null && myTeamMapFragment.isVisible())
        {
            getSupportFragmentManager().beginTransaction().remove(myTeamMapFragment).commitAllowingStateLoss();
            initMapFragmentView();
        }
        else
        {
            initListView();
        }


        invalidateOptionsMenu();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }


    public void sendMessage()
    {
        SINGLE_ITEM_CLICKED = false;
        Intent notes_intent = new Intent(this, NotesActivity.class);

        MyTeamData myTeamData;
        String toDevicesList="";
        boolean anythingFound = false;
        for(int i = 0; i < myTeamDataList.size(); i++){
            myTeamData = myTeamDataList.get(i);
            if(myTeamData.isChecked()){
                if(toDevicesList.length() > 0)
                    toDevicesList = toDevicesList+","+myTeamData.getDeviceNumber();
                else
                    toDevicesList = toDevicesList+myTeamData.getDeviceNumber();
                anythingFound = true;
            }
        }

        if(!anythingFound){
            for(int i = 0; i < myTeamDataList.size(); i++){

                myTeamData = myTeamDataList.get(i);
                if(toDevicesList.length() > 0)
                    toDevicesList = toDevicesList+","+myTeamData.getDeviceNumber();
                else
                    toDevicesList = toDevicesList+myTeamData.getDeviceNumber();

            }
        }
        notes_intent.putExtra(NotesActivity.TO_DEVICE_STRING_EXTRA, toDevicesList);
        startActivity(notes_intent);
    }

    public void refreshList(){
        if(myTeamListFragment != null) {
            getSupportFragmentManager().beginTransaction().remove(myTeamListFragment).commitAllowingStateLoss();
            myTeamListFragment = null;
        }
        if(myTeamMapFragment != null) {
            getSupportFragmentManager().beginTransaction().remove(myTeamMapFragment).commitAllowingStateLoss();
            myTeamMapFragment = null;
        }
        progressDialog.setMessage("Refreshing...");
        progressDialog.show();
        new MyTeamDataPullTask(this, this).execute();
        SINGLE_ITEM_CLICKED = false;
    }

    public void switchViews(){
        if(myTeamListFragment.isVisible())
        {

            initMapFragmentView();



        }else if(myTeamMapFragment.isVisible()) {


            initListView();
            getSupportFragmentManager().beginTransaction().remove(myTeamMapFragment).commitAllowingStateLoss();

        }
        invalidateOptionsMenu();
    }
    public boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state);
    }

    private void initMapFragmentView() {
        Log.d(TAG,"MAPINISTDFAD ");

        if(isExternalStorageWritable()) {
            myTeamMapFragment = new MyTeamMapFragment();

            if (myTeamMapFragment.getMyTeamDataArrayListCount() <= 0)
                myTeamMapFragment.setArguments(constructIntentToPassList().getExtras());

            // Create fragment and give it an argument for the selected article
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, myTeamMapFragment).addToBackStack(null).commitAllowingStateLoss();
            getSupportFragmentManager().beginTransaction().remove(myTeamListFragment).commitAllowingStateLoss();
            invalidateOptionsMenu();
        }else{
            //https://code.google.com/p/gmaps-api-issues/issues/detail?id=9021
            Toast.makeText(MyTeamActivity.this, "Google maps error #9021", Toast.LENGTH_SHORT).show();
        }
    }


    /*MyTeamList Fragment Listener methods block : Begins*/

    @Override
    public void onItemChecked(int position) {

        //if(myTeamMapFragment != null)
        //myTeamMapFragment.updateMapViewItemChecked(position);
        if(myTeamDataList.get(position).isChecked())
            myTeamDataList.get(position).setChecked(true);
        else
            myTeamDataList.get(position).setChecked(false);

    }

    @Override
    public void onSingleItemClick(int position) {
        if(isExternalStorageWritable()) {
            SINGLE_ITEM_CLICKED = true;
            clearAllSelection();
            myTeamDataList.get(position).setChecked(true);

            myTeamMapFragment = new MyTeamMapFragment();
            Intent passIntent = getIntent();
            Bundle args = new Bundle();
            args.putInt(MyTeamMapFragment.ARG_POSITION, position);
            args.putSerializable(MY_TEAM_BUNDLE_LIST, myTeamDataList);
            passIntent.putExtras(args);
            myTeamMapFragment.setArguments(passIntent.getExtras());
            // Create fragment and give it an argument for the selected article
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, myTeamMapFragment).addToBackStack(null).commitAllowingStateLoss();
            getSupportFragmentManager().beginTransaction().remove(myTeamListFragment).commitAllowingStateLoss();
            invalidateOptionsMenu();
        }else{
            //https://code.google.com/p/gmaps-api-issues/issues/detail?id=9021
            Toast.makeText(MyTeamActivity.this, "Google maps error #9021", Toast.LENGTH_SHORT).show();
        }
    }

    public void clearAllSelection(){
        for (MyTeamData myTeamDatas : myTeamDataList){
            myTeamDatas.setChecked(false);
        }
    }

    /*MyTeamList Fragment Listener methods block : Ends*/

    @Override
    public void onBackPressed() {
        if(myTeamMapFragment!= null && myTeamMapFragment.isVisible()) {
            super.onBackPressed();
            SINGLE_ITEM_CLICKED = false;
            invalidateOptionsMenu();
        }
        else
            finish();
    }

    @Override
    public void sendnotes() {
        sendMessage();
    }

    @Override
    public void team_refresh() {
        refreshList();
    }

    @Override
    public void myteamMapView() {
        SINGLE_ITEM_CLICKED = false;
        switchViews();

    }

    @Override
    public void sendmapnotes() {
        sendMessage();
    }

    @Override
    public void map_refresh() {

    }

    @Override
    public void myteamList() {
        switchViews();
    }
}
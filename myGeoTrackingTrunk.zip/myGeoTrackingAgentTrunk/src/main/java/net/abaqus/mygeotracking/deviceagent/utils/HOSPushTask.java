package net.abaqus.mygeotracking.deviceagent.utils;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.webkit.WebView;
import android.widget.Toast;

import com.facebook.network.connectionclass.DeviceBandwidthSampler;

import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobTable;
import net.abaqus.mygeotracking.deviceagent.data.HOSEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSEntryTable;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryTable;
import net.abaqus.mygeotracking.deviceagent.ui.HOSConfirmActivity;

import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EncodingUtils;
import org.apache.http.util.EntityUtils;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class HOSPushTask extends AsyncTask<String, Void, Boolean> {
	//**FIELDS**//
	private static final String TAG = HOSPushTask.class.getSimpleName();
	
	private Context mContext;
	private SharedPreferences prefs;
	SAXParserFactory spf = null; 
	SAXParser sp = null;
	/* Get the XMLReader of the SAXParser we created. */ 
	XMLReader xr = null;
	/* Create a new ContentHandler and apply it to the XML-Reader*/ 
	HOSPushXmlHandler hosPUSHXMLHandler=null;
	
	
	public HOSPushTask(Context con) {
		this.mContext = con;
		this.prefs = con.getSharedPreferences(MDACons.PREFS, 0);
        hosPUSHXMLHandler=new HOSPushXmlHandler();
		DebugLog.debug(TAG, "HOSPushTask constructing");
	}
	
	protected void onPreExecute() {
		DeviceBandwidthSampler.getInstance().startSampling();

	}

		
	protected void onPostExecute(Boolean success) {

		DeviceBandwidthSampler.getInstance().stopSampling();

		if (hosPUSHXMLHandler.error_occured){
			/*if (hosPUSHXMLHandler.getErrorMSG().contains("Can not find a account for the Device with"))
			{*/
			ContentValues initialValues = new ContentValues();
			Cursor eCursor = getHOSEntries();
			if (eCursor.getCount() > 0) {
				eCursor.moveToLast();
				initialValues.put(HOSEntryTable.HOS_ENTRY_NO_OF_TRIES, Integer.parseInt(eCursor.getString(eCursor
						.getColumnIndexOrThrow(HOSEntryTable.HOS_ENTRY_NO_OF_TRIES)))+1);
				this.mContext.getContentResolver().update(HOSEntryContentProvider.CONTENT_URI, initialValues, HOSEntryTable.COLUMN_ID+" = '"+ eCursor.getString(eCursor
						.getColumnIndexOrThrow(HOSEntryTable.COLUMN_ID))+"'", null);
			}
			if(!hosPUSHXMLHandler.getErrorMSG().isEmpty())
				Toast.makeText(mContext.getApplicationContext(), hosPUSHXMLHandler.getErrorMSG(), Toast.LENGTH_LONG).show();
//			}
//			else if (hosPUSHXMLHandler.getErrorMSG().contains("Multiple account for the Device")){
//				Toast.makeText(mContext.getApplicationContext(), hosPUSHXMLHandler.getErrorMSG(), Toast.LENGTH_LONG).show();
//			}
			eCursor.close();
		}else{
			Cursor eCursor = getHOSEntries();
			if (eCursor.getCount() > 0){
			eCursor.moveToLast();

					SharedPreferences sharedPreferences = mContext.getSharedPreferences(MDACons.PREFS, 0);
					String url = MDACons.BASE_URL + "/track/htmlform";
					String data = eCursor.getString(eCursor
							.getColumnIndexOrThrow(HOSEntryTable.HOS_ENTRY_FORM_POST_DATA));
				List<String> postDataList = Arrays.asList(data.split("\\|"));
				for (String tempPostData : postDataList) {
					if(tempPostData != null && tempPostData.length() > 0)
					{
						WebView webview = new WebView(mContext);
						webview.postUrl(url, EncodingUtils.getBytes(tempPostData, "base64"));
						DebugLog.debug(TAG, "FORM_SUBMISSION" + "Submitting form" + tempPostData);
					}
				}

					this.mContext.getContentResolver().delete(HOSEntryContentProvider.CONTENT_URI, HOSEntryTable.COLUMN_ID+" = '"+ eCursor.getString(eCursor
		              .getColumnIndexOrThrow(HOSEntryTable.COLUMN_ID))+"'" ,null);
			}
			eCursor.close();
			
			Cursor entryCursor = getHOSEntries();
			if (entryCursor.getCount() > 0){
			
			    new HOSPushTask(this.mContext).execute();
			}else{
				/*ZDAListener.getInstance().sendLocationShot(
						1000,
						30);*/
			}
			entryCursor.close();
		}
		
		
	}
	
	protected Boolean doInBackground(String... urls) {
		Log.d(TAG,"DOINBKGRIMD ");
	    try{
		Cursor entriesCursor = getHOSEntries();
		ConnectionManager cm;
		HttpEntity en = null;
		if (entriesCursor.getCount() > 0){
			entriesCursor.moveToLast();
		DebugLog.debug(TAG, "REQUEST" + MDACons.SERVER_URL+"createHOSData");
		cm = new ConnectionManager();
		cm.setupHttpPost(MDACons.SERVER_URL+"createHOSData");
		cm.setHttpHeader("Content-Type", "application/xml");

		try {
			en = new StringEntity(entriesCursor.getString(entriesCursor
					.getColumnIndexOrThrow(HOSEntryTable.HOS_ENTRY_XML)));
			if(Integer.parseInt(entriesCursor.getString(entriesCursor
									.getColumnIndexOrThrow(HOSEntryTable.HOS_ENTRY_NO_OF_TRIES))) >= 5)
						{
									String trimmedStatus = getTrimmedHOSStatus(entriesCursor.getString(entriesCursor
											.getColumnIndexOrThrow(HOSEntryTable.HOS_ENTRY_XML)));
							en = new StringEntity(trimmedStatus);
						}else {
								en = new StringEntity(entriesCursor.getString(entriesCursor
												.getColumnIndexOrThrow(HOSEntryTable.HOS_ENTRY_XML)));
							}
		} catch (UnsupportedEncodingException e2) {
			e2.printStackTrace();
		}

		try {
			DebugLog.debug(TAG, "REQUEST" + EntityUtils.toString(en));
		} catch (Exception e1) {
			DebugLog.debug(TAG, "REQUEST" + e1.toString());
			e1.printStackTrace();
		}
		cm.setHttpPostEntity(en);
		
		
		try {
			InputSource m_is = cm.makeRequestGetResponse();
			 spf = SAXParserFactory.newInstance(); 
		        sp = spf.newSAXParser(); 
		
		        /* Get the XMLReader of the SAXParser we created. */ 
		        xr = sp.getXMLReader(); 
			xr.setContentHandler(hosPUSHXMLHandler);
			xr.parse(m_is);
			
			
		}catch (Exception e)
		{
			hosPUSHXMLHandler.error_occured = true;
			e.printStackTrace();
		}
		entriesCursor.close();
		return true;
		}else{
			entriesCursor.close();
			return false;
		}
		
	    }catch(Exception e){
        e.printStackTrace();
		return false;
	    }
		
	}

	private String getTrimmedHOSStatus(String hosEntry){
		String temp = "";
		int indexOne = hosEntry.indexOf("</Time>");
			temp = hosEntry.substring(0, indexOne+7);

		return temp+"</Device></MGTRequest>";
	}

	private Cursor getHOSEntries() {
		String[] projection = { 
		        HOSEntryTable.HOS_ENTRY_XML, HOSEntryTable.COLUMN_ID, HOSEntryTable.HOS_ENTRY_NO_OF_TRIES, HOSEntryTable.HOS_ENTRY_FORM_POST_DATA};
		    Cursor cursor = this.mContext.getContentResolver().query(Uri.parse(HOSEntryContentProvider.CONTENT_URI.toString()), projection, null, null,
		        null);

		    return cursor;
	}

	public static String error_message = "";
	
	public class HOSPushXmlHandler extends DefaultHandler{

		private boolean in_GTSResponseTag = false;
		private boolean in_Comment = false;
		
		
		private boolean in_NEW_CUSTOMERTag = false;
		private boolean in_NEW_JOBTAG = false;
		private boolean in_NEW_WORKTAG = false;
		private boolean in_NEW_CUSTOMER_ID = false;
		private boolean in_NEW_JOB_ID = false;
		private boolean in_NEW_WORK_ID = false;
		private boolean in_NEW_CUSTOMER_NAME = false;
		private boolean in_NEW_JOB_NAME = false;
		
		private String new_Entry_ID = "", new_Entry_name = "";
		
		public boolean error_occured = false;
		// =========================================================== 
	    // Methods 
	    // =========================================================== 
		
		public String getErrorMSG(){	
			return error_message;
		}
		
		@Override 
	    public void startDocument() throws SAXException { 
	         
	    } 

	    @Override 
	    public void endDocument() throws SAXException { 
	         // Nothing to do 
	    }
	    
	    public void startElement(String namespaceURI, String localName, 
	              String qName, Attributes atts) throws SAXException { 
	    	
	    	if (localName.equals("MGTResponse")) { 
	            this.in_GTSResponseTag = true;
	            if(atts.getValue("result").equalsIgnoreCase("error"))
	            {
	            	error_occured = true;
	            }
	       }else if (localName.equals("Comment")) { 
	           this.in_Comment = true; 
	      }else if (localName.equals("Customer")) { 
	           this.in_NEW_CUSTOMERTag = true; 
	           new_Entry_ID = "";
	           new_Entry_name = "";
	      }else if (localName.equals("Job")) { 
	           this.in_NEW_JOBTAG = true; 
	           new_Entry_ID = "";
	           new_Entry_name = "";
	      }else if (localName.equals("CustomerID")) { 
	           this.in_NEW_CUSTOMER_ID = true; 
	      }else if (localName.equals("JobID")) { 
	           this.in_NEW_JOB_ID = true; 
	      }else if(localName.equals("WorkOrderID"))
			{
				this.in_NEW_WORK_ID = true;
			}else if (localName.equals("CustomerName")) {
	           this.in_NEW_CUSTOMER_NAME = true; 
	      }else if (localName.equals("JobName")) { 
	           this.in_NEW_JOB_NAME = true; 
	      }
	    	
	       
	    } /* startELement */
	    
	    @Override 
	    public void endElement(String namespaceURI, String localName, String qName) 
	              throws SAXException { 
	    	if (localName.equals("MGTResponse")) { 
	            this.in_GTSResponseTag = false;
	       }else if (localName.equals("Comment")) { 
	            this.in_Comment = false;   
	       }else if (localName.equals("Customer")) { 
	           this.in_NEW_CUSTOMERTag = false; 
	           
	           insertIntoJobCustomerTable(localName, new_Entry_ID, new_Entry_name);
	           
	      }else if (localName.equals("Job")) { 
	           this.in_NEW_JOBTAG = false; 
	           
	           insertIntoJobCustomerTable(localName, new_Entry_ID, new_Entry_name);
	           
	      }else if (localName.equals("CustomerID")) { 
	           this.in_NEW_CUSTOMER_ID = false; 
	      }else if (localName.equals("JobID")) { 
	           this.in_NEW_JOB_ID = false; 
	      }else if(localName.equals("WorkOrderID"))
			{
				this.in_NEW_WORK_ID = false;
			}
	      else if (localName.equals("CustomerName")) {
	           this.in_NEW_CUSTOMER_NAME = false; 
	      }else if (localName.equals("JobName")) { 
	           this.in_NEW_JOB_NAME = false; 
	      }
	       
	    } 

	    @Override 
	   public void characters(char ch[], int start, int length) { 
	    	if (in_GTSResponseTag && in_Comment )
	    	{
				String message = new String(ch,start,length);
	    		if (error_occured && !message.equals("HOS Service not Authorized for Account"))
	    		error_message = message;
	    	}else if (in_GTSResponseTag && in_NEW_CUSTOMERTag && in_NEW_CUSTOMER_ID){
	    		new_Entry_ID = new String(ch,start,length);
	    	}else if (in_GTSResponseTag && in_NEW_CUSTOMERTag && in_NEW_CUSTOMER_NAME){
	    		new_Entry_name = new String(ch,start,length);
	    	}else if (in_GTSResponseTag && in_NEW_JOBTAG && in_NEW_JOB_ID){
	    		new_Entry_ID = new String(ch,start,length);
	    	}else if (in_GTSResponseTag && in_NEW_JOBTAG && in_NEW_JOB_NAME){
	    		new_Entry_name = new String(ch,start,length);
	    	}else if (in_GTSResponseTag && in_NEW_WORKTAG && in_NEW_WORK_ID){
				new_Entry_ID = new String(ch,start,length);
			}
	    	 
	    }/* characters*/
	}

	private void insertIntoJobCustomerTable(String which, String ID, String name){
		
		ContentValues initialValues = new ContentValues();
        initialValues.put(HOSCustomerANDJobTable.HOS_CJ_ID, ID);
        initialValues.put(HOSCustomerANDJobTable.HOS_CJ_NAME, name);
        initialValues.put(HOSCustomerANDJobTable.HOS_CJ_WHICH, which);
         
        this.mContext.getContentResolver().insert(HOSCustomerANDJobContentProvider.CONTENT_URI, initialValues);
		
	}
}

package net.abaqus.mygeotracking.deviceagent.sixgill;

import com.google.gson.annotations.SerializedName;

class DeviceModel {
    @SerializedName("method")
    private String method;

    @SerializedName("speed")
    private String speed;

    @SerializedName("movementDetected")
    private String movementDetected;

    @SerializedName("batteryLevel")
    private float batteryLevel;

    @SerializedName("battery_life")
    private long batteryLife;

    @SerializedName("charging")
    private boolean charging;


    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    public String getMovementDetected() {
        return movementDetected;
    }

    public void setMovementDetected(String movementDetected) {
        this.movementDetected = movementDetected;
    }

    public float getBatteryLevel() {
        return batteryLevel;
    }

    public void setBatteryLevel(float batteryLevel) {
        this.batteryLevel = batteryLevel;
    }

    public long getBatteryLife() {
        return batteryLife;
    }

    public void setBatteryLife(long batteryLife) {
        this.batteryLife = batteryLife;
    }

    public boolean isCharging() {
        return charging;
    }

    public void setCharging(boolean charging) {
        this.charging = charging;
    }


}

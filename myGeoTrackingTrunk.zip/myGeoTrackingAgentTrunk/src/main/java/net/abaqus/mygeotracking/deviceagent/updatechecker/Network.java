package net.abaqus.mygeotracking.deviceagent.updatechecker;

import net.abaqus.mygeotracking.deviceagent.utils.MDACons;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;



public class Network {
    /**
     * Check if a network is available
     */
    public static boolean isAvailable(Context context) {
        boolean connected = false;
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo ni = cm.getActiveNetworkInfo();
            if (ni != null) {
                connected = ni.isConnected();
            }
        }
        return connected;
    }
    /**
     * Log connection error
     */
    public static void logConnectionError() {
        Log.e(MDACons.LOG_TAG, "Cannot connect to the Internet!");
    }
}
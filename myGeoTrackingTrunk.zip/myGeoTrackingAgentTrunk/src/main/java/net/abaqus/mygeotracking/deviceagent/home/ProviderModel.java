package net.abaqus.mygeotracking.deviceagent.home;

import com.google.gson.annotations.SerializedName;

public class ProviderModel {


    @SerializedName("provider")
    private String provider;

    @SerializedName("statusCode")
    private int statusCode;

    @SerializedName("statusMsg")
    private String statusMessage;

    @SerializedName("deviceID")
    private String deviceId;

    @SerializedName("regionCode")
    private String regionCode;

    @SerializedName("countryCode")
    private String countryCode;

    @SerializedName("regionCountry")
    private String regionCountry;

    @SerializedName("nationalNumber")
    private String nationalNumber;

    @SerializedName("locateTime")
    private String locateTime;

    @SerializedName("locateMethod")
    private String locateMethod;

    @SerializedName("coordinateFormat")
    private String coOrdinateFormat;

    @SerializedName("device")
    private DeviceModel device;

    @SerializedName("civicAddress")
    private AddressModel address;

    @SerializedName("geo")
    private GeoModel geo;

    @SerializedName("property")
    private PropertyModel property;

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getRegionCountry() {
        return regionCountry;
    }

    public void setRegionCountry(String regionCountry) {
        this.regionCountry = regionCountry;
    }

    public String getNationalNumber() {
        return nationalNumber;
    }

    public void setNationalNumber(String nationalNumber) {
        this.nationalNumber = nationalNumber;
    }

    public String getLocateTime() {
        return locateTime;
    }

    public void setLocateTime(String locateTime) {
        this.locateTime = locateTime;
    }

    public String getLocateMethod() {
        return locateMethod;
    }

    public void setLocateMethod(String locateMethod) {
        this.locateMethod = locateMethod;
    }

    public String getCoOrdinateFormat() {
        return coOrdinateFormat;
    }

    public void setCoOrdinateFormat(String coOrdinateFormat) {
        this.coOrdinateFormat = coOrdinateFormat;
    }

    public DeviceModel getDevice() {
        return device;
    }

    public void setDevice(DeviceModel device) {
        this.device = device;
    }

    public AddressModel getAddress() {
        return address;
    }

    public void setAddress(AddressModel address) {
        this.address = address;
    }

    public GeoModel getGeo() {
        return geo;
    }

    public void setGeo(GeoModel geo) {
        this.geo = geo;
    }

    public PropertyModel getProperty() {
        return property;
    }

    public void setProperty(PropertyModel property) {
        this.property = property;
    }
}

package net.abaqus.mygeotracking.deviceagent.notes;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class NotesUploadXMLHandler extends DefaultHandler {
	
	private boolean		MGTResponseTag	= false;
	private boolean		MGTComment		= false;
	
	public static String	error_message	= "";
	public boolean		error_occured	= false;
	
	/*
	 * =========================================================== Methods
	 * ===========================================================
	 */
	
	public String getErrorMSG() {
		return error_message;
	}
	
	@Override
	public void startDocument() throws SAXException {
	
	}
	
	@Override
	public void endDocument() throws SAXException {
	// Nothing to do
	}
	
	public void startElement(String namespaceURI, String localName,
			String qName, Attributes atts) throws SAXException {
	
		if (localName.equals("MGTResponse")) {
			this.MGTResponseTag = true;
			if (atts.getValue("result").equalsIgnoreCase("error")) {
				error_occured = true;
			}
			else {
				error_occured = false;
			}
		}
		else if (localName.equals("Comment")) {
			this.MGTComment = true;
		}
	
	} /* startELement */
	
	@Override
	public void endElement(String namespaceURI, String localName, String qName)
			throws SAXException {
		if (localName.equals("MGTResponse")) {
			this.MGTResponseTag = false;
		}
		else if (localName.equals("Comment")) {
			this.MGTComment = false;
		}
	
	}
	
	@Override
	public void characters(char ch[], int start, int length) {
		if (MGTResponseTag && MGTComment) {
			if (error_occured) {
				error_message = new String(ch, start, length);
				//MDAMainActivity
						//.pinOptinErrorCloseButtonPressedFromAsyncTask(error_message);
			}
			/*else
				error_message = "Message sent successfully!!";*/
		}
	}/* characters */
}
package net.abaqus.mygeotracking.deviceagent.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.backgroundjobs.DozeModeWarningRemoverJob;
import net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder;
import net.abaqus.mygeotracking.deviceagent.utils.DeviceUtils;

import static net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder.NOTIFICATION_ACTION_WHITELIST;
import static net.abaqus.mygeotracking.deviceagent.notification.AgentNotificationBuilder.NOTIFICATION_ID_DOZEMODE;

/**
 * Created by bmandyam on 4/3/18.
 */

public class PowerSaveModeChangeReceiver extends BroadcastReceiver {


    public PowerSaveModeChangeReceiver() {}

    @Override
    public void onReceive(Context context, Intent intent) {

        if (DeviceUtils.getPowerSavingMode(context) && !DeviceUtils.getBatteryOptimizationStatus(context)) {
            AgentNotificationBuilder.showPowerSaveModeNotification(context, context.getString(R.string.str_doze_mode_notif_title), context.getString(R.string.str_doze_mode_notif_msg), NOTIFICATION_ID_DOZEMODE, NOTIFICATION_ACTION_WHITELIST);

            //Schedule a Job to run while device is in Battery charge mode once
            DozeModeWarningRemoverJob dozeModeWarningRemoverJob = DozeModeWarningRemoverJob.getInstance();
            dozeModeWarningRemoverJob.removeNotification(context);
        } else {
            AgentNotificationBuilder.dismissNotification(context, NOTIFICATION_ID_DOZEMODE);
        }

    }

}


package net.abaqus.mygeotracking.deviceagent.notes;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;

import com.activeandroid.query.Select;
import com.activeandroid.util.SQLiteUtils;
import com.facebook.network.connectionclass.DeviceBandwidthSampler;

import net.abaqus.mygeotracking.deviceagent.forms.FormsTable;
import net.abaqus.mygeotracking.deviceagent.utils.ConnectionManager;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.DownloadFiles;
import net.abaqus.mygeotracking.deviceagent.utils.MDACons;

import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlSerializer;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import okhttp3.ResponseBody;
import okio.BufferedSink;
import okio.Okio;
import retrofit2.Response;
import rx.Observable;
import rx.Subscriber;

/**
 * Created by root on 13/10/16.
 */

public class FormsPullTask extends AsyncTask<String, Void, Boolean> {

    private static final String TAG = FormsPullTask.class.getSimpleName();

    //**FIELDS**//

    private Context mContext;
    private SharedPreferences prefs;
    private SharedPreferences.Editor edit_prefs;
    private SAXParserFactory spf = null;
    private SAXParser sp = null;
    /* Get the XMLReader of the SAXParser we created. */
    private XMLReader xr = null;
    /* Create a new ContentHandler and apply it to the XML-Reader*/
    private FormsPullXmlHandler formsPullXmlHandler=null;
    //TODO List variable does not needs to be declared in global as it is used only in one method block
    //TODO myFormTable variable is unused. So it does not needs to be declared.
    private List<FormsTable> formsTableArrayList;
	private FormsTable myFormTable;
    public FormsPullTask(Context con) {
        this.mContext = con;
        this.prefs = con.getSharedPreferences(MDACons.PREFS, 0);
        this.edit_prefs = prefs.edit();
        /*
         * Prepare the SAX Parser
         * Assign the XMLHandler
         */
        formsPullXmlHandler = new FormsPullXmlHandler();
    }

    protected void onPreExecute() {
        DeviceBandwidthSampler.getInstance().startSampling();

    }


    protected void onPostExecute(Boolean success) {
        DebugLog.debug(TAG, "REQUEST" + "FormsPullTask onPostExecute");
        DeviceBandwidthSampler.getInstance().stopSampling();
    }

    protected Boolean doInBackground(String... urls) {


        if(prefs.getString(MDACons.DEVICE_NUMBER, "").isEmpty())
            return false;
        DebugLog.debug(TAG, "REQUEST" + MDACons.SERVER_URL+"getForms");
        ConnectionManager cm = new ConnectionManager();
        cm.setupHttpPost(MDACons.SERVER_URL+"getForms");
        cm.setHttpHeader("Content-Type", "application/xml");
        XmlSerializer serializer = Xml.newSerializer();
        StringWriter writer = new StringWriter();
        try{
            serializer.setOutput(writer);
            serializer.startDocument("UTF-8", true);
            serializer.startTag(null, "MGTRequest");
            serializer.startTag(null, "Device");
            serializer.startTag(null, "DeviceID");
            serializer.text(prefs.getString(MDACons.DEVICE_NUMBER, ""));
            serializer.endTag(null,"DeviceID");
            serializer.startTag(null, "UUID");
            serializer.text(prefs.getString(MDACons.DEVICE_GUID, ""));
            serializer.endTag(null,"UUID");

            String versionName = "";
            String bundleid = "";
            try {
                bundleid = mContext.getPackageManager()
                        .getPackageInfo(mContext.getPackageName(), 0).packageName;
                versionName =mContext.getPackageManager()
                        .getPackageInfo(mContext.getPackageName(), 0).versionName;
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }

            serializer.startTag(null, "AgentVersion");
            serializer.text(versionName);
            serializer.endTag(null,"AgentVersion");

            serializer.startTag(null, "BundleID");
            serializer.text(bundleid);
            serializer.endTag(null,"BundleID");

            serializer.startTag(null, "Platform");
            serializer.text("Android");
            serializer.endTag(null,"Platform");

            serializer.endTag(null,"Device");
            serializer.endTag(null,"MGTRequest");
            serializer.endDocument();
        }catch (Exception e) {
            //new SendExceptionLogToServerTask(mContext).execute(e.toString());
        }
        HttpEntity en = null;
        try {
            en = new StringEntity(writer.toString());
        } catch (UnsupportedEncodingException e2) {
            e2.printStackTrace();
        }
        try {
            Log.i("REQUEST", EntityUtils.toString(en));
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        cm.setHttpPostEntity(en);
        try {
            InputSource m_is =  cm.makeRequestGetResponse();
            spf = SAXParserFactory.newInstance();
            sp = spf.newSAXParser();
		        /* Get the XMLReader of the SAXParser we created. */
            xr = sp.getXMLReader();
            xr.setContentHandler(formsPullXmlHandler);
            xr.parse(m_is);
        }catch (Exception e)
        {
        }
        return true;
    }

    public static String error_message = "";
    public class FormsPullXmlHandler extends DefaultHandler {

        private boolean in_GTSResponseTag = false;
        private boolean in_Comment = false;
        private boolean TAG_FORMS = false;
        private boolean TAG_FORM = false;
        private boolean TAG_FORM_NAME = false;
        private boolean TAG_FORM_ID = false;
        private boolean TAG_FORM_URL = false;
        private boolean TAG_FORM_TOKEN = false;
        private boolean TAG_FORM_TYPE = false;
        private boolean TAG_FORM_LINK_URL = false;

        private int formIdCount = 0;
        private String formName = "", formId = "", formToken = "", formURL = "", formType = "", formLinkURL = "";
        public boolean error_occured = false;

        StringBuilder stringBuilder;
        // ===========================================================
        // Methods
        // ===========================================================

        public String getErrorMSG(){
            return error_message;
        }

        @Override
        public void startDocument() throws SAXException {
        }

        @Override
        public void endDocument() throws SAXException {
            // Nothing to do
        }

        public void startElement(String namespaceURI, String localName,
                                 String qName, Attributes atts) throws SAXException {
            stringBuilder = new StringBuilder();
            if (localName.equals("MGTResponse")) {
                this.in_GTSResponseTag = true;
                if(atts.getValue("result").equalsIgnoreCase("error"))
                {
                    error_occured = true;
                }
            } else if (localName.equals("forms")) {
                SQLiteUtils.execSql("DELETE FROM "+ FormsTable.class.getSimpleName());
                this.TAG_FORMS = true;
            } else if (localName.equals("form")) {
                formId = "";
                formName = "";
                formToken = "";
                formURL = "";
                formType = "";
                formLinkURL = "";
                this.TAG_FORM = true;
            } else if (localName.equals("formName")) {
                this.TAG_FORM_NAME = true;
            } else if (localName.equals("formURL")) {
                this.TAG_FORM_URL = true;
            } else if (localName.equals("Token")) {
                this.TAG_FORM_TOKEN = true;
            } else if (localName.equals("formId")) {
                formIdCount = formIdCount + 1;
                this.TAG_FORM_ID = true;
            }else if (localName.equals("formType")) {
                this.TAG_FORM_TYPE = true;
            }else if (localName.equals("formLinkURL")) {
                this.TAG_FORM_LINK_URL = true;
            }
        }

        @Override
        public void endElement(String namespaceURI, String localName, String qName)
                throws SAXException {
            if (localName.equals("MGTResponse")) {
                this.in_GTSResponseTag = false;
            } else if (localName.equals("Comment")) {
                this.in_Comment = false;
            } else if (localName.equals("formURL")) {
                formURL = stringBuilder.toString();
                this.TAG_FORM_URL = false;
            } else if (localName.equals("Token")) {
                formToken = stringBuilder.toString();
                this.TAG_FORM_TOKEN = false;
            } else if (localName.equals("forms")) {
                this.TAG_FORMS = false;
				 downLoadFiles();
            }   else if (localName.equals("form")) {
                FormsTable formsTable = new FormsTable();
                formsTable.formName = formName;
                formsTable.formId = formId;
                formsTable.formURL = formURL;
                formsTable.formToken = formToken;
                formsTable.formType = formType;
                formsTable.formLinkURL = formLinkURL;

                formsTable.save();
                this.TAG_FORM = false;
            }   else if (localName.equals("formName")) {
                formName = stringBuilder.toString();
                this.TAG_FORM_NAME = false;
            }   else if (localName.equals("formType")) {
                formType = stringBuilder.toString();
                this.TAG_FORM_TYPE = false;
            }   else if (localName.equals("formLinkURL")) {
                formLinkURL = stringBuilder.toString();
                this.TAG_FORM_LINK_URL = false;
            }   else if (localName.equals("formId")) {
                formId = stringBuilder.toString();
                //Store it in db
                this.TAG_FORM_ID = false;
            }

        }

        //TODO format the code based on the guideline document or CTRL+ALT+L for this block
        public void downLoadFiles() {

            formsTableArrayList = getFormsData();;
            for(FormsTable myFormTable:formsTableArrayList)
            {
                DownloadFiles.downloadZipFileRx(myFormTable,mContext);
            }
        }

        private List<FormsTable> getFormsData() {
            return new Select()
                    .from(FormsTable.class)
                    .execute();
        }

        //TODO Remove unused methods from this class. Below methods are unused
        //TODO Also remove commented code pieces
        private Observable<File> saveToDiskRx(final Response<ResponseBody> response, final FormsTable myFormTable) {
            return Observable.create(new Observable.OnSubscribe<File>() {
                @Override
                public void call(Subscriber<? super File> subscriber) {
                    try {


                        File destinationFile = new File("/data/data/" + mContext.getPackageName() +"/" + myFormTable.formId+".html");
                        Log.d(TAG, "MYFILE :  " +destinationFile.toString());
                        BufferedSink bufferedSink = Okio.buffer(Okio.sink(destinationFile));
                        bufferedSink.writeAll(response.body().source());
                        bufferedSink.close();

                        subscriber.onNext(destinationFile);
                        subscriber.onCompleted();
                    } catch (IOException e) {
                        e.printStackTrace();
                        subscriber.onError(e);
                    }
                }
            });
        }

//
//
//        private void downloadZipFileRx(FormsTable formsTable) {
//
//            String BaseURL;
//            String urlLink;
//
//            if(formsTable.formType.equalsIgnoreCase("Upload"))
//            {
//                BaseURL ="https://abaqusforms.s3.amazonaws.com/";
//                urlLink = formsTable.formLinkURL;
//            }
//            else
//            {
//                BaseURL="https://www.mygeotracking.com/";
//                urlLink = formsTable.formURL+"?formId=" + formsTable.formId + "&Token=" + formsTable.formToken;
//            }
//            ApiEndPointsInterface downloadService = createService(ApiEndPointsInterface.class,BaseURL);
//
//
//            downloadService.downloadFileByUrlRxForUpload(urlLink)
//                    .flatMap(processResponse(formsTable))
//                    .subscribeOn(Schedulers.io())
//                    .observeOn(AndroidSchedulers.mainThread())
//                    .subscribe(handleResult());
//
//
//        }

       /* private Func1<Response<ResponseBody>, Observable<File>> processResponse(final FormsTable myFormTable) {
            return new Func1<Response<ResponseBody>, Observable<File>>() {
                @Override
                public Observable<File> call(Response<ResponseBody> responseBodyResponse) {
                    return saveToDiskRx(responseBodyResponse,myFormTable);
                }
            };
        }


        private Observer<File> handleResult() {
            return new Observer<File>() {

                @Override
                public void onCompleted() {
                    Log.d(TAG, "onCompleted");
                }

                @Override
                public void onError(Throwable e) {
                    e.printStackTrace();
                    Log.d(TAG, "Error " + e.getMessage());
                }

                @Override
                public void onNext(File file) {
                    Log.d(TAG, "File downloaded to " + file.getAbsolutePath());
                }
            };
        }

        public <T> T createService(Class<T> serviceClass, String baseUrl) {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .client(new OkHttpClient.Builder().build())
                    .addCallAdapterFactory(RxJavaCallAdapterFactory.create()).build();
            return retrofit.create(serviceClass);
        }*/

        @Override
        public void characters(char ch[], int start, int length) {
            if (in_GTSResponseTag && in_Comment ) {
                if (error_occured)
                    error_message = new String(ch,start,length);
            } else if (in_GTSResponseTag && TAG_FORMS) {
                stringBuilder.append(new String(ch, start, length));
            }
        }/* characters*/
    }
}

package net.abaqus.mygeotracking.deviceagent.notification;

/**
 * Created by root on 12/5/16.
 */

import android.annotation.TargetApi;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.provider.Settings;
import android.support.v4.app.NotificationCompat;
import android.text.TextUtils;
import android.util.Log;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.hos.HOSActivity;
import net.abaqus.mygeotracking.deviceagent.receivers.DozeModeNotificationActionReceiver;

import java.util.Calendar;

/**
 * Helper methods to create notifications.
 */
public class AgentNotificationBuilder {

    public static final String GENERAL_CHANNEL = "General";

    public static final int NOTIFICATION_ID_DOZEMODE = 107;
    public static final int NOTIFICATION_ID_NORMAL_MESSAGE = 106;
    public static final int NOTIFICATION_ID_UPDATE_VERSION = 105;
    public static final int NOTIFICATION_ID_LAUNCH_APP = 104;
    public static final int NOTIFICATION_ID_TIMECLOCK_ACTION = 103;

    public static final String NOTIFICATION_ACTION_UPDATE = "UPDATE";
    public static final String NOTIFICATION_ACTION_LAUNCH = "LAUNCH";
    public static final String NOTIFICATION_ACTION_WHITELIST = "WHITELIST";


    //TODO utilize the getters used in this class which makes the code more clean and visible. Also uses the created objects
    //https://github.com/googlecodelabs/notification-channels-java/blob/Initial-Code/Application/src/main/java/com/example/android/notificationchannels/NotificationHelper.java


    @TargetApi(26)
    private static void getNotificationChannel(NotificationManager notificationManager) {
        // Create the channel object with the unique ID FOLLOWERS_CHANNEL
        NotificationChannel followersChannel =
                new NotificationChannel(
                        GENERAL_CHANNEL,
                        "General",
                        NotificationManager.IMPORTANCE_DEFAULT);
        followersChannel.setDescription("Notifications about the configuration changes and important alerts.");
        // Configure the channel's initial settings
        followersChannel.setLightColor(Color.GREEN);
        followersChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 500, 200, 500});

        // Submit the notification channel object to the notification manager
        notificationManager.createNotificationChannel(followersChannel);
    }

    public static void showSimpleNotification(Context mContext, String title, String message, Intent intent, int mNotificationID) {
        // Check for empty push message
        if (TextUtils.isEmpty(message))
            return;
         //if (Utils.isAppIsInBackground(mContext)) {
            // notification icon
            int icon = R.drawable.notification_icon;
            int iconLarge = R.drawable.main_image_72;

            PendingIntent resultPendingIntent =
                    PendingIntent.getActivity(
                            mContext,
                            0,
                            intent,
                            PendingIntent.FLAG_CANCEL_CURRENT
                    );

            NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
                    mContext, GENERAL_CHANNEL);
            Notification notification = mBuilder.setSmallIcon(icon).setTicker(title).setWhen(Calendar.getInstance().getTimeInMillis())
                    .setAutoCancel(true)
                    .setContentTitle(title)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                    .setContentIntent(resultPendingIntent)
                    .setLargeIcon(BitmapFactory.decodeResource(mContext.getResources(), iconLarge))
                    .setSmallIcon(icon)
                    .setContentText(message)
                    .build();

            NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
            if(Build.VERSION.SDK_INT >= 26)
                getNotificationChannel(notificationManager);
            notificationManager.notify(mNotificationID, notification);
        //} else {
            /*intent.putExtra("title", title);
            intent.putExtra("message", message);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            mContext.startActivity(intent);*/
        //}

    }

    public static void showTimeClockActionNotification(Context mContext, String title, String message, int mNotificationID, String actionTitle, String hosID) {
        Log.d("TAG", "Notification title : "+ title +", Notification Message :" + message);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
                mContext, GENERAL_CHANNEL);

        int icon = R.drawable.notification_icon;
        int iconLarge = R.drawable.main_image_72;


        Intent iAction = new Intent(mContext.getApplicationContext(), NotificationActionService.class);
        iAction.putExtra("stage_id",hosID);
        iAction.putExtra("stage_desc",actionTitle);
        iAction.setAction(NotificationActionService.ACTION_TIMECLOCKING);
        PendingIntent piAction = PendingIntent.getService(mContext, 0, iAction, PendingIntent.FLAG_UPDATE_CURRENT);
        // This action will be embedded into the notification.
        mBuilder.addAction(R.drawable.ic_action_timeclocking, actionTitle, piAction);
        mBuilder.setStyle(new NotificationCompat.BigTextStyle().bigText(message));
        mBuilder.setContentTitle(title);
        mBuilder.setSmallIcon(icon);
        mBuilder.setLargeIcon(BitmapFactory.decodeResource(mContext.getResources(), iconLarge));
        mBuilder.setContentText(message);
        mBuilder.setTicker(title);
        mBuilder.setWhen(Calendar.getInstance().getTimeInMillis());
        Notification notification = mBuilder.build();
        NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT >= 26)
            getNotificationChannel(notificationManager);
        notificationManager.notify(mNotificationID, notification);
        Log.d("TAG", "Completed");

    }

    public static void showReLaunchActionNotification(Context mContext, String title, String message, int mNotificationID, String actionTitle) {
        Log.d("TAG", "Notification title : "+ title +", Notification Message :" + message);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
                mContext, GENERAL_CHANNEL);

        int icon = R.drawable.notification_icon;
        int iconLarge = R.drawable.main_image_72;

        Intent intent = new Intent(mContext, LaunchAppActivivty.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pIntent = PendingIntent.getActivity(mContext, 0, intent, 0);

        // This action will be embedded into the notification.
        mBuilder.addAction(R.drawable.ic_action_navigation_refresh, actionTitle, pIntent);
        mBuilder.setStyle(new NotificationCompat.BigTextStyle().bigText(message));
        mBuilder.setContentTitle(title);
        mBuilder.setSmallIcon(icon);
        mBuilder.setLargeIcon(BitmapFactory.decodeResource(mContext.getResources(), iconLarge));
        mBuilder.setContentText(message);
        mBuilder.setTicker(title);
        mBuilder.setWhen(Calendar.getInstance().getTimeInMillis());
        Notification notification = mBuilder.build();
        NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT >= 26)
            getNotificationChannel(notificationManager);
        notificationManager.notify(mNotificationID, notification);
        Log.d("TAG", "Completed");

    }

    public static void showAppUpdateActionNotification(Context mContext, String title, String message, int mNotificationID, String actionTitle) {
        Log.d("TAG", "Notification title : "+ title +", Notification Message :" + message);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
                mContext, GENERAL_CHANNEL);

        int icon = R.drawable.notification_icon;
        int iconLarge = R.drawable.main_image_72;


        mBuilder.setLargeIcon(BitmapFactory.decodeResource(mContext.getResources(), iconLarge));


        Intent intentLaunch = new Intent(mContext, LaunchStoreActivity.class);
        intentLaunch.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pIntent = PendingIntent.getActivity(mContext, 0, intentLaunch, 0);

        // This action will be embedded into the notification.
        mBuilder.addAction(R.drawable.ic_update_app, actionTitle, pIntent);
        mBuilder.setStyle(new NotificationCompat.BigTextStyle().bigText(message));
        mBuilder.setContentTitle(title);
        mBuilder.setSmallIcon(icon);
        mBuilder.setSmallIcon(icon);
        mBuilder.setLargeIcon(BitmapFactory.decodeResource(mContext.getResources(), iconLarge));
        mBuilder.setContentText(message);
        mBuilder.setTicker(title);
        mBuilder.setWhen(Calendar.getInstance().getTimeInMillis());
        Notification notification = mBuilder.build();
        NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT >= 26)
            getNotificationChannel(notificationManager);
        notificationManager.notify(mNotificationID, notification);
        Log.d("TAG", "Completed");

    }


    public static void showPowerSaveModeNotification(Context mContext, String title, String message, int mNotificationID, String actionTitle) {
        Log.d("TAG", "Notification title : " + title + ", Notification Message :" + message);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
                mContext, GENERAL_CHANNEL);
        int icon = R.drawable.notification_icon;
        int iconLarge = R.drawable.main_image_72;

        mBuilder.setLargeIcon(BitmapFactory.decodeResource(mContext.getResources(), iconLarge));

        //Intent intent = new Intent(mContext, DozeModeNotificationActionReceiver.class);

        //if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            //intent.setAction(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);

            Intent move = new Intent();
            move.setAction(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);


            move.putExtra("notificationId", mNotificationID);
            //intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            //PendingIntent pIntent = PendingIntent.getBroadcast(mContext, 0, intent, 0);
            PendingIntent pIntent = PendingIntent.getActivity(mContext, 0, move, 0);

            // This action will be embedded into the notification.
            //mBuilder.addAction(R.drawable.ic_action_accept, actionTitle, pIntent);
            mBuilder.setStyle(new NotificationCompat.BigTextStyle().bigText(message));
            mBuilder.setContentTitle(title);
            mBuilder.setContentIntent(pIntent);
            mBuilder.setSmallIcon(icon);
            mBuilder.setAutoCancel(true);
            mBuilder.setLargeIcon(BitmapFactory.decodeResource(mContext.getResources(), iconLarge));
            mBuilder.setContentText(message);
            mBuilder.setTicker(title);
            mBuilder.setWhen(Calendar.getInstance().getTimeInMillis());
            Notification notification = mBuilder.build();
            NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26)
                getNotificationChannel(notificationManager);
            notificationManager.notify(mNotificationID, notification);
            Log.d("TAG", "Completed");

        //}
    }




    public static void showActionNotification(Context mContext, String title, String message, int mNotificationID, String[] actionTitles, String[] actionIDs, int[] actionIcons, Intent intent) {
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
                mContext);
        NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);

        PendingIntent actionIntent;
        NotificationCompat.Action action;

        int icon = R.drawable.notification_icon;
        int iconLarge = R.drawable.main_image_72;



        for (int i = 0; i < actionTitles.length; i++) {
            String tempTitle = actionTitles[i];
            String tempActionID = actionIDs[i];
            int tempIcon = actionIcons[i];
            actionIntent = PendingIntent.getService(mContext, 0,
                    intent.setAction(tempActionID), PendingIntent.FLAG_CANCEL_CURRENT);
            action = new NotificationCompat.Action(tempIcon,
                    tempTitle, actionIntent);
            mBuilder.addAction(action);
        }

        mBuilder.setStyle(new NotificationCompat.BigTextStyle().bigText(message));
        mBuilder.setContentTitle(title);
        mBuilder.setSmallIcon(icon);
        mBuilder.setLargeIcon(BitmapFactory.decodeResource(mContext.getResources(), iconLarge));
        mBuilder.setContentText(message);
        Notification notification = mBuilder.build();
        notificationManager.notify(mNotificationID, notification);

    }

    public static void remindToTImeClock(Context mContext, String title, String message, Intent intent, int mNotificationID) {
        // Check for empty push message
        if (TextUtils.isEmpty(message))
            return;

        //if (Utils.isAppIsInBackground(mContext)) {
            // notification icon
            int icon = R.drawable.notification_icon;
            int iconLarge = R.drawable.main_image_72;

            PendingIntent resultPendingIntent =
                    PendingIntent.getActivity(
                            mContext,
                            0,
                            intent,
                            PendingIntent.FLAG_CANCEL_CURRENT
                    );
        NotificationManager notificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);

            NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
                    mContext);
            mBuilder.setSmallIcon(icon);
            mBuilder.setLargeIcon(BitmapFactory.decodeResource(mContext.getResources(), iconLarge));


            mBuilder.setAutoCancel(true);
            mBuilder.setContentTitle("setAutoCancel true");
            Notification notification = mBuilder.build();
            mNotificationID++;
            notificationManager.notify(mNotificationID, notification);

            mBuilder.setAutoCancel(false);
            mBuilder.setContentTitle("setAutoCancel false");
            Notification notificationa = mBuilder.build();
            mNotificationID++;
            notificationManager.notify(mNotificationID, notificationa);

            mBuilder.setColor(mContext.getResources().getColor(R.color.blue_bg));
            mBuilder.setContentTitle("setColor blue bg");
            Notification notificationb = mBuilder.build();
            mNotificationID++;
            notificationManager.notify(mNotificationID, notificationb);

        /*RemoteViews notificationView = new RemoteViews(
                mContext.getPackageName(),
                R.layout.please_optin_message);
            mBuilder.setContent(notificationView);
            mBuilder.setContentTitle("setContent with optin message view");
            notification = mBuilder.build();
            mNotificationID++;
            notificationManager.notify(mNotificationID, notification);*/


            mBuilder.setContentInfo("This is character sequence and content info");
            mBuilder.setContentTitle("setContentInfo");
            Notification notificationc = mBuilder.build();
            mNotificationID++;
            notificationManager.notify(mNotificationID, notificationc);

        mBuilder.setContentIntent(resultPendingIntent);
        mBuilder.setContentTitle("setContentIntent with resultPendingIntent");
        Notification notificationd = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, notificationd);


        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setContentText");
        Notification notificatione = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, notificatione);

        mBuilder.setGroup("group");
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("Group message one");
        Notification notificationf = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, notificationf);


        mBuilder.setGroup("group");
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("Group message two");
        Notification notificationg = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, notificationg);


        mBuilder.setGroup("group");
        mBuilder.setContentText("Content text is here");
        mBuilder.setGroupSummary(true);
        mBuilder.setContentTitle("Group message three (Summary)");
        Notification notificationh = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, notificationh);


        mBuilder.setLights(Color.BLUE, 500, 500);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setLights(Color.BLUE, 500, 500)");
        Notification notificationi = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, notificationi);


        mBuilder.setLocalOnly(true);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setLocalOnly(true)");
        Notification jnotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, jnotification);


        mBuilder.setNumber(500);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setNumber(mNotificationID)");
        Notification knotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, knotification);


        mBuilder.setOngoing(true);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setOngoing(true)");
        Notification lnotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, lnotification);

        mBuilder.setOngoing(false);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setOngoing(false)");
        Notification mnotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, mnotification);


        mBuilder.setOnlyAlertOnce(true);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setOnlyAlertOnce(true)");
        Notification nnotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, nnotification);


        mBuilder.setPriority(Notification.PRIORITY_MAX);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setPriority(Notification.PRIORITY_MAX)");
        Notification onotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, onotification);


        mBuilder.setProgress(100, 77, true);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setProgress(100, 77, true)");
        Notification pnotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, pnotification);

        mBuilder.setWhen(Calendar.getInstance().getTimeInMillis());
        mBuilder.setShowWhen(true);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setShowWhen(true)");
        Notification qnotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, qnotification);



        mBuilder.setVisibility(Notification.VISIBILITY_PRIVATE);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setVisibility(Notification.VISIBILITY_PRIVATE)");
        Notification rnotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, rnotification);


        mBuilder.setVisibility(Notification.VISIBILITY_PUBLIC);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setVisibility(Notification.VISIBILITY__PUBLIC)");
        Notification snotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, snotification);


        mBuilder.setVisibility(Notification.VISIBILITY_SECRET);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setVisibility(Notification.VISIBILITY_SECRET)");
        Notification unotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, unotification);


        mBuilder.setWhen(Calendar.getInstance().getTimeInMillis());
        mBuilder.setUsesChronometer(true);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setUsesChronometer(true)");
        Notification vnotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, vnotification);

        mBuilder.setWhen(Calendar.getInstance().getTimeInMillis());
        mBuilder.setUsesChronometer(false);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setUsesChronometer(false)");
        Notification wnotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, wnotification);


        mBuilder.setTicker("SetTicker");
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setUsesChronometer(true)");
        Notification xnotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, xnotification);


        mBuilder.setSubText("Setting subtext");
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setSubText(\"Setting subtext\")");
        Notification ynotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, ynotification);

        NotificationCompat.InboxStyle inboxStyle = new NotificationCompat.InboxStyle().addLine("ertertrtrergfdgertgergertggfr");
        inboxStyle.setSummaryText("Summary text");
        inboxStyle.setBigContentTitle("Content Title");
        mBuilder.setStyle(inboxStyle);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setStyle(inboxStyle)setStyle(inboxStyle)setStyle(inboxStyle)setStyle(inboxStyle)");
        Notification znotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, znotification);

        NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle().bigText("Oh Here is tjhe big text");
        bigTextStyle.setBigContentTitle("Big Content Title");
        bigTextStyle.setSummaryText("Summary Text");
        mBuilder.setStyle(bigTextStyle);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setStyle(bigText)setStyle(inboxStyle)setStyle(inboxStyle)setStyle(inboxStyle)");
        Notification anotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, anotification);

        Bitmap bitmap_image = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.main_image);
        NotificationCompat.BigPictureStyle bigPictureStyle = new NotificationCompat.BigPictureStyle().bigPicture(bitmap_image);
        bigPictureStyle.setBigContentTitle("Content title");
        bigPictureStyle.setSummaryText("Summary text");

        mBuilder.setStyle(bigPictureStyle);
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setStyle(image)setStyle(inboxStyle)setStyle(inboxStyle)setStyle(inboxStyle)");
        Notification bnotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, bnotification);


        mBuilder.setSortKey("sortkey");
        mBuilder.setContentText("Content text is here");
        mBuilder.setContentTitle("setSortKey(\"sortkey\")");
        Notification cnotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, cnotification);

        Intent checkInOperation =
                new Intent(mContext, HOSActivity.class);//.setData(dataItemUri);
        PendingIntent checkInIntent = PendingIntent.getService(mContext, 0,
                checkInOperation.setAction("chekcin"), PendingIntent.FLAG_CANCEL_CURRENT);
        PendingIntent deleteDataItemIntent = PendingIntent.getService(mContext, 1,
                checkInOperation.setAction("delete"),
                PendingIntent.FLAG_CANCEL_CURRENT);
        // This action will be embedded into the notification.
        NotificationCompat.Action checkInAction = new NotificationCompat.Action(R.drawable.ic_action_accept,
                mContext.getText(R.string.action_settings), checkInIntent);
        NotificationCompat.Action deleteAction = new NotificationCompat.Action(R.drawable.ic_action_timeclocking,
                mContext.getText(R.string.button_register), checkInIntent);
        mBuilder.addAction(checkInAction);
        mBuilder.addAction(deleteAction);
        mBuilder.setStyle(bigTextStyle);
        mBuilder.setContentTitle("Title of the message");
        Notification dnotification = mBuilder.build();
        mNotificationID++;
        notificationManager.notify(mNotificationID, dnotification);





        //} else {
            /*intent.putExtra("title", title);
            intent.putExtra("message", message);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            mContext.startActivity(intent);*/
       // }

    }






    /**
     * Dismiss all notifications.
     */
    public static void DismissNotifications(Context c) {
        NotificationManager mNotificationManager = (NotificationManager) c
                .getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.cancelAll();
    }

    /**
     * Dismiss notification with notification ID.
     * @param c Context
     * @param notificationID  notificationId which is used while registering and displaying
     */
    public static void dismissNotification(Context c, int notificationID) {
        NotificationManager mNotificationManager = (NotificationManager) c
                .getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.cancel(notificationID);
    }

    /**
     * Schedule a basic notification at an approximate time.
     */
    public static void ScheduleAgentNotification(Context c, long timestamp, int notificationType) {

        // Only schedule a notification if the time is in the future
        if (timestamp < System.currentTimeMillis()) {
            return;
        }

        AlarmManager alarm = (AlarmManager) c
                .getSystemService(Context.ALARM_SERVICE);

/*
        Intent i = new Intent(c, NotificationBroadcastReceiver.class);
        i.putExtra(NotificationConstants.KEY_NOTIFICATION_ID,
                NotificationConstants.NOTIFICATION_ID);

        // Type is "takeoff", "location", etc.
        i.putExtra(NotificationConstants.KEY_NOTIFICATION_TYPE, notificationType);

*/
        // Generate unique pending intent
       // PendingIntent pi = PendingIntent.getBroadcast(c, notificationType, i, 0);

        // Deliver next time the device is woken up
        //alarm.set(AlarmManager.RTC, timestamp, pi);

    }

}

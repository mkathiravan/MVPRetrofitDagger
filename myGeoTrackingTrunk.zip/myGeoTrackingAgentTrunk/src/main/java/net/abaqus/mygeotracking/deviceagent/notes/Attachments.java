package net.abaqus.mygeotracking.deviceagent.notes;

/**
 * Created by bm on 15/10/15.
 */
public class Attachments {

//    public static int MAX_ATTACHMENT_SIZE = 5242880;



    public enum Attachment_Type {
        IMAGE,
        SIGNATURE,
        TASK,
        CUSTOMER,
        SCAN,
        FORM
    }

    public Attachments() {
        this.attachment_type = null;
        this.text_value = "";
        this.imageAttachment = null;
        this.formAttachment = null;
        this.attachmentID = -1;
    }

    public Attachments(Attachment_Type attachment_type, String text_value, ImageAttachment imageAttachment, FormAttachment formAttachment, int attachmentID) {
        this.attachment_type = attachment_type;
        this.text_value = text_value;
        this.imageAttachment = imageAttachment;
        this.formAttachment = formAttachment;
        this.attachmentID = attachmentID;
    }

    private Attachment_Type attachment_type;
    private int attachmentID;
    private String text_value;

    private ImageAttachment imageAttachment;
    private FormAttachment formAttachment;

    public ImageAttachment getImageAttachment() {
        return imageAttachment;
    }

    public void setImageAttachment(ImageAttachment imageAttachment) {
        this.imageAttachment = imageAttachment;
    }

    public String getText_value() {
        return text_value;
    }

    public void setText_value(String text_value) {
        this.text_value = text_value;
    }

    public Attachment_Type getAttachment_type() {
        return attachment_type;
    }

    public void setAttachment_type(Attachment_Type attachment_type) {
        this.attachment_type = attachment_type;
    }

    public FormAttachment getFormAttachment() {
        return formAttachment;
    }

    public void setFormAttachment(FormAttachment formAttachment) {
        this.formAttachment = formAttachment;
    }

    public int getAttachmentID() {
        return attachmentID;
    }

    public void setAttachmentID(int attachmentID) {
        this.attachmentID = attachmentID;
    }
}

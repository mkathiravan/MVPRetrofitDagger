package net.abaqus.mygeotracking.deviceagent.timeclocking;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import net.abaqus.mygeotracking.deviceagent.R;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.HOSCustomerANDJobTable;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryContentProvider;
import net.abaqus.mygeotracking.deviceagent.data.NotesEntryTable;
import net.abaqus.mygeotracking.deviceagent.notes.Attachments;
import net.abaqus.mygeotracking.deviceagent.notes.Notes;
import net.abaqus.mygeotracking.deviceagent.notes.UploadNotesTask;
import net.abaqus.mygeotracking.deviceagent.utils.CurrentDateAndTime;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;
import net.abaqus.mygeotracking.deviceagent.utils.NetworkConnectionInfo;
import net.abaqus.mygeotracking.deviceagent.utils.NotesEntryConstruction;
import net.abaqus.mygeotracking.deviceagent.utils.myGeoTrackingDevieAgentApplication;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by root on 12/8/16.
 */
public class JobOnlyTimeClockingActivity extends AppCompatActivity {

    private static final String TAG = JobOnlyTimeClockingActivity.class.getSimpleName();
    private static final String LOG_TAG = "myGeoTracking Agent";
    private Spinner jobSitesSpinner, tasksSpinner;
    private Button submitButton;
    private List<String> jobSitesList, tasksList;
    ArrayAdapter<String> jobSitesAdapter, tasksAdapter;
    String selectedJobSite = "", selectedTask = "";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activty_job_and_task_only_hos);

        jobSitesSpinner = (Spinner) findViewById(R.id.spinner_jobsites);
        jobSitesSpinner.setOnItemSelectedListener(new JobsSpinnerSelectedListener());
        tasksSpinner = (Spinner) findViewById(R.id.spinner_tasks);
        tasksSpinner.setOnItemSelectedListener(new TasksSpinnerSelectedListener());
        submitButton = (Button) findViewById(R.id.btn_submit_hos_wo_stages);
        submitButton.setOnClickListener(new SubmitButtonClickLstener());
        jobSitesList = new ArrayList<String>();
        jobSitesList.add("--Select--");
        tasksList = new ArrayList<String>();
        tasksList.add("--Select--");
        loadJobSites();
        loadTasks();
    }


    public void loadJobSites() {
        String[] projection_cus = {HOSCustomerANDJobTable.COLUMN_ID,
                HOSCustomerANDJobTable.HOS_CJ_NAME,
                HOSCustomerANDJobTable.HOS_CJ_SITE_ID,
                HOSCustomerANDJobTable.HOS_CJ_WHICH};

        Cursor mCursor = this.getContentResolver().query(Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI.toString()), projection_cus, HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ?", new String[]{"Customer"},
                HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");

        for (int i = 0; i < mCursor.getCount(); i++) {
            while (mCursor.moveToNext() == true) {
                DebugLog.debug(TAG, "Cusname : " + mCursor.getString(mCursor.getColumnIndex(HOSCustomerANDJobTable.HOS_CJ_NAME)));
                jobSitesList.add(mCursor.getString(mCursor.getColumnIndex(HOSCustomerANDJobTable.HOS_CJ_NAME)));
                mCursor.moveToNext();
            }
        }


        // Create an ArrayAdapter using the string array and a default spinner layout
        jobSitesAdapter = new ArrayAdapter<String>(getApplicationContext(),
                R.layout.spinner_item, jobSitesList);
        // Specify the layout to use when the list of choices appears
        jobSitesAdapter.setDropDownViewResource(R.layout.spinner_item);
        // Apply the adapter to the spinner
        jobSitesSpinner.setAdapter(jobSitesAdapter);
        mCursor.close();

    }

    public void loadTasks() {
        String[] projection = {HOSCustomerANDJobTable.COLUMN_ID,
                HOSCustomerANDJobTable.HOS_CJ_NAME,
                HOSCustomerANDJobTable.HOS_CJ_WHICH};
        Cursor mCursor = this.getContentResolver().query(Uri.parse(HOSCustomerANDJobContentProvider.CONTENT_URI.toString()), projection, HOSCustomerANDJobTable.HOS_CJ_WHICH + " LIKE ?", new String[]{"Job"},
                HOSCustomerANDJobTable.HOS_CJ_NAME + " COLLATE NOCASE ASC");
        for (int i = 0; i < mCursor.getCount(); i++) {
            while (mCursor.moveToNext() == true) {
                DebugLog.debug(TAG, "Cusname : " + mCursor.getString(mCursor.getColumnIndex(HOSCustomerANDJobTable.HOS_CJ_NAME)));
                tasksList.add(mCursor.getString(mCursor.getColumnIndex(HOSCustomerANDJobTable.HOS_CJ_NAME)));
                mCursor.moveToNext();
            }
        }

        tasksAdapter = new ArrayAdapter<String>(getApplicationContext(),
                R.layout.spinner_item, tasksList);
        tasksAdapter.setDropDownViewResource(R.layout.spinner_item);
        tasksSpinner.setAdapter(tasksAdapter);
        mCursor.close();

    }


    class SubmitButtonClickLstener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            if (!selectedJobSite.equals("--Select--") || !selectedTask.equals("--Select--")) {
                jobSitesSpinner.setSelection(0, true);
                tasksSpinner.setSelection(0, true);
                Snackbar.make(submitButton, "Submitting ...", Snackbar.LENGTH_SHORT).show();
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    public void run() {
                        processMessage();
                    }
                }, 2000);
            } else {
                Snackbar.make(submitButton, "Please select the input.", Snackbar.LENGTH_SHORT).show();
            }
        }
    }


    class JobsSpinnerSelectedListener implements AdapterView.OnItemSelectedListener {

        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            selectedJobSite = adapterView.getItemAtPosition(i).toString();
            //loadTasks();
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {}
    }

    class TasksSpinnerSelectedListener implements AdapterView.OnItemSelectedListener {

        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long l) {
            selectedTask = adapterView.getItemAtPosition(pos).toString();
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {

        }
    }


    protected void processMessage() {
        Notes notes = new Notes();

        notes.setTask_description(selectedTask);
        notes.setjobsite_description(selectedJobSite);
        pushNotesEntrytoDB(notes);

        if (NetworkConnectionInfo.isOnline(this)) {
            new UploadNotesTask(this).execute();

            AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AppCompatAlertDialogStyle);
            builder.setTitle("myGeoTracking Agent");
            builder.setMessage("Message sent!");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    finish();
                }
            });
            builder.show();
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AppCompatAlertDialogStyle);
            builder.setTitle("myGeoTracking Agent");
            builder.setMessage("Internet connection problem! Your message will be sent later.");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    finish();
                }
            });
            builder.show();
        }
    }

    private void pushNotesEntrytoDB(Notes notes) {
        // save data into database
        ContentValues initialValues = new ContentValues();
        initialValues.put(NotesEntryTable.NOTES_ENTRY_NO_OF_TRIES,
                0);
        initialValues.put(NotesEntryTable.NOTES_ENTRY_XML,
                NotesEntryConstruction.constructNotesEntryBlock(this, notes, new ArrayList<Attachments>()));
        getContentResolver().insert(NotesEntryContentProvider.CONTENT_URI,
                initialValues);
    }

}
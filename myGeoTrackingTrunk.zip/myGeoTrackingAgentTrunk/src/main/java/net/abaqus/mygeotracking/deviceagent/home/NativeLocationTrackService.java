package net.abaqus.mygeotracking.deviceagent.home;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.util.Log;

import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;
import net.abaqus.mygeotracking.deviceagent.utils.DebugLog;

public class NativeLocationTrackService extends JobService {

    private static final String TAG = NativeLocationTrackService.class.getSimpleName();

    @Override
    public boolean onStartJob(JobParameters job) {

        DebugLog.debug("Native Tracking job!", "Should be recurring - Native Track Service");


        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                call_location_service();
            }
        });
        return false;
    }

    private void call_location_service()
    {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            Intent intent = new Intent(this, LocationUpdatesService.class);
            startForegroundService(intent);
        }

    }


    @Override
    public boolean onStopJob(JobParameters job) {
        Log.d(TAG,"ONSTOOPPED ");
        return false;

    }
}

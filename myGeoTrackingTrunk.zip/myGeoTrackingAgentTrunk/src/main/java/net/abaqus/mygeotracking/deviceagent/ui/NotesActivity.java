package net.abaqus.mygeotracking.deviceagent.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import net.abaqus.mygeotracking.deviceagent.R;

/**
 * Created by bm on 12/6/15.
 */
public class NotesActivity extends AppCompatActivity{

    public static final String TO_DEVICE_STRING_EXTRA = "to_device_string_extra";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.notes_activity_layout);

    }
}
